'use strict';
// 此目录构建时复制到微信开放数据域，不进入 Cocos 主域依赖图。
const { readScore, rankFriends } = require('./ranking');
const canvas = wx.getSharedCanvas();
const ctx = canvas.getContext('2d');
const WIDTH = 422, HEIGHT = 320, PAGE_SIZE = 3;
const ink = '#6a4e3e', muted = '#8e765f';
let visible = false, key = '', page = 0, generation = 0;
let ranking = { entries: [], self: null }, state = 'loading';
const avatars = new Map();

function text(value, x, y, size, color = ink, align = 'left') {
    ctx.font = `${size >= 26 ? 'bold ' : ''}${size}px sans-serif`;
    ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'middle';
    ctx.fillText(String(value), x, y);
}

function ellipsis(value, maxWidth) {
    let chars = Array.from(value || '微信好友');
    if (ctx.measureText(chars.join('')).width <= maxWidth) return chars.join('');
    while (chars.length && ctx.measureText(chars.join('') + '…').width > maxWidth) chars.pop();
    return chars.join('') + '…';
}

function avatar(url, x, y) {
    const size = 58;
    ctx.save(); ctx.beginPath(); ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = '#ede7ce'; ctx.fillRect(x, y, size, size);
    const cached = avatars.get(url);
    if (cached && cached.ready) {
        // 微信原始头像在开放域直接绘制，按中心裁切，不拉伸非正方形头像。
        const w = cached.image.width, h = cached.image.height, edge = Math.min(w, h);
        ctx.drawImage(cached.image, (w - edge) / 2, (h - edge) / 2, edge, edge, x, y, size, size);
    }
    else {
        // 轻盈的小芽作为缺省头像，无额外远程资源。
        ctx.fillStyle = '#a0b98a'; ctx.beginPath(); ctx.ellipse(x + 23, y + 24, 11, 6, 0.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(x + 36, y + 19, 10, 6, -0.5, 0, Math.PI * 2); ctx.fill();
        if (url && !cached) {
            const image = wx.createImage();
            const record = { image, ready: false }; avatars.set(url, record);
            image.onload = () => { record.ready = true; if (visible) render(); };
            image.onerror = () => { /* 保留小芽占位。 */ };
            image.src = url;
            // 只缓存近几页，避免浏览长好友榜一直持有头像。
            if (avatars.size > 24) avatars.delete(avatars.keys().next().value);
        }
    }
    ctx.restore();
}

function row(entry, y, own) {
    if (own || entry.isSelf) {
        ctx.fillStyle = '#e6efd9'; ctx.fillRect(0, y, WIDTH, 66);
    }
    if (!own) text(entry.rank, 16, y + 33, 26, entry.rank <= 3 ? '#aa7046' : muted, 'center');
    avatar(entry.avatarUrl, own ? 8 : 39, y + 4);
    ctx.font = '26px sans-serif';
    const name = own ? `我 · 第${entry.rank}名` : `${entry.isSelf ? '我 · ' : ''}${entry.nickname}`;
    text(ellipsis(name, own ? 208 : 172), own ? 78 : 109, y + 33, 26);
    const score = entry.score.toLocaleString('en-US');
    ctx.font = 'bold 28px sans-serif';
    const scoreSize = Math.min(28, Math.floor(28 * 112 / Math.max(1, ctx.measureText(score).width)));
    text(score, WIDTH - 10, y + 33, scoreSize, ink, 'right');
    ctx.strokeStyle = '#e7dac1'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(8, y + 68); ctx.lineTo(WIDTH - 8, y + 68); ctx.stroke();
}

function render() {
    if (!visible) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save(); ctx.scale(canvas.width / WIDTH, canvas.height / HEIGHT);
    if (state === 'loading') text('正在寻找好友的好成绩…', WIDTH / 2, 140, 24, muted, 'center');
    else if (state === 'error') {
        text('好友排名暂时没加载出来', WIDTH / 2, 126, 24, muted, 'center');
        text('点下方「刷新」再试一次', WIDTH / 2, 162, 24, muted, 'center');
    } else {
        const count = ranking.entries.length;
        if (count === 0) {
            text('好友们的好成绩，等你来开启', WIDTH / 2, 115, 24, muted, 'center');
            text('邀请好友一起消除吧', WIDTH / 2, 152, 24, muted, 'center');
        } else {
            text(`第 ${page + 1} / ${Math.ceil(count / PAGE_SIZE)} 页`, 4, 12, 20, muted);
            text('最高分', WIDTH - 10, 12, 20, muted, 'right');
            ranking.entries.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE).forEach((entry, index) => row(entry, 30 + index * 72, false));
            if (!ranking.entries.some(entry => !entry.isSelf))
                text('邀请好友来，看看谁分数更高', WIDTH / 2, 170, 24, muted, 'center');
        }
        if (ranking.self) row(ranking.self, 250, true);
        else text('我的成绩同步后显示排名', WIDTH / 2, 283, 24, muted, 'center');
    }
    ctx.restore();
}

function api(method, options) {
    return new Promise((resolve, reject) => {
        try { wx[method](Object.assign({}, options, { success: resolve, fail: reject })); }
        catch (error) { reject(error); }
    });
}

function load() {
    const request = ++generation;
    state = 'loading'; render();
    // 三项均在开放数据域执行；任何一项失败都不伪装成空榜或未上榜。
    Promise.all([
        api('getFriendCloudStorage', { keyList: [key] }),
        api('getUserInfo', { openIdList: ['selfOpenId'], lang: 'zh_CN' }),
        api('getUserCloudStorage', { keyList: [key] }),
    ]).then(([friends, self, storage]) => {
        if (!visible || request !== generation) return;
        ranking = rankFriends(friends.data, key, self.data && self.data[0], readScore(storage.KVDataList, key));
        page = Math.min(page, Math.max(0, Math.ceil(ranking.entries.length / PAGE_SIZE) - 1));
        state = 'ready'; render();
    }).catch(() => {
        if (!visible || request !== generation) return;
        state = 'error'; render();
    });
}

wx.onMessage(message => {
    if (!message || message.fromEngine) return;
    if (message.type === 'friends:hide') {
        visible = false; generation++; avatars.clear();
        ranking = { entries: [], self: null };
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    } else if (message.type === 'friends:show') {
        visible = true; key = message.key; page = 0;
        canvas.width = WIDTH; canvas.height = HEIGHT;
        load();
    } else if (message.type === 'friends:page' && visible) {
        if (message.action === 'refresh') { load(); return; }
        if (state !== 'ready') return;
        const last = Math.max(0, Math.ceil(ranking.entries.length / PAGE_SIZE) - 1);
        page = Math.max(0, Math.min(last, page + (message.action === 'next' ? 1 : -1)));
        render();
    }
});
