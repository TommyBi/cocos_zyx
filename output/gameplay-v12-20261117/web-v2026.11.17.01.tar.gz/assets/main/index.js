window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
        o = b;
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  AssetLoader: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "79bceibCe9GL5XDF/KbhGtH", "AssetLoader");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.loadRemoteTexture = exports.loadMusicClip = exports.getAudioClip = exports.getSkeletonData = exports.getTTFFont = exports.getBitmapFont = exports.getSpriteFrame = exports.isFeatureReady = exports.prepareFeature = exports.prepareMoodBeanArt = exports.isTypographyReady = exports.prepareTypography = exports.ASSET_PATHS = void 0;
    exports.ASSET_PATHS = {
      game: {
        background: "images/formal/game_room_bg_v3",
        hammer: "images/formal/relief_hammer_v2",
        magicWand: "images/formal/magic_wand_v1",
        hudMascot: "images/formal/bean_hud_mascot_v1",
        hudGlyphs: "images/formal/hud_glyphs_v1",
        hudFont: "images/formal/hud_round_v1",
        uiBitmapFont: "fonts/zyx_happy_round_ui_bitmap_v1",
        rewardSpine: "spine/get_1",
        breakSound: "sound/sound_break",
        moveSound: "sound/sound_move",
        hammerSound: "sound/sound_tool1",
        bombSound: "sound/sound_bomb_v1",
        magicWandSound: "sound/sound_tool2"
      },
      effects: {
        reviveCard: "images/formal/revive_card_v2",
        comboWow: "images/formal/combo_wow_v1",
        comboGood: "images/formal/combo_good_v1",
        comboGreat: "images/formal/combo_great_v1",
        comboPerfect: "images/formal/combo_perfect_v1",
        scoreDigits: "images/formal/score_digits_green_v1"
      },
      home: {
        background: "images/home_studio_bg_v3",
        title: "images/home_title_logo_v1",
        rankEntry: "images/rank_entry_trophy_v2",
        guideHand: "images/start_guide_hand_v3",
        startWordmark: "images/start_wordmark_v2",
        leaderboardTitle: "images/leaderboard/title_v2",
        leaderboardGold: "images/leaderboard/podium_gold_v2",
        leaderboardSilver: "images/leaderboard/podium_silver_v2",
        leaderboardBronze: "images/leaderboard/podium_bronze_v2",
        leaderboardBodyFont: "fonts/zyx_happy_round_body_v1",
        leaderboardDisplayFont: "fonts/zyx_happy_round_display_v1"
      },
      music: {
        main: "music_main",
        game: "music_game"
      }
    };
    var bundlePromises = {};
    var featurePromises = {};
    var readyFeatures = {};
    var typographyPromise = null;
    var typographyReady = false;
    function prepareTypography() {
      if (typographyPromise) return typographyPromise;
      typographyPromise = loadSpecs("game", [ {
        path: exports.ASSET_PATHS.game.uiBitmapFont,
        type: cc.BitmapFont
      } ]).then(function() {
        typographyReady = true;
      }).catch(function(error) {
        typographyPromise = null;
        throw error;
      });
      return typographyPromise;
    }
    exports.prepareTypography = prepareTypography;
    function isTypographyReady() {
      return typographyReady;
    }
    exports.isTypographyReady = isTypographyReady;
    function loadBundle(name) {
      var existing = cc.assetManager.getBundle ? cc.assetManager.getBundle(name) : null;
      if (existing) return Promise.resolve(existing);
      if (bundlePromises[name]) return bundlePromises[name];
      bundlePromises[name] = new Promise(function(resolve, reject) {
        cc.assetManager.loadBundle(name, function(error, bundle) {
          if (error || !bundle) {
            delete bundlePromises[name];
            reject(new Error("[\u8d44\u6e90] Bundle " + name + " \u52a0\u8f7d\u5931\u8d25\uff1a" + (error ? error.message : "unknown error")));
            return;
          }
          resolve(bundle);
        });
      });
      return bundlePromises[name];
    }
    function waitForNativeTexture(bundleName, path, type, asset) {
      if (type !== cc.SpriteFrame && type !== cc.BitmapFont) return Promise.resolve(asset);
      var frame = type === cc.BitmapFont ? asset.spriteFrame : asset;
      if (frame.textureLoaded()) return Promise.resolve(asset);
      var texture = frame.getTexture();
      if (!texture) return Promise.reject(new Error("[\u8d44\u6e90] " + bundleName + "/" + path + " \u7f3a\u5c11\u7eb9\u7406\u5f15\u7528"));
      return new Promise(function(resolve, reject) {
        var onLoaded = function() {
          return resolve(asset);
        };
        frame.once("load", onLoaded);
        cc.assetManager.postLoadNative(texture, function(error) {
          if (!error) return;
          frame.off("load", onLoaded);
          reject(new Error("[\u8d44\u6e90] " + bundleName + "/" + path + " \u539f\u751f\u7eb9\u7406\u52a0\u8f7d\u5931\u8d25\uff1a" + error.message));
        });
      });
    }
    function loadAsset(bundleName, path, type) {
      return loadBundle(bundleName).then(function(bundle) {
        return new Promise(function(resolve, reject) {
          var cached = bundle.get(path, type);
          if (cached) {
            resolve(cached);
            return;
          }
          bundle.load(path, type, function(error, asset) {
            if (error || !asset) {
              reject(new Error("[\u8d44\u6e90] " + bundleName + "/" + path + " \u52a0\u8f7d\u5931\u8d25\uff1a" + (error ? error.message : "asset is empty")));
              return;
            }
            resolve(asset);
          });
        });
      }).then(function(asset) {
        return waitForNativeTexture(bundleName, path, type, asset);
      });
    }
    function loadSpecs(bundleName, specs) {
      return Promise.all(specs.map(function(spec) {
        return loadAsset(bundleName, spec.path, spec.type);
      })).then(function() {
        return;
      });
    }
    function featureSpecs(feature) {
      if ("leaderboard" === feature) return [ exports.ASSET_PATHS.home.leaderboardTitle, exports.ASSET_PATHS.home.leaderboardGold, exports.ASSET_PATHS.home.leaderboardSilver, exports.ASSET_PATHS.home.leaderboardBronze ].map(function(path) {
        return {
          path: path,
          type: cc.SpriteFrame
        };
      });
      if ("game" === feature) return [ {
        path: exports.ASSET_PATHS.game.background,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.game.hammer,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.game.magicWand,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.game.hudMascot,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.game.hudGlyphs,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.game.hudFont,
        type: cc.BitmapFont
      }, {
        path: exports.ASSET_PATHS.game.uiBitmapFont,
        type: cc.BitmapFont
      }, {
        path: exports.ASSET_PATHS.game.rewardSpine,
        type: sp.SkeletonData
      }, {
        path: exports.ASSET_PATHS.game.breakSound,
        type: cc.AudioClip
      }, {
        path: exports.ASSET_PATHS.game.moveSound,
        type: cc.AudioClip
      }, {
        path: exports.ASSET_PATHS.game.hammerSound,
        type: cc.AudioClip
      }, {
        path: exports.ASSET_PATHS.game.bombSound,
        type: cc.AudioClip
      }, {
        path: exports.ASSET_PATHS.game.magicWandSound,
        type: cc.AudioClip
      } ];
      if ("effects" === feature) return [ {
        path: exports.ASSET_PATHS.effects.comboWow,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.effects.comboGood,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.effects.comboGreat,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.effects.comboPerfect,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.effects.scoreDigits,
        type: cc.SpriteFrame
      } ];
      if ("home" === feature) return [ {
        path: exports.ASSET_PATHS.home.background,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.home.title,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.home.rankEntry,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.home.guideHand,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.home.startWordmark,
        type: cc.SpriteFrame
      }, {
        path: exports.ASSET_PATHS.home.leaderboardBodyFont,
        type: cc.TTFFont
      }, {
        path: exports.ASSET_PATHS.home.leaderboardDisplayFont,
        type: cc.BitmapFont
      } ];
      throw new Error("[\u8d44\u6e90] \u672a\u77e5 Feature\uff1a" + feature);
    }
    function prepareMoodBeanArt() {
      return loadSpecs("game", [ {
        path: exports.ASSET_PATHS.game.hudMascot,
        type: cc.SpriteFrame
      } ]);
    }
    exports.prepareMoodBeanArt = prepareMoodBeanArt;
    function prepareFeature(feature) {
      if (readyFeatures[feature]) return Promise.resolve();
      if (featurePromises[feature]) return featurePromises[feature];
      var shared = "home" === feature ? loadSpecs("game", [ exports.ASSET_PATHS.game.hudMascot, exports.ASSET_PATHS.game.hammer, exports.ASSET_PATHS.game.magicWand ].map(function(path) {
        return {
          path: path,
          type: cc.SpriteFrame
        };
      })) : Promise.resolve();
      var bundleName = "leaderboard" === feature ? "home" : feature;
      featurePromises[feature] = Promise.all([ shared, loadSpecs(bundleName, featureSpecs(feature)), "home" === feature || "game" === feature ? loadSpecs("effects", [ {
        path: exports.ASSET_PATHS.effects.reviveCard,
        type: cc.SpriteFrame
      } ]) : Promise.resolve() ]).then(function() {
        readyFeatures[feature] = true;
      }).catch(function(error) {
        delete featurePromises[feature];
        throw error;
      });
      return featurePromises[feature];
    }
    exports.prepareFeature = prepareFeature;
    function isFeatureReady(feature) {
      return true === readyFeatures[feature];
    }
    exports.isFeatureReady = isFeatureReady;
    function getLoadedAsset(bundleName, path, type) {
      var bundle = cc.assetManager.getBundle ? cc.assetManager.getBundle(bundleName) : null;
      var asset = bundle ? bundle.get(path, type) : null;
      if (!asset) throw new Error("[\u8d44\u6e90] " + bundleName + "/" + path + " \u5c1a\u672a\u51c6\u5907\uff0c\u7981\u6b62\u5728\u6e32\u67d3\u9636\u6bb5\u5f02\u6b65\u8865\u56fe");
      return asset;
    }
    function getSpriteFrame(bundleName, path) {
      return getLoadedAsset(bundleName, path, cc.SpriteFrame);
    }
    exports.getSpriteFrame = getSpriteFrame;
    function getBitmapFont(bundleName, path) {
      return getLoadedAsset(bundleName, path, cc.BitmapFont);
    }
    exports.getBitmapFont = getBitmapFont;
    function getTTFFont(bundleName, path) {
      return getLoadedAsset(bundleName, path, cc.TTFFont);
    }
    exports.getTTFFont = getTTFFont;
    function getSkeletonData(bundleName, path) {
      return getLoadedAsset(bundleName, path, sp.SkeletonData);
    }
    exports.getSkeletonData = getSkeletonData;
    function getAudioClip(bundleName, path) {
      return getLoadedAsset(bundleName, path, cc.AudioClip);
    }
    exports.getAudioClip = getAudioClip;
    function loadMusicClip(name) {
      return loadAsset("music", exports.ASSET_PATHS.music[name], cc.AudioClip).then(function(clip) {
        if (clip.loaded) return clip;
        return new Promise(function(resolve, reject) {
          cc.assetManager.postLoadNative(clip, function(error) {
            error ? reject(error) : resolve(clip);
          });
        });
      });
    }
    exports.loadMusicClip = loadMusicClip;
    function loadRemoteTexture(url) {
      return new Promise(function(resolve, reject) {
        cc.assetManager.loadRemote(url, {
          ext: ".png"
        }, function(error, texture) {
          if (error || !texture) {
            reject(new Error("[\u8d44\u6e90] \u8fdc\u7a0b\u5934\u50cf\u52a0\u8f7d\u5931\u8d25\uff1a" + (error ? error.message : url)));
            return;
          }
          resolve(texture);
        });
      });
    }
    exports.loadRemoteTexture = loadRemoteTexture;
    cc._RF.pop();
  }, {} ],
  AudioManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "36f1b4Wm59NDabHPm7bEuZy", "AudioManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.audioManager = void 0;
    var GameSettings_1 = require("./GameSettings");
    var AssetLoader_1 = require("./AssetLoader");
    var SOUND_RESOURCES = {
      break: {
        bundle: "game",
        path: AssetLoader_1.ASSET_PATHS.game.breakSound
      },
      move: {
        bundle: "game",
        path: AssetLoader_1.ASSET_PATHS.game.moveSound
      },
      bomb: {
        bundle: "game",
        path: AssetLoader_1.ASSET_PATHS.game.bombSound
      },
      hammer: {
        bundle: "game",
        path: AssetLoader_1.ASSET_PATHS.game.hammerSound
      },
      magicWand: {
        bundle: "game",
        path: AssetLoader_1.ASSET_PATHS.game.magicWandSound
      }
    };
    var AudioManager = function() {
      function AudioManager() {
        var _this = this;
        this.initialized = false;
        this.scene = "silent";
        this.gamePaused = false;
        this.appVisible = true;
        this.webFocused = true;
        this.previewMuted = false;
        this.previewAudioOwner = true;
        this.currentMusic = null;
        this.musicLoadName = null;
        this.musicRequestId = 0;
        this.musicAudioId = -1;
        this.musicClip = null;
        this.appliedVolume = -1;
        this.unsubscribeSettings = null;
        this.onHide = function() {
          _this.appVisible = false;
          _this.syncMusic();
          cc.audioEngine.stopAllEffects();
        };
        this.onShow = function() {
          _this.appVisible = true;
          _this.syncMusic();
        };
        this.onBlur = function() {
          _this.webFocused = false;
          _this.syncMusic();
          cc.audioEngine.stopAllEffects();
        };
        this.onFocus = function() {
          _this.webFocused = true;
          _this.syncMusic();
        };
        this.onVisibility = function() {
          _this.webFocused = document.hasFocus();
          _this.syncMusic();
        };
        this.onPageHide = function() {
          return _this.dispose();
        };
      }
      Object.defineProperty(AudioManager, "instance", {
        get: function() {
          this._instance || (this._instance = new AudioManager());
          return this._instance;
        },
        enumerable: false,
        configurable: true
      });
      AudioManager.prototype.initialize = function() {
        var _this = this;
        if (this.initialized) return;
        this.initialized = true;
        this.appVisible = true;
        this.previewAudioOwner = "undefined" === typeof window || false !== window.__zyxPreviewAudioGranted;
        this.unsubscribeSettings = GameSettings_1.gameSettings.onAudioChange(function() {
          return _this.applySettings();
        });
        cc.game.on(cc.game.EVENT_HIDE, this.onHide);
        cc.game.on(cc.game.EVENT_SHOW, this.onShow);
        if (cc.sys.isBrowser && "undefined" !== typeof window) {
          this.webFocused = document.hasFocus();
          window.addEventListener("blur", this.onBlur);
          window.addEventListener("focus", this.onFocus);
          window.addEventListener("pagehide", this.onPageHide);
          document.addEventListener("visibilitychange", this.onVisibility);
        }
        this.applySettings();
      };
      AudioManager.prototype.enterScene = function(scene) {
        this.initialize();
        this.scene = scene;
        this.gamePaused = false;
        "game" !== scene && cc.audioEngine.stopAllEffects();
        var name = "home" === scene ? "main" : "game" === scene ? "game" : null;
        if (name !== this.currentMusic) {
          this.musicRequestId++;
          this.musicLoadName = null;
          this.musicClip = null;
          this.currentMusic = name;
          this.stopCurrentMusic();
        }
        this.syncMusic();
      };
      AudioManager.prototype.setGamePaused = function(paused) {
        this.gamePaused = paused;
        paused && cc.audioEngine.stopAllEffects();
        this.syncMusic();
      };
      AudioManager.prototype.setPreviewMuted = function(muted) {
        this.previewMuted = muted;
        this.syncMusic();
      };
      AudioManager.prototype.setPreviewAudioOwner = function(owner) {
        this.previewAudioOwner = owner;
        this.syncMusic();
        owner || cc.audioEngine.stopAllEffects();
      };
      AudioManager.prototype.foreground = function() {
        return this.appVisible && this.previewAudioOwner && (!cc.sys.isBrowser || this.webFocused && "undefined" !== typeof document && !document.hidden);
      };
      AudioManager.prototype.canPlayMusic = function() {
        return !!this.currentMusic && this.foreground() && !this.previewMuted && !("game" === this.scene && this.gamePaused) && GameSettings_1.gameSettings.soundEnabled && GameSettings_1.gameSettings.soundVolume > 0;
      };
      AudioManager.prototype.syncMusic = function() {
        var _this = this;
        if (!this.initialized) return;
        if (!this.currentMusic) {
          this.stopCurrentMusic();
          return;
        }
        if (!this.canPlayMusic()) {
          this.musicAudioId >= 0 && cc.audioEngine.getState(this.musicAudioId) === cc.audioEngine.AudioState.PLAYING && cc.audioEngine.pause(this.musicAudioId);
          return;
        }
        if (this.musicAudioId >= 0) {
          var state = cc.audioEngine.getState(this.musicAudioId);
          state === cc.audioEngine.AudioState.PAUSED && cc.audioEngine.resume(this.musicAudioId);
          if (state === cc.audioEngine.AudioState.PLAYING || state === cc.audioEngine.AudioState.PAUSED) return;
          this.stopCurrentMusic();
        }
        if (this.musicClip) {
          this.musicAudioId = cc.audioEngine.playMusic(this.musicClip, true);
          return;
        }
        if (this.musicLoadName) return;
        var name = this.currentMusic;
        var requestId = ++this.musicRequestId;
        this.musicLoadName = name;
        AssetLoader_1.loadMusicClip(name).then(function(clip) {
          if (!_this.initialized || requestId !== _this.musicRequestId || _this.currentMusic !== name) return;
          _this.musicLoadName = null;
          _this.musicClip = clip;
          _this.syncMusic();
        }).catch(function(error) {
          if (requestId !== _this.musicRequestId) return;
          _this.musicLoadName = null;
          cc.warn("\u80cc\u666f\u97f3\u4e50\u52a0\u8f7d\u5931\u8d25", name, error);
        });
      };
      AudioManager.prototype.stopCurrentMusic = function() {
        var id = this.musicAudioId;
        this.musicAudioId = -1;
        if (id < 0) return;
        cc.audioEngine.setFinishCallback(id, null);
        cc.audioEngine.stop(id);
      };
      AudioManager.prototype.playSound = function(name) {
        if ("game" !== this.scene || this.gamePaused || !this.foreground() || !GameSettings_1.gameSettings.soundEnabled || GameSettings_1.gameSettings.soundVolume <= 0) return;
        cc.audioEngine.playEffect(this.getClip(SOUND_RESOURCES[name]), false);
      };
      AudioManager.prototype.applySettings = function() {
        var enabled = GameSettings_1.gameSettings.soundEnabled && GameSettings_1.gameSettings.soundVolume > 0;
        var volume = enabled ? GameSettings_1.gameSettings.soundVolume : 0;
        if (volume !== this.appliedVolume) {
          this.appliedVolume = volume;
          cc.audioEngine.setMusicVolume(volume);
          cc.audioEngine.setEffectsVolume(volume);
        }
        enabled || cc.audioEngine.stopAllEffects();
        this.syncMusic();
      };
      AudioManager.prototype.dispose = function() {
        this.scene = "silent";
        this.currentMusic = this.musicLoadName = null;
        this.musicClip = null;
        this.musicRequestId++;
        this.gamePaused = this.previewMuted = false;
        this.stopCurrentMusic();
        cc.audioEngine.stopAllEffects();
        if (!this.initialized) return;
        this.initialized = false;
        cc.game.off(cc.game.EVENT_HIDE, this.onHide);
        cc.game.off(cc.game.EVENT_SHOW, this.onShow);
        if (cc.sys.isBrowser && "undefined" !== typeof window) {
          window.removeEventListener("blur", this.onBlur);
          window.removeEventListener("focus", this.onFocus);
          window.removeEventListener("pagehide", this.onPageHide);
          document.removeEventListener("visibilitychange", this.onVisibility);
        }
        this.unsubscribeSettings && this.unsubscribeSettings();
        this.unsubscribeSettings = null;
      };
      AudioManager.prototype.getClip = function(resource) {
        return AssetLoader_1.getAudioClip(resource.bundle, resource.path);
      };
      return AudioManager;
    }();
    exports.default = AudioManager;
    exports.audioManager = AudioManager.instance;
    cc._RF.pop();
  }, {
    "./AssetLoader": "AssetLoader",
    "./GameSettings": "GameSettings"
  } ],
  BeanCollectionHud: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d07f8G9m/NMeLlfUDR8rcIt", "BeanCollectionHud");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.applyHudFont = exports.formatHudScore = void 0;
    var MoodBeanConfig_1 = require("../dataModule/MoodBeanConfig");
    var UIManager_1 = require("../manager/UIManager");
    var AssetLoader_1 = require("../manager/AssetLoader");
    var MoodArt_1 = require("./MoodArt");
    var GamePanel_1 = require("./GamePanel");
    function formatHudScore(value) {
      var number = Math.max(0, Math.floor(value || 0));
      var unit = number >= 1e8 ? 1e8 : number >= 1e6 ? 1e4 : 0;
      if (!unit) return String(number);
      return String(Math.floor(number / unit * 100) / 100) + (1e4 === unit ? "\u4e07" : "\u4ebf");
    }
    exports.formatHudScore = formatHudScore;
    function applyHudFont(label) {
      var size = label.fontSize;
      label.font = AssetLoader_1.getBitmapFont("game", AssetLoader_1.ASSET_PATHS.game.hudFont);
      label.useSystemFont = false;
      label.enableBold = false;
      label.fontSize = size;
      label.lineHeight = size;
      label.enableWrapText = false;
    }
    exports.applyHudFont = applyHudFont;
    var BeanCollectionHud = function() {
      function BeanCollectionHud(parent, x, width) {
        this.state = {
          blocks: 0
        };
        this.target = 0;
        this.animating = false;
        this.disposed = false;
        this.reward = null;
        this.root = GamePanel_1.createGamePanel(parent, "beanCollectionCard", width, 148, x);
        var ringX = -width / 2 + 86;
        this.ringNode = new cc.Node("collectionRing");
        this.root.addChild(this.ringNode);
        this.ringNode.setPosition(ringX, 5);
        this.ring = this.ringNode.addComponent(cc.Graphics);
        this.icon = MoodArt_1.createMoodBeanMascot(this.root, ringX, 7, 86);
        this.badge = UIManager_1.uimanager.createRect(this.root, "roundBeanBadge", 132, 36, new cc.Color(119, 78, 44), 216, 18, ringX, -46);
        this.badge.zIndex = 90;
        this.count = UIManager_1.uimanager.createLabel(this.badge, "\u672c\u5c40 +0", 0, 0, 24, new cc.Color(255, 252, 238), 120, 30);
        var textWidth = width - 198;
        var textX = 75;
        this.percent = UIManager_1.uimanager.createLabel(this.root, "0%", textX, 0, 64, new cc.Color(38, 89, 29), textWidth, 70);
        this.goal = UIManager_1.uimanager.createLabel(this.root, "\u96c6\u6ee1100%\u518d\u5f971\u9897", textX, -54, 16, new cc.Color(117, 82, 51), textWidth, 20);
        this.goal.fontSize = 18;
        this.goal.node.height = 24;
        for (var _i = 0, _a = [ this.count, this.percent, this.goal ]; _i < _a.length; _i++) {
          var label = _a[_i];
          applyHudFont(label);
        }
        this.render(false);
      }
      BeanCollectionHud.prototype.resize = function(width) {
        if (this.disposed || !cc.isValid(this.root, true)) return;
        GamePanel_1.resizeGamePanel(this.root, width, 148);
        var ringX = -width / 2 + 86;
        this.ringNode.x = this.icon.x = this.badge.x = ringX;
        this.percent.node.width = this.goal.node.width = width - 198;
      };
      BeanCollectionHud.prototype.collectTo = function(blocks) {
        if (this.disposed || !cc.isValid(this.root, true)) return;
        this.target = Math.max(this.target, Math.floor(blocks));
        this.pump();
      };
      BeanCollectionHud.prototype.complete = function(blocks) {
        if (this.disposed || !cc.isValid(this.root, true)) return;
        cc.Tween.stopAllByTarget(this.state);
        this.clearReward();
        this.state.blocks = this.target = Math.max(0, Math.floor(blocks));
        this.animating = false;
        this.render(false);
      };
      BeanCollectionHud.prototype.dispose = function() {
        if (this.disposed) return;
        this.disposed = true;
        this.animating = false;
        cc.Tween.stopAllByTarget(this.state);
        var percentNode = this.percent && this.percent.node;
        for (var _i = 0, _a = [ this.icon, this.badge, percentNode ]; _i < _a.length; _i++) {
          var node = _a[_i];
          cc.isValid(node, true) && cc.Tween.stopAllByTarget(node);
        }
        this.clearReward(false);
      };
      BeanCollectionHud.prototype.clearReward = function(restoreGoal) {
        void 0 === restoreGoal && (restoreGoal = true);
        if (this.reward && cc.isValid(this.reward, true)) {
          cc.Tween.stopAllByTarget(this.reward);
          this.reward.destroy();
        }
        this.reward = null;
        restoreGoal && !this.disposed && this.goal && cc.isValid(this.goal.node, true) && (this.goal.node.opacity = 255);
      };
      BeanCollectionHud.prototype.pump = function() {
        var _this = this;
        if (this.disposed || !cc.isValid(this.root, true) || this.animating || this.state.blocks >= this.target) return;
        this.animating = true;
        var boundary = (Math.floor(this.state.blocks / MoodBeanConfig_1.MOOD_BLOCKS_PER_BEAN) + 1) * MoodBeanConfig_1.MOOD_BLOCKS_PER_BEAN;
        var end = Math.min(this.target, boundary);
        var full = end === boundary;
        cc.Tween.stopAllByTarget(this.percent.node);
        this.percent.node.y = -3;
        cc.tween(this.percent.node).to(.28, {
          y: 0
        }, {
          easing: "quadOut"
        }).start();
        cc.tween(this.state).to(.28, {
          blocks: end
        }, {
          easing: "quadOut",
          onUpdate: function() {
            !_this.disposed && cc.isValid(_this.root) && _this.render(full && _this.state.blocks >= end);
          }
        }).call(function() {
          if (_this.disposed || !cc.isValid(_this.root)) return;
          _this.render(full);
          full && _this.celebrate();
        }).delay(full ? .32 : 0).call(function() {
          if (_this.disposed || !cc.isValid(_this.root)) return;
          _this.animating = false;
          _this.render(false);
          _this.pump();
        }).start();
      };
      BeanCollectionHud.prototype.render = function(full) {
        var collection = MoodBeanConfig_1.getMoodCollection(this.state.blocks);
        this.percent.string = full ? "100%" : collection.percent;
        this.count.string = "\u672c\u5c40 +" + collection.beans;
        this.count.fontSize = this.count.string.length > 7 ? 19 : 24;
        var progress = full ? 1 : collection.progress / MoodBeanConfig_1.MOOD_BLOCKS_PER_BEAN;
        var g = this.ring;
        g.clear();
        g.lineWidth = 16;
        g.lineCap = cc.Graphics.LineCap.ROUND;
        g.strokeColor = new cc.Color(220, 210, 169);
        g.circle(0, 0, 55);
        g.stroke();
        g.lineWidth = 12;
        g.strokeColor = new cc.Color(243, 234, 194);
        g.circle(0, 0, 55);
        g.stroke();
        if (progress > 0) {
          var arc = function(width, color) {
            g.lineWidth = width;
            g.strokeColor = color;
            progress >= 1 ? g.circle(0, 0, 55) : g.arc(0, 0, 55, Math.PI / 2, Math.PI / 2 - 2 * Math.PI * progress, false);
            g.stroke();
          };
          arc(16, new cc.Color(100, 155, 70));
          arc(13, new cc.Color(108, 189, 105));
          arc(6, new cc.Color(155, 216, 132));
        }
      };
      BeanCollectionHud.prototype.celebrate = function() {
        var _this = this;
        for (var _i = 0, _a = [ this.icon, this.badge ]; _i < _a.length; _i++) {
          var node = _a[_i];
          cc.Tween.stopAllByTarget(node);
          node.scale = 1;
          cc.tween(node).to(.12, {
            scale: 1.12
          }, {
            easing: "quadOut"
          }).to(.2, {
            scale: 1
          }, {
            easing: "backOut"
          }).start();
        }
        this.clearReward();
        this.goal.node.opacity = 0;
        var label = UIManager_1.uimanager.createLabel(this.root, "\u5f00\u5fc3\u8c46 +1", 75, -47, 22, new cc.Color(121, 89, 35), this.root.width - 198, 30);
        applyHudFont(label);
        this.reward = label.node;
        this.reward.zIndex = 20;
        cc.tween(this.reward).to(.12, {
          scale: 1.06
        }, {
          easing: "quadOut"
        }).delay(.2).to(.22, {
          scale: 1,
          opacity: 0
        }).call(function() {
          return _this.clearReward();
        }).start();
      };
      return BeanCollectionHud;
    }();
    exports.default = BeanCollectionHud;
    cc._RF.pop();
  }, {
    "../dataModule/MoodBeanConfig": "MoodBeanConfig",
    "../manager/AssetLoader": "AssetLoader",
    "../manager/UIManager": "UIManager",
    "./GamePanel": "GamePanel",
    "./MoodArt": "MoodArt"
  } ],
  BoardEngine: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2b69bdj0npNQ47Ra3/VhA0j", "BoardEngine");
    "use strict";
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __spreadArrays = this && this.__spreadArrays || function() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
      for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, 
      k++) r[k] = a[j];
      return r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.MAX_ACTION_APPENDS = exports.MAX_BOARD_BOMBS = exports.ROUND_RESCUE_COOLDOWN_MS = exports.BOARD_RULES_VERSION = exports.BOARD_COLS = exports.BOARD_ROWS = void 0;
    exports.BOARD_ROWS = 10;
    exports.BOARD_COLS = 8;
    exports.BOARD_RULES_VERSION = 12;
    exports.ROUND_RESCUE_COOLDOWN_MS = 6e4;
    exports.MAX_BOARD_BOMBS = 3;
    exports.MAX_ACTION_APPENDS = 5;
    var BoardEngine = function() {
      function BoardEngine() {
        this.pieces = [];
        this.nextPieces = [];
        this.secondNextPieces = [];
        this.score = 0;
        this.combo = 0;
        this.bestScore = 0;
        this.hammerCount = 0;
        this.colorPurifierCount = 0;
        this.turn = 0;
        this.moveCount = 0;
        this.difficultyActionCount = 0;
        this.roundClearedRows = 0;
        this.roundCollectedMoodBeans = 0;
        this.roundSeed = 1;
        this.rulesVersion = exports.BOARD_RULES_VERSION;
        this.roundActions = [];
        this.generationDebugLog = [];
        this.actionAppends = 0;
        this.actionCascade = 0;
        this.recentMisses = 0;
        this.currentRoundIsTutorial = false;
        this.randomState = 1;
        this.nextId = 1;
        this.tutorialMoves = [];
        this.comboActionCleared = false;
        this.pendingComboBomb = false;
        this.actionOpen = false;
        this.actionBlast = false;
        this.actionRows = 0;
        this.balloonAvailable = false;
        this.rescueKind = null;
        this.rescueLastOfferedAt = -exports.ROUND_RESCUE_COOLDOWN_MS;
        this.rescueRiseRows = 0;
        this.heartRescueEligible = false;
        this.heartAvailable = false;
        this.heartOffered = false;
        this.hammerUses = 0;
        this.wandUses = 0;
        this.rescueOfferCounts = {
          balloon: 0,
          clear: 0
        };
        this.pendingLightningCount = 0;
        this.lightningEffects = [];
      }
      BoardEngine.prototype.takeLightningEffects = function() {
        var effects = this.lightningEffects;
        this.lightningEffects = [];
        return effects;
      };
      BoardEngine.prototype.saveToolInventory = function() {};
      BoardEngine.prototype.resetBoard = function(seed, tutorial, rulesVersion, heartEligible) {
        void 0 === rulesVersion && (rulesVersion = exports.BOARD_RULES_VERSION);
        void 0 === heartEligible && (heartEligible = false);
        this.rulesVersion = rulesVersion;
        this.hammerUses = this.wandUses = this.pendingLightningCount = 0;
        this.rescueOfferCounts = {
          balloon: 0,
          clear: 0
        };
        this.lightningEffects = [];
        rulesVersion >= 12 && (this.hammerCount = this.colorPurifierCount = 0);
        this.heartRescueEligible = heartEligible;
        this.score = this.combo = this.turn = this.moveCount = 0;
        this.difficultyActionCount = 0;
        this.roundClearedRows = this.roundCollectedMoodBeans = 0;
        this.actionAppends = this.actionCascade = this.recentMisses = 0;
        this.comboActionCleared = this.pendingComboBomb = this.actionOpen = this.actionBlast = false;
        this.actionRows = 0;
        this.balloonAvailable = false;
        this.rescueKind = null;
        this.rescueLastOfferedAt = -exports.ROUND_RESCUE_COOLDOWN_MS;
        this.rescueRiseRows = 0;
        this.heartAvailable = this.heartOffered = false;
        this.nextId = 1;
        this.roundSeed = this.randomState = seed >>> 0 || 1;
        this.currentRoundIsTutorial = tutorial;
        this.roundActions = [ {
          type: "rules",
          version: this.rulesVersion
        } ];
        this.generationDebugLog = [];
        if (tutorial) {
          this.pieces = this.createTutorialBoard();
          this.nextPieces = this.createTutorialNextRow();
        } else {
          this.tutorialMoves = [];
          this.pieces = [ this.createPiece(9, 0, 3, 8, 8), this.createPiece(9, 5, 3, 6, 0), this.createPiece(8, 0, 2, 2, 2), this.createPiece(8, 2, 1, 9, 0), this.createPiece(8, 4, 2, 1, 1), this.createPiece(7, 0, 1, 3, 3), this.createPiece(7, 4, 2, 7, 0) ];
          this.rulesVersion >= 6 && this.random() < .5 && this.pieces.forEach(function(piece) {
            return piece.col = exports.BOARD_COLS - piece.col - piece.size;
          });
          this.nextPieces = this.generateNextRow();
        }
        this.secondNextPieces = [];
      };
      BoardEngine.prototype.isTutorialRound = function() {
        return this.currentRoundIsTutorial;
      };
      BoardEngine.prototype.canCheckpoint = function() {
        if (this.actionOpen && !this.isGameOver()) return false;
        if (1 === this.roundActions.length) return true;
        var prediction = new BoardEngine();
        prediction.pieces = this.pieces.map(function(piece) {
          return __assign({}, piece);
        });
        return 0 === prediction.applyGravity().length && 0 === prediction.eliminateFullRows().clearedRows;
      };
      BoardEngine.prototype.getTutorialMove = function(step) {
        var move = this.tutorialMoves[step];
        return move ? __assign({}, move) : null;
      };
      BoardEngine.prototype.getPiece = function(id) {
        return this.pieces.find(function(piece) {
          return piece.id === id;
        }) || null;
      };
      BoardEngine.prototype.getMoveRange = function(id) {
        var piece = this.getPiece(id);
        if (!piece) return {
          min: 0,
          max: 0
        };
        var minCol = 0;
        var maxCol = exports.BOARD_COLS - piece.size;
        for (var _i = 0, _a = this.pieces; _i < _a.length; _i++) {
          var other = _a[_i];
          if (other.id === id || other.row !== piece.row) continue;
          other.col + other.size <= piece.col ? minCol = Math.max(minCol, other.col + other.size) : other.col >= piece.col + piece.size && (maxCol = Math.min(maxCol, other.col - piece.size));
        }
        return {
          min: minCol - piece.col,
          max: maxCol - piece.col
        };
      };
      BoardEngine.prototype.movePiece = function(id, offset) {
        var piece = this.getPiece(id);
        if (!piece || 0 === offset) return false;
        var range = this.getMoveRange(id);
        var safeOffset = Math.max(range.min, Math.min(range.max, offset));
        if (0 === safeOffset) return false;
        this.beginPlayerAction();
        this.moveCount++;
        piece.col += safeOffset;
        this.roundActions.push({
          type: "move",
          id: id,
          offset: safeOffset
        });
        return true;
      };
      BoardEngine.prototype.useHammer = function(id) {
        if (this.hammerCount <= 0 || !this.getPiece(id) || this.rulesVersion >= 12 && this.hammerUses >= 3) return false;
        this.beginPlayerAction();
        var removed = this.getPiece(id);
        this.hammerUses++;
        this.hammerCount--;
        this.saveToolInventory();
        this.pieces = this.pieces.filter(function(piece) {
          return piece.id !== id;
        });
        this.dischargeLightning([ removed ]);
        this.addToolScore(1);
        this.roundActions.push({
          type: "hammer",
          id: id
        });
        return true;
      };
      BoardEngine.prototype.grantRewardedHammer = function() {
        this.hammerCount++;
        this.saveToolInventory();
      };
      BoardEngine.prototype.useColorPurifier = function(color) {
        if (this.colorPurifierCount <= 0 || this.rulesVersion >= 12 && this.wandUses >= 1) return [];
        var removedPieceIds = this.pieces.filter(function(piece) {
          return piece.color === color;
        }).map(function(piece) {
          return piece.id;
        });
        if (0 === removedPieceIds.length) return [];
        this.beginPlayerAction();
        this.wandUses++;
        this.colorPurifierCount--;
        this.saveToolInventory();
        var removedSet = {};
        removedPieceIds.forEach(function(id) {
          return removedSet[id] = true;
        });
        var removed = this.pieces.filter(function(piece) {
          return removedSet[piece.id];
        });
        this.pieces = this.pieces.filter(function(piece) {
          return !removedSet[piece.id];
        });
        this.dischargeLightning(removed);
        this.addToolScore(removedPieceIds.length);
        this.roundActions.push({
          type: "purify",
          color: color
        });
        return removedPieceIds;
      };
      BoardEngine.prototype.grantRewardedColorPurifier = function() {
        this.colorPurifierCount++;
        this.saveToolInventory();
      };
      BoardEngine.prototype.hasEnteredRescueZone = function(emptyRows) {
        void 0 === emptyRows && (emptyRows = 2);
        if (0 === this.pieces.length) return false;
        var topmostRow = this.pieces.reduce(function(minimum, piece) {
          return Math.min(minimum, piece.row);
        }, exports.BOARD_ROWS);
        return topmostRow <= Math.max(0, emptyRows);
      };
      BoardEngine.prototype.getOccupiedRowCount = function() {
        var occupiedRows = {};
        this.pieces.forEach(function(piece) {
          return occupiedRows[piece.row] = true;
        });
        return Object.keys(occupiedRows).length;
      };
      BoardEngine.prototype.getBoardHeight = function() {
        return this.pieces.length ? exports.BOARD_ROWS - Math.min.apply(Math, this.pieces.map(function(piece) {
          return piece.row;
        })) : 0;
      };
      BoardEngine.prototype.canOfferBalloonRescue = function() {
        return this.rulesVersion >= 6 && this.rulesVersion < 8 && !this.balloonAvailable && this.score > 1e3 && this.getBoardHeight() > 6 && !this.isGameOver();
      };
      BoardEngine.prototype.canOfferRoundRescue = function(elapsedMs) {
        return this.rulesVersion >= 8 && !this.rescueKind && !this.heartAvailable && this.score > 500 && this.getBoardHeight() > 6 && (this.rulesVersion < 12 || this.rescueOfferCounts.balloon < 4 || this.rescueOfferCounts.clear < 4) && !this.isGameOver() && Number.isSafeInteger(elapsedMs) && elapsedMs >= 0 && elapsedMs - this.rescueLastOfferedAt >= exports.ROUND_RESCUE_COOLDOWN_MS;
      };
      BoardEngine.prototype.offerRoundRescue = function(elapsedMs) {
        if (!this.canOfferRoundRescue(elapsedMs)) return null;
        var roll = this.random();
        this.rescueKind = this.rulesVersion >= 12 && this.rescueOfferCounts.balloon >= 4 ? "clear" : this.rulesVersion >= 12 && this.rescueOfferCounts.clear >= 4 ? "balloon" : roll < .5 ? "balloon" : "clear";
        this.rescueOfferCounts[this.rescueKind]++;
        this.rescueLastOfferedAt = elapsedMs;
        this.roundActions.push({
          type: "rescueOffer",
          elapsedMs: elapsedMs,
          kind: this.rescueKind
        });
        return this.rescueKind;
      };
      BoardEngine.prototype.dismissRoundRescue = function() {
        if (!this.rescueKind) return false;
        this.rescueKind = null;
        this.roundActions.push({
          type: "rescueDismiss"
        });
        return true;
      };
      BoardEngine.prototype.applyClearRescue = function() {
        if (this.rulesVersion < 8 || "clear" !== this.rescueKind) return null;
        this.rescueKind = null;
        this.beginPlayerAction();
        var ids = this.pieces.map(function(piece) {
          return piece.id;
        });
        var removed = this.pieces.slice();
        this.pieces = [];
        this.dischargeLightning(removed);
        this.addToolScore(ids.length);
        this.rulesVersion >= 9 && (this.rescueRiseRows = 2);
        this.roundActions.push({
          type: "rescueClear"
        });
        return ids;
      };
      BoardEngine.prototype.offerBalloonRescue = function() {
        if (!this.canOfferBalloonRescue()) return false;
        this.balloonAvailable = true;
        this.roundActions.push({
          type: "balloonOffer"
        });
        return true;
      };
      BoardEngine.prototype.dismissBalloonRescue = function() {
        if (this.rulesVersion >= 8) return this.dismissRoundRescue();
        if (!this.balloonAvailable) return false;
        this.balloonAvailable = false;
        this.roundActions.push({
          type: "balloonDismiss"
        });
        return true;
      };
      BoardEngine.prototype.getBalloonTargets = function() {
        var state = this.randomState;
        try {
          return this.shuffle(this.pieces.slice()).slice(0, Math.ceil(this.pieces.length / 4));
        } finally {
          this.randomState = state;
        }
      };
      BoardEngine.prototype.applyBalloonRescue = function() {
        if (this.rulesVersion < 6 || (this.rulesVersion >= 8 ? "balloon" !== this.rescueKind : !this.balloonAvailable)) return null;
        this.rescueKind = null;
        this.balloonAvailable = false;
        if (this.rulesVersion >= 9) {
          this.beginPlayerAction();
          this.rescueRiseRows = 1;
        }
        var targets = this.shuffle(this.pieces.slice()).slice(0, Math.ceil(this.pieces.length / 4));
        this.roundActions.push({
          type: "balloon"
        });
        if (this.rulesVersion >= 7) return this.removeWithBombs(targets.map(function(piece) {
          return __assign(__assign({}, piece), {
            bomb: true
          });
        }), []);
        var ids = new Set(targets.map(function(piece) {
          return piece.id;
        }));
        var moods = targets.filter(function(piece) {
          return piece.stampMood > 0;
        }).map(function(piece) {
          return piece.stampMood;
        });
        this.pieces = this.pieces.filter(function(piece) {
          return !ids.has(piece.id);
        });
        this.roundCollectedMoodBeans += moods.length;
        return {
          clearedRows: 0,
          gainedScore: 0,
          removedPieceIds: targets.map(function(piece) {
            return piece.id;
          }),
          clearedRowIndexes: [],
          collectedMoodTypes: moods,
          detonatedBombs: []
        };
      };
      BoardEngine.prototype.canOfferHeartRescue = function() {
        return this.rulesVersion >= 10 && this.heartRescueEligible && !this.heartOffered && !this.isGameOver() && this.hasEnteredRescueZone(2);
      };
      BoardEngine.prototype.offerHeartRescue = function(elapsedMs) {
        if (this.rescueKind || !this.canOfferHeartRescue() || !Number.isSafeInteger(elapsedMs) || elapsedMs < 2e3) return false;
        this.heartOffered = this.heartAvailable = true;
        this.roundActions.push({
          type: "heartOffer",
          elapsedMs: elapsedMs
        });
        return true;
      };
      BoardEngine.prototype.dismissHeartRescue = function() {
        if (!this.heartAvailable) return false;
        this.heartAvailable = false;
        this.roundActions.push({
          type: "heartDismiss"
        });
        return true;
      };
      BoardEngine.prototype.applyHeartRescue = function() {
        if (this.rulesVersion < 10 || !this.heartAvailable) return null;
        this.heartAvailable = false;
        this.beginPlayerAction();
        this.rescueRiseRows = 1;
        var targets = this.shuffle(this.pieces.slice()).slice(0, Math.ceil(this.pieces.length / 4));
        this.roundActions.push({
          type: "heart"
        });
        return this.removeWithBombs(targets.map(function(piece) {
          return __assign(__assign({}, piece), {
            bomb: true
          });
        }), []);
      };
      BoardEngine.prototype.removeMostCommonColor = function() {
        var stats = {};
        for (var _i = 0, _a = this.pieces; _i < _a.length; _i++) {
          var piece = _a[_i];
          stats[piece.color] || (stats[piece.color] = {
            count: 0,
            cells: 0
          });
          stats[piece.color].count++;
          stats[piece.color].cells += piece.size;
        }
        var colors = Object.keys(stats).map(function(value) {
          return Number(value);
        });
        if (0 === colors.length) return {
          color: 0,
          removedPieceIds: []
        };
        colors.sort(function(left, right) {
          var countDifference = stats[right].count - stats[left].count;
          if (0 !== countDifference) return countDifference;
          var cellDifference = stats[right].cells - stats[left].cells;
          if (0 !== cellDifference) return cellDifference;
          return left - right;
        });
        var color = colors[0];
        var removedPieceIds = this.pieces.filter(function(piece) {
          return piece.color === color;
        }).map(function(piece) {
          return piece.id;
        });
        var removedSet = {};
        removedPieceIds.forEach(function(id) {
          return removedSet[id] = true;
        });
        this.pieces = this.pieces.filter(function(piece) {
          return !removedSet[piece.id];
        });
        return {
          color: color,
          removedPieceIds: removedPieceIds
        };
      };
      BoardEngine.prototype.removeAllPieces = function() {
        this.beginPlayerAction();
        var removedPieceIds = this.pieces.map(function(piece) {
          return piece.id;
        });
        this.pieces = [];
        this.roundActions.push({
          type: "clear"
        });
        return removedPieceIds;
      };
      BoardEngine.prototype.removeTopRowsForRevive = function(rowCount, useCard) {
        void 0 === rowCount && (rowCount = 8);
        void 0 === useCard && (useCard = false);
        if (useCard && this.rulesVersion < 11) return [];
        if (this.rulesVersion >= 11) {
          var adCount = this.roundActions.filter(function(action) {
            return "revive" === action.type;
          }).length;
          var cardCount = this.roundActions.filter(function(action) {
            return "reviveCard" === action.type;
          }).length;
          if (8 !== rowCount || !this.isGameOver() || cardCount > 0 || (useCard ? 1 !== adCount : 0 !== adCount)) return [];
        }
        var firstPreservedRow = Math.max(0, Math.min(exports.BOARD_ROWS, Math.floor(rowCount)));
        var removedPieceIds = this.pieces.filter(function(piece) {
          return piece.row < firstPreservedRow;
        }).map(function(piece) {
          return piece.id;
        });
        if (0 === removedPieceIds.length) return [];
        this.beginPlayerAction();
        var removedSet = {};
        removedPieceIds.forEach(function(id) {
          return removedSet[id] = true;
        });
        this.pieces = this.pieces.filter(function(piece) {
          return !removedSet[piece.id];
        });
        this.roundActions.push({
          type: useCard ? "reviveCard" : "revive",
          rowCount: rowCount
        });
        return removedPieceIds;
      };
      BoardEngine.prototype.findEliminationHint = function() {
        var easy = this.easyMoves(this.pieces);
        if (easy.length) return {
          id: easy[0].id,
          offset: easy[0].offset
        };
        for (var _i = 0, _a = this.pieces.slice().sort(function(a, b) {
          return b.row - a.row;
        }); _i < _a.length; _i++) {
          var piece = _a[_i];
          var range = this.getMoveRange(piece.id);
          for (var offset = range.min; offset <= range.max; offset++) if (offset && this.wouldCreateFullRow(piece, offset)) return {
            id: piece.id,
            offset: offset
          };
        }
        return null;
      };
      BoardEngine.prototype.beginPlayerAction = function() {
        this.actionOpen && this.finishPlayerAction();
        this.difficultyActionCount++;
        this.prepareSecondRow(this.difficultyActionCount);
        this.actionOpen = true;
        this.comboActionCleared = this.actionBlast = this.pendingComboBomb = false;
        this.actionRows = this.actionCascade = this.actionAppends = 0;
      };
      BoardEngine.prototype.finishPlayerAction = function() {
        var _a;
        if (!this.actionOpen) return [];
        this.roundActions.push({
          type: "finish"
        });
        this.comboActionCleared || this.actionBlast || (this.combo = 0);
        this.recentMisses = this.comboActionCleared || this.actionBlast ? 0 : this.recentMisses + 1;
        var rewards = [];
        while (this.pendingLightningCount > 0) {
          var candidates = this.pieces.filter(function(piece) {
            return 1 === piece.size && !piece.bomb && !piece.lightning;
          });
          if (!candidates.length) {
            var next = this.nextPieces.find(function(piece) {
              return !piece.lightning;
            });
            if (!next) break;
            var cells = [];
            for (var cell_1 = 0; cell_1 < next.size; cell_1++) cells.push(__assign(__assign({}, next), {
              col: next.col + cell_1,
              size: 1,
              stampMood: cell_1 === next.stampCell ? next.stampMood : 0,
              stampCell: 0,
              collectibleType: cell_1 === next.collectibleCell ? next.collectibleType : 0,
              collectibleCell: 0,
              lightning: 0 === cell_1
            }));
            (_a = this.nextPieces).splice.apply(_a, __spreadArrays([ this.nextPieces.indexOf(next), 1 ], cells));
            this.pendingLightningCount--;
            continue;
          }
          var target = candidates[Math.floor(this.random() * candidates.length)];
          var cell = target;
          cell.lightning = true;
          rewards.push(cell);
          this.pendingLightningCount--;
        }
        var count = (this.actionRows >= 2 ? 1 : 0) + (this.pendingComboBomb ? 1 : 0);
        for (var index = 0; index < count; index++) {
          var bomb = this.awardBomb(2);
          bomb && rewards.push(bomb);
        }
        this.pendingComboBomb = false;
        this.actionOpen = false;
        this.rescueRiseRows = 0;
        this.prepareSecondRow(this.difficultyActionCount + 1);
        return rewards;
      };
      BoardEngine.prototype.resolveBoard = function() {
        var clearedRows = 0;
        var gainedScore = 0;
        while (true) {
          this.applyGravity();
          var result = this.eliminateFullRows();
          if (0 === result.clearedRows) break;
          clearedRows += result.clearedRows;
          gainedScore += result.gainedScore;
        }
        return {
          clearedRows: clearedRows,
          gainedScore: gainedScore
        };
      };
      BoardEngine.prototype.awardBomb = function(clearedRows) {
        var _this = this;
        if (clearedRows < 2 || this.pieces.filter(function(piece) {
          return piece.bomb;
        }).length >= exports.MAX_BOARD_BOMBS) return null;
        var eligible = this.pieces.filter(function(piece) {
          return !piece.bomb && (_this.rulesVersion < 12 || !piece.lightning);
        });
        var target = this.rulesVersion >= 6 ? eligible[Math.floor(this.random() * eligible.length)] : eligible.sort(function(a, b) {
          return b.row - a.row || a.col - b.col || a.id - b.id;
        })[0];
        if (!target) if (this.rulesVersion >= 6) {
          var _loop_1 = function(row) {
            var empty = Array.from({
              length: exports.BOARD_COLS
            }, function(_, col) {
              return col;
            }).filter(function(col) {
              return !_this.pieces.some(function(piece) {
                return piece.row === row && col >= piece.col && col < piece.col + piece.size;
              });
            });
            if (empty.length) {
              target = this_1.createPiece(row, empty[Math.floor(this_1.random() * empty.length)], 1, 1, 0);
              this_1.pieces.push(target);
            }
          };
          var this_1 = this;
          for (var row = exports.BOARD_ROWS - 1; row >= 0 && !target; row--) _loop_1(row);
        } else {
          var _loop_2 = function(row) {
            var _loop_3 = function(col) {
              if (this_2.pieces.some(function(piece) {
                return piece.row === row && col >= piece.col && col < piece.col + piece.size;
              })) return "continue";
              target = this_2.createPiece(row, col, 1, 1, 0);
              this_2.pieces.push(target);
            };
            for (var col = 0; col < exports.BOARD_COLS && !target; col++) _loop_3(col);
          };
          var this_2 = this;
          for (var row = exports.BOARD_ROWS - 1; row >= 0 && !target; row--) _loop_2(row);
        }
        if (!target) return null;
        target.bomb = true;
        return target;
      };
      BoardEngine.prototype.detonateBomb = function(id) {
        var bomb = this.getPiece(id);
        if (!bomb || !bomb.bomb) return null;
        this.beginPlayerAction();
        this.roundActions.push({
          type: "bomb",
          id: id
        });
        return this.removeWithBombs([ bomb ], []);
      };
      BoardEngine.prototype.removeWithBombs = function(initial, rows) {
        var removed = new Set(initial.map(function(piece) {
          return piece.id;
        }));
        var queue = initial.filter(function(piece) {
          return piece.bomb;
        });
        var detonations = [];
        for (var index = 0; index < queue.length; index++) {
          var bomb = queue[index];
          var center = bomb.col + bomb.size / 2;
          var affectedPieceIds = [];
          for (var _i = 0, _a = this.pieces; _i < _a.length; _i++) {
            var piece = _a[_i];
            if (Math.abs(piece.row - bomb.row) > 1 || piece.col >= center + 1.5 || piece.col + piece.size <= center - 1.5) continue;
            affectedPieceIds.push(piece.id);
            if (removed.has(piece.id)) continue;
            removed.add(piece.id);
            piece.bomb && queue.push(piece);
          }
          detonations.push({
            id: bomb.id,
            row: bomb.row,
            col: bomb.col,
            size: bomb.size,
            affectedPieceIds: affectedPieceIds
          });
        }
        var removedPieces = this.pieces.filter(function(piece) {
          return removed.has(piece.id);
        });
        var moods = removedPieces.filter(function(piece) {
          return piece.stampMood > 0;
        }).map(function(piece) {
          return piece.stampMood;
        });
        this.pieces = this.pieces.filter(function(piece) {
          return !removed.has(piece.id);
        });
        this.dischargeLightning(removedPieces);
        this.roundCollectedMoodBeans += moods.length;
        queue.length && (this.actionBlast = true);
        var blastIds = new Set();
        detonations.forEach(function(bomb) {
          return bomb.affectedPieceIds.forEach(function(id) {
            return blastIds.add(id);
          });
        });
        var gainedScore = this.addToolScore(blastIds.size);
        return {
          clearedRows: rows.length,
          gainedScore: gainedScore,
          removedPieceIds: removedPieces.map(function(piece) {
            return piece.id;
          }),
          clearedRowIndexes: rows,
          collectedMoodTypes: moods,
          detonatedBombs: detonations
        };
      };
      BoardEngine.prototype.addToolScore = function(count) {
        var gained = this.rulesVersion >= 9 ? 5 * count : 0;
        this.score += gained;
        this.bestScore = Math.max(this.bestScore, this.score);
        return gained;
      };
      BoardEngine.prototype.applyGravity = function() {
        var moves = [];
        var ordered = this.pieces.slice().sort(function(a, b) {
          return b.row - a.row;
        });
        for (var _i = 0, ordered_1 = ordered; _i < ordered_1.length; _i++) {
          var piece = ordered_1[_i];
          var fromRow = piece.row;
          while (piece.row < exports.BOARD_ROWS - 1 && this.canOccupy(piece, piece.row + 1)) piece.row++;
          piece.row !== fromRow && moves.push({
            id: piece.id,
            fromRow: fromRow,
            toRow: piece.row
          });
        }
        return moves;
      };
      BoardEngine.prototype.eliminateFullRows = function() {
        this.roundActions.push({
          type: "settle"
        });
        var fullRows = this.findFullRows();
        if (!fullRows.length) return {
          clearedRows: 0,
          gainedScore: 0,
          removedPieceIds: [],
          clearedRowIndexes: [],
          collectedMoodTypes: [],
          detonatedBombs: []
        };
        this.actionOpen || this.beginPlayerAction();
        var result = this.removeWithBombs(this.pieces.filter(function(piece) {
          return fullRows.indexOf(piece.row) >= 0;
        }), fullRows);
        if (!this.comboActionCleared) {
          this.combo = Math.min(5, this.combo + 1);
          this.comboActionCleared = true;
          (3 === this.combo || this.rulesVersion >= 5 && this.combo >= 3) && (this.pendingComboBomb = true);
        }
        this.actionRows += fullRows.length;
        this.actionCascade++;
        result.combo = this.combo;
        result.cascade = this.actionCascade;
        var baseScore = 10 * fullRows.length * this.combo;
        result.gainedScore += baseScore;
        this.score += baseScore;
        this.roundClearedRows += fullRows.length;
        this.rulesVersion >= 12 && (this.pendingLightningCount += Math.floor(this.roundClearedRows / 20) - Math.floor((this.roundClearedRows - fullRows.length) / 20));
        this.bestScore = Math.max(this.bestScore, this.score);
        return result;
      };
      BoardEngine.prototype.appendNextRow = function(recordAction) {
        void 0 === recordAction && (recordAction = true);
        if (this.pieces.some(function(piece) {
          return 0 === piece.row;
        }) || this.actionAppends >= exports.MAX_ACTION_APPENDS) return false;
        this.actionAppends++;
        recordAction && this.roundActions.push({
          type: "append"
        });
        for (var _i = 0, _a = this.pieces; _i < _a.length; _i++) {
          var piece = _a[_i];
          piece.row--;
        }
        for (var _b = 0, _c = this.nextPieces; _b < _c.length; _b++) {
          var next = _c[_b];
          var piece = this.createPiece(exports.BOARD_ROWS - 1, next.col, next.size, next.color, next.stampMood, next.stampCell, next.collectibleType, next.collectibleCell);
          next.lightning && (piece.lightning = true);
          this.pieces.push(piece);
        }
        this.turn++;
        if (this.rulesVersion >= 5 && this.secondNextPieces.length) {
          this.nextPieces = this.secondNextPieces;
          this.secondNextPieces = [];
        } else this.nextPieces = this.generateNextRow();
        return true;
      };
      BoardEngine.prototype.appendTurnRows = function() {
        if (this.rulesVersion < 5) return this.appendNextRow();
        var rows = this.getRiseRowCount();
        if (this.actionAppends + rows > exports.MAX_ACTION_APPENDS || this.pieces.some(function(piece) {
          return piece.row < rows;
        })) return false;
        this.prepareSecondRow(this.difficultyActionCount);
        this.roundActions.push({
          type: "rise",
          rows: rows
        });
        for (var index = 0; index < rows; index++) this.appendNextRow(false);
        return true;
      };
      BoardEngine.prototype.getRiseRowCount = function(actions) {
        void 0 === actions && (actions = this.difficultyActionCount);
        if (this.rescueRiseRows) return this.rescueRiseRows;
        if (this.rulesVersion < 5 || actions <= 25) return 1;
        if (this.rulesVersion >= 6 && this.getBoardHeight() > 4) return 1;
        if (actions < 40) return (actions - 26) % 4 === 0 ? 2 : 1;
        if (actions < 55) return (actions - 40) % 2 === 0 ? 2 : 1;
        return 2;
      };
      BoardEngine.prototype.isGameOver = function() {
        return this.pieces.some(function(piece) {
          return 0 === piece.row;
        });
      };
      BoardEngine.prototype.canOccupy = function(piece, row) {
        return !this.pieces.some(function(other) {
          if (other.id === piece.id || other.row !== row) return false;
          var pieceEnd = piece.col + piece.size;
          var otherEnd = other.col + other.size;
          return piece.col < otherEnd && pieceEnd > other.col;
        });
      };
      BoardEngine.prototype.splitPiece = function(piece) {
        var _a;
        this.nextId = Math.max.apply(Math, __spreadArrays([ this.nextId ], this.pieces.map(function(item) {
          return item.id + 1;
        })));
        var fragments = [];
        for (var cell = 0; cell < piece.size; cell++) fragments.push(__assign(__assign({}, piece), {
          id: 0 === cell ? piece.id : this.nextId++,
          col: piece.col + cell,
          size: 1,
          stampMood: piece.stampCell === cell ? piece.stampMood : 0,
          stampCell: 0,
          collectibleType: piece.collectibleCell === cell ? piece.collectibleType : 0,
          collectibleCell: 0,
          bomb: !!piece.bomb && cell === Math.floor(piece.size / 2),
          lightning: false
        }));
        var index = this.pieces.findIndex(function(item) {
          return item.id === piece.id;
        });
        (_a = this.pieces).splice.apply(_a, __spreadArrays([ index, 1 ], fragments));
        return fragments;
      };
      BoardEngine.prototype.dischargeLightning = function(removed) {
        var _this = this;
        if (this.rulesVersion < 12) return;
        for (var _i = 0, _a = removed.filter(function(piece) {
          return piece.lightning;
        }); _i < _a.length; _i++) {
          var source = _a[_i];
          var candidates = this.shuffle(this.pieces.filter(function(piece) {
            return piece.size > 1 && !piece.lightning;
          }));
          var targets = candidates.slice(0, 3).map(function(piece) {
            return {
              original: __assign({}, piece),
              fragments: _this.splitPiece(piece).map(function(cell) {
                return __assign({}, cell);
              })
            };
          });
          this.lightningEffects.push({
            source: __assign({}, source),
            targets: targets
          });
        }
      };
      BoardEngine.prototype.findFullRows = function() {
        var fullRows = [];
        for (var row = 0; row < exports.BOARD_ROWS; row++) {
          var occupied = new Array(exports.BOARD_COLS).fill(false);
          for (var _i = 0, _a = this.pieces; _i < _a.length; _i++) {
            var piece = _a[_i];
            if (piece.row !== row) continue;
            for (var col = piece.col; col < piece.col + piece.size; col++) occupied[col] = true;
          }
          occupied.every(function(value) {
            return value;
          }) && fullRows.push(row);
        }
        return fullRows;
      };
      BoardEngine.prototype.getRefillRowTarget = function() {
        return this.moveCount < 6 ? 3 : 4;
      };
      BoardEngine.prototype.getDifficulty = function() {
        if (this.rulesVersion >= 5) {
          var actions = this.difficultyActionCount;
          var stage_1 = actions <= 25 ? 0 : actions < 40 ? 1 : actions < 55 ? 2 : 3;
          return {
            stage: stage_1,
            label: [ "\u8fde\u6d88\u65f6\u523b", "\u8fdb\u9636\u6311\u6218", "\u9ad8\u624b\u6311\u6218", "\u5927\u5e08\u6311\u6218" ][stage_1],
            progress: Math.max(0, Math.min(1, (actions - 25) / 30))
          };
        }
        var difficultyMoves = this.rulesVersion >= 4 ? 4 * this.difficultyActionCount : this.moveCount * (this.rulesVersion >= 3 ? 2 : 1);
        var progress = Math.max(0, Math.min(1, (difficultyMoves - 36) / 48));
        var stage = difficultyMoves <= 36 ? 0 : difficultyMoves < 60 ? 1 : difficultyMoves < 84 ? 2 : 3;
        return {
          stage: stage,
          label: [ "\u8fde\u6d88\u65f6\u523b", "\u8fdb\u9636\u6311\u6218", "\u9ad8\u624b\u6311\u6218", "\u5927\u5e08\u6311\u6218" ][stage],
          progress: progress
        };
      };
      BoardEngine.prototype.getHintDelay = function() {
        return this.rulesVersion >= 4 ? 2 + 6 * this.getDifficulty().progress : 2;
      };
      BoardEngine.prototype.getAssistanceChance = function(height, bombs) {
        var current = this.rulesVersion >= 4;
        var base = 1 - this.getDifficulty().progress * (current ? .85 : .65);
        return Math.min(1, base + (height >= 7 && !bombs ? current ? .08 : .15 : 0) + Math.min(current ? .06 : .12, this.recentMisses * (current ? .02 : .04)));
      };
      BoardEngine.prototype.preview = function(pieces) {
        var simulation = new BoardEngine();
        simulation.rulesVersion = this.rulesVersion;
        simulation.randomState = this.randomState;
        simulation.pieces = pieces.map(function(piece) {
          return __assign({}, piece);
        });
        var rows = 0;
        var waves = 0;
        var _loop_4 = function() {
          simulation.applyGravity();
          var full = simulation.findFullRows();
          if (!full.length) return "break";
          rows += full.length;
          waves++;
          simulation.removeWithBombs(simulation.pieces.filter(function(piece) {
            return full.indexOf(piece.row) >= 0;
          }), full);
        };
        while (true) {
          var state_1 = _loop_4();
          if ("break" === state_1) break;
        }
        return {
          pieces: simulation.pieces,
          rows: rows,
          waves: waves
        };
      };
      BoardEngine.prototype.easyMoves = function(pieces) {
        var simulation = new BoardEngine();
        simulation.pieces = pieces;
        var moves = [];
        var _loop_5 = function(piece) {
          var range = simulation.getMoveRange(piece.id);
          var _loop_6 = function(offset) {
            if (offset < range.min || offset > range.max) return "continue";
            var result = this_3.preview(pieces.map(function(item) {
              return item.id === piece.id ? __assign(__assign({}, item), {
                col: item.col + offset
              }) : item;
            }));
            result.rows && moves.push({
              id: piece.id,
              offset: offset,
              rows: result.rows,
              waves: result.waves
            });
          };
          for (var _i = 0, _a = [ -1, 1, -2, 2 ]; _i < _a.length; _i++) {
            var offset = _a[_i];
            _loop_6(offset);
          }
        };
        var this_3 = this;
        for (var _i = 0, pieces_1 = pieces; _i < pieces_1.length; _i++) {
          var piece = pieces_1[_i];
          _loop_5(piece);
        }
        return moves.sort(function(a, b) {
          return b.rows - a.rows || b.waves - a.waves || Math.abs(a.offset) - Math.abs(b.offset);
        });
      };
      BoardEngine.prototype.rowWithGap = function(col, size) {
        var pieces = [];
        for (var cell = 0; cell < exports.BOARD_COLS; ) {
          if (cell === col) {
            cell += size;
            continue;
          }
          var available = cell < col ? col - cell : exports.BOARD_COLS - cell;
          var length = this.rulesVersion >= 5 ? this.pickBlockSize(Math.min(3, available)) : Math.min(available, 1 + Math.floor(3 * this.random()));
          var color = this.pickMoodColor();
          pieces.push({
            col: cell,
            size: length,
            color: color,
            stampMood: this.random() < .5 ? color : 0,
            stampCell: 0,
            collectibleType: 0,
            collectibleCell: 0
          });
          cell += length;
        }
        if (this.rulesVersion >= 6 && this.random() < .5) {
          pieces.forEach(function(piece) {
            return piece.col = exports.BOARD_COLS - piece.col - piece.size;
          });
          pieces.sort(function(a, b) {
            return a.col - b.col;
          });
        }
        return {
          pieces: pieces,
          sizes: pieces.map(function(piece) {
            return piece.size;
          }),
          gaps: [],
          movablePieces: this.countMovableNextPieces(pieces)
        };
      };
      BoardEngine.prototype.generateNextRow = function() {
        var stable = this.preview(this.pieces).pieces;
        var height = stable.length ? exports.BOARD_ROWS - Math.min.apply(Math, stable.map(function(piece) {
          return piece.row;
        })) : 0;
        var bombs = stable.filter(function(piece) {
          return piece.bomb;
        }).length;
        var help = this.random() < this.getAssistanceChance(height, bombs);
        var candidates = [];
        var targetCells = this.pickTargetCells();
        for (var index = 0; index < 6; index++) candidates.push(this.createNextRowCandidate(targetCells));
        if (help) for (var gap = 1; gap <= 3; gap++) for (var col = 0; col <= exports.BOARD_COLS - gap; col++) candidates.push(this.rowWithGap(col, gap));
        this.rulesVersion >= 6 && this.shuffle(candidates);
        var moves = help ? this.easyMoves(stable) : [];
        var plans = [];
        if (new Set(stable.map(function(piece) {
          return piece.row;
        })).size >= 3 && moves.length) {
          var indexes = Array.from(new Set([ 0, Math.floor(moves.length / 2), moves.length - 1 ]));
          var _loop_7 = function(index) {
            var move = moves[index];
            plans.push(this_4.preview(stable.map(function(piece) {
              return piece.id === move.id ? __assign(__assign({}, piece), {
                col: piece.col + move.offset
              }) : piece;
            })).pieces);
          };
          var this_4 = this;
          for (var _i = 0, indexes_1 = indexes; _i < indexes_1.length; _i++) {
            var index = indexes_1[_i];
            _loop_7(index);
          }
        } else plans.push(stable);
        var best = candidates[0];
        var bestValue = -Infinity;
        for (var _a = 0, candidates_1 = candidates; _a < candidates_1.length; _a++) {
          var candidate = candidates_1[_a];
          var values = [];
          var _loop_8 = function(projected) {
            var input = projected.map(function(piece) {
              return __assign(__assign({}, piece), {
                row: piece.row - 1
              });
            });
            candidate.pieces.forEach(function(piece, index) {
              return input.push(__assign(__assign({}, piece), {
                row: 9,
                id: -index - 1
              }));
            });
            if (input.some(function(piece) {
              return piece.row < 0;
            })) {
              values.push(-1e3);
              return "continue";
            }
            var result = this_5.preview(input);
            var options = help || this_5.rulesVersion >= 4 ? this_5.easyMoves(result.pieces) : [];
            var top = options[0];
            var nextHeight = result.pieces.length ? 10 - Math.min.apply(Math, result.pieces.map(function(piece) {
              return piece.row;
            })) : 0;
            values.push(help ? (top ? 30 + 12 * Math.min(3, top.rows) + 5 * Math.min(3, top.waves) : 0) + 4 * Math.min(5, options.filter(function(move) {
              return 1 === Math.abs(move.offset);
            }).length) + 9 * Math.min(2, result.rows) - 8 * Math.max(0, nextHeight - 5) + 3 * Math.min(3, nextHeight) : 2 * candidate.movablePieces - 4 * Math.max(0, nextHeight - 8) - (this_5.rulesVersion >= 4 ? 20 * result.rows + 4 * Math.min(6, options.length) : 0));
          };
          var this_5 = this;
          for (var _b = 0, plans_1 = plans; _b < plans_1.length; _b++) {
            var projected = plans_1[_b];
            _loop_8(projected);
          }
          var value = .65 * Math.min.apply(Math, values) + values.reduce(function(sum, value) {
            return sum + value;
          }, 0) / values.length * .35;
          if (value > bestValue) {
            best = candidate;
            bestValue = value;
          }
        }
        this.generationDebugLog.push({
          seed: this.roundSeed,
          turn: this.turn,
          targetCells: best.pieces.reduce(function(sum, piece) {
            return sum + piece.size;
          }, 0),
          sizes: best.sizes,
          gaps: best.gaps,
          colors: best.pieces.map(function(piece) {
            return piece.color;
          }),
          stampCount: best.pieces.filter(function(piece) {
            return piece.stampMood > 0;
          }).length,
          movablePieces: best.movablePieces,
          attempts: candidates.length
        });
        this.generationDebugLog.length > 120 && this.generationDebugLog.shift();
        return best.pieces;
      };
      BoardEngine.prototype.createTutorialBoard = function() {
        var threeCell = this.createPiece(6, 1, 3, 3, 3, 1);
        var oneCell = this.createPiece(6, 4, 1, 1, 1);
        var twoCell = this.createPiece(6, 5, 2, 5, 5);
        this.tutorialMoves = [ {
          id: threeCell.id,
          offset: -1,
          pieceSize: 3,
          targetRow: 7,
          targetCol: 0
        }, {
          id: twoCell.id,
          offset: 1,
          pieceSize: 2,
          targetRow: 8,
          targetCol: 6
        }, {
          id: oneCell.id,
          offset: -1,
          pieceSize: 1,
          targetRow: 9,
          targetCol: 3
        } ];
        return [ threeCell, oneCell, twoCell, this.createPiece(7, 3, 2, 7, 7, 1), this.createPiece(7, 5, 3, 9, 9, 1), this.createPiece(8, 0, 3, 4, 0), this.createPiece(8, 3, 3, 6, 6, 1), this.createPiece(9, 0, 3, 10, 10, 1), this.createPiece(9, 4, 2, 8, 0), this.createPiece(9, 6, 2, 2, 2) ];
      };
      BoardEngine.prototype.createTutorialNextRow = function() {
        return [ {
          col: 0,
          size: 2,
          color: 2,
          stampMood: 2,
          stampCell: 0,
          collectibleType: 0,
          collectibleCell: 0
        }, {
          col: 3,
          size: 1,
          color: 4,
          stampMood: 0,
          stampCell: 0,
          collectibleType: 0,
          collectibleCell: 0
        }, {
          col: 5,
          size: 2,
          color: 6,
          stampMood: 6,
          stampCell: 1,
          collectibleType: 0,
          collectibleCell: 0
        } ];
      };
      BoardEngine.prototype.pickTargetCells = function() {
        var progress = this.getDifficulty().progress;
        return this.random() < progress ? 6 : 5;
      };
      BoardEngine.prototype.pickBlockSize = function(maxSize) {
        var progress = this.getDifficulty().progress;
        return 1 + this.pickWeightedIndex([ 1 - .8 * progress, 1 + .2 * progress, 1 + 1.6 * progress ].slice(0, maxSize));
      };
      BoardEngine.prototype.prepareSecondRow = function(actions) {
        this.rulesVersion >= 5 && 2 === this.getRiseRowCount(actions) && !this.secondNextPieces.length && (this.secondNextPieces = this.generateAfterNextRow());
      };
      BoardEngine.prototype.generateAfterNextRow = function() {
        var original = this.pieces;
        var future = original.map(function(piece) {
          return __assign(__assign({}, piece), {
            row: piece.row - 1
          });
        });
        this.nextPieces.forEach(function(piece, index) {
          return future.push(__assign(__assign({}, piece), {
            row: exports.BOARD_ROWS - 1,
            id: -index - 1
          }));
        });
        try {
          this.pieces = this.preview(future).pieces;
          return this.generateNextRow();
        } finally {
          this.pieces = original;
        }
      };
      BoardEngine.prototype.createNextRowCandidate = function(targetCells) {
        var _this = this;
        var emptyCells = exports.BOARD_COLS - targetCells;
        var sizes = [];
        var cellsLeft = targetCells;
        while (cellsLeft > 0) {
          var maxSize = Math.min(3, cellsLeft);
          var size = this.rulesVersion >= 5 ? this.pickBlockSize(maxSize) : 1 + Math.floor(this.random() * maxSize);
          sizes.push(size);
          cellsLeft -= size;
        }
        this.rulesVersion >= 6 && this.shuffle(sizes);
        var gaps = new Array(sizes.length + 1).fill(0);
        var heights = this.getColumnStackHeights();
        var leftPressure = 0;
        var rightPressure = 0;
        for (var c = 0; c < exports.BOARD_COLS; c++) c < exports.BOARD_COLS / 2 ? leftPressure += heights[c] : rightPressure += heights[c];
        for (var i = 0; i < emptyCells; i++) {
          var weights = gaps.map(function(_, slot) {
            if (_this.rulesVersion >= 6) return 1;
            var t = gaps.length <= 1 ? .5 : slot / (gaps.length - 1);
            return 1 + leftPressure * (1 - t) + rightPressure * t;
          });
          gaps[this.pickWeightedIndex(weights)]++;
        }
        var pieces = [];
        var col = gaps[0];
        for (var i = 0; i < sizes.length; i++) {
          var size = sizes[i];
          var color = this.pickMoodColor();
          var hasStamp = this.random() < .5;
          pieces.push({
            col: col,
            size: size,
            color: color,
            stampMood: hasStamp ? color : 0,
            stampCell: 0,
            collectibleType: 0,
            collectibleCell: 0
          });
          col += size + gaps[i + 1];
        }
        return {
          pieces: pieces,
          sizes: sizes,
          gaps: gaps,
          movablePieces: this.countMovableNextPieces(pieces)
        };
      };
      BoardEngine.prototype.countMovableNextPieces = function(pieces) {
        var movable = 0;
        for (var i = 0; i < pieces.length; i++) {
          var piece = pieces[i];
          var leftEdge = i > 0 ? pieces[i - 1].col + pieces[i - 1].size : 0;
          var rightEdge = i < pieces.length - 1 ? pieces[i + 1].col : exports.BOARD_COLS;
          (piece.col > leftEdge || piece.col + piece.size < rightEdge) && movable++;
        }
        return movable;
      };
      BoardEngine.prototype.getColumnStackHeights = function() {
        var heights = new Array(exports.BOARD_COLS).fill(0);
        for (var _i = 0, _a = this.pieces; _i < _a.length; _i++) {
          var piece = _a[_i];
          var stack = exports.BOARD_ROWS - piece.row;
          for (var c = piece.col; c < piece.col + piece.size; c++) c >= 0 && c < exports.BOARD_COLS && (heights[c] = Math.max(heights[c], stack));
        }
        return heights;
      };
      BoardEngine.prototype.pickWeightedIndex = function(weights) {
        var total = 0;
        for (var _i = 0, weights_1 = weights; _i < weights_1.length; _i++) {
          var weight = weights_1[_i];
          total += Math.max(0, weight);
        }
        if (total <= 0) return Math.floor(this.random() * weights.length);
        var roll = this.random() * total;
        for (var i = 0; i < weights.length; i++) {
          roll -= Math.max(0, weights[i]);
          if (roll <= 0) return i;
        }
        return weights.length - 1;
      };
      BoardEngine.prototype.shuffle = function(items) {
        var _a;
        for (var index = items.length - 1; index > 0; index--) {
          var other = Math.floor(this.random() * (index + 1));
          _a = [ items[other], items[index] ], items[index] = _a[0], items[other] = _a[1];
        }
        return items;
      };
      BoardEngine.prototype.createPiece = function(row, col, size, color, stampMood, stampCell, collectibleType, collectibleCell) {
        void 0 === stampMood && (stampMood = -1);
        void 0 === stampCell && (stampCell = 0);
        void 0 === collectibleType && (collectibleType = 0);
        void 0 === collectibleCell && (collectibleCell = 0);
        var resolvedStamp = stampMood < 0 ? this.random() < .5 ? color : 0 : stampMood;
        return {
          id: this.nextId++,
          row: row,
          col: col,
          size: size,
          color: color,
          stampMood: resolvedStamp,
          stampCell: resolvedStamp > 0 ? Math.max(0, Math.min(size - 1, stampCell)) : 0,
          collectibleType: collectibleType,
          collectibleCell: collectibleType > 0 ? Math.max(0, Math.min(size - 1, collectibleCell)) : 0
        };
      };
      BoardEngine.prototype.pickMoodColor = function() {
        var pool = [ 1, 2, 3, 4, 5, 6, 1, 3, 5, 7, 8, 9, 10, 7, 9 ];
        this.roundClearedRows >= 12 ? pool = [ 1, 2, 2, 3, 5, 5, 6, 6 ] : this.roundClearedRows >= 7 ? pool = [ 1, 2, 3, 3, 4, 5, 5, 6, 7, 9 ] : this.roundClearedRows >= 3 && (pool = [ 1, 2, 3, 4, 5, 6, 1, 3, 5, 7, 9 ]);
        return pool[Math.floor(this.random() * pool.length)];
      };
      BoardEngine.prototype.random = function() {
        var value = 0 | this.randomState;
        value ^= value << 13;
        value ^= value >>> 17;
        value ^= value << 5;
        this.randomState = value >>> 0;
        return this.randomState / 4294967296;
      };
      BoardEngine.prototype.wouldCreateFullRow = function(piece, offset) {
        var simulated = this.pieces.map(function(item) {
          return __assign({}, item);
        });
        var moved = simulated.find(function(item) {
          return item.id === piece.id;
        });
        if (!moved) return false;
        moved.col += offset;
        var ordered = simulated.slice().sort(function(a, b) {
          return b.row - a.row;
        });
        var _loop_9 = function(falling) {
          var _loop_10 = function() {
            var nextRow = falling.row + 1;
            var blocked = simulated.some(function(other) {
              if (other.id === falling.id || other.row !== nextRow) return false;
              return falling.col < other.col + other.size && falling.col + falling.size > other.col;
            });
            if (blocked) return "break";
            falling.row = nextRow;
          };
          while (falling.row < exports.BOARD_ROWS - 1) {
            var state_2 = _loop_10();
            if ("break" === state_2) break;
          }
        };
        for (var _i = 0, ordered_2 = ordered; _i < ordered_2.length; _i++) {
          var falling = ordered_2[_i];
          _loop_9(falling);
        }
        for (var row = 0; row < exports.BOARD_ROWS; row++) {
          var occupied = new Array(exports.BOARD_COLS).fill(false);
          for (var _a = 0, simulated_1 = simulated; _a < simulated_1.length; _a++) {
            var item = simulated_1[_a];
            if (item.row !== row) continue;
            for (var col = item.col; col < item.col + item.size; col++) occupied[col] = true;
          }
          if (occupied.every(function(value) {
            return value;
          })) return true;
        }
        return false;
      };
      return BoardEngine;
    }();
    exports.default = BoardEngine;
    cc._RF.pop();
  }, {} ],
  BombEffect: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "24f3bIg8JdKsLJyWfnclXeL", "BombEffect");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.playBombEffect = exports.bombPlaybackDuration = exports.bombResolutionDelay = exports.BOMB_CHAIN_INTERVAL = exports.BOMB_PRIME_TIME = void 0;
    var RewardArt_1 = require("./RewardArt");
    exports.BOMB_PRIME_TIME = .14;
    exports.BOMB_CHAIN_INTERVAL = .12;
    function bombResolutionDelay(count) {
      return count > 0 ? .34 + (count - 1) * exports.BOMB_CHAIN_INTERVAL : .2;
    }
    exports.bombResolutionDelay = bombResolutionDelay;
    function bombPlaybackDuration(count) {
      return count > 0 ? 1.18 + (count - 1) * exports.BOMB_CHAIN_INTERVAL : 0;
    }
    exports.bombPlaybackDuration = bombPlaybackDuration;
    function playBombEffect(parent, center, cellSize, delay, onIgnite, alreadyPrimed) {
      void 0 === alreadyPrimed && (alreadyPrimed = false);
      var primeTime = alreadyPrimed ? 0 : exports.BOMB_PRIME_TIME;
      var root = new cc.Node("bombExplosion");
      root.setPosition(center);
      root.setContentSize(3 * cellSize, 3 * cellSize);
      root.zIndex = 80;
      root.opacity = 0;
      parent.addChild(root);
      var half = 1.5 * cellSize;
      var glow = new cc.Node("bombEmberGlow");
      root.addChild(glow);
      var ember = glow.addComponent(cc.Graphics);
      ember.fillColor = new cc.Color(255, 184, 73, 45);
      ember.circle(0, 0, 32);
      ember.fill();
      ember.fillColor = new cc.Color(255, 230, 145, 90);
      ember.circle(0, 0, 21);
      ember.fill();
      cc.tween(glow).delay(delay).to(primeTime, {
        scale: 1.6,
        opacity: 0
      }).start();
      var wave = new cc.Node("bombFireRing");
      root.addChild(wave);
      wave.opacity = 0;
      wave.scale = .12;
      var fire = wave.addComponent(cc.Graphics);
      fire.strokeColor = new cc.Color(246, 111, 32, 38);
      fire.lineWidth = 36;
      fire.circle(0, 0, .69 * half);
      fire.stroke();
      fire.strokeColor = new cc.Color(246, 119, 32, 110);
      fire.lineWidth = 23;
      fire.circle(0, 0, .69 * half);
      fire.stroke();
      fire.strokeColor = new cc.Color(255, 216, 106, 200);
      fire.lineWidth = 9;
      fire.circle(0, 0, .65 * half);
      fire.stroke();
      var _loop_1 = function(index) {
        var angle = index * Math.PI * 2 / 14;
        var radius = half * (.75 + index % 5 * .045);
        var point = function(r, offset) {
          return {
            x: Math.cos(angle + offset) * r,
            y: Math.sin(angle + offset) * r
          };
        };
        var base = point(.58 * half, -.12);
        var outside = point(radius, -.18);
        var tip = point(radius, .04 + index % 3 * .06);
        var inside = point(.68 * half, .16);
        var end = point(.57 * half, .12);
        fire.fillColor = new cc.Color(252, 144 + index % 3 * 16, 47, 185);
        fire.moveTo(base.x, base.y);
        fire.quadraticCurveTo(outside.x, outside.y, tip.x, tip.y);
        fire.quadraticCurveTo(inside.x, inside.y, end.x, end.y);
        fire.close();
        fire.fill();
      };
      for (var index = 0; index < 14; index++) _loop_1(index);
      cc.tween(wave).delay(delay + primeTime).to(.025, {
        opacity: 255
      }).to(.18, {
        scale: 1.02,
        opacity: 210
      }, {
        easing: "quadOut"
      }).to(.18, {
        scale: 1.12,
        opacity: 0
      }).start();
      var flash = new cc.Node("bombCoreFlash");
      root.addChild(flash);
      flash.opacity = 0;
      flash.scale = .25;
      var light = flash.addComponent(cc.Graphics);
      light.fillColor = new cc.Color(255, 189, 61, 120);
      light.circle(0, 0, 62);
      light.fill();
      light.fillColor = new cc.Color(255, 230, 146, 220);
      light.circle(0, 0, 39);
      light.fill();
      light.fillColor = new cc.Color(255, 255, 236, 255);
      light.circle(0, 0, 22);
      light.fill();
      cc.tween(flash).delay(delay + primeTime).to(.025, {
        scale: .8,
        opacity: 255
      }).to(.14, {
        scale: 1.35,
        opacity: 0
      }, {
        easing: "quadOut"
      }).start();
      var sparks = new cc.Node("bombSparks");
      root.addChild(sparks);
      sparks.scale = .2;
      sparks.opacity = 0;
      var rays = sparks.addComponent(cc.Graphics);
      rays.fillColor = new cc.Color(255, 233, 151, 250);
      for (var index = 0; index < 12; index++) {
        var angle = index * Math.PI / 6;
        var radius = 66 + index % 3 * 12;
        rays.moveTo(23 * Math.cos(angle - .055), 23 * Math.sin(angle - .055));
        rays.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
        rays.lineTo(23 * Math.cos(angle + .055), 23 * Math.sin(angle + .055));
        rays.close();
        rays.fill();
      }
      cc.tween(sparks).delay(delay + primeTime).to(.025, {
        opacity: 255
      }).to(.23, {
        scale: 1.1,
        opacity: 0
      }, {
        easing: "quadOut"
      }).start();
      var stem = new cc.Node("bombCloudStem");
      root.addChild(stem);
      stem.opacity = 0;
      stem.scaleX = .55;
      stem.scaleY = .2;
      var plume = stem.addComponent(cc.Graphics);
      plume.fillColor = new cc.Color(180, 118, 57, 160);
      plume.ellipse(0, 22, 17, 30);
      plume.fill();
      plume.ellipse(-9, 42, 12, 19);
      plume.fill();
      plume.ellipse(9, 42, 12, 19);
      plume.fill();
      plume.fillColor = new cc.Color(255, 213, 119, 190);
      plume.ellipse(-3, 21, 9, 24);
      plume.fill();
      cc.tween(stem).delay(delay + primeTime + .035).to(.09, {
        opacity: 210,
        scaleX: .9,
        scaleY: 1
      }, {
        easing: "quadOut"
      }).to(.38, {
        y: 25,
        scaleX: 1.15,
        scaleY: 1.3,
        opacity: 0
      }).start();
      var cap = new cc.Node("bombMushroomCap");
      root.addChild(cap);
      cap.setPosition(0, 10);
      cap.scaleX = .3;
      cap.scaleY = .25;
      cap.opacity = 0;
      var cloud = cap.addComponent(cc.Graphics);
      cloud.fillColor = new cc.Color(158, 109, 62, 205);
      cloud.ellipse(-31, -5, 28, 22);
      cloud.fill();
      cloud.ellipse(0, 5, 42, 29);
      cloud.fill();
      cloud.ellipse(31, -5, 28, 22);
      cloud.fill();
      cloud.fillColor = new cc.Color(235, 165, 79, 235);
      cloud.ellipse(-29, 2, 24, 19);
      cloud.fill();
      cloud.ellipse(0, 12, 37, 25);
      cloud.fill();
      cloud.ellipse(29, 2, 24, 19);
      cloud.fill();
      cloud.fillColor = new cc.Color(255, 225, 159, 235);
      cloud.ellipse(-20, 13, 19, 13);
      cloud.fill();
      cloud.ellipse(3, 22, 25, 15);
      cloud.fill();
      cloud.ellipse(27, 12, 14, 11);
      cloud.fill();
      cc.tween(cap).delay(delay + primeTime + .04).to(.1, {
        y: 32,
        scaleX: .9,
        scaleY: .75,
        opacity: 255
      }, {
        easing: "quadOut"
      }).to(.24, {
        y: 66,
        scaleX: 1.22,
        scaleY: 1.05,
        opacity: 170
      }, {
        easing: "sineOut"
      }).to(.18, {
        y: 83,
        scaleX: 1.4,
        scaleY: 1.15,
        opacity: 0
      }).start();
      var body = RewardArt_1.createBombBadge(root);
      body.zIndex = 10;
      body.scale = 1.1;
      if (alreadyPrimed) {
        body.active = false;
        cc.tween(root).delay(delay).call(onIgnite).start();
      } else cc.tween(body).delay(delay).to(.06, {
        scale: 1.4,
        angle: -7
      }, {
        easing: "quadOut"
      }).to(primeTime - .06, {
        scale: 1.65,
        angle: 6
      }, {
        easing: "quadIn"
      }).call(onIgnite).to(.035, {
        scale: 1.9,
        opacity: 0
      }).start();
      cc.tween(root).delay(delay).to(.055, {
        opacity: 255
      }).delay(primeTime + .395).to(.22, {
        opacity: 0
      }).call(function() {
        return root.destroy();
      }).start();
    }
    exports.playBombEffect = playBombEffect;
    cc._RF.pop();
  }, {
    "./RewardArt": "RewardArt"
  } ],
  CloudService: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0d638RpiplJfqXQ3lvZfpWL", "CloudService");
    "use strict";
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.cloudService = exports.isLocalApiOverrideActive = exports.getEnvName = exports.getApiBase = void 0;
    var PlatformAdapter_1 = require("./PlatformAdapter");
    var BoardEngine_1 = require("../dataModule/BoardEngine");
    var MoodBeanConfig_1 = require("../dataModule/MoodBeanConfig");
    var PRODUCTION_API_BASE = "https://api.tcjstory.cn/v1/cocos-zyx";
    var STAGING_API_BASE = "https://staging-api.tcjstory.cn/v1/cocos-zyx";
    function getApiBase() {
      var wxApi = PlatformAdapter_1.getWxApi();
      if (wxApi && "function" === typeof wxApi.request) try {
        var accountInfo = wxApi.getAccountInfoSync && wxApi.getAccountInfoSync();
        var envVersion = accountInfo && accountInfo.miniProgram ? accountInfo.miniProgram.envVersion : "release";
        if ("release" === envVersion) return PRODUCTION_API_BASE;
        return STAGING_API_BASE;
      } catch (error) {
        return PRODUCTION_API_BASE;
      }
      if ((true, true) && "undefined" !== typeof location && /^(localhost|127\.0\.0\.1)$/.test(location.hostname) && /(?:^|[?&])localApi=1(?:&|$)/.test(location.search)) return "http://127.0.0.1:8080/v1/cocos-zyx";
      return STAGING_API_BASE;
    }
    exports.getApiBase = getApiBase;
    function getEnvName() {
      return getApiBase() === PRODUCTION_API_BASE ? "production" : "staging";
    }
    exports.getEnvName = getEnvName;
    function isLocalApiOverrideActive() {
      return "production" !== getEnvName();
    }
    exports.isLocalApiOverrideActive = isLocalApiOverrideActive;
    var CloudService = function() {
      function CloudService() {
        this.token = "";
        this.deviceId = "";
      }
      Object.defineProperty(CloudService, "instance", {
        get: function() {
          this._instance || (this._instance = new CloudService());
          return this._instance;
        },
        enumerable: false,
        configurable: true
      });
      CloudService.prototype.bootstrap = function(nickname, avatarUrl) {
        return __awaiter(this, void 0, Promise, function() {
          var loginCode, data;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              this.ensureDeviceId();
              return [ 4, this.requestWeChatLoginCode() ];

             case 1:
              loginCode = _a.sent();
              return [ 4, this.request("/players/bootstrap", "POST", {
                deviceId: this.deviceId,
                loginCode: loginCode,
                nickname: nickname,
                avatarUrl: avatarUrl
              }, false) ];

             case 2:
              data = _a.sent();
              this.token = data.token;
              cc.sys.localStorage.setItem("zyx_cloud_token", this.token);
              return [ 2, data.profile ];
            }
          });
        });
      };
      CloudService.prototype.updateWeChatProfile = function(nickname, avatarUrl) {
        return __awaiter(this, void 0, Promise, function() {
          var data;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/players/profile", "POST", {
                nickname: nickname,
                avatarUrl: avatarUrl
              }, true) ];

             case 1:
              data = _a.sent();
              return [ 2, data.profile ];
            }
          });
        });
      };
      CloudService.prototype.startRound = function(roundId, replacement) {
        return __awaiter(this, void 0, Promise, function() {
          var health, error, result, error;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/health", "GET", null, false) ];

             case 1:
              health = _a.sent();
              if (!health.capabilities || health.capabilities.indexOf("bean-collection-progress") < 0 || health.capabilities.indexOf("adaptive-combo-v2") < 0 || health.capabilities.indexOf("bean-collection-1pct") < 0 || health.capabilities.indexOf("bean-tool-shop") < 0 || health.capabilities.indexOf("difficulty-ramp-2x") < 0 || health.capabilities.indexOf("difficulty-pressure-v4") < 0 || health.capabilities.indexOf("rising-rows-v5") < 0 || health.capabilities.indexOf("balloon-rescue-v6") < 0 || health.capabilities.indexOf("balloon-blast-v7") < 0 || health.capabilities.indexOf("random-rescue-v8") < 0 || health.capabilities.indexOf("rescue-scoring-v9") < 0 || health.capabilities.indexOf("heart-rescue-v10") < 0 || health.capabilities.indexOf("round-checkpoints-v1") < 0 || health.capabilities.indexOf("revive-card-v11") < 0 || health.capabilities.indexOf("round-tools-lightning-v12") < 0) {
                error = new Error("\u6e38\u620f\u670d\u52a1\u66f4\u65b0\u4e2d\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
                error.businessCode = "COLLECTION_RULE_UNSUPPORTED";
                throw error;
              }
              return [ 4, this.request("/games/start", "POST", __assign({
                roundId: roundId,
                collectionRule: MoodBeanConfig_1.MOOD_COLLECTION_RULE,
                rulesVersion: BoardEngine_1.BOARD_RULES_VERSION,
                resumeProtocol: 1
              }, replacement), true) ];

             case 2:
              result = _a.sent();
              if (result.collectionRule !== MoodBeanConfig_1.MOOD_COLLECTION_RULE || result.rulesVersion !== BoardEngine_1.BOARD_RULES_VERSION || "string" !== typeof result.sessionToken || !result.sessionToken) {
                error = new Error("\u6e38\u620f\u670d\u52a1\u66f4\u65b0\u4e2d\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
                error.businessCode = "COLLECTION_RULE_UNSUPPORTED";
                throw error;
              }
              return [ 2, result ];
            }
          });
        });
      };
      CloudService.prototype.useReviveCard = function(record) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/games/revive-card", "POST", record, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.getActiveRound = function() {
        return __awaiter(this, void 0, Promise, function() {
          var result;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/games/active", "GET", null, true) ];

             case 1:
              result = _a.sent();
              return [ 2, result.round || null ];
            }
          });
        });
      };
      CloudService.prototype.saveRoundProgress = function(record) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/games/checkpoint", "POST", record, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.resumeRound = function(record) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/games/resume", "POST", record, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.claimSharedStamina = function(claimId) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/stamina/share-claim", "POST", {
                claimId: claimId
              }, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.submitSettlement = function(roundId, startedAt, endedAt, score, collectedMoodBeanCount, actions, sessionToken) {
        return __awaiter(this, void 0, Promise, function() {
          var data;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/games/settlements", "POST", {
                roundId: roundId,
                startedAt: startedAt,
                endedAt: endedAt,
                score: score,
                collectedMoodBeanCount: collectedMoodBeanCount,
                actions: actions || [],
                sessionToken: sessionToken
              }, true) ];

             case 1:
              data = _a.sent();
              return [ 2, data ];
            }
          });
        });
      };
      CloudService.prototype.getLeaderboard = function(type) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/leaderboards?type=" + type, "GET", null, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.exchangeTool = function(actionId, item) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/shop/exchanges", "POST", {
                actionId: actionId,
                item: item
              }, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.useTool = function(roundId, item, actionIndex, target, sessionToken) {
        return __awaiter(this, void 0, Promise, function() {
          var actionId;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              actionId = roundId + ":use:" + actionIndex;
              return [ 4, this.request("/games/tools/use", "POST", {
                roundId: roundId,
                item: item,
                actionIndex: actionIndex,
                target: target,
                actionId: actionId,
                sessionToken: sessionToken
              }, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.claimToolReward = function(roundId, item, actionId, sessionToken) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request("/games/tools/reward", "POST", {
                roundId: roundId,
                item: item,
                actionId: actionId,
                sessionToken: sessionToken
              }, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.postAuthenticated = function(path, body) {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.request(path, "POST", body, true) ];

             case 1:
              return [ 2, _a.sent() ];
            }
          });
        });
      };
      CloudService.prototype.requestWeChatLoginCode = function() {
        var wxApi = PlatformAdapter_1.getWxApi();
        if (!wxApi || "function" !== typeof wxApi.login) return Promise.resolve("");
        return new Promise(function(resolve, reject) {
          wxApi.login({
            success: function(result) {
              result && result.code ? resolve(String(result.code)) : reject(new Error(result && result.errMsg ? result.errMsg : "\u5fae\u4fe1\u767b\u5f55\u672a\u8fd4\u56de\u6709\u6548\u51ed\u8bc1"));
            },
            fail: function(error) {
              return reject(new Error(error && error.errMsg ? error.errMsg : "\u5fae\u4fe1\u767b\u5f55\u5931\u8d25"));
            }
          });
        });
      };
      CloudService.prototype.ensureDeviceId = function() {
        this.token = cc.sys.localStorage.getItem("zyx_cloud_token") || "";
        this.deviceId = cc.sys.localStorage.getItem("zyx_cloud_device_id") || "";
        if (this.deviceId) return;
        this.deviceId = "device_" + Date.now() + "_" + Math.floor(1e9 * Math.random());
        cc.sys.localStorage.setItem("zyx_cloud_device_id", this.deviceId);
      };
      CloudService.prototype.request = function(path, method, body, authenticated, _allowAuthRetry) {
        void 0 === _allowAuthRetry && (_allowAuthRetry = true);
        return __awaiter(this, void 0, Promise, function() {
          var headers, sentToken, checkAccount, url, wxApi, result, error_1;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              this.ensureDeviceId();
              headers = {
                "Content-Type": "application/json"
              };
              authenticated && this.token && (headers.Authorization = "Bearer " + this.token);
              sentToken = this.token;
              checkAccount = function() {
                if (authenticated && (cc.sys.localStorage.getItem("zyx_cloud_token") || "") !== sentToken) {
                  var error = new Error("\u8d26\u53f7\u5df2\u5207\u6362\uff0c\u8bf7\u91cd\u65b0\u8fdb\u5165\u5f53\u524d\u64cd\u4f5c");
                  error.businessCode = "ACCOUNT_CHANGED";
                  throw error;
                }
              };
              url = "" + getApiBase() + path;
              wxApi = PlatformAdapter_1.getWxApi();
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 6, , 10 ]);
              if (!(wxApi && "function" === typeof wxApi.request)) return [ 3, 3 ];
              return [ 4, this.requestWithWeChat(wxApi, url, method, headers, body) ];

             case 2:
              result = _a.sent();
              return [ 3, 5 ];

             case 3:
              return [ 4, this.requestWithFetch(url, method, headers, body) ];

             case 4:
              result = _a.sent();
              _a.label = 5;

             case 5:
              return [ 3, 10 ];

             case 6:
              error_1 = _a.sent();
              checkAccount();
              if (!(authenticated && _allowAuthRetry && 401 === Number(error_1.status))) return [ 3, 9 ];
              return [ 4, this.bootstrap("", "") ];

             case 7:
              _a.sent();
              return [ 4, this.request(path, method, body, authenticated, false) ];

             case 8:
              return [ 2, _a.sent() ];

             case 9:
              throw error_1;

             case 10:
              checkAccount();
              return [ 2, result ];
            }
          });
        });
      };
      CloudService.prototype.requestWithFetch = function(url, method, headers, body) {
        return __awaiter(this, void 0, Promise, function() {
          var controller, timer, response, payload, error;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if ("function" !== typeof fetch) throw new Error("\u5f53\u524d\u5e73\u53f0\u4e0d\u652f\u6301\u7f51\u7edc\u8bf7\u6c42");
              controller = "undefined" !== typeof AbortController ? new AbortController() : null;
              timer = controller ? setTimeout(function() {
                return controller.abort();
              }, 1e4) : null;
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, , 4, 5 ]);
              return [ 4, fetch(url, {
                method: method,
                headers: headers,
                body: body ? JSON.stringify(body) : void 0,
                signal: controller ? controller.signal : void 0
              }) ];

             case 2:
              response = _a.sent();
              return [ 4, response.json() ];

             case 3:
              payload = _a.sent();
              return [ 3, 5 ];

             case 4:
              null !== timer && clearTimeout(timer);
              return [ 7 ];

             case 5:
              if (!response.ok || 0 !== payload.code) {
                error = new Error(payload.message || "\u4e91\u7aef\u670d\u52a1\u6682\u4e0d\u53ef\u7528");
                error.status = response.status;
                payload && "string" === typeof payload.errorCode && payload.errorCode.length > 0 && (error.businessCode = payload.errorCode);
                payload && payload.data && payload.data.stamina && (error.stamina = payload.data.stamina);
                throw error;
              }
              return [ 2, payload.data ];
            }
          });
        });
      };
      CloudService.prototype.requestWithWeChat = function(wxApi, url, method, headers, body) {
        return new Promise(function(resolve, reject) {
          wxApi.request({
            url: url,
            method: method,
            header: headers,
            data: body || void 0,
            timeout: 1e4,
            success: function(response) {
              var payload = response && response.data;
              var statusCode = Number(response && response.statusCode) || 0;
              if (statusCode < 200 || statusCode >= 300 || !payload || 0 !== payload.code) {
                var error = new Error(payload && payload.message ? payload.message : "\u4e91\u7aef\u670d\u52a1\u6682\u4e0d\u53ef\u7528");
                error.status = statusCode;
                payload && "string" === typeof payload.errorCode && payload.errorCode.length > 0 && (error.businessCode = payload.errorCode);
                payload && payload.data && payload.data.stamina && (error.stamina = payload.data.stamina);
                reject(error);
                return;
              }
              resolve(payload.data);
            },
            fail: function(error) {
              return reject(new Error(error && error.errMsg ? error.errMsg : "\u7f51\u7edc\u8fde\u63a5\u5931\u8d25"));
            }
          });
        });
      };
      return CloudService;
    }();
    exports.default = CloudService;
    exports.cloudService = CloudService.instance;
    cc._RF.pop();
  }, {
    "../dataModule/BoardEngine": "BoardEngine",
    "../dataModule/MoodBeanConfig": "MoodBeanConfig",
    "./PlatformAdapter": "PlatformAdapter"
  } ],
  DangerGlow: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d840d96MylGZY3OFoyfCZhT", "DangerGlow");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createDangerGlow = void 0;
    var frame = null;
    function createDangerGlow(parent, width, height) {
      var fullWidth = width + 136, fullHeight = height + 136;
      if (!frame) {
        var w = 384, h = Math.round(w * fullHeight / fullWidth);
        var rgba = new Uint8Array(w * h * 4);
        var radius = 24;
        for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
          var px = Math.abs((x + .5) / w * fullWidth - fullWidth / 2);
          var py = Math.abs((y + .5) / h * fullHeight - fullHeight / 2);
          var qx = px - (width / 2 + 6 - radius), qy = py - (height / 2 + 6 - radius);
          var distance = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - radius;
          var d = Math.abs(distance);
          var core = Math.exp(-d * d / 14);
          var bloom = Math.exp(-d / (distance < 0 ? 19 : 25));
          var index = 4 * (y * w + x);
          rgba[index] = 255;
          rgba[index + 1] = Math.round(28 + 105 * core);
          rgba[index + 2] = Math.round(42 + 70 * core);
          rgba[index + 3] = Math.round(255 * Math.min(1, .8 * core + .65 * bloom));
        }
        var texture = new cc.Texture2D();
        texture.initWithData(rgba, cc.Texture2D.PixelFormat.RGBA8888, w, h);
        frame = new cc.SpriteFrame(texture);
      }
      var node = new cc.Node("roundRescueBoardHalo");
      parent.addChild(node);
      node.setContentSize(fullWidth, fullHeight);
      node.zIndex = 105;
      var sprite = node.addComponent(cc.Sprite);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      sprite.spriteFrame = frame;
      cc.tween(node).repeatForever(cc.tween().to(.55, {
        opacity: 165
      }, {
        easing: "sineInOut"
      }).to(.55, {
        opacity: 255
      }, {
        easing: "sineInOut"
      })).start();
      return node;
    }
    exports.createDangerGlow = createDangerGlow;
    cc._RF.pop();
  }, {} ],
  GameMainScene: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6cdb6JEOW9Nxa5wcoF5wJIY", "GameMainScene");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var UIManager_1 = require("./manager/UIManager");
    var PlatformAdapter_1 = require("./manager/PlatformAdapter");
    var CloudService_1 = require("./manager/CloudService");
    var RoundProgress_1 = require("./manager/RoundProgress");
    var SettingsPanel_1 = require("./manager/SettingsPanel");
    var ZyxGameModule_1 = require("./dataModule/ZyxGameModule");
    var ZyxGame_1 = require("./zyxGame/ZyxGame");
    var MoodArt_1 = require("./zyxGame/MoodArt");
    var LeaderboardPanel_1 = require("./zyxGame/LeaderboardPanel");
    var HomeFriendRanking_1 = require("./zyxGame/HomeFriendRanking");
    var GlyphFactory_1 = require("./zyxGame/GlyphFactory");
    var WeChatFriends_1 = require("./manager/WeChatFriends");
    var ShopPanel_1 = require("./zyxGame/ShopPanel");
    var AssetLoader_1 = require("./manager/AssetLoader");
    var ShareReward_1 = require("./manager/ShareReward");
    var AudioManager_1 = require("./manager/AudioManager");
    var GmAccess_1 = require("./manager/GmAccess");
    var SettlementSync_1 = require("./manager/SettlementSync");
    var ResponsiveLayout_1 = require("./manager/ResponsiveLayout");
    var ccclass = cc._decorator.ccclass;
    var PENDING_START_ROUND_ID_KEY = "zyx_pending_start_round_id";
    var PENDING_STAMINA_SHARE_ID_KEY = "zyx_pending_stamina_share_id";
    var CLIENT_VERSION = "2026.11.17.01";
    var GameMainScene = function(_super) {
      __extends(GameMainScene, _super);
      function GameMainScene() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.screen = null;
        _this.backdrop = null;
        _this.profileNameLabel = null;
        _this.profileAvatarContent = null;
        _this.profileAvatarUrl = "";
        _this.currentCloudProfile = null;
        _this.profileAuthorizationInFlight = false;
        _this.profileLevelLabel = null;
        _this.profileExperienceFill = null;
        _this.profileExperienceLabel = null;
        _this.profileExperienceTrackWidth = 238;
        _this.profileExperienceFillWidth = 210;
        _this.profileExperienceFillLeft = -133;
        _this.homeMoodBeanIcon = null;
        _this.homeDemoLayer = null;
        _this.homeDemoClock = null;
        _this.homeDemoPlaying = false;
        _this.startHomeDemoLoop = null;
        _this.homeFriendRanking = null;
        _this.startButton = null;
        _this.startStaminaRecoveryLabel = null;
        _this.startStaminaTimer = null;
        _this.startStaminaSuffix = null;
        _this.moodBeanCountLabel = null;
        _this.moodBeanCountCard = null;
        _this.cloudProfileReady = false;
        _this.cloudProfileBootstrapPromise = null;
        _this.gameAssetsLoading = false;
        _this.stamina = null;
        _this.serverClockOffsetMs = 0;
        _this.staminaLabel = null;
        _this.staminaRecoveryLabel = null;
        _this.staminaIcon = null;
        _this.shareClaimInFlight = false;
        _this.activeRoundId = "";
        _this.gameHiddenAt = 0;
        _this.settlementReceipts = {};
        _this.pendingSettlementPresentation = null;
        _this.wxShowHandler = null;
        _this.wxNetworkHandler = null;
        _this.viewportResizeHandler = null;
        _this.viewportRefreshPending = false;
        return _this;
      }
      GameMainScene.prototype.onLoad = function() {
        var _this = this;
        AudioManager_1.audioManager.enterScene("silent");
        var balloonPreview = (true, true) && "undefined" !== typeof window && /(?:^|[?&])balloonDemo=1(?:&|$)/.test(window.location.search);
        AudioManager_1.audioManager.setPreviewMuted(balloonPreview);
        UIManager_1.uimanager.init(this.node);
        ShareReward_1.registerSystemShare();
        cc.debug.setDisplayStats(false);
        var canvas = this.node.getComponent(cc.Canvas);
        canvas && this.configureCanvas(canvas);
        if (GmAccess_1.isGmEnvironmentAvailable()) {
          var gm = require("./gm/GmBubble");
          gm.attachGmBubble(this.node, {
            refreshInventoryDisplays: function() {
              return _this.refreshGmInventoryDisplays();
            },
            applyServerProfile: function(profile) {
              return _this.applyCloudProfile(profile);
            },
            ensureCloudProfileReady: function() {
              return _this.ensureCloudProfileReadyForGm();
            }
          });
        }
        var wxApi = PlatformAdapter_1.getWxApi();
        if (wxApi) {
          if ("function" === typeof wxApi.onShow) {
            this.wxShowHandler = function() {
              _this.refreshCloudProfile().then(function() {
                return _this.flushPendingRoundSettlements();
              });
              void RoundProgress_1.roundProgress.sync(true);
            };
            wxApi.onShow(this.wxShowHandler);
          }
          if ("function" === typeof wxApi.onNetworkStatusChange) {
            this.wxNetworkHandler = function(res) {
              if (res && res.isConnected) {
                void RoundProgress_1.roundProgress.sync(true);
                _this.refreshCloudProfile().then(function() {
                  return _this.flushPendingRoundSettlements();
                });
              }
            };
            wxApi.onNetworkStatusChange(this.wxNetworkHandler);
          }
          if ("function" === typeof wxApi.onWindowResize) {
            this.viewportResizeHandler = function() {
              return _this.scheduleViewportRefresh();
            };
            wxApi.onWindowResize(this.viewportResizeHandler);
          }
        }
        this.viewportResizeHandler || (this.viewportResizeHandler = function() {
          return _this.scheduleViewportRefresh();
        });
        "undefined" !== typeof window && "function" === typeof window.addEventListener && window.addEventListener("resize", this.viewportResizeHandler);
        cc.game.on(cc.game.EVENT_HIDE, this.saveBeforeHide, this);
        cc.game.on(cc.game.EVENT_SHOW, this.restoreAfterShow, this);
        RoundProgress_1.roundProgress.onStorageFailure = function() {
          return UIManager_1.uimanager.showToast("\u672c\u673a\u5b58\u50a8\u7a7a\u95f4\u4e0d\u8db3\uff0c\u8bf7\u4fdd\u6301\u8054\u7f51\u4fdd\u5b58\u8fdb\u5ea6");
        };
        RoundProgress_1.roundProgress.onConflict = function() {
          _this.enterHome(function() {
            return UIManager_1.uimanager.showModal("\u8fdb\u5ea6\u5df2\u66f4\u65b0", "\u8fd9\u5c40\u5df2\u5728\u522b\u5904\u66f4\u65b0\u6216\u7ed3\u675f\u3002\n\u56de\u5230\u9996\u9875\u786e\u8ba4\u6700\u65b0\u8fdb\u5ea6\u540e\uff0c\u518d\u63a5\u7740\u73a9\u5427\u3002", [ {
              text: "\u77e5\u9053\u4e86",
              color: UIManager_1.BUTTON_COLORS.green,
              onClick: function() {
                return;
              }
            } ]);
          });
          _this.activeRoundId = "";
        };
        this.schedule(this.updateStaminaStatus, 1);
      };
      GameMainScene.prototype.start = function() {
        var _this = this;
        if (cc.dynamicAtlasManager) {
          cc.dynamicAtlasManager.enabled = false;
          cc.dynamicAtlasManager.reset();
        }
        AssetLoader_1.prepareTypography().then(function() {
          if (!cc.isValid(_this.node)) return;
          UIManager_1.uimanager.refreshTypography(_this.node);
          _this.launch();
        }).catch(function(error) {
          cc.warn("[\u5b57\u4f53] \u4f7f\u7528\u53ef\u8bfb\u5b57\u4f53\u7ee7\u7eed\u542f\u52a8", error);
          cc.isValid(_this.node) && _this.launch();
        });
      };
      GameMainScene.prototype.launch = function() {
        var _this = this;
        var search = "undefined" !== typeof window && window.location && "string" === typeof window.location.search ? window.location.search : "";
        var seedMatch = search.match(/[?&]seed=(\d+)/);
        ZyxGameModule_1.zyxGameModule.setRoundSeedOverride(seedMatch ? Number(seedMatch[1]) : 0);
        this.showLaunchLoading();
        this.bootstrapCloudProfile().then(function() {
          return __awaiter(_this, void 0, void 0, function() {
            var local_1, _1, active, _a, previewHome, started;
            var _this = this;
            return __generator(this, function(_b) {
              switch (_b.label) {
               case 0:
                if (!(!this.cloudProfileReady && this.currentCloudProfile)) return [ 3, 4 ];
                local_1 = RoundProgress_1.roundProgress.getOfflineRound();
                if (!(local_1 && !ZyxGameModule_1.zyxGameModule.getPendingRoundSettlements().some(function(record) {
                  return record.roundId === local_1.roundId;
                }))) return [ 3, 4 ];
                _b.label = 1;

               case 1:
                _b.trys.push([ 1, 3, , 4 ]);
                return [ 4, AssetLoader_1.prepareFeature("game") ];

               case 2:
                _b.sent();
                this.enterRestoredGame(local_1);
                return [ 2 ];

               case 3:
                _1 = _b.sent();
                return [ 3, 4 ];

               case 4:
                return [ 4, this.flushPendingRoundSettlements() ];

               case 5:
                _b.sent();
                if (!this.cloudProfileReady) return [ 3, 7 ];
                return [ 4, CloudService_1.cloudService.getActiveRound().catch(function() {
                  return null;
                }) ];

               case 6:
                _a = _b.sent();
                return [ 3, 8 ];

               case 7:
                _a = null;
                _b.label = 8;

               case 8:
                active = _a;
                if (!(active && (!active.mode || "main" === active.mode) && !ZyxGameModule_1.zyxGameModule.getPendingRoundSettlements().some(function(record) {
                  return record.roundId === active.roundId;
                }))) return [ 3, 10 ];
                return [ 4, this.resumeSavedRound(active) ];

               case 9:
                _b.sent();
                return [ 2 ];

               case 10:
                previewHome = (true, true) && /(?:^|[?&])home=1(?:&|$)/.test(search);
                if (!(search.indexOf("autostart=1") >= 0 || !previewHome && ZyxGameModule_1.zyxGameModule.shouldEnterGameOnLaunch())) return [ 3, 12 ];
                return [ 4, this.startGame(true) ];

               case 11:
                started = _b.sent();
                started || this.screen && "home" === this.screen.name || this.enterHome(function() {
                  _this.stamina && _this.getStaminaPreview().current < 1 && _this.showStaminaEmptyModal();
                });
                return [ 2 ];

               case 12:
                this.enterHome();
                return [ 2 ];
              }
            });
          });
        });
      };
      GameMainScene.prototype.saveBeforeHide = function() {
        var game = this.screen && this.screen.getComponent(ZyxGame_1.default);
        if (game) {
          game.captureProgress(true);
          this.gameHiddenAt || (this.gameHiddenAt = Date.now());
        }
      };
      GameMainScene.prototype.restoreAfterShow = function() {
        var game = this.screen && this.screen.getComponent(ZyxGame_1.default);
        if (game && this.gameHiddenAt) {
          game.resumeAfterBackground(Math.max(0, Date.now() - this.gameHiddenAt));
          game.captureProgress(true);
        }
        this.gameHiddenAt = 0;
      };
      GameMainScene.prototype.showResumePrompt = function(active, onLaunch) {
        var _this = this;
        var savedAt = new Date(active.updatedAt);
        var when = savedAt.getMonth() + 1 + "\u6708" + savedAt.getDate() + "\u65e5 " + String(savedAt.getHours()).padStart(2, "0") + ":" + String(savedAt.getMinutes()).padStart(2, "0");
        var details = "\u4e0a\u6b21\u7684\u5c0f\u4e16\u754c\u8fd8\u5728\u7b49\u4f60\uff5e\n\u4e91\u7aef\u5df2\u4fdd\u5b58 " + active.score.toLocaleString() + " \u5206 \xb7 " + active.operationCount + "\u6b65\n" + when + "\n";
        this.showSavedProgressDialog("\u63a5\u7740\u4e0a\u6b21\u7ee7\u7eed\u5427", details + (onLaunch ? "\u7ee7\u7eed\u4e0a\u5c40\u4e0d\u6d88\u8017\u4f53\u529b" : "\u91cd\u5f00\u5c06\u653e\u5f03\u672c\u5c40\uff0c\u5e76\u6d88\u80171\u70b9\u4f53\u529b"), [ {
          text: onLaunch ? "\u7a0d\u540e\u518d\u73a9" : "\u91cd\u65b0\u5f00\u59cb",
          color: UIManager_1.BUTTON_COLORS.yellow,
          icon: function(button) {
            return GlyphFactory_1.decorateActionButton(button, onLaunch ? "back" : "restart");
          },
          onClick: function() {
            onLaunch || void _this.startGame(false, active);
          }
        }, {
          text: "\u7ee7\u7eed\u4e0a\u5c40",
          color: UIManager_1.BUTTON_COLORS.green,
          icon: function(button) {
            return GlyphFactory_1.decorateSettingsActionButton(button, "play");
          },
          onClick: function() {
            void _this.resumeSavedRound(active);
          }
        } ]);
      };
      GameMainScene.prototype.showSavedProgressDialog = function(title, message, actions) {
        var root = UIManager_1.uimanager.showModal(title, "", actions, null, 80, true, true);
        if (!root) return;
        var panel = root.getChildByName("panel");
        for (var _i = 0, _a = [ "panelInner", "modalTitleShadow", "modalTitlePlate" ]; _i < _a.length; _i++) {
          var name = _a[_i];
          panel.getChildByName(name).active = false;
        }
        panel.children.filter(function(node) {
          return !!node.getComponent(cc.Label);
        }).forEach(function(node) {
          return node.active = false;
        });
        var paper = new cc.Color(255, 250, 235);
        UIManager_1.uimanager.drawRect(panel, panel.width, panel.height, paper, 24);
        var outline = panel.getComponent(cc.Graphics);
        outline.lineWidth = 2;
        outline.strokeColor = new cc.Color(176, 148, 112, 190);
        outline.roundRect(-panel.width / 2 + 1, -panel.height / 2 + 1, panel.width - 2, panel.height - 2, 24);
        outline.stroke();
        UIManager_1.uimanager.createLabel(panel, title, 0, 183, 32, MoodArt_1.MOOD_COLORS.cocoa, 440, 46);
        MoodArt_1.createMoodBeanMascot(panel, 0, 100, 64);
        var body = UIManager_1.uimanager.createLabel(panel, message, 0, -27, 24, MoodArt_1.MOOD_COLORS.cocoaSoft, 470, 160);
        body.node.name = "resumeDetails";
        panel.children.filter(function(node) {
          return !!node.getComponent(cc.Button) && "modalCloseButton" !== node.name;
        }).forEach(function(button, index) {
          button.y = -170;
          UIManager_1.uimanager.drawRect(button, button.width, button.height, actions[index].color, 16);
        });
      };
      GameMainScene.prototype.resumeSavedRound = function(active, cloudOnly) {
        void 0 === cloudOnly && (cloudOnly = false);
        return __awaiter(this, void 0, Promise, function() {
          var saved, error_1, code;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.gameAssetsLoading) return [ 2 ];
              this.gameAssetsLoading = true;
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 4, 5, 6 ]);
              UIManager_1.uimanager.showToast("\u6b63\u5728\u627e\u56de\u4e0a\u6b21\u7684\u8fdb\u5ea6\u2026");
              return [ 4, AssetLoader_1.prepareFeature("game") ];

             case 2:
              _a.sent();
              return [ 4, RoundProgress_1.roundProgress.resume(active, cloudOnly) ];

             case 3:
              saved = _a.sent();
              this.enterRestoredGame(saved);
              return [ 3, 6 ];

             case 4:
              error_1 = _a.sent();
              true, true;
              cc.warn("[\u7eed\u73a9] \u6062\u590d\u5931\u8d25", error_1);
              this.screen && "launchLoading" === this.screen.name && this.enterHome();
              code = error_1 && error_1.businessCode;
              [ "PROGRESS_INVALID", "PROGRESS_CONFLICT" ].includes(code) && !cloudOnly ? this.showSavedProgressDialog("\u4e91\u7aef\u8fdb\u5ea6\u8fd8\u5728", "\u672c\u673a\u6700\u8fd1\u7684\u8bb0\u5f55\u6682\u65f6\u672a\u80fd\u6838\u9a8c\u3002\n\u53ef\u4ee5\u56de\u5230\u4e91\u7aef\u6700\u540e\u4fdd\u5b58\u7684\u4f4d\u7f6e\u7ee7\u7eed\u3002\n\u672a\u540c\u6b65\u7684\u64cd\u4f5c\u5c06\u4e0d\u4f1a\u4fdd\u7559\u3002", [ {
                text: "\u5148\u4fdd\u7559\u8bb0\u5f55",
                color: UIManager_1.BUTTON_COLORS.yellow,
                onClick: function() {
                  return;
                }
              }, {
                text: "\u6062\u590d\u4e91\u7aef\u8fdb\u5ea6",
                color: UIManager_1.BUTTON_COLORS.green,
                onClick: function() {
                  void _this.resumeSavedRound(active, true);
                }
              } ]) : UIManager_1.uimanager.showToast("ROUND_SESSION_CONFLICT" === code ? "\u8fdb\u5ea6\u521a\u521a\u66f4\u65b0\uff0c\u8bf7\u518d\u6b21\u70b9\u51fb\u5f00\u59cb\u67e5\u770b" : "\u6682\u65f6\u6ca1\u80fd\u6062\u590d\uff0c\u5b58\u6863\u5df2\u4fdd\u7559\uff0c\u8bf7\u8054\u7f51\u540e\u91cd\u8bd5");
              return [ 3, 6 ];

             case 5:
              this.gameAssetsLoading = false;
              return [ 7 ];

             case 6:
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.enterRestoredGame = function(saved) {
        var _this = this;
        this.activeRoundId = saved.roundId;
        ZyxGameModule_1.zyxGameModule.cloudRoundId = saved.roundId;
        cc.sys.localStorage.removeItem(PENDING_START_ROUND_ID_KEY);
        this.replaceScreen("game");
        this.screen.addComponent(ZyxGame_1.default).initialize(function(request) {
          return _this.handleSettlementExit(request);
        }, function(settlement, startedAt) {
          return _this.submitSettlementToCloud(settlement, startedAt);
        }, function() {
          return _this.startGame(false, "current");
        }, this.currentCloudProfile, saved, function() {
          return _this.enterHome();
        });
      };
      GameMainScene.prototype.showLaunchLoading = function() {
        var _this = this;
        this.replaceScreen("launchLoading");
        var launchScreen = this.screen;
        UIManager_1.uimanager.createLabel(this.screen, "\u6b63\u5728\u51c6\u5907\u5feb\u4e50\u6d88\u9664\u2026", 0, -50, 22, MoodArt_1.MOOD_COLORS.cocoa, 360, 36);
        AssetLoader_1.prepareMoodBeanArt().then(function() {
          if (!cc.isValid(launchScreen) || _this.screen !== launchScreen) return;
          var mascot = MoodArt_1.createMoodBeanMascot(launchScreen, 0, 32, 96);
          cc.tween(mascot).repeatForever(cc.tween().to(.42, {
            y: 46
          }, {
            easing: "sineOut"
          }).to(.42, {
            y: 32
          }, {
            easing: "sineIn"
          })).start();
        }).catch(function(error) {
          return cc.warn("[\u8d44\u6e90] \u542f\u52a8\u89d2\u8272\u6682\u672a\u5c31\u7eea", error);
        });
      };
      GameMainScene.prototype.onDestroy = function() {
        cc.game.off(cc.game.EVENT_HIDE, this.saveBeforeHide, this);
        cc.game.off(cc.game.EVENT_SHOW, this.restoreAfterShow, this);
        RoundProgress_1.roundProgress.onConflict = null;
        RoundProgress_1.roundProgress.onStorageFailure = null;
        AudioManager_1.audioManager.dispose();
        this.unschedule(this.updateStaminaStatus);
        var wxApi = PlatformAdapter_1.getWxApi();
        if (wxApi) {
          this.wxShowHandler && "function" === typeof wxApi.offShow && wxApi.offShow(this.wxShowHandler);
          this.wxNetworkHandler && "function" === typeof wxApi.offNetworkStatusChange && wxApi.offNetworkStatusChange(this.wxNetworkHandler);
          this.viewportResizeHandler && "function" === typeof wxApi.offWindowResize && wxApi.offWindowResize(this.viewportResizeHandler);
        }
        this.viewportResizeHandler && "undefined" !== typeof window && "function" === typeof window.removeEventListener && window.removeEventListener("resize", this.viewportResizeHandler);
        this.wxShowHandler = null;
        this.wxNetworkHandler = null;
      };
      GameMainScene.prototype.configureCanvas = function(canvas) {
        var frame = cc.view.getFrameSize();
        var fitHeight = ResponsiveLayout_1.shouldFitHeight(frame.width, frame.height);
        canvas.fitWidth = !fitHeight;
        canvas.fitHeight = fitHeight;
        cc.view.setDesignResolutionSize(ResponsiveLayout_1.DESIGN_WIDTH, ResponsiveLayout_1.DESIGN_HEIGHT, fitHeight ? cc.ResolutionPolicy.FIXED_HEIGHT : cc.ResolutionPolicy.FIXED_WIDTH);
      };
      GameMainScene.prototype.scheduleViewportRefresh = function() {
        var _this = this;
        if (this.viewportRefreshPending) return;
        this.viewportRefreshPending = true;
        this.scheduleOnce(function() {
          _this.viewportRefreshPending = false;
          var canvas = _this.node.getComponent(cc.Canvas);
          canvas && _this.configureCanvas(canvas);
          _this.scheduleOnce(function() {
            if (!_this.screen || !cc.isValid(_this.screen)) return;
            if ("home" === _this.screen.name) _this.showHome(); else if ("launchLoading" === _this.screen.name) _this.showLaunchLoading(); else {
              _this.renderBackdrop(_this.screen.name);
              _this.applyStageLayout(_this.screen);
            }
          }, 0);
        }, 0);
      };
      GameMainScene.prototype.readViewportSegments = function() {
        if ("undefined" === typeof window) return [];
        try {
          var source = window;
          var reported = source.viewport && source.viewport.segments || source.visualViewport && source.visualViewport.segments || ("function" === typeof source.getWindowSegments ? source.getWindowSegments() : null);
          if (!reported || reported.length < 2) return [];
          return Array.prototype.map.call(reported, function(rect) {
            return {
              x: Number(void 0 !== rect.left ? rect.left : rect.x),
              y: Number(void 0 !== rect.top ? rect.top : rect.y),
              width: Number(rect.width),
              height: Number(rect.height)
            };
          });
        } catch (_) {
          return [];
        }
      };
      GameMainScene.prototype.getStageRegion = function() {
        var full = {
          x: 0,
          y: 0,
          width: cc.winSize.width,
          height: cc.winSize.height
        };
        var segment = ResponsiveLayout_1.chooseViewportSegment(this.readViewportSegments());
        if (!segment || "undefined" === typeof window) return full;
        var frame = cc.view.getFrameSize();
        var viewportWidth = Number(window.innerWidth) || frame.width;
        var viewportHeight = Number(window.innerHeight) || frame.height;
        var world = ResponsiveLayout_1.segmentToWorld(segment, viewportWidth, viewportHeight, full.width, full.height);
        var safe = UIManager_1.uimanager.getSafeAreaMetrics();
        var left = Math.max(world.x - world.width / 2, -full.width / 2 + safe.left);
        var right = Math.min(world.x + world.width / 2, full.width / 2 - safe.right);
        var bottom = Math.max(world.y - world.height / 2, -full.height / 2 + safe.bottom);
        var top = Math.min(world.y + world.height / 2, full.height / 2 - safe.top);
        if (!(right > left) || !(top > bottom)) return full;
        return {
          x: (left + right) / 2,
          y: (top + bottom) / 2,
          width: right - left,
          height: top - bottom
        };
      };
      GameMainScene.prototype.applyStageLayout = function(screen) {
        var game = "game" === screen.name;
        var region = game ? ResponsiveLayout_1.insetGameRegion(this.getStageRegion(), cc.winSize.width, cc.winSize.height, UIManager_1.uimanager.getSafeAreaMetrics()) : this.getStageRegion();
        var stage = ResponsiveLayout_1.calculateStageLayout(region, game);
        screen.setPosition(stage.x, stage.y);
        screen.setContentSize(stage.width, stage.height);
        screen.scale = stage.scale;
        var gameComponent = game ? screen.getComponent(ZyxGame_1.default) : null;
        gameComponent && gameComponent.refreshLayout();
        UIManager_1.uimanager.refreshModalLayout();
      };
      GameMainScene.prototype.renderBackdrop = function(name) {
        this.backdrop && cc.isValid(this.backdrop) && this.backdrop.destroy();
        this.backdrop = new cc.Node("viewportBackdrop");
        this.backdrop.setContentSize(cc.winSize.width, cc.winSize.height);
        this.backdrop.zIndex = -100;
        this.node.addChild(this.backdrop);
        if ("home" === name) {
          MoodArt_1.createMoodCanvasBackground(this.backdrop, cc.winSize.width, cc.winSize.height);
          MoodArt_1.createMoodWatermarkWall(this.backdrop, cc.winSize.width, cc.winSize.height);
        } else "game" === name ? MoodArt_1.createGameRoomBackground(this.backdrop, cc.winSize.width, cc.winSize.height) : UIManager_1.uimanager.createRect(this.backdrop, "launchBackground", cc.winSize.width, cc.winSize.height, new cc.Color(255, 247, 225));
      };
      GameMainScene.prototype.enterHome = function(onReady) {
        var _this = this;
        AudioManager_1.audioManager.enterScene("silent");
        AssetLoader_1.isFeatureReady("home") || this.pendingSettlementPresentation || UIManager_1.uimanager.showToast("\u6b63\u5728\u52a0\u8f7d\u9996\u9875\u2026");
        AssetLoader_1.prepareFeature("home").then(function() {
          _this.showHome();
          onReady && onReady();
        }).catch(function(error) {
          cc.error("\u9996\u9875\u521d\u59cb\u5316\u5931\u8d25", error);
          _this.showResourceLoadFailure("\u9996\u9875", function() {
            return _this.enterHome(onReady);
          });
        });
      };
      GameMainScene.prototype.showHome = function() {
        var _this = this;
        UIManager_1.uimanager.closeModal();
        this.replaceScreen("home");
        ZyxGameModule_1.zyxGameModule.refreshPersistentProgress();
        var width = this.screen.width;
        var height = this.screen.height;
        var safeArea = UIManager_1.uimanager.getSafeAreaMetrics();
        var heightDelta = height - 1334;
        var titleY = 380 + Math.max(0, Math.min(80, .25 * heightDelta));
        var friendY = -104 + Math.max(0, Math.min(28, .08 * heightDelta));
        var tipY = -height / 2 + safeArea.bottom + 68;
        var startY = -475 - Math.max(-14, Math.min(32, .09 * heightDelta));
        var profileY = height / 2 - Math.max(32, safeArea.top) - 64;
        var profile = this.createHomeProfile(profileY);
        this.createMoodBeanCount(profile);
        this.bootstrapCloudProfile();
        this.flushPendingRoundSettlements();
        this.createHomeTitleLogo(titleY);
        var title = this.screen.getChildByName("homeTitleLogo");
        var demoCenterY = (title.y - title.height / 2 + friendY + 230) / 2;
        this.createHomeMoodScene(demoCenterY - 42);
        var friendModule = new cc.Node("homeFriendRanking");
        friendModule.setPosition(0, friendY);
        friendModule.zIndex = 90;
        this.screen.addChild(friendModule);
        this.homeFriendRanking = friendModule.addComponent(HomeFriendRanking_1.default);
        this.createHomeFeatureEntries();
        this.createHomeSettingsEntry();
        this.createHomeRotatingTip(tipY);
        var version = UIManager_1.uimanager.createLabel(this.screen, "v" + CLIENT_VERSION, width / 2 - safeArea.right - 22, -height / 2 + safeArea.bottom + 22, 16, MoodArt_1.MOOD_COLORS.cocoaSoft, 240, 28);
        version.node.name = "clientVersion";
        version.node.setAnchorPoint(1, .5);
        version.horizontalAlign = cc.Label.HorizontalAlign.RIGHT;
        version.enableWrapText = false;
        this.startButton = UIManager_1.uimanager.createButton(this.screen, "\u5f00 \u59cb", 0, startY, 462, 136, UIManager_1.BUTTON_COLORS.green, function() {
          return _this.startGame();
        }, 24);
        this.decorateStartButton();
        var countdown = new cc.Node("startStaminaCountdown");
        this.startButton.addChild(countdown);
        countdown.setPosition(0, this.startButton.height / 2 + 25);
        var countdownLayout = countdown.addComponent(cc.Layout);
        countdownLayout.type = cc.Layout.Type.HORIZONTAL;
        countdownLayout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
        countdownLayout.spacingX = 2;
        this.startStaminaRecoveryLabel = UIManager_1.uimanager.createLabel(countdown, "", 0, 0, 21, MoodArt_1.MOOD_COLORS.cocoaSoft, 1, 34);
        this.startStaminaTimer = UIManager_1.uimanager.createLabel(countdown, "", 0, 0, 21, new cc.Color(48, 132, 70), 1, 34);
        this.startStaminaSuffix = UIManager_1.uimanager.createLabel(countdown, "", 0, 0, 21, MoodArt_1.MOOD_COLORS.cocoaSoft, 1, 34);
        this.startStaminaTimer.node.color = new cc.Color(48, 132, 70);
        this.startStaminaRecoveryLabel.node.color = this.startStaminaSuffix.node.color = MoodArt_1.MOOD_COLORS.cocoaSoft;
        for (var _i = 0, _a = [ this.startStaminaRecoveryLabel, this.startStaminaTimer, this.startStaminaSuffix ]; _i < _a.length; _i++) {
          var label = _a[_i];
          label.overflow = cc.Label.Overflow.NONE;
          label.enableWrapText = false;
          UIManager_1.uimanager.applyTypography(label);
        }
        this.createStartButtonGuide();
        this.updateStaminaStatus();
        this.preloadGameResourcesSilently();
      };
      GameMainScene.prototype.applyStaminaState = function(state) {
        if (!state) return;
        this.stamina = state;
        var serverTime = Date.parse(state.serverTime);
        this.serverClockOffsetMs = Number.isFinite(serverTime) ? serverTime - Date.now() : 0;
        this.updateStaminaStatus();
      };
      GameMainScene.prototype.getStaminaPreview = function() {
        if (!this.stamina) return {
          current: 0,
          secondsToNext: 0
        };
        var max = Math.max(1, this.stamina.max || 10);
        var current = Math.max(0, Math.floor(this.stamina.current || 0));
        var recoveryAt = this.stamina.nextRecoveryAt ? Date.parse(this.stamina.nextRecoveryAt) : NaN;
        if (current >= max || !Number.isFinite(recoveryAt)) return {
          current: current,
          secondsToNext: 0
        };
        var now = Date.now() + this.serverClockOffsetMs;
        var interval = 1e3 * Math.max(1, this.stamina.regenSeconds || 300);
        var recovered = now >= recoveryAt ? 1 + Math.floor((now - recoveryAt) / interval) : 0;
        var preview = Math.min(max, current + recovered);
        if (preview >= max) return {
          current: preview,
          secondsToNext: 0
        };
        var nextAt = recoveryAt + recovered * interval;
        return {
          current: preview,
          secondsToNext: Math.max(0, Math.ceil((nextAt - now) / 1e3))
        };
      };
      GameMainScene.prototype.updateStaminaStatus = function() {
        if (this.staminaLabel && cc.isValid(this.staminaLabel.node)) if (this.stamina) {
          var preview = this.getStaminaPreview();
          this.staminaLabel.string = preview.current + "/" + this.stamina.max;
        } else this.staminaLabel.string = "\u2014/10";
        if (this.staminaRecoveryLabel && cc.isValid(this.staminaRecoveryLabel.node)) {
          var showRecovery = !!this.stamina && this.getStaminaPreview().current < this.stamina.max;
          this.staminaRecoveryLabel.node.active = showRecovery;
          if (showRecovery) {
            var seconds = this.getStaminaPreview().secondsToNext;
            var minutesText = String(Math.floor(seconds / 60)).padStart(2, "0");
            var secondsText = String(seconds % 60).padStart(2, "0");
            this.staminaRecoveryLabel.string = minutesText + ":" + secondsText + " \u540e\u6062\u590d";
          }
        }
        if (this.startStaminaRecoveryLabel && cc.isValid(this.startStaminaRecoveryLabel.node, true)) {
          var text = this.getChallengeStaminaText();
          var parts = text.match(/^(.*?)(\d{2}:\d{2})(.*)$/);
          this.startStaminaRecoveryLabel.string = parts ? parts[1] : text;
          this.startStaminaTimer.string = parts ? parts[2] : "";
          this.startStaminaSuffix.string = parts ? parts[3] : "";
          for (var _i = 0, _a = [ this.startStaminaRecoveryLabel, this.startStaminaTimer, this.startStaminaSuffix ]; _i < _a.length; _i++) {
            var label = _a[_i];
            label._forceUpdateRenderData();
          }
          var group = this.startStaminaRecoveryLabel.node.parent;
          group.getComponent(cc.Layout).updateLayout();
          group.scale = Math.min(1, 540 / Math.max(1, group.width));
        }
        ShopPanel_1.refreshShopPanel();
      };
      GameMainScene.prototype.getChallengeStaminaText = function() {
        if (!this.stamina) return "\u6b63\u5728\u540c\u6b65\u4f53\u529b\u2026";
        var preview = this.getStaminaPreview();
        var max = this.stamina.max || 10;
        var amount = "\u4f53\u529b " + preview.current + "/" + max;
        if (preview.current >= max) return amount + " \xb7 \u4f53\u529b\u5df2\u6ee1";
        if (preview.secondsToNext <= 0) return amount + " \xb7 \u7b49\u5f85\u540c\u6b65\u6062\u590d\u65f6\u95f4";
        var minutes = String(Math.floor(preview.secondsToNext / 60)).padStart(2, "0");
        var seconds = String(preview.secondsToNext % 60).padStart(2, "0");
        return amount + " \xb7 " + minutes + ":" + seconds + " \u540e\u6062\u590d1\u70b9";
      };
      GameMainScene.prototype.showStaminaInfo = function() {
        if (!this.stamina) {
          UIManager_1.uimanager.showToast("\u4f53\u529b\u6b63\u5728\u540c\u6b65\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
          return;
        }
        var preview = this.getStaminaPreview();
        if (0 === preview.current) {
          this.showStaminaEmptyModal();
          return;
        }
        if (preview.current > this.stamina.max) {
          UIManager_1.uimanager.showToast("\u989d\u5916\u4f53\u529b\u5df2\u4fdd\u7559 \xb7 \u4f4e\u4e8e\u4e0a\u9650\u540e\u81ea\u52a8\u6062\u590d");
          return;
        }
        if (preview.current >= this.stamina.max) {
          UIManager_1.uimanager.showToast("\u4f53\u529b\u5df2\u6ee1 \xb7 \u6bcf 5 \u5206\u949f\u6062\u590d 1 \u70b9");
          return;
        }
        var minutes = Math.max(1, Math.ceil(preview.secondsToNext / 60));
        UIManager_1.uimanager.showToast("\u4f53\u529b " + preview.current + "/" + this.stamina.max + " \xb7 \u7ea6 " + minutes + " \u5206\u949f\u540e\u6062\u590d 1 \u70b9");
      };
      GameMainScene.prototype.showStaminaEmptyModal = function() {
        var _this = this;
        var preview = this.getStaminaPreview();
        var minutes = Math.max(1, Math.ceil(preview.secondsToNext / 60));
        var available = !this.stamina || false !== this.stamina.shareAvailableToday;
        var offerAction = ShareReward_1.getRewardOfferActionText();
        var videoEnabled = "\u770b\u89c6\u9891" === offerAction;
        UIManager_1.uimanager.showModal("\u4f53\u529b\u4e0d\u8db3", available ? "\u4e0b\u4e00\u70b9\u7ea6 " + minutes + " \u5206\u949f\u540e\u6062\u590d\u3002\n" + (videoEnabled ? "\u5b8c\u6574\u770b\u89c6\u9891" : "\u5206\u4eab\u7ed9\u670b\u53cb") + "\uff0c\u7acb\u5373\u83b7\u5f97 5 \u70b9\u4f53\u529b\u3002" : "\u4e0b\u4e00\u70b9\u7ea6 " + minutes + " \u5206\u949f\u540e\u6062\u590d\u3002\n\u4eca\u5929\u7684" + (videoEnabled ? "\u89c6\u9891" : "\u5206\u4eab") + "\u4f53\u529b\u5df2\u9886\u53d6\uff0c\u660e\u5929\u518d\u6765\u5427\u3002", available ? [ {
          text: offerAction + "\u5f97 5 \u4f53\u529b",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            return _this.requestStaminaReward();
          }
        }, {
          text: "\u7a0d\u540e\u518d\u6765",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return;
          }
        } ] : [ {
          text: "\u77e5\u9053\u4e86",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return;
          }
        } ], null, 0, false, true);
      };
      GameMainScene.prototype.requestStaminaReward = function() {
        var _this = this;
        if (this.shareClaimInFlight) return;
        ShareReward_1.requestRewardOffer(function(rewarded) {
          if (!rewarded) {
            UIManager_1.uimanager.showToast(ShareReward_1.getRewardOfferFailToast("stamina"));
            return;
          }
          _this.claimSharedStamina();
        }, "5 \u70b9\u4f53\u529b");
      };
      GameMainScene.prototype.claimSharedStamina = function() {
        return __awaiter(this, void 0, Promise, function() {
          var storage, requestSent, claimId, result, error_2, code;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.shareClaimInFlight) return [ 2 ];
              this.shareClaimInFlight = true;
              storage = cc.sys.localStorage;
              requestSent = false;
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, 4, 5 ]);
              claimId = storage.getItem(PENDING_STAMINA_SHARE_ID_KEY) || "";
              if (!/^share_[a-z0-9_]{8,80}$/.test(claimId)) {
                claimId = "share_" + Date.now() + "_" + Math.floor(1e9 * Math.random()).toString(36);
                storage.setItem(PENDING_STAMINA_SHARE_ID_KEY, claimId);
              }
              requestSent = true;
              return [ 4, CloudService_1.cloudService.claimSharedStamina(claimId) ];

             case 2:
              result = _a.sent();
              storage.removeItem(PENDING_STAMINA_SHARE_ID_KEY);
              this.applyStaminaState(result.stamina);
              UIManager_1.uimanager.showToast(result.previousDay ? "\u6b64\u524d\u5956\u52b1\u5df2\u786e\u8ba4\uff0c\u4eca\u5929\u4ecd\u53ef\u9886\u53d6" : result.duplicate ? "\u4f53\u529b\u5df2\u5230\u8d26" : "\u4f53\u529b +" + result.awarded);
              return [ 3, 5 ];

             case 3:
              error_2 = _a.sent();
              error_2 && error_2.stamina && this.applyStaminaState(error_2.stamina);
              code = error_2 && error_2.businessCode;
              if ("STAMINA_SHARE_DAILY_LIMIT" === code) {
                storage.removeItem(PENDING_STAMINA_SHARE_ID_KEY);
                UIManager_1.uimanager.showToast("\u4eca\u5929\u7684\u5956\u52b1\u4f53\u529b\u5df2\u9886\u53d6");
              } else if ("STAMINA_FULL" === code) {
                storage.removeItem(PENDING_STAMINA_SHARE_ID_KEY);
                UIManager_1.uimanager.showToast("\u4f53\u529b\u5df2\u6ee1\uff0c\u6682\u65f6\u65e0\u9700\u8865\u5145");
              } else UIManager_1.uimanager.showToast(requestSent ? "\u4f53\u529b\u9886\u53d6\u672a\u786e\u8ba4\uff0c\u8bf7\u8054\u7f51\u540e\u91cd\u8bd5" : "\u5b58\u50a8\u7a7a\u95f4\u4e0d\u8db3\uff0c\u6e05\u7406\u540e\u518d\u9886\u53d6");
              return [ 3, 5 ];

             case 4:
              this.shareClaimInFlight = false;
              return [ 7 ];

             case 5:
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.playStartStaminaFlight = function() {
        if (!this.screen || "home" !== this.screen.name || !this.staminaIcon || !this.startButton || !cc.isValid(this.staminaIcon) || !cc.isValid(this.startButton)) return Promise.resolve();
        var start = this.getNodePositionInScreen(this.staminaIcon);
        var end = this.getNodePositionInScreen(this.startButton);
        var control1 = cc.v2(start.x + 105, start.y - 118);
        var control2 = cc.v2(end.x + 118, end.y + 145);
        var bolt = MoodArt_1.createStaminaBolt(this.screen, start.x, start.y, 50);
        bolt.zIndex = 2900;
        var state = {
          t: 0
        };
        return new Promise(function(resolve) {
          cc.tween(state).to(.3, {
            t: 1
          }, {
            easing: "cubicInOut",
            onUpdate: function() {
              if (!cc.isValid(bolt)) return;
              var t = state.t;
              var inverse = 1 - t;
              bolt.x = inverse * inverse * inverse * start.x + 3 * inverse * inverse * t * control1.x + 3 * inverse * t * t * control2.x + t * t * t * end.x;
              bolt.y = inverse * inverse * inverse * start.y + 3 * inverse * inverse * t * control1.y + 3 * inverse * t * t * control2.y + t * t * t * end.y;
              bolt.scale = 1 - .48 * t;
              bolt.angle = 26 * -t;
            }
          }).call(function() {
            cc.isValid(bolt) && bolt.destroy();
            resolve();
          }).start();
        });
      };
      GameMainScene.prototype.preloadGameResourcesSilently = function() {
        AssetLoader_1.prepareFeature("game").catch(function(error) {
          return cc.warn("Game resource preload failed", error);
        });
      };
      GameMainScene.prototype.createHomeTitleLogo = function(centerY) {
        var logo = new cc.Node("homeTitleLogo");
        logo.setPosition(0, centerY + 6);
        logo.setContentSize(560, 190);
        logo.zIndex = 65;
        this.screen.addChild(logo);
        var sprite = logo.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        var frame = AssetLoader_1.getSpriteFrame("home", AssetLoader_1.ASSET_PATHS.home.title);
        sprite.spriteFrame = frame;
        UIManager_1.uimanager.fitSpriteFrameInside(logo, frame, 560, 190);
        logo.opacity = 0;
        logo.scale = .9;
        cc.tween(logo).to(.28, {
          opacity: 255,
          scale: 1
        }, {
          easing: "backOut"
        }).start();
      };
      GameMainScene.prototype.createHomeResourceCapsule = function(profile, name, x, fill, borderColor, iconFill) {
        var cardWidth = 148;
        var cardHeight = 58;
        var resourceY = 24;
        UIManager_1.uimanager.createRect(profile, name + "Shadow", cardWidth, cardHeight, new cc.Color(91, 73, 57), 22, 23, x, resourceY - 3);
        var card = UIManager_1.uimanager.createRect(profile, name, cardWidth, cardHeight, fill, 255, 23, x, resourceY);
        var borderNode = new cc.Node(name + "Border");
        borderNode.zIndex = 2;
        card.addChild(borderNode);
        var border = borderNode.addComponent(cc.Graphics);
        border.strokeColor = borderColor;
        border.lineWidth = 1.6;
        border.roundRect(-cardWidth / 2 + 1, -cardHeight / 2 + 1, cardWidth - 2, cardHeight - 2, 22);
        border.stroke();
        var iconPlate = UIManager_1.uimanager.createCircle(card, name + "IconPlate", 21, iconFill, -50, 0);
        iconPlate.zIndex = 3;
        var plateBorder = iconPlate.getComponent(cc.Graphics);
        plateBorder.strokeColor = borderColor;
        plateBorder.lineWidth = 1.1;
        plateBorder.circle(0, 0, 20);
        plateBorder.stroke();
        return card;
      };
      GameMainScene.prototype.createMoodBeanCount = function(profile) {
        var _this = this;
        var staminaCard = this.createHomeResourceCapsule(profile, "staminaCount", 244, new cc.Color(255, 237, 197), new cc.Color(201, 155, 82, 175), new cc.Color(255, 249, 226));
        this.staminaIcon = MoodArt_1.createStaminaBolt(staminaCard, -50, 0, 38);
        this.staminaLabel = UIManager_1.uimanager.createLabel(staminaCard, "\u2014/10", 20, 0, 23, MoodArt_1.MOOD_COLORS.cocoa, 104, 29);
        this.makeLabelBold(this.staminaLabel);
        this.staminaRecoveryLabel = UIManager_1.uimanager.createLabel(staminaCard, "", 0, -52, 18, new cc.Color(48, 132, 70), 148, 28);
        this.makeLabelBold(this.staminaRecoveryLabel);
        staminaCard.addComponent(cc.Button);
        staminaCard.on(cc.Node.EventType.TOUCH_END, function() {
          return _this.showStaminaInfo();
        }, this);
        var card = this.createHomeResourceCapsule(profile, "moodBeanCount", 75, new cc.Color(255, 243, 215), new cc.Color(205, 173, 103, 175), new cc.Color(255, 250, 230));
        card.zIndex = 25;
        this.moodBeanCountCard = card;
        var icon = MoodArt_1.createMoodBeanMascot(card, -50, -1, 40);
        icon.zIndex = 16;
        this.moodBeanCountLabel = UIManager_1.uimanager.createLabel(card, String(ZyxGameModule_1.zyxGameModule.getDisplayMoodBeanBalance()), 20, 0, 23, MoodArt_1.MOOD_COLORS.cocoa, 104, 29);
        this.makeLabelBold(this.moodBeanCountLabel);
        this.layoutMoodBeanCountBadge();
      };
      GameMainScene.prototype.layoutMoodBeanCountBadge = function(countOverride) {
        if (!this.moodBeanCountLabel || !cc.isValid(this.moodBeanCountLabel.node)) return;
        var count = Math.max(0, Math.floor(Number.isFinite(countOverride) ? countOverride : ZyxGameModule_1.zyxGameModule.getDisplayMoodBeanBalance()));
        this.moodBeanCountLabel.string = String(count);
        var digits = String(count).length;
        this.moodBeanCountLabel.fontSize = digits >= 6 ? 21 : digits >= 4 ? 25 : 29;
      };
      GameMainScene.prototype.updateMoodBeanCount = function() {
        this.layoutMoodBeanCountBadge();
        this.moodBeanCountCard && this.pulseRewardTarget(this.moodBeanCountCard);
      };
      GameMainScene.prototype.bootstrapCloudProfile = function() {
        return __awaiter(this, void 0, Promise, function() {
          var _this = this;
          return __generator(this, function(_a) {
            if (this.cloudProfileReady) return [ 2 ];
            if (this.cloudProfileBootstrapPromise) return [ 2, this.cloudProfileBootstrapPromise ];
            ZyxGameModule_1.zyxGameModule.refreshPersistentProgress();
            this.cloudProfileBootstrapPromise = function() {
              return __awaiter(_this, void 0, void 0, function() {
                var profile, error_3, cached;
                return __generator(this, function(_a) {
                  switch (_a.label) {
                   case 0:
                    _a.trys.push([ 0, 2, 3, 4 ]);
                    return [ 4, CloudService_1.cloudService.bootstrap(this.profileNameLabel ? this.profileNameLabel.string : "\u89e3\u5fe7\u73a9\u5bb6", "") ];

                   case 1:
                    profile = _a.sent();
                    this.cloudProfileReady = true;
                    this.applyCloudProfile(profile);
                    this.flushPendingRoundSettlements(false);
                    return [ 3, 4 ];

                   case 2:
                    error_3 = _a.sent();
                    if (!error_3 || ![ 401, 403 ].includes(error_3.status)) try {
                      cached = JSON.parse(cc.sys.localStorage.getItem("zyx_confirmed_profile_" + CloudService_1.getApiBase()) || "null");
                      cached && cached.token === cc.sys.localStorage.getItem("zyx_cloud_token") && this.applyCloudProfile(cached.profile);
                    } catch (_) {}
                    return [ 3, 4 ];

                   case 3:
                    this.cloudProfileBootstrapPromise = null;
                    return [ 7 ];

                   case 4:
                    return [ 2 ];
                  }
                });
              });
            }();
            return [ 2, this.cloudProfileBootstrapPromise ];
          });
        });
      };
      GameMainScene.prototype.refreshCloudProfile = function() {
        return __awaiter(this, void 0, Promise, function() {
          var profile, error_4;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (!this.cloudProfileReady) return [ 2, this.bootstrapCloudProfile() ];
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, , 4 ]);
              return [ 4, CloudService_1.cloudService.bootstrap(this.profileNameLabel ? this.profileNameLabel.string : "", "") ];

             case 2:
              profile = _a.sent();
              this.applyCloudProfile(profile);
              return [ 3, 4 ];

             case 3:
              error_4 = _a.sent();
              return [ 3, 4 ];

             case 4:
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.applyCloudProfile = function(profile) {
        if (!profile) return;
        if (!ZyxGameModule_1.zyxGameModule.applyCloudProfile(profile)) return;
        this.currentCloudProfile = profile;
        try {
          cc.sys.localStorage.setItem("zyx_confirmed_profile_" + CloudService_1.getApiBase(), JSON.stringify({
            profile: profile,
            token: cc.sys.localStorage.getItem("zyx_cloud_token")
          }));
        } catch (_) {}
        RoundProgress_1.roundProgress.bind(profile.playerId);
        WeChatFriends_1.syncConfirmedFriendScore(profile.playerId, profile.highestSingleGameScore);
        if (this.profileNameLabel) {
          this.profileNameLabel.string = UIManager_1.formatDisplayNickname(profile.nickname);
          UIManager_1.uimanager.applyTypography(this.profileNameLabel);
        }
        this.profileAvatarContent && cc.isValid(this.profileAvatarContent) && this.profileAvatarUrl !== (profile.avatarUrl || "") && this.renderProfileAvatar(this.profileAvatarContent, profile.avatarUrl || "");
        this.applyStaminaState(profile.stamina);
        this.updateStaminaStatus();
        this.updateMoodBeanCount();
        var game = this.screen && this.screen.getComponent(ZyxGame_1.default);
        game && game.node && cc.isValid(game.node) && game.refreshInventoryHud();
        ShopPanel_1.refreshShopPanel();
        var display = ZyxGameModule_1.zyxGameModule.getDisplayLevelAndExperience();
        this.updateHomeExperienceDisplay(display.level, display.experience, display.target);
      };
      GameMainScene.prototype.submitSettlementToCloud = function(settlement, startedAt) {
        if (!this.activeRoundId) {
          cc.error("\u7ed3\u7b97\u7f3a\u5c11\u670d\u52a1\u7aef\u5f00\u5c40 ID");
          return;
        }
        var record = {
          roundId: this.activeRoundId,
          sessionToken: RoundProgress_1.roundProgress.token,
          startedAt: startedAt,
          endedAt: Date.now(),
          score: settlement.roundScore,
          collectedMoodBeanCount: settlement.roundCollectedMoodBeans,
          actions: ZyxGameModule_1.zyxGameModule.roundActions.slice()
        };
        ZyxGameModule_1.zyxGameModule.enqueuePendingRoundSettlement(record);
        RoundProgress_1.roundProgress.clear(record.roundId);
        this.flushPendingRoundSettlements();
      };
      GameMainScene.prototype.flushPendingRoundSettlements = function(allowBootstrap) {
        void 0 === allowBootstrap && (allowBootstrap = true);
        return __awaiter(this, void 0, Promise, function() {
          var outcome, refreshed, error_5;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (!!this.cloudProfileReady) return [ 3, 2 ];
              if (!allowBootstrap) return [ 2 ];
              return [ 4, this.bootstrapCloudProfile() ];

             case 1:
              _a.sent();
              if (!this.cloudProfileReady) return [ 2 ];
              _a.label = 2;

             case 2:
              return [ 4, SettlementSync_1.flushPendingRoundSettlements(function(record) {
                return CloudService_1.cloudService.submitSettlement(record.roundId, record.startedAt, record.endedAt, record.score, record.collectedMoodBeanCount, record.actions, record.sessionToken);
              }, {
                onSettled: function(record, result) {
                  if (result && result.settlement && result.settlement.profile) {
                    _this.applyCloudProfile(result.settlement.profile);
                    if (record.roundId === _this.activeRoundId || _this.pendingSettlementPresentation && record.roundId === _this.pendingSettlementPresentation.roundId) {
                      _this.settlementReceipts[record.roundId] = result;
                      _this.tryPresentConfirmedSettlement();
                    }
                  }
                },
                onDeadLetter: function(record) {
                  _this.pendingSettlementPresentation && record.roundId === _this.pendingSettlementPresentation.roundId && (_this.pendingSettlementPresentation = null);
                  UIManager_1.uimanager.showToast("\u6709\u4e00\u5c40\u8bb0\u5f55\u672a\u83b7\u670d\u52a1\u7aef\u786e\u8ba4\uff0c\u672a\u8ba1\u5165\u5f00\u5fc3\u8c46");
                }
              }) ];

             case 3:
              outcome = _a.sent();
              if (!(outcome.deadLettered > 0)) return [ 3, 7 ];
              _a.label = 4;

             case 4:
              _a.trys.push([ 4, 6, , 7 ]);
              return [ 4, CloudService_1.cloudService.bootstrap(this.profileNameLabel ? this.profileNameLabel.string : "", "") ];

             case 5:
              refreshed = _a.sent();
              this.applyCloudProfile(refreshed);
              return [ 3, 7 ];

             case 6:
              error_5 = _a.sent();
              return [ 3, 7 ];

             case 7:
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.createHomeFeatureEntries = function() {
        var _this = this;
        var safeArea = UIManager_1.uimanager.getSafeAreaMetrics();
        var cardWidth = 118;
        var entryHeight = 126;
        var railPadY = 18;
        var railHeight = 2 * railPadY + 2 * entryHeight + 18;
        var contentRight = Math.min(this.screen.width / 2 - safeArea.right, ResponsiveLayout_1.DESIGN_WIDTH / 2);
        var entryX = contentRight - 15 - cardWidth / 2;
        var rail = UIManager_1.uimanager.createRect(this.screen, "homeFeatureRail", cardWidth, railHeight, new cc.Color(239, 220, 178), 230, 26, entryX, 0);
        rail.zIndex = 125;
        var railBorder = new cc.Node("homeFeatureRailBorder");
        railBorder.zIndex = 2;
        rail.addChild(railBorder);
        var railGraphics = railBorder.addComponent(cc.Graphics);
        railGraphics.strokeColor = new cc.Color(144, 108, 76, 142);
        railGraphics.lineWidth = 1.8;
        railGraphics.roundRect(-cardWidth / 2 + 2, -railHeight / 2 + 2, cardWidth - 4, railHeight - 4, 24);
        railGraphics.stroke();
        this.createHomeFeatureIcon(rail, "rankEntry", "\u6392\u884c\u699c", 72, new cc.Color(105, 164, 190), AssetLoader_1.ASSET_PATHS.home.rankEntry, function() {
          return LeaderboardPanel_1.showLeaderboardPanel(function() {
            return _this.bootstrapCloudProfile();
          }, function() {
            return _this.authorizeWeChatProfile(false);
          });
        });
        this.createHomeFeatureIcon(rail, "shopEntry", "\u5546\u57ce", -72, MoodArt_1.MOOD_COLORS.honey, null, function() {
          return ShopPanel_1.showShopPanel(function() {
            return _this.refreshCloudProfile();
          }, function(profile) {
            return _this.applyCloudProfile(profile);
          }, {
            staminaText: function() {
              return _this.getChallengeStaminaText();
            },
            staminaAmount: function() {
              return _this.stamina ? "\u5f53\u524d\u4f53\u529b " + _this.getStaminaPreview().current + "/" + _this.stamina.max : "\u4f53\u529b\u540c\u6b65\u4e2d\u2026";
            },
            start: function() {
              return _this.startGame();
            }
          });
        });
      };
      GameMainScene.prototype.createHomeSettingsEntry = function() {
        var _this = this;
        var safeArea = UIManager_1.uimanager.getSafeAreaMetrics();
        var buttonWidth = 104;
        var buttonHeight = 104;
        var contentRight = Math.min(this.screen.width / 2 - safeArea.right, ResponsiveLayout_1.DESIGN_WIDTH / 2);
        var x = contentRight - 15 - buttonWidth / 2;
        var y = -this.screen.height / 2 + safeArea.bottom + 190;
        var entry = UIManager_1.uimanager.createRect(this.screen, "settingsEntry", buttonWidth, buttonHeight, MoodArt_1.MOOD_COLORS.mistBlue, 255, 24, x, y);
        entry.zIndex = 150;
        UIManager_1.uimanager.drawButtonSurface(entry, buttonWidth, buttonHeight, MoodArt_1.MOOD_COLORS.mistBlue, 24);
        var gear = this.drawSettingsGear(entry);
        var title = UIManager_1.uimanager.createLabel(entry, "\u8bbe\u7f6e", 0, -24, 28, UIManager_1.BUTTON_TEXT_COLOR, 90, 38);
        this.makeLabelBold(title);
        entry.addComponent(cc.Button);
        entry.on(cc.Node.EventType.TOUCH_START, function() {
          cc.Tween.stopAllByTarget(entry);
          cc.Tween.stopAllByTarget(gear);
          cc.tween(entry).to(.07, {
            scale: .93
          }).start();
          cc.tween(gear).to(.07, {
            angle: 12
          }).start();
        }, this);
        entry.on(cc.Node.EventType.TOUCH_END, function() {
          cc.Tween.stopAllByTarget(entry);
          cc.Tween.stopAllByTarget(gear);
          cc.tween(entry).to(.12, {
            scale: 1
          }, {
            easing: "backOut"
          }).start();
          cc.tween(gear).to(.16, {
            angle: 0
          }, {
            easing: "backOut"
          }).start();
          _this.showSettings();
        }, this);
        entry.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.Tween.stopAllByTarget(entry);
          cc.Tween.stopAllByTarget(gear);
          cc.tween(entry).to(.1, {
            scale: 1
          }).start();
          cc.tween(gear).to(.1, {
            angle: 0
          }).start();
        }, this);
      };
      GameMainScene.prototype.drawSettingsGear = function(parent) {
        var gear = new cc.Node("settingsGearGlyph");
        gear.setPosition(0, 14);
        gear.zIndex = 4;
        parent.addChild(gear);
        var g = gear.addComponent(cc.Graphics);
        g.fillColor = MoodArt_1.MOOD_COLORS.cream;
        g.strokeColor = MoodArt_1.MOOD_COLORS.cocoa;
        g.lineWidth = 2.6;
        var points = [];
        for (var index = 0; index < 32; index++) {
          var phase = index % 4;
          var radius = 1 === phase || 2 === phase ? 21 : 16.5;
          var angle = Math.PI / 2 + index * Math.PI * 2 / 32;
          points.push(new cc.Vec2(Math.cos(angle) * radius, Math.sin(angle) * radius));
        }
        g.moveTo(points[0].x, points[0].y);
        points.slice(1).forEach(function(point) {
          return g.lineTo(point.x, point.y);
        });
        g.close();
        g.fill();
        g.stroke();
        g.fillColor = MoodArt_1.MOOD_COLORS.honey;
        g.circle(0, 0, 10);
        g.fill();
        g.strokeColor = MoodArt_1.MOOD_COLORS.cocoa;
        g.lineWidth = 1.8;
        g.circle(0, 0, 10);
        g.stroke();
        g.fillColor = MoodArt_1.MOOD_COLORS.cocoa;
        g.circle(-3.8, 2.2, 1.35);
        g.circle(3.8, 2.2, 1.35);
        g.fill();
        g.strokeColor = MoodArt_1.MOOD_COLORS.cocoa;
        g.lineWidth = 1.6;
        g.moveTo(-4, -1.4);
        g.quadraticCurveTo(0, -5.2, 4, -1.4);
        g.stroke();
        return gear;
      };
      GameMainScene.prototype.showSettings = function() {
        SettingsPanel_1.settingsPanel.show();
      };
      GameMainScene.prototype.refreshGmInventoryDisplays = function() {
        var display = ZyxGameModule_1.zyxGameModule.getDisplayLevelAndExperience();
        this.updateHomeExperienceDisplay(display.level, display.experience, display.target);
        this.updateMoodBeanCount();
        var game = this.screen ? this.screen.getComponent(ZyxGame_1.default) : null;
        game && game.refreshInventoryHud();
      };
      GameMainScene.prototype.ensureCloudProfileReadyForGm = function() {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.cloudProfileReady) return [ 2 ];
              return [ 4, CloudService_1.cloudService.bootstrap(this.profileNameLabel ? this.profileNameLabel.string : "\u89e3\u5fe7\u73a9\u5bb6", "") ];

             case 1:
              _a.sent();
              this.cloudProfileReady = true;
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.createHomeFeatureIcon = function(parent, name, title, y, color, resourcePath, onClick) {
        var entry = new cc.Node(name);
        entry.width = 110;
        entry.height = 126;
        entry.setPosition(0, y);
        entry.zIndex = 10;
        parent.addChild(entry);
        var iconBase = UIManager_1.uimanager.createRect(entry, "featureIconBase", 86, 86, color, 255, 20, 0, 20);
        UIManager_1.uimanager.drawButtonSurface(iconBase, 86, 86, color, 20);
        resourcePath ? this.loadHomeFeatureIcon(iconBase, resourcePath, 70, 0, 2) : ShopPanel_1.drawShopBag(iconBase);
        var titleLabel = UIManager_1.uimanager.createLabel(entry, title, 0, -44, 24, MoodArt_1.MOOD_COLORS.cocoa, 108, 32);
        this.makeLabelBold(titleLabel);
        entry.addComponent(cc.Button);
        entry.on(cc.Node.EventType.TOUCH_START, function() {
          cc.tween(entry).stop();
          cc.tween(entry).to(.07, {
            scale: .94
          }).start();
        }, this);
        entry.on(cc.Node.EventType.TOUCH_END, function() {
          cc.tween(entry).stop();
          cc.tween(entry).to(.12, {
            scale: 1
          }).start();
          onClick();
        }, this);
        entry.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.tween(entry).stop();
          cc.tween(entry).to(.12, {
            scale: 1
          }).start();
        }, this);
      };
      GameMainScene.prototype.loadHomeFeatureIcon = function(parent, resourcePath, iconSize, x, y) {
        var icon = new cc.Node("featureIconArt");
        icon.setPosition(x, y);
        icon.setContentSize(iconSize, iconSize);
        icon.zIndex = 8;
        parent.addChild(icon);
        var sprite = icon.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        sprite.spriteFrame = AssetLoader_1.getSpriteFrame("home", resourcePath);
        icon.width = iconSize;
        icon.height = iconSize;
      };
      GameMainScene.prototype.drawRankFeatureGlyph = function(parent, x, y) {
        var glyph = new cc.Node("rankTrophyGlyph");
        glyph.setPosition(x, y);
        parent.addChild(glyph);
        var g = glyph.addComponent(cc.Graphics);
        g.fillColor = new cc.Color(255, 230, 153);
        g.strokeColor = new cc.Color(150, 105, 56);
        g.lineWidth = 2.4;
        g.roundRect(-16, -12, 32, 27, 10);
        g.fill();
        g.stroke();
        g.strokeColor = new cc.Color(150, 105, 56);
        g.lineWidth = 3;
        g.arc(-17, 4, 11, Math.PI / 2, 1.5 * Math.PI, true);
        g.stroke();
        g.arc(17, 4, 11, 1.5 * Math.PI, Math.PI / 2, true);
        g.stroke();
        g.fillColor = new cc.Color(244, 181, 60);
        g.roundRect(-5, -25, 10, 14, 3);
        g.fill();
        g.roundRect(-17, -31, 34, 9, 4);
        g.fill();
      };
      GameMainScene.prototype.createHomeMoodScene = function(centerY) {
        var _this = this;
        var stage = new cc.Node("homeMoodScene");
        stage.width = 560;
        stage.height = 390;
        stage.setPosition(0, centerY);
        stage.zIndex = 30;
        this.screen.addChild(stage);
        var demoLayer = new cc.Node("homeDemoLayer");
        demoLayer.setAnchorPoint(.5, .5);
        demoLayer.zIndex = 10;
        demoLayer.setPosition(-62, -110);
        demoLayer.scale = .8;
        stage.addChild(demoLayer);
        this.homeDemoLayer = demoLayer;
        var cellSize = 46;
        var cellGap = 4;
        var boardLeft = -138;
        var bottomY = 160;
        var upperY = bottomY + cellSize + cellGap;
        var boardCenterX = boardLeft + 3 * cellSize;
        var boardCenterY = (bottomY + upperY) / 2;
        var boardWidth = 6 * cellSize + 20;
        var boardHeight = 2 * cellSize + cellGap + 20;
        var shadow = UIManager_1.uimanager.createRect(demoLayer, "homeDemoBoardShadow", boardWidth + 8, boardHeight + 8, new cc.Color(78, 53, 46), 34, 18, boardCenterX, boardCenterY - 5);
        shadow.zIndex = -2;
        var board = UIManager_1.uimanager.createRect(demoLayer, "homeDemoBoard", boardWidth, boardHeight, new cc.Color(102, 75, 65), 226, 17, boardCenterX, boardCenterY);
        board.zIndex = -1;
        for (var row = 0; row < 2; row++) for (var col = 0; col < 6; col++) UIManager_1.uimanager.createRect(demoLayer, "homeDemoCell_" + row + "_" + col, cellSize - 4, cellSize - 4, new cc.Color(255, 247, 226), 238, 10, boardLeft + (col + .5) * cellSize, 0 === row ? bottomY : upperY);
        var leftPiece = this.createHomeDemoPiece(demoLayer, 8, 2, cellSize, boardLeft, 0, bottomY, true);
        var rightPiece = this.createHomeDemoPiece(demoLayer, 6, 2, cellSize, boardLeft, 4, bottomY, false);
        var movingPiece = this.createHomeDemoPiece(demoLayer, 1, 2, cellSize, boardLeft, 3, upperY, true);
        var movingStartX = movingPiece.x;
        var movingTargetX = boardLeft + 3 * cellSize;
        var hand = this.createHomeDemoHand(demoLayer, movingStartX, upperY + 42);
        var softGlow = UIManager_1.uimanager.createCircle(demoLayer, "sceneGlow", 62, new cc.Color(255, 236, 170, 48), 210, 18);
        softGlow.zIndex = -1;
        cc.tween(softGlow).repeatForever(cc.tween().to(1.8, {
          scale: 1.06
        }).to(1.8, {
          scale: .94
        })).start();
        var beanIcon = MoodArt_1.createMoodBeanMascot(stage, 145, demoLayer.y + boardCenterY * demoLayer.scale, 106);
        beanIcon.zIndex = 60;
        beanIcon.opacity = 0;
        beanIcon.scale = .72;
        cc.tween(beanIcon).to(.34, {
          scale: 1,
          opacity: 255
        }, {
          easing: "backOut"
        }).start();
        this.homeMoodBeanIcon = beanIcon;
        var demoTip = UIManager_1.uimanager.createLabel(demoLayer, "\u5de6\u53f3\u632a\u52a8 \xb7 \u6536\u96c6\u5f00\u5fc3\u8c46", boardCenterX, 105, 20, MoodArt_1.MOOD_COLORS.cocoaSoft, 280, 28);
        this.makeLabelBold(demoTip);
        var demoPieces = [ leftPiece, rightPiece, movingPiece ];
        var demoClock = new cc.Node("homeDemoClock");
        stage.addChild(demoClock);
        this.homeDemoClock = demoClock;
        var resetDemo = function() {
          if (!_this.homeDemoPlaying) return;
          for (var _i = 0, _a = demoLayer.children.slice(); _i < _a.length; _i++) {
            var child = _a[_i];
            0 === child.name.indexOf("homeDemoTransient") && child.destroy();
          }
          for (var _b = 0, demoPieces_1 = demoPieces; _b < demoPieces_1.length; _b++) {
            var piece = demoPieces_1[_b];
            cc.Tween.stopAllByTarget(piece);
            piece.opacity = 255;
            piece.scale = 1;
            piece.scaleX = 1;
            piece.scaleY = 1;
          }
          movingPiece.setPosition(movingStartX, upperY);
          cc.Tween.stopAllByTarget(hand);
          hand.setPosition(movingStartX, upperY + 42);
          hand.opacity = 0;
          hand.scale = 1;
        };
        var playDrag = function() {
          if (!_this.homeDemoPlaying) return;
          hand.opacity = 255;
          cc.tween(hand).to(.2, {
            y: upperY + 23,
            scale: .88
          }, {
            easing: "quadOut"
          }).to(.88, {
            x: movingTargetX
          }, {
            easing: "cubicInOut"
          }).to(.16, {
            y: upperY + 39,
            scale: 1
          }, {
            easing: "backOut"
          }).start();
          cc.tween(movingPiece).delay(.2).to(.88, {
            x: movingTargetX
          }, {
            easing: "cubicInOut"
          }).start();
        };
        var playDrop = function() {
          if (!_this.homeDemoPlaying) return;
          cc.tween(movingPiece).to(.44, {
            y: bottomY
          }, {
            easing: "quadIn"
          }).start();
          cc.tween(hand).to(.25, {
            opacity: 0,
            y: upperY + 56
          }, {
            easing: "quadOut"
          }).start();
        };
        var playClear = function() {
          if (!_this.homeDemoPlaying) return;
          _this.playHomeDemoClear(demoLayer, demoPieces, boardCenterX, bottomY, cellSize);
        };
        var playCollect = function() {
          if (!_this.homeDemoPlaying) return;
          _this.playHomeMoodFlight(demoLayer, beanIcon, leftPiece, 8, 0);
          _this.playHomeMoodFlight(demoLayer, beanIcon, movingPiece, 1, 1);
        };
        var startDemoLoop = function() {
          if (!_this.homeDemoClock || !cc.isValid(_this.homeDemoClock)) return;
          cc.Tween.stopAllByTarget(_this.homeDemoClock);
          _this.homeDemoPlaying = true;
          resetDemo();
          cc.tween(_this.homeDemoClock).repeatForever(cc.tween().call(resetDemo).delay(.58).call(playDrag).delay(1.42).call(playDrop).delay(.54).call(playClear).delay(.22).call(playCollect).delay(2.45)).start();
        };
        this.startHomeDemoLoop = startDemoLoop;
        startDemoLoop();
      };
      GameMainScene.prototype.setHomeDemoActive = function(active) {
        var _this = this;
        if (!this.homeDemoLayer || !cc.isValid(this.homeDemoLayer)) return;
        cc.Tween.stopAllByTarget(this.homeDemoLayer);
        if (!active) {
          this.homeDemoPlaying = false;
          this.homeDemoClock && cc.isValid(this.homeDemoClock) && cc.Tween.stopAllByTarget(this.homeDemoClock);
          for (var _i = 0, _a = this.homeDemoLayer.children.slice(); _i < _a.length; _i++) {
            var child = _a[_i];
            if (0 === child.name.indexOf("homeDemoTransient")) {
              cc.Tween.stopAllByTarget(child);
              child.destroy();
            }
          }
          cc.tween(this.homeDemoLayer).to(.18, {
            opacity: 0
          }, {
            easing: "sineOut"
          }).call(function() {
            _this.homeDemoLayer && cc.isValid(_this.homeDemoLayer) && (_this.homeDemoLayer.active = false);
          }).start();
          return;
        }
        this.homeDemoLayer.active = true;
        this.homeDemoLayer.opacity = 0;
        cc.tween(this.homeDemoLayer).to(.4, {
          opacity: 255
        }, {
          easing: "sineOut"
        }).call(function() {
          _this.startHomeDemoLoop && _this.startHomeDemoLoop();
        }).start();
      };
      GameMainScene.prototype.getNodePositionInParent = function(node, parent) {
        if (!node || !parent || !cc.isValid(node) || !cc.isValid(parent)) return cc.v2(0, 0);
        return parent.convertToNodeSpaceAR(node.convertToWorldSpaceAR(cc.v2(0, 0)));
      };
      GameMainScene.prototype.createHomeDemoPiece = function(parent, mood, size, cellSize, boardLeft, col, y, hasStamp) {
        var node = new cc.Node("homeDemoPiece_" + mood);
        node.width = size * cellSize - 10;
        node.height = cellSize - 10;
        node.setPosition(boardLeft + (col + size / 2) * cellSize, y);
        node.zIndex = 20;
        node.demoMood = mood;
        parent.addChild(node);
        var color = MoodArt_1.getMoodColor(mood);
        MoodArt_1.drawMoodBlockMaterial(node, color);
        hasStamp && MoodArt_1.createMoodStamp(node, mood, cellSize, 0, 152);
        return node;
      };
      GameMainScene.prototype.createHomeDemoHand = function(parent, x, y) {
        var node = new cc.Node("homeDemoHand");
        node.width = 46;
        node.height = 56;
        node.setPosition(x, y);
        node.zIndex = 80;
        parent.addChild(node);
        var halo = UIManager_1.uimanager.createCircle(node, "handHalo", 23, new cc.Color(239, 151, 105, 62));
        cc.tween(halo).repeatForever(cc.tween().to(.5, {
          scale: 1.14,
          opacity: 80
        }).to(.5, {
          scale: .9,
          opacity: 220
        })).start();
        var g = node.addComponent(cc.Graphics);
        g.fillColor = new cc.Color(255, 249, 229);
        g.strokeColor = MoodArt_1.MOOD_COLORS.cocoaSoft;
        g.lineWidth = 2;
        g.circle(0, -4, 14);
        g.fill();
        g.stroke();
        g.roundRect(-5, -1, 10, 31, 5);
        g.fill();
        g.stroke();
        g.fillColor = new cc.Color(239, 151, 105);
        g.circle(0, 23, 3.8);
        g.fill();
        return node;
      };
      GameMainScene.prototype.playHomeDemoClear = function(stage, pieces, boardCenterX, rowY, cellSize) {
        var flash = UIManager_1.uimanager.createRect(stage, "homeDemoTransientFlash", 6 * cellSize - 4, cellSize - 6, new cc.Color(255, 224, 134), 0, 12, boardCenterX, rowY);
        flash.zIndex = 55;
        cc.tween(flash).to(.1, {
          opacity: 215,
          scaleX: 1.03
        }, {
          easing: "quadOut"
        }).to(.28, {
          opacity: 0,
          scaleX: 1.08
        }, {
          easing: "quadIn"
        }).call(function() {
          return flash.destroy();
        }).start();
        for (var _i = 0, pieces_1 = pieces; _i < pieces_1.length; _i++) {
          var piece = pieces_1[_i];
          cc.tween(piece).to(.1, {
            scaleX: 1.03,
            scaleY: .72
          }, {
            easing: "quadOut"
          }).to(.3, {
            opacity: 0,
            scale: .78
          }, {
            easing: "quadIn"
          }).start();
          this.spawnHomeDemoShards(stage, piece);
        }
      };
      GameMainScene.prototype.spawnHomeDemoShards = function(stage, piece) {
        var color = MoodArt_1.getMoodColor(Number(piece.demoMood) || 1);
        var _loop_1 = function(index) {
          var shard = UIManager_1.uimanager.createRect(stage, "homeDemoTransientShard_" + index, 10 + index % 2 * 4, 8 + (index + 1) % 3 * 3, color, 220, 3, piece.x + (index - 2) * (piece.width / 6), piece.y + (index % 2 === 0 ? 8 : -8));
          shard.zIndex = 58;
          cc.tween(shard).delay(.08).to(.48, {
            x: shard.x + 22 * (index - 2),
            y: shard.y - 35 - 5 * index,
            angle: 48 * -(index - 2),
            opacity: 0,
            scale: .5
          }, {
            easing: "quadIn"
          }).call(function() {
            return shard.destroy();
          }).start();
        };
        for (var index = 0; index < 5; index++) _loop_1(index);
      };
      GameMainScene.prototype.playHomeMoodFlight = function(stage, beanIcon, piece, moodIndex, order) {
        var _this = this;
        var start = new cc.Vec2(piece.x + piece.width / 2 - 22, piece.y);
        var target = stage.convertToNodeSpaceAR(beanIcon.convertToWorldSpaceAR(cc.v2(0, 4)));
        var control = new cc.Vec2((start.x + target.x) / 2, Math.max(start.y, target.y) + 88 + 10 * order);
        var token = MoodArt_1.createMoodBean(stage, moodIndex, start.x, start.y, 36, 0);
        token.name = "homeDemoTransientMood_" + order;
        token.zIndex = 45;
        var state = {
          t: 0
        };
        var delay = .2 * order;
        cc.tween(token).delay(delay).to(.12, {
          opacity: 255,
          scale: 1.1
        }, {
          easing: "backOut"
        }).start();
        cc.tween(state).delay(delay + .04).to(.9, {
          t: 1
        }, {
          easing: "quadIn",
          onUpdate: function() {
            if (!cc.isValid(token)) return;
            var inverse = 1 - state.t;
            token.x = inverse * inverse * start.x + 2 * inverse * state.t * control.x + state.t * state.t * target.x;
            token.y = inverse * inverse * start.y + 2 * inverse * state.t * control.y + state.t * state.t * target.y;
            token.scale = 1.1 - .6 * state.t;
            token.angle = 180 * -state.t;
            state.t > .9 && (token.opacity = Math.floor(255 * (1 - (state.t - .9) / .1)));
          }
        }).call(function() {
          cc.isValid(token) && token.destroy();
          if (!cc.isValid(beanIcon)) return;
          cc.Tween.stopAllByTarget(beanIcon);
          beanIcon.angle = 0;
          cc.tween(beanIcon).to(.1, {
            angle: -9,
            scale: 1.05
          }, {
            easing: "sineOut"
          }).to(.16, {
            angle: 8,
            scale: 1.02
          }, {
            easing: "sineInOut"
          }).to(.14, {
            angle: -4,
            scale: 1
          }, {
            easing: "sineInOut"
          }).to(.12, {
            angle: 0
          }, {
            easing: "sineOut"
          }).start();
          _this.spawnHomeDemoBeanSparkles(stage, beanIcon, moodIndex, order);
        }).start();
      };
      GameMainScene.prototype.spawnHomeDemoBeanSparkles = function(stage, beanIcon, moodIndex, order) {
        var color = MoodArt_1.getMoodColor(moodIndex);
        var target = stage.convertToNodeSpaceAR(beanIcon.convertToWorldSpaceAR(cc.v2(0, 18)));
        var _loop_2 = function(index) {
          var spark = UIManager_1.uimanager.createCircle(stage, "homeDemoTransientSplash_" + order + "_" + index, 4 + index, new cc.Color(color.r, color.g, color.b, 210), target.x + 8 * (index - 1), target.y);
          spark.zIndex = 35;
          cc.tween(spark).to(.26, {
            x: spark.x + 10 * (index - 1),
            y: target.y + 18 + 3 * index,
            opacity: 0,
            scale: .35
          }, {
            easing: "quadOut"
          }).call(function() {
            cc.isValid(spark) && spark.destroy();
          }).start();
        };
        for (var index = 0; index < 3; index++) _loop_2(index);
      };
      GameMainScene.prototype.createHomeProfile = function(panelY) {
        var _this = this;
        var panelX = 0;
        UIManager_1.uimanager.createRect(this.screen, "profileShadow", 674, 128, new cc.Color(78, 53, 46), 32, 28, panelX, panelY - 5);
        var panel = UIManager_1.uimanager.createRect(this.screen, "profileCard", 666, 122, new cc.Color(255, 249, 232), 246, 26, panelX, panelY);
        var avatarX = -274;
        var avatarFrame = MoodArt_1.createAvatarFrame(panel, "avatarRoundedFrame", avatarX, 0, 92);
        avatarFrame.zIndex = 10;
        var avatarMask = new cc.Node("avatarMask");
        avatarMask.width = 68;
        avatarMask.height = 64;
        avatarMask.setPosition(avatarX, 0);
        avatarMask.zIndex = 20;
        panel.addChild(avatarMask);
        MoodArt_1.applyRoundedAvatarMask(avatarMask);
        this.profileAvatarContent = new cc.Node("avatarContent");
        this.profileAvatarContent.width = 68;
        this.profileAvatarContent.height = 64;
        avatarMask.addChild(this.profileAvatarContent);
        this.drawDefaultAvatar();
        this.profileAvatarUrl = "";
        var avatarTouch = UIManager_1.uimanager.createRect(panel, "avatarTouch", 104, 104, cc.Color.WHITE, 0, 22, avatarX, 0);
        avatarTouch.zIndex = 30;
        avatarTouch.addComponent(cc.Button);
        var avatarNodes = [ avatarFrame, avatarMask ];
        var restoreAvatar = function() {
          return avatarNodes.forEach(function(node) {
            cc.Tween.stopAllByTarget(node);
            cc.tween(node).to(.1, {
              scale: 1
            }).start();
          });
        };
        avatarTouch.on(cc.Node.EventType.TOUCH_START, function() {
          return avatarNodes.forEach(function(node) {
            cc.Tween.stopAllByTarget(node);
            cc.tween(node).to(.07, {
              scale: .92
            }).start();
          });
        }, this);
        avatarTouch.on(cc.Node.EventType.TOUCH_END, function() {
          restoreAvatar();
          _this.showUserProfileModal();
        }, this);
        avatarTouch.on(cc.Node.EventType.TOUCH_CANCEL, restoreAvatar, this);
        this.profileNameLabel = UIManager_1.uimanager.createLabel(panel, "\u89e3\u5fe7\u73a9\u5bb6", -210, 22, 28, MoodArt_1.MOOD_COLORS.cocoa, 200, 36);
        this.profileNameLabel.node.name = "profileNickname";
        this.profileNameLabel.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        this.profileNameLabel.node.setAnchorPoint(0, .5);
        this.profileNameLabel.node.setPosition(-210, 22);
        this.profileNameLabel.enableWrapText = false;
        var displayProgress = ZyxGameModule_1.zyxGameModule.getDisplayLevelAndExperience();
        var target = displayProgress.target;
        var ratio = Math.max(0, Math.min(1, displayProgress.experience / target));
        var trackWidth = this.profileExperienceTrackWidth;
        var trackX = -19;
        var trackY = -28;
        UIManager_1.uimanager.createRect(panel, "experienceTrack", trackWidth, 30, new cc.Color(87, 79, 72), 220, 10, trackX, trackY);
        var fillWidth = Math.max(8, this.profileExperienceFillWidth * ratio);
        this.profileExperienceFill = UIManager_1.uimanager.createRect(panel, "experienceFill", fillWidth, 20, MoodArt_1.MOOD_COLORS.sage, 255, 7, this.profileExperienceFillLeft + fillWidth / 2, trackY);
        this.profileExperienceLabel = UIManager_1.uimanager.createLabel(panel, "\u7ecf\u9a8c " + displayProgress.experience + "/" + target, -18, trackY, 16, cc.Color.WHITE, 190, 25);
        this.makeLabelBold(this.profileExperienceLabel);
        var levelBadge = UIManager_1.uimanager.createRect(panel, "levelBadge", 72, 34, MoodArt_1.MOOD_COLORS.cocoa, 255, 11, -181, trackY);
        levelBadge.zIndex = 12;
        this.profileLevelLabel = UIManager_1.uimanager.createLabel(levelBadge, "Lv." + displayProgress.level, 0, 0, 17, cc.Color.WHITE, 66, 28);
        if (this.currentCloudProfile) {
          this.profileNameLabel.string = UIManager_1.formatDisplayNickname(this.currentCloudProfile.nickname);
          UIManager_1.uimanager.applyTypography(this.profileNameLabel);
          this.renderProfileAvatar(this.profileAvatarContent, this.currentCloudProfile.avatarUrl || "");
        }
        return panel;
      };
      GameMainScene.prototype.drawDefaultAvatar = function(content, width, height) {
        void 0 === content && (content = this.profileAvatarContent);
        void 0 === width && (width = 68);
        void 0 === height && (height = 64);
        if (!content || !cc.isValid(content)) return;
        content.removeAllChildren();
        var avatar = MoodArt_1.createMoodBeanMascot(content, 0, -2, .92 * Math.min(width, height));
        avatar.name = "defaultAvatar";
      };
      GameMainScene.prototype.renderProfileAvatar = function(content, avatarUrl, width, height) {
        var _this = this;
        void 0 === width && (width = 68);
        void 0 === height && (height = 64);
        if (!content || !cc.isValid(content)) return;
        content === this.profileAvatarContent && (this.profileAvatarUrl = avatarUrl);
        this.drawDefaultAvatar(content, width, height);
        if (!avatarUrl) return;
        AssetLoader_1.loadRemoteTexture(avatarUrl).then(function(texture) {
          if (!cc.isValid(content)) return;
          if (content === _this.profileAvatarContent && _this.profileAvatarUrl !== avatarUrl) return;
          content.removeAllChildren();
          var spriteNode = new cc.Node("wechatAvatar");
          content.addChild(spriteNode);
          var sprite = spriteNode.addComponent(cc.Sprite);
          sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
          sprite.spriteFrame = new cc.SpriteFrame(texture);
          UIManager_1.uimanager.fitSpriteFrameInside(spriteNode, sprite.spriteFrame, width, height);
        }).catch(function() {
          return;
        });
      };
      GameMainScene.prototype.authorizeWeChatProfile = function(force) {
        void 0 === force && (force = true);
        return __awaiter(this, void 0, Promise, function() {
          var current, failureStage, wechatProfile, profile, error_6, detail, wxApi;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              current = this.currentCloudProfile;
              if (!force && current && PlatformAdapter_1.hasWeChatProfileAuthorization(current.playerId, current.avatarUrl)) return [ 2, current ];
              if (this.profileAuthorizationInFlight) return [ 2, null ];
              this.profileAuthorizationInFlight = true;
              failureStage = "\u5fae\u4fe1\u6388\u6743";
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 4, 5, 6 ]);
              return [ 4, PlatformAdapter_1.requestWeChatUserProfile(function() {
                return UIManager_1.uimanager.showWeChatAuthorizationSheet();
              }) ];

             case 2:
              wechatProfile = _a.sent();
              failureStage = "\u4fdd\u5b58\u5fae\u4fe1\u8d44\u6599";
              return [ 4, CloudService_1.cloudService.updateWeChatProfile(wechatProfile.nickName, wechatProfile.avatarUrl) ];

             case 3:
              profile = _a.sent();
              this.applyCloudProfile(profile);
              PlatformAdapter_1.rememberWeChatProfileAuthorization(profile.playerId);
              UIManager_1.uimanager.showToast("\u6388\u6743\u6210\u529f\uff0c\u6635\u79f0\u548c\u5934\u50cf\u5df2\u66f4\u65b0");
              return [ 2, profile ];

             case 4:
              error_6 = _a.sent();
              detail = error_6 && error_6.message ? error_6.message : String(error_6 || "\u672a\u77e5\u9519\u8bef");
              "undefined" !== typeof console && "function" === typeof console.error && console.error("[" + failureStage + "\u5931\u8d25]", error_6);
              wxApi = PlatformAdapter_1.getWxApi();
              wxApi && "function" === typeof wxApi.showModal ? wxApi.showModal({
                title: failureStage + "\u5931\u8d25",
                content: detail,
                showCancel: false,
                confirmText: "\u77e5\u9053\u4e86"
              }) : UIManager_1.uimanager.showToast(failureStage + "\u5931\u8d25\uff1a" + detail);
              return [ 2, null ];

             case 5:
              this.profileAuthorizationInFlight = false;
              return [ 7 ];

             case 6:
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.showUserProfileModal = function() {
        return __awaiter(this, void 0, Promise, function() {
          var profile, nickname, avatarUrl;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              return [ 4, this.bootstrapCloudProfile() ];

             case 1:
              _a.sent();
              profile = this.currentCloudProfile;
              nickname = UIManager_1.formatDisplayNickname(profile ? profile.nickname : this.profileNameLabel ? this.profileNameLabel.string : "\u89e3\u5fe7\u73a9\u5bb6");
              avatarUrl = profile ? profile.avatarUrl : "";
              UIManager_1.uimanager.showModal("\u7528\u6237\u4fe1\u606f", "", [ {
                text: "\u4fee\u6539",
                color: UIManager_1.BUTTON_COLORS.yellow,
                closeOnClick: false,
                onClick: function() {
                  _this.authorizeWeChatProfile().then(function(updated) {
                    updated && _this.showUserProfileModal();
                  });
                }
              }, {
                text: "\u5173\u95ed",
                color: UIManager_1.BUTTON_COLORS.green,
                onClick: function() {
                  return;
                }
              } ], function(panel, centerY) {
                MoodArt_1.createAvatarFrame(panel, "profileModalAvatarFrame", 0, centerY + 40, 136);
                var maskNode = new cc.Node("profileModalAvatarMask");
                maskNode.width = 112;
                maskNode.height = 112;
                maskNode.setPosition(0, centerY + 40);
                panel.addChild(maskNode);
                MoodArt_1.applyRoundedAvatarMask(maskNode);
                var content = new cc.Node("profileModalAvatar");
                content.width = 112;
                content.height = 112;
                maskNode.addChild(content);
                _this.renderProfileAvatar(content, avatarUrl || "", 112, 112);
                var name = UIManager_1.uimanager.createLabel(panel, nickname, 0, centerY - 48, 28, MoodArt_1.MOOD_COLORS.cocoa, 420, 48);
                UIManager_1.uimanager.applyTypography(name);
              }, 220, false, true);
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.createHomeRotatingTip = function(centerY) {
        var pill = UIManager_1.uimanager.createRect(this.screen, "homeTipPill", 600, 56, new cc.Color(255, 249, 232), 230, 28, 0, centerY);
        var tips = [ "\u5de6\u53f3\u62d6\u52a8\u5fc3\u60c5\u5757\uff0c\u8ba9\u5b83\u843d\u8fdb\u5408\u9002\u7684\u4f4d\u7f6e", "\u586b\u6ee1\u4e00\u6574\u884c\uff0c\u5c31\u80fd\u628a\u70e6\u607c\u8f7b\u8f7b\u6d88\u6389", "\u6d88\u9664\u5e26\u8868\u60c5\u7684\u5fc3\u60c5\u5757\uff0c\u6536\u96c6\u5f00\u5fc3\u8c46", "\u6311\u6218\u66f4\u9ad8\u5206\uff0c\u770b\u770b\u80fd\u6392\u7b2c\u51e0\u540d" ];
        var index = 0;
        var label = UIManager_1.uimanager.createLabel(pill, tips[index], 0, 0, 23, new cc.Color(45, 42, 39), 568, 40);
        this.makeLabelBold(label);
        cc.tween(label.node).repeatForever(cc.tween().delay(4.2).to(.38, {
          opacity: 0
        }, {
          easing: "sineIn"
        }).call(function() {
          index = (index + 1) % tips.length;
          label.string = tips[index];
        }).to(.42, {
          opacity: 255
        }, {
          easing: "sineOut"
        })).start();
      };
      GameMainScene.prototype.decorateStartButton = function() {
        if (!this.startButton || !cc.isValid(this.startButton)) return;
        var watermark = new cc.Node("startButtonMoodWatermark");
        watermark.setPosition(-155, 4);
        watermark.angle = -8;
        watermark.zIndex = 18;
        this.startButton.addChild(watermark);
        var g = watermark.addComponent(cc.Graphics);
        g.fillColor = new cc.Color(255, 255, 255, 20);
        g.strokeColor = new cc.Color(255, 255, 255, 42);
        g.lineWidth = 4;
        g.roundRect(-46, -43, 92, 86, 22);
        g.fill();
        g.stroke();
        g.fillColor = new cc.Color(255, 255, 255, 72);
        g.circle(-14, 8, 4);
        g.circle(14, 8, 4);
        g.fill();
        g.strokeColor = new cc.Color(255, 255, 255, 74);
        g.lineWidth = 4;
        g.moveTo(-18, -7);
        g.quadraticCurveTo(0, -24, 18, -7);
        g.stroke();
        g.fillColor = new cc.Color(255, 255, 255, 36);
        g.ellipse(-27, -4, 7, 3.5);
        g.ellipse(27, -4, 7, 3.5);
        g.fill();
        var labelNode = this.startButton.getChildByName("label");
        var label = labelNode ? labelNode.getComponent(cc.Label) : null;
        if (!label || !labelNode) return;
        labelNode.active = false;
        var art = new cc.Node("startWordmark");
        this.startButton.addChild(art);
        art.zIndex = 80;
        art.setPosition(0, 4);
        var sprite = art.addComponent(cc.Sprite);
        sprite.spriteFrame = AssetLoader_1.getSpriteFrame("home", AssetLoader_1.ASSET_PATHS.home.startWordmark);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        UIManager_1.uimanager.fitSpriteFrameInside(art, sprite.spriteFrame, 270, 112);
      };
      GameMainScene.prototype.createStartButtonGuide = function() {
        var _this = this;
        if (!this.startButton || !cc.isValid(this.startButton)) return;
        var button = this.startButton;
        var restX = button.x + 244;
        var restY = button.y - 142;
        var hoverX = button.x + 188;
        var hoverY = button.y - 57;
        var pressX = button.x + 181;
        var pressY = button.y - 48;
        var hand = this.createStartGuideHand(this.screen, restX, restY);
        hand.name = "startButtonGuideHand";
        hand.opacity = 0;
        hand.scale = .76;
        cc.tween(hand).repeatForever(cc.tween().delay(2.4).call(function() {
          if (!cc.isValid(hand)) return;
          hand.setPosition(restX, restY);
          hand.opacity = 0;
          hand.scale = .76;
        }).to(1.05, {
          x: hoverX,
          y: hoverY,
          opacity: 248,
          scale: .86
        }, {
          easing: "sineOut"
        }).delay(.35).to(.16, {
          x: pressX,
          y: pressY,
          scale: .8
        }, {
          easing: "sineInOut"
        }).call(function() {
          if (!cc.isValid(button)) return;
          cc.tween(button).to(.1, {
            scale: .965
          }, {
            easing: "sineOut"
          }).to(.22, {
            scale: 1
          }, {
            easing: "backOut"
          }).start();
          _this.playStartGuideTapRipple(button.x + 143, button.y + 2);
        }).delay(.38).to(.26, {
          x: hoverX,
          y: hoverY,
          scale: .86
        }, {
          easing: "sineOut"
        }).to(.72, {
          x: restX,
          y: restY + 14,
          opacity: 0,
          scale: .76
        }, {
          easing: "sineIn"
        }).delay(1.8)).start();
      };
      GameMainScene.prototype.createStartGuideHand = function(parent, x, y) {
        var node = new cc.Node("startGuideHand");
        node.width = 128;
        node.height = 128;
        node.setAnchorPoint(.5, .5);
        node.setPosition(x, y);
        node.zIndex = 180;
        parent.addChild(node);
        var sprite = node.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        var frame = AssetLoader_1.getSpriteFrame("home", AssetLoader_1.ASSET_PATHS.home.guideHand);
        sprite.spriteFrame = frame;
        UIManager_1.uimanager.fitSpriteFrameInside(node, frame, 128, 128);
        return node;
      };
      GameMainScene.prototype.playStartGuideTapRipple = function(x, y) {
        var _this = this;
        if (!this.screen || !cc.isValid(this.screen)) return;
        [ 0, .1, .2 ].forEach(function(delay, index) {
          var ripple = new cc.Node("startGuideTapRipple");
          ripple.width = 72;
          ripple.height = 72;
          ripple.setPosition(x, y);
          ripple.scale = .28;
          ripple.opacity = 0;
          ripple.zIndex = 170;
          _this.screen.addChild(ripple);
          var graphics = ripple.addComponent(cc.Graphics);
          graphics.strokeColor = 0 === index ? new cc.Color(255, 255, 245, 235) : new cc.Color(116, 190, 171, 205);
          graphics.lineWidth = 0 === index ? 4 : 2.5;
          graphics.circle(0, 0, 30);
          graphics.stroke();
          cc.tween(ripple).delay(delay).to(.06, {
            opacity: 220
          }).to(.62, {
            scale: 1.2 + .12 * index,
            opacity: 0
          }, {
            easing: "sineOut"
          }).call(function() {
            return ripple.destroy();
          }).start();
        });
      };
      GameMainScene.prototype.handleSettlementExit = function(request) {
        var _this = this;
        var roundId = this.activeRoundId;
        this.activeRoundId = "";
        if (request.restart) {
          delete this.settlementReceipts[roundId];
          this.startGame().then(function(started) {
            started || _this.enterHome();
          });
          return;
        }
        this.pendingSettlementPresentation = {
          roundId: roundId,
          request: request
        };
        this.enterHome(function() {
          _this.tryPresentConfirmedSettlement();
          _this.pendingSettlementPresentation && UIManager_1.uimanager.showToast("\u672c\u5c40\u6536\u96c6\u5df2\u4fdd\u5b58\uff0c\u5b9e\u9645\u5956\u52b1\u5f85\u4e91\u7aef\u786e\u8ba4");
        });
      };
      GameMainScene.prototype.tryPresentConfirmedSettlement = function() {
        var pending = this.pendingSettlementPresentation;
        if (!pending || !this.screen || "home" !== this.screen.name) return;
        var receipt = this.settlementReceipts[pending.roundId];
        if (!receipt || !receipt.settlement || !receipt.settlement.profile) return;
        delete this.settlementReceipts[pending.roundId];
        this.pendingSettlementPresentation = null;
        var remote = receipt.settlement;
        var profile = this.currentCloudProfile || remote.profile;
        var confirmedRequest = {
          restart: false,
          settlement: __assign(__assign({}, pending.request.settlement), {
            roundEarnedMoodBeans: remote.awardedMoodBeans,
            gainedExperience: remote.gainedExperience,
            moodBeanBalanceBefore: Math.max(0, profile.moodBeanBalance - remote.awardedMoodBeans),
            moodBeanBalanceAfter: profile.moodBeanBalance,
            levelAfter: profile.level,
            experienceAfter: profile.experience,
            experienceTargetAfter: ZyxGameModule_1.zyxGameModule.getExperienceTargetForLevel(profile.level)
          })
        };
        this.playSettlementRewardReturn(confirmedRequest, function() {});
      };
      GameMainScene.prototype.playSettlementRewardReturn = function(request, onComplete) {
        var _this = this;
        var settlement = request.settlement;
        if (!this.screen || !cc.isValid(this.screen)) {
          onComplete();
          return;
        }
        var earned = settlement.roundEarnedMoodBeans;
        if (earned <= 0) {
          onComplete();
          return;
        }
        this.setHomeDemoActive(false);
        var balanceEnd = ZyxGameModule_1.zyxGameModule.getDisplayMoodBeanBalance();
        var balanceStart = Math.max(0, balanceEnd - earned);
        this.layoutMoodBeanCountBadge(balanceStart);
        var rewardLayer = new cc.Node("settlementRewardReturn");
        rewardLayer.setContentSize(this.screen.width, this.screen.height);
        rewardLayer.addComponent(cc.BlockInputEvents);
        rewardLayer.zIndex = 2600;
        this.screen.addChild(rewardLayer);
        var veil = UIManager_1.uimanager.createRect(rewardLayer, "rewardSoftVeil", rewardLayer.width, rewardLayer.height, new cc.Color(72, 53, 47), 0);
        veil.zIndex = -2;
        cc.tween(veil).to(.16, {
          opacity: 58
        }).delay(.78).to(.38, {
          opacity: 0
        }).start();
        var target = this.getNodePositionInScreen(this.homeMoodBeanIcon);
        var count = Math.min(16, Math.max(4, 3 + Math.ceil(1.6 * Math.sqrt(earned))));
        var arrivals = 0;
        var seed = Math.max(1, 31 * settlement.roundScore + 17 * earned);
        var random = function() {
          seed = (9301 * seed + 49297) % 233280;
          return seed / 233280;
        };
        for (var index = 0; index < count; index++) {
          var token = MoodArt_1.createMoodBean(rewardLayer, 1 + index % 6, 470 * random() - 235, 330 * random() - 70, 38 + 11 * random(), 0);
          token.scale = .35;
          token.angle = 18 - 36 * random();
          this.animateRewardToken(token, target, .04 + .03 * index + .08 * random(), random, function() {
            arrivals++;
            var shown = balanceStart + Math.round((balanceEnd - balanceStart) * arrivals / count);
            _this.layoutMoodBeanCountBadge(shown);
            _this.pulseRewardTarget(_this.homeMoodBeanIcon);
            if (arrivals === count) {
              rewardLayer.destroy();
              _this.updateMoodBeanCount();
              _this.setHomeDemoActive(true);
              onComplete();
            }
          });
        }
      };
      GameMainScene.prototype.animateRewardToken = function(token, target, delay, random, onArrive) {
        var start = new cc.Vec2(token.x, token.y);
        var control = new cc.Vec2((start.x + target.x) / 2 + 160 * (random() - .5), Math.max(start.y, target.y) + 105 + 90 * random());
        var state = {
          t: 0
        };
        cc.tween(token).delay(delay).to(.2, {
          opacity: 255,
          scale: 1.08
        }, {
          easing: "backOut"
        }).delay(.2).start();
        cc.tween(state).delay(delay + .4).to(.58, {
          t: 1
        }, {
          easing: "quadIn",
          onUpdate: function() {
            if (!cc.isValid(token)) return;
            var inverse = 1 - state.t;
            token.x = inverse * inverse * start.x + 2 * inverse * state.t * control.x + state.t * state.t * target.x;
            token.y = inverse * inverse * start.y + 2 * inverse * state.t * control.y + state.t * state.t * target.y;
            token.scale = 1.08 - .58 * state.t;
            token.angle -= 5.5;
          }
        }).call(function() {
          onArrive();
          cc.isValid(token) && token.destroy();
        }).start();
      };
      GameMainScene.prototype.updateHomeExperienceDisplay = function(level, experience, target) {
        this.profileLevelLabel && (this.profileLevelLabel.string = "Lv." + level);
        this.profileExperienceLabel && (this.profileExperienceLabel.string = "\u7ecf\u9a8c " + experience + "/" + target);
        if (!this.profileExperienceFill || !cc.isValid(this.profileExperienceFill)) return;
        var ratio = Math.max(0, Math.min(1, experience / Math.max(1, target)));
        var fillWidth = Math.max(8, this.profileExperienceFillWidth * ratio);
        this.profileExperienceFill.width = fillWidth;
        this.profileExperienceFill.x = this.profileExperienceFillLeft + fillWidth / 2;
        UIManager_1.uimanager.drawRect(this.profileExperienceFill, fillWidth, 20, MoodArt_1.MOOD_COLORS.sage, 7, 255);
      };
      GameMainScene.prototype.getNodePositionInScreen = function(node) {
        if (!node || !cc.isValid(node) || !this.screen) return cc.v2(0, 0);
        return this.screen.convertToNodeSpaceAR(node.convertToWorldSpaceAR(cc.v2(0, 0)));
      };
      GameMainScene.prototype.pulseRewardTarget = function(node) {
        if (!node || !cc.isValid(node)) return;
        cc.Tween.stopAllByTarget(node);
        node.scale = 1;
        cc.tween(node).to(.08, {
          scale: 1.08
        }).to(.14, {
          scale: 1
        }, {
          easing: "backOut"
        }).start();
      };
      GameMainScene.prototype.makeLabelBold = function(label) {
        label && UIManager_1.uimanager.applyTypography(label, true);
      };
      GameMainScene.prototype.startGame = function(profileBootstrapHandled, replacement) {
        void 0 === profileBootstrapHandled && (profileBootstrapHandled = false);
        void 0 === replacement && (replacement = null);
        return __awaiter(this, void 0, Promise, function() {
          var active_1, error_7, storage, roundId, started, error_8, game, error_9;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.gameAssetsLoading) return [ 2, false ];
              this.gameAssetsLoading = true;
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 25, 26, 27 ]);
              if (!(!profileBootstrapHandled || !this.cloudProfileReady)) return [ 3, 3 ];
              return [ 4, this.bootstrapCloudProfile() ];

             case 2:
              _a.sent();
              _a.label = 3;

             case 3:
              if (!this.cloudProfileReady) {
                UIManager_1.uimanager.showToast("\u9700\u8981\u8054\u7f51\u786e\u8ba4\u8fdb\u5ea6\u540e\u624d\u80fd\u5f00\u59cb");
                return [ 2, false ];
              }
              return [ 4, CloudService_1.cloudService.getActiveRound() ];

             case 4:
              active_1 = _a.sent();
              if (!(active_1 && ZyxGameModule_1.zyxGameModule.getPendingRoundSettlements().some(function(record) {
                return record.roundId === active_1.roundId;
              }))) return [ 3, 7 ];
              return [ 4, this.flushPendingRoundSettlements() ];

             case 5:
              _a.sent();
              return [ 4, CloudService_1.cloudService.getActiveRound() ];

             case 6:
              active_1 = _a.sent();
              if (active_1 && ZyxGameModule_1.zyxGameModule.getPendingRoundSettlements().some(function(record) {
                return record.roundId === active_1.roundId;
              })) {
                UIManager_1.uimanager.showToast("\u4e0a\u4e00\u5c40\u7ed3\u679c\u6b63\u5728\u540c\u6b65\uff0c\u8bf7\u8054\u7f51\u540e\u91cd\u8bd5");
                return [ 2, false ];
              }
              _a.label = 7;

             case 7:
              if (active_1 && "current" === replacement && (active_1.roundId !== this.activeRoundId || !RoundProgress_1.roundProgress.token)) {
                UIManager_1.uimanager.showToast("\u8fd9\u5c40\u72b6\u6001\u5df2\u66f4\u65b0\uff0c\u8bf7\u8fd4\u56de\u9996\u9875\u786e\u8ba4\u6700\u65b0\u8fdb\u5ea6");
                return [ 2, false ];
              }
              if (active_1 && replacement && "current" !== replacement && (active_1.roundId !== replacement.roundId || active_1.generation !== replacement.generation)) {
                UIManager_1.uimanager.showToast("\u8fdb\u5ea6\u521a\u521a\u66f4\u65b0\uff0c\u8bf7\u518d\u6b21\u70b9\u51fb\u5f00\u59cb\u786e\u8ba4");
                return [ 2, false ];
              }
              if (!(active_1 && !replacement)) return [ 3, 11 ];
              if (!(this.screen && "home" === this.screen.name)) return [ 3, 8 ];
              this.showResumePrompt(active_1, false);
              return [ 3, 10 ];

             case 8:
              return [ 4, new Promise(function(resolve) {
                return _this.enterHome(function() {
                  _this.showResumePrompt(active_1, false);
                  resolve();
                });
              }) ];

             case 9:
              _a.sent();
              _a.label = 10;

             case 10:
              return [ 2, false ];

             case 11:
              if (this.stamina && this.getStaminaPreview().current < 1 && !cc.sys.localStorage.getItem(PENDING_START_ROUND_ID_KEY)) {
                this.showStaminaEmptyModal();
                return [ 2, false ];
              }
              if (!!ZyxGameModule_1.zyxGameModule.canAcceptPendingRoundSettlement()) return [ 3, 13 ];
              UIManager_1.uimanager.showToast("\u6b63\u5728\u540c\u6b65\u8fdb\u5ea6\u2026");
              return [ 4, this.flushPendingRoundSettlements() ];

             case 12:
              _a.sent();
              if (!ZyxGameModule_1.zyxGameModule.canAcceptPendingRoundSettlement()) {
                UIManager_1.uimanager.showToast("\u9700\u8981\u8054\u7f51\u540c\u6b65\u8fdb\u5ea6\u540e\u7ee7\u7eed");
                return [ 2, false ];
              }
              _a.label = 13;

             case 13:
              AssetLoader_1.isFeatureReady("game") || UIManager_1.uimanager.showToast("\u6b63\u5728\u52a0\u8f7d\u6d88\u9664\u8d44\u6e90\u2026");
              _a.label = 14;

             case 14:
              _a.trys.push([ 14, 16, , 17 ]);
              return [ 4, AssetLoader_1.prepareFeature("game") ];

             case 15:
              _a.sent();
              return [ 3, 17 ];

             case 16:
              error_7 = _a.sent();
              UIManager_1.uimanager.showToast("\u6d88\u9664\u8d44\u6e90\u52a0\u8f7d\u5931\u8d25\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc\u540e\u91cd\u8bd5");
              return [ 2, false ];

             case 17:
              if (!(!profileBootstrapHandled || !this.cloudProfileReady)) return [ 3, 19 ];
              return [ 4, this.bootstrapCloudProfile() ];

             case 18:
              _a.sent();
              _a.label = 19;

             case 19:
              if (!this.cloudProfileReady) {
                UIManager_1.uimanager.showToast("\u9700\u8981\u8054\u7f51\u786e\u8ba4\u4f53\u529b\u540e\u624d\u80fd\u5f00\u59cb\u65b0\u5c40");
                return [ 2, false ];
              }
              storage = cc.sys.localStorage;
              roundId = storage.getItem(PENDING_START_ROUND_ID_KEY) || "";
              if (!/^round_[a-z0-9_]{8,80}$/.test(roundId)) {
                roundId = "round_" + Date.now() + "_" + Math.floor(1e9 * Math.random()).toString(36);
                storage.setItem(PENDING_START_ROUND_ID_KEY, roundId);
              }
              started = void 0;
              _a.label = 20;

             case 20:
              _a.trys.push([ 20, 22, , 23 ]);
              return [ 4, CloudService_1.cloudService.startRound(roundId, active_1 ? {
                replaceRoundId: active_1.roundId,
                replacementGeneration: active_1.generation,
                replaceSessionToken: RoundProgress_1.roundProgress.roundId === active_1.roundId ? RoundProgress_1.roundProgress.token : void 0
              } : void 0) ];

             case 21:
              started = _a.sent();
              return [ 3, 23 ];

             case 22:
              error_8 = _a.sent();
              error_8 && error_8.stamina && this.applyStaminaState(error_8.stamina);
              if (error_8 && "ROUND_RESUME_REQUIRED" === error_8.businessCode) {
                storage.removeItem(PENDING_START_ROUND_ID_KEY);
                UIManager_1.uimanager.showToast("\u5df2\u6709\u672a\u7ed3\u7b97\u8fdb\u5ea6\uff0c\u8bf7\u518d\u6b21\u70b9\u51fb\u5f00\u59cb\u67e5\u770b");
              } else if (error_8 && "STAMINA_EMPTY" === error_8.businessCode) this.showStaminaEmptyModal(); else if (!error_8 || "BOARD_RULES_UNSUPPORTED" !== error_8.businessCode && "ROUND_COLLECTION_RULE_CONFLICT" !== error_8.businessCode && "ROUND_ALREADY_SETTLED" !== error_8.businessCode) error_8 && "COLLECTION_RULE_UNSUPPORTED" === error_8.businessCode ? UIManager_1.uimanager.showToast(error_8.message) : UIManager_1.uimanager.showToast("\u5f00\u5c40\u6821\u9a8c\u5931\u8d25\uff0c\u8bf7\u8054\u7f51\u540e\u91cd\u8bd5"); else {
                storage.removeItem(PENDING_START_ROUND_ID_KEY);
                UIManager_1.uimanager.showToast("\u5bf9\u5c40\u72b6\u6001\u5df2\u66f4\u65b0\uff0c\u8bf7\u91cd\u65b0\u5f00\u59cb");
              }
              return [ 2, false ];

             case 23:
              if (!started || started.roundId !== roundId) {
                UIManager_1.uimanager.showToast("\u5f00\u5c40\u6821\u9a8c\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5");
                return [ 2, false ];
              }
              RoundProgress_1.roundProgress.begin(started, this.currentCloudProfile.playerId);
              this.applyStaminaState(started.stamina);
              this.activeRoundId = roundId;
              ZyxGameModule_1.zyxGameModule.cloudRoundId = roundId;
              started.profile && this.applyCloudProfile(started.profile);
              started.seed && ZyxGameModule_1.zyxGameModule.setRoundSeed(started.seed, true === started.isTutorial, true === started.heartRescueEligible);
              return [ 4, this.playStartStaminaFlight() ];

             case 24:
              _a.sent();
              if (this.pendingSettlementPresentation) {
                delete this.settlementReceipts[this.pendingSettlementPresentation.roundId];
                this.pendingSettlementPresentation = null;
              }
              this.replaceScreen("game");
              game = this.screen.addComponent(ZyxGame_1.default);
              game.initialize(function(request) {
                return _this.handleSettlementExit(request);
              }, function(settlement, startedAt) {
                return _this.submitSettlementToCloud(settlement, startedAt);
              }, function() {
                return _this.startGame(false, "current");
              }, this.currentCloudProfile, null, function() {
                return _this.enterHome();
              });
              storage.removeItem(PENDING_START_ROUND_ID_KEY);
              return [ 2, true ];

             case 25:
              error_9 = _a.sent();
              cc.error("\u5f00\u5c40\u5931\u8d25", error_9);
              UIManager_1.uimanager.showToast("\u5f00\u5c40\u5931\u8d25\uff0c\u8bf7\u91cd\u8bd5");
              return [ 2, false ];

             case 26:
              this.gameAssetsLoading = false;
              return [ 7 ];

             case 27:
              return [ 2 ];
            }
          });
        });
      };
      GameMainScene.prototype.showResourceLoadFailure = function(feature, retry) {
        UIManager_1.uimanager.showModal("\u8d44\u6e90\u52a0\u8f7d\u5931\u8d25", feature + "\u8d44\u6e90\u672a\u80fd\u52a0\u8f7d\uff0c\u8bf7\u68c0\u67e5\u7f51\u7edc\u540e\u91cd\u8bd5\u3002", [ {
          text: "\u91cd\u65b0\u52a0\u8f7d",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: retry
        } ], null, 0, false, true);
      };
      GameMainScene.prototype.stopScreenTweens = function(root) {
        var nodes = [ root ];
        while (nodes.length > 0) {
          var node = nodes.pop();
          if (!node) continue;
          cc.Tween.stopAllByTarget(node);
          var waterTweenState = node.waterTweenState;
          waterTweenState && cc.Tween.stopAllByTarget(waterTweenState);
          nodes.push.apply(nodes, node.children);
        }
      };
      GameMainScene.prototype.replaceScreen = function(name) {
        this.homeFriendRanking && WeChatFriends_1.postFriendMessage("friends:hide");
        this.homeFriendRanking = null;
        AudioManager_1.audioManager.enterScene("home" === name ? "home" : "game" === name ? "game" : "silent");
        if (this.screen && this.screen.isValid) {
          this.stopScreenTweens(this.screen);
          this.screen.destroy();
        }
        this.profileNameLabel = null;
        this.profileAvatarContent = null;
        this.profileLevelLabel = null;
        this.profileExperienceFill = null;
        this.profileExperienceLabel = null;
        this.homeMoodBeanIcon = null;
        this.homeDemoLayer = null;
        this.homeDemoClock = null;
        this.homeDemoPlaying = false;
        this.startHomeDemoLoop = null;
        this.startButton = null;
        this.startStaminaRecoveryLabel = null;
        this.staminaLabel = null;
        this.staminaRecoveryLabel = null;
        this.staminaIcon = null;
        this.moodBeanCountLabel = null;
        this.moodBeanCountCard = null;
        this.screen = new cc.Node(name);
        this.screen.setAnchorPoint(.5, .5);
        this.node.addChild(this.screen);
        this.applyStageLayout(this.screen);
        this.renderBackdrop(name);
        UIManager_1.uimanager.init(this.screen);
      };
      GameMainScene = __decorate([ ccclass ], GameMainScene);
      return GameMainScene;
    }(cc.Component);
    exports.default = GameMainScene;
    cc._RF.pop();
  }, {
    "./dataModule/ZyxGameModule": "ZyxGameModule",
    "./gm/GmBubble": "GmBubble",
    "./manager/AssetLoader": "AssetLoader",
    "./manager/AudioManager": "AudioManager",
    "./manager/CloudService": "CloudService",
    "./manager/GmAccess": "GmAccess",
    "./manager/PlatformAdapter": "PlatformAdapter",
    "./manager/ResponsiveLayout": "ResponsiveLayout",
    "./manager/RoundProgress": "RoundProgress",
    "./manager/SettingsPanel": "SettingsPanel",
    "./manager/SettlementSync": "SettlementSync",
    "./manager/ShareReward": "ShareReward",
    "./manager/UIManager": "UIManager",
    "./manager/WeChatFriends": "WeChatFriends",
    "./zyxGame/GlyphFactory": "GlyphFactory",
    "./zyxGame/HomeFriendRanking": "HomeFriendRanking",
    "./zyxGame/LeaderboardPanel": "LeaderboardPanel",
    "./zyxGame/MoodArt": "MoodArt",
    "./zyxGame/ShopPanel": "ShopPanel",
    "./zyxGame/ZyxGame": "ZyxGame"
  } ],
  GamePanel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "39ab0ja9dBFt7VhkemVwJd7", "GamePanel");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createGamePanel = exports.resizeGamePanel = exports.GAME_PANEL_FILL = exports.GAME_PANEL_RADIUS = void 0;
    exports.GAME_PANEL_RADIUS = 24;
    exports.GAME_PANEL_FILL = [ 255, 247, 225 ];
    var panelFrame = null;
    function getPanelFrame() {
      if (panelFrame) return panelFrame;
      var size = 96;
      var half = 42;
      var radius = exports.GAME_PANEL_RADIUS;
      var data = new Uint8Array(size * size * 4);
      var distance = function(x, y) {
        var qx = Math.abs(x) - (half - radius);
        var qy = Math.abs(y) - (half - radius);
        return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - radius;
      };
      for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
        var px = x + .5 - size / 2;
        var py = y + .5 - size / 2;
        var d = distance(px, py);
        var body = Math.max(0, Math.min(1, .5 - d));
        var shadow = .2 * Math.max(0, Math.min(1, 1.5 - distance(px, py - 4)));
        var alpha = body + shadow * (1 - body);
        var color = d > -2.4 ? [ 159, 117, 80 ] : d > -3.6 ? [ 255, 255, 247 ] : exports.GAME_PANEL_FILL;
        var index = 4 * (y * size + x);
        for (var channel = 0; channel < 3; channel++) data[index + channel] = alpha > 0 ? Math.round((color[channel] * body + [ 101, 70, 46 ][channel] * shadow * (1 - body)) / alpha) : 0;
        data[index + 3] = Math.round(255 * alpha);
      }
      var texture = new cc.Texture2D();
      texture.initWithData(data, cc.Texture2D.PixelFormat.RGBA8888, size, size);
      panelFrame = new cc.SpriteFrame(texture);
      panelFrame.insetTop = panelFrame.insetBottom = panelFrame.insetLeft = panelFrame.insetRight = 30;
      return panelFrame;
    }
    function resizeGamePanel(node, width, height) {
      node.setContentSize(width, height);
      var skin = node.getChildByName("gamePanelSkin");
      skin && skin.setContentSize(width + 12, height + 12);
    }
    exports.resizeGamePanel = resizeGamePanel;
    function createGamePanel(parent, name, width, height, x, y) {
      void 0 === x && (x = 0);
      void 0 === y && (y = 0);
      var root = new cc.Node(name);
      parent.addChild(root);
      root.setPosition(x, y);
      var skin = new cc.Node("gamePanelSkin");
      skin.zIndex = -1;
      root.addChild(skin);
      var sprite = skin.addComponent(cc.Sprite);
      sprite.spriteFrame = getPanelFrame();
      sprite.type = cc.Sprite.Type.SLICED;
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      resizeGamePanel(root, width, height);
      return root;
    }
    exports.createGamePanel = createGamePanel;
    cc._RF.pop();
  }, {} ],
  GameSettings: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "1c7932B38BL2IZcLvbeDIDg", "GameSettings");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.gameSettings = void 0;
    var PlatformAdapter_1 = require("./PlatformAdapter");
    var STORAGE_KEY = "zyx_game_settings_v1";
    var GameSettings = function() {
      function GameSettings() {
        this.loaded = false;
        this.audioListeners = new Set();
        this.state = {
          soundEnabled: true,
          soundVolume: .7,
          vibrationEnabled: true
        };
      }
      Object.defineProperty(GameSettings, "instance", {
        get: function() {
          this._instance || (this._instance = new GameSettings());
          return this._instance;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(GameSettings.prototype, "soundEnabled", {
        get: function() {
          this.ensureLoaded();
          return this.state.soundEnabled;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(GameSettings.prototype, "soundVolume", {
        get: function() {
          this.ensureLoaded();
          return this.state.soundVolume;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(GameSettings.prototype, "vibrationEnabled", {
        get: function() {
          this.ensureLoaded();
          return this.state.vibrationEnabled;
        },
        enumerable: false,
        configurable: true
      });
      GameSettings.prototype.getSnapshot = function() {
        this.ensureLoaded();
        return {
          soundEnabled: this.state.soundEnabled,
          soundVolume: this.state.soundVolume,
          vibrationEnabled: this.state.vibrationEnabled
        };
      };
      GameSettings.prototype.setSoundEnabled = function(enabled) {
        this.ensureLoaded();
        this.state.soundEnabled = !!enabled;
        this.persist();
        this.audioListeners.forEach(function(listener) {
          return listener();
        });
      };
      GameSettings.prototype.setSoundVolume = function(volume) {
        this.ensureLoaded();
        this.state.soundVolume = Math.max(0, Math.min(1, Number(volume) || 0));
        this.persist();
        this.audioListeners.forEach(function(listener) {
          return listener();
        });
      };
      GameSettings.prototype.setVibrationEnabled = function(enabled) {
        this.ensureLoaded();
        this.state.vibrationEnabled = !!enabled;
        this.persist();
      };
      GameSettings.prototype.vibrateLight = function() {
        this.ensureLoaded();
        if (!this.state.vibrationEnabled) return;
        PlatformAdapter_1.vibrateShortLight();
      };
      GameSettings.prototype.ensureLoaded = function() {
        if (this.loaded) return;
        this.loaded = true;
        try {
          var raw = cc.sys.localStorage.getItem(STORAGE_KEY);
          if (raw) {
            var stored = JSON.parse(raw);
            this.state.soundEnabled = false !== stored.soundEnabled;
            this.state.soundVolume = Math.max(0, Math.min(1, Number(stored.soundVolume)));
            Number.isFinite(this.state.soundVolume) || (this.state.soundVolume = .7);
            this.state.vibrationEnabled = false !== stored.vibrationEnabled;
          }
        } catch (error) {}
      };
      GameSettings.prototype.onAudioChange = function(listener) {
        var _this = this;
        this.audioListeners.add(listener);
        return function() {
          return _this.audioListeners.delete(listener);
        };
      };
      GameSettings.prototype.persist = function() {
        try {
          cc.sys.localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
        } catch (error) {}
      };
      return GameSettings;
    }();
    exports.default = GameSettings;
    exports.gameSettings = GameSettings.instance;
    cc._RF.pop();
  }, {
    "./PlatformAdapter": "PlatformAdapter"
  } ],
  GlyphFactory: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a3966Xn2uJCq4NNFSjJOpBe", "GlyphFactory");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createRestartGlyph = exports.createBackGlyph = exports.createShareGlyph = exports.createVideoGlyph = exports.decorateSettingsActionButton = exports.decorateActionButton = exports.createPauseGlyph = exports.createPurifierGlyph = exports.createHammerGlyph = void 0;
    var AssetLoader_1 = require("../manager/AssetLoader");
    var UIManager_1 = require("../manager/UIManager");
    function createHammerGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      var node = new cc.Node("hammerGlyph");
      node.width = 82;
      node.height = 82;
      node.setAnchorPoint(.5, .5);
      node.setPosition(x, y);
      node.scale = scale;
      node.angle = 0;
      node.zIndex = 55;
      parent.addChild(node);
      var shadow = new cc.Node("hammerShadow");
      shadow.zIndex = 0;
      shadow.setPosition(0, -31);
      node.addChild(shadow);
      var shadowG = shadow.addComponent(cc.Graphics);
      shadowG.fillColor = new cc.Color(73, 48, 43, 42);
      shadowG.ellipse(0, 0, 25, 6);
      shadowG.fill();
      var art = new cc.Node("hammerArt");
      art.width = 66;
      art.height = 84;
      art.setPosition(0, 3);
      art.zIndex = 2;
      node.addChild(art);
      var sprite = art.addComponent(cc.Sprite);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      var frame = AssetLoader_1.getSpriteFrame("game", AssetLoader_1.ASSET_PATHS.game.hammer);
      sprite.spriteFrame = frame;
      UIManager_1.uimanager.fitSpriteFrameInside(art, frame, 66, 84);
      art.scaleX = -Math.abs(art.scaleX || 1);
      return node;
    }
    exports.createHammerGlyph = createHammerGlyph;
    function createPurifierGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      var node = new cc.Node("magicWandGlyph");
      node.width = 82;
      node.height = 82;
      node.setAnchorPoint(.5, .5);
      node.setPosition(x, y);
      node.scale = scale;
      node.zIndex = 55;
      parent.addChild(node);
      var shadow = new cc.Node("magicWandShadow");
      shadow.zIndex = 0;
      shadow.setPosition(0, -31);
      node.addChild(shadow);
      var shadowGraphics = shadow.addComponent(cc.Graphics);
      shadowGraphics.fillColor = new cc.Color(73, 48, 43, 42);
      shadowGraphics.ellipse(0, 0, 24, 6);
      shadowGraphics.fill();
      var art = new cc.Node("magicWandArt");
      art.width = 68;
      art.height = 86;
      art.setPosition(0, 3);
      art.zIndex = 2;
      node.addChild(art);
      var sprite = art.addComponent(cc.Sprite);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      var frame = AssetLoader_1.getSpriteFrame("game", AssetLoader_1.ASSET_PATHS.game.magicWand);
      sprite.spriteFrame = frame;
      UIManager_1.uimanager.fitSpriteFrameInside(art, frame, 68, 86);
      return node;
    }
    exports.createPurifierGlyph = createPurifierGlyph;
    function createPauseGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      var node = new cc.Node("pauseGlyph");
      node.setPosition(x, y);
      node.scale = scale;
      node.zIndex = 60;
      parent.addChild(node);
      var graphics = node.addComponent(cc.Graphics);
      graphics.fillColor = new cc.Color(112, 61, 55, 92);
      graphics.roundRect(-17, -20, 13, 42, 6);
      graphics.roundRect(5, -20, 13, 42, 6);
      graphics.fill();
      graphics.fillColor = new cc.Color(255, 239, 193);
      graphics.strokeColor = new cc.Color(132, 73, 62);
      graphics.lineWidth = 2;
      graphics.roundRect(-18, -17, 12, 38, 6);
      graphics.roundRect(6, -17, 12, 38, 6);
      graphics.fill();
      graphics.stroke();
      return node;
    }
    exports.createPauseGlyph = createPauseGlyph;
    function layoutActionButton(button, glyphWidth, fontSize) {
      var node = button.getChildByName("label");
      var label = node.getComponent(cc.Label);
      if (fontSize) {
        label.fontSize = fontSize;
        label.lineHeight = fontSize + 8;
      }
      label.overflow = cc.Label.Overflow.NONE;
      label.enableWrapText = false;
      UIManager_1.uimanager.applyTypography(label, true);
      label._forceUpdateRenderData();
      var iconScale = Math.min(1, label.fontSize / 32);
      var iconWidth = glyphWidth * iconScale;
      var gap = 8;
      var width = iconWidth + gap + node.width;
      var fit = Math.min(1, (button.width - 32) / width);
      node.scale = fit;
      node.setPosition(-(iconWidth + gap) / 2 * fit, 2);
      return {
        x: (node.width + gap) / 2 * fit,
        scale: iconScale * fit
      };
    }
    function decorateActionButton(button, icon, fontSize) {
      var layout = layoutActionButton(button, "video" === icon || "share" === icon ? 64 : 44, fontSize);
      "video" === icon ? createVideoGlyph(button, layout.x, 2, layout.scale) : "share" === icon ? createShareGlyph(button, layout.x, 2, layout.scale) : "back" === icon ? createBackGlyph(button, layout.x, 2, layout.scale) : createRestartGlyph(button, layout.x, 2, layout.scale);
    }
    exports.decorateActionButton = decorateActionButton;
    function decorateSettingsActionButton(button, icon) {
      if ("restart" === icon) {
        decorateActionButton(button, "restart");
        return;
      }
      var layout = layoutActionButton(button, 44);
      createNavigationGlyph(button, icon, layout.x, 2, layout.scale);
    }
    exports.decorateSettingsActionButton = decorateSettingsActionButton;
    function createVideoGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      var node = new cc.Node("videoGlyph");
      node.setPosition(x, y);
      node.scale = scale;
      node.zIndex = 60;
      parent.addChild(node);
      var graphics = node.addComponent(cc.Graphics);
      graphics.fillColor = new cc.Color(85, 56, 49, 54);
      graphics.roundRect(-31, -23, 62, 49, 15);
      graphics.fill();
      graphics.fillColor = new cc.Color(255, 247, 220);
      graphics.strokeColor = new cc.Color(119, 78, 66);
      graphics.lineWidth = 2.4;
      graphics.roundRect(-32, -20, 64, 48, 15);
      graphics.fill();
      graphics.stroke();
      graphics.fillColor = new cc.Color(248, 194, 72);
      graphics.roundRect(-24, -13, 38, 32, 10);
      graphics.fill();
      graphics.fillColor = new cc.Color(255, 250, 224);
      graphics.moveTo(-10, -6);
      graphics.lineTo(7, 3);
      graphics.lineTo(-10, 12);
      graphics.close();
      graphics.fill();
      graphics.fillColor = new cc.Color(226, 104, 95);
      graphics.circle(23, 10, 4);
      graphics.fill();
      graphics.fillColor = new cc.Color(105, 181, 129);
      graphics.circle(23, -4, 4);
      graphics.fill();
      return node;
    }
    exports.createVideoGlyph = createVideoGlyph;
    function createShareGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      var node = new cc.Node("shareGlyph");
      node.setPosition(x, y);
      node.scale = scale;
      node.zIndex = 60;
      parent.addChild(node);
      var graphics = node.addComponent(cc.Graphics);
      graphics.fillColor = new cc.Color(85, 56, 49, 48);
      graphics.roundRect(-31, -23, 62, 49, 15);
      graphics.fill();
      graphics.fillColor = new cc.Color(255, 247, 220);
      graphics.strokeColor = new cc.Color(119, 78, 66);
      graphics.lineWidth = 2.4;
      graphics.roundRect(-32, -20, 64, 48, 15);
      graphics.fill();
      graphics.stroke();
      graphics.fillColor = new cc.Color(105, 181, 129);
      graphics.moveTo(-22, -2);
      graphics.lineTo(22, 12);
      graphics.lineTo(4, -2);
      graphics.close();
      graphics.fill();
      graphics.fillColor = new cc.Color(244, 181, 60);
      graphics.moveTo(-22, -2);
      graphics.lineTo(22, 12);
      graphics.lineTo(8, -14);
      graphics.close();
      graphics.fill();
      graphics.strokeColor = new cc.Color(90, 64, 56);
      graphics.lineWidth = 2;
      graphics.moveTo(-22, -2);
      graphics.lineTo(4, -2);
      graphics.lineTo(22, 12);
      graphics.moveTo(4, -2);
      graphics.lineTo(8, -14);
      graphics.stroke();
      graphics.fillColor = new cc.Color(226, 104, 95);
      graphics.circle(24, -8, 3.5);
      graphics.fill();
      graphics.fillColor = new cc.Color(248, 194, 72);
      graphics.circle(24, 4, 3.5);
      graphics.fill();
      return node;
    }
    exports.createShareGlyph = createShareGlyph;
    function createNavigationGlyph(parent, icon, x, y, scale) {
      var node = new cc.Node(icon + "Glyph");
      node.setPosition(x, y);
      node.scale = scale;
      node.zIndex = 60;
      parent.addChild(node);
      var g = node.addComponent(cc.Graphics);
      g.lineCap = cc.Graphics.LineCap.ROUND;
      g.lineJoin = cc.Graphics.LineJoin.ROUND;
      g.strokeColor = UIManager_1.BUTTON_TEXT_COLOR;
      g.fillColor = new cc.Color(255, 247, 222);
      g.lineWidth = 2.8;
      if ("restart" === icon) {
        g.moveTo(10, 10);
        g.bezierCurveTo(4, 16, -5, 16, -10, 10);
        g.bezierCurveTo(-16, 4, -16, -4, -10, -10);
        g.bezierCurveTo(-4, -16, 5, -16, 10, -10);
        g.bezierCurveTo(13, -7, 14, -3, 14, 2);
        g.stroke();
        g.moveTo(8, -3);
        g.lineTo(14, 3);
        g.lineTo(20, -3);
        g.stroke();
      } else if ("play" === icon) {
        g.moveTo(-8, -13);
        g.lineTo(12, -2);
        g.quadraticCurveTo(15, 0, 12, 2);
        g.lineTo(-8, 13);
        g.quadraticCurveTo(-12, 15, -12, 11);
        g.lineTo(-12, -11);
        g.quadraticCurveTo(-12, -15, -8, -13);
        g.close();
        g.fill();
        g.stroke();
      } else if ("exit" === icon) {
        g.moveTo(2, 14);
        g.lineTo(-11, 14);
        g.quadraticCurveTo(-15, 14, -15, 10);
        g.lineTo(-15, -10);
        g.quadraticCurveTo(-15, -14, -11, -14);
        g.lineTo(2, -14);
        g.stroke();
        g.moveTo(-4, 0);
        g.lineTo(17, 0);
        g.moveTo(10, 7);
        g.lineTo(17, 0);
        g.lineTo(10, -7);
        g.stroke();
      } else if ("back" === icon) {
        g.moveTo(14, 0);
        g.lineTo(-14, 0);
        g.moveTo(-5, 9);
        g.lineTo(-14, 0);
        g.lineTo(-5, -9);
        g.stroke();
      } else {
        g.moveTo(-13, 0);
        g.lineTo(-4, -9);
        g.lineTo(14, 11);
        g.stroke();
      }
      return node;
    }
    function createBackGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      return createNavigationGlyph(parent, "back", x, y, scale);
    }
    exports.createBackGlyph = createBackGlyph;
    function createRestartGlyph(parent, x, y, scale) {
      void 0 === scale && (scale = 1);
      return createNavigationGlyph(parent, "restart", x, y, scale);
    }
    exports.createRestartGlyph = createRestartGlyph;
    cc._RF.pop();
  }, {
    "../manager/AssetLoader": "AssetLoader",
    "../manager/UIManager": "UIManager"
  } ],
  GmAccess: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "da204M3qqhEPIqOj/mmIkCV", "GmAccess");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.isGmEnvironmentAvailable = void 0;
    function isGmEnvironmentAvailable() {
      return (true, true) && true === cc.sys.isBrowser;
    }
    exports.isGmEnvironmentAvailable = isGmEnvironmentAvailable;
    cc._RF.pop();
  }, {} ],
  GmBubble: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "de75dxZXE9J84rOnG5+mXiF", "GmBubble");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.attachGmBubble = void 0;
    var UIManager_1 = require("../manager/UIManager");
    var GmPanel_1 = require("./GmPanel");
    var GmCloudApi_1 = require("./GmCloudApi");
    var gmBubble = null;
    function loadBubblePosition(defaultX, defaultY) {
      try {
        var raw = cc.sys.localStorage.getItem("zyx_gm_bubble_pos_v1");
        if (!raw) return {
          x: defaultX,
          y: defaultY
        };
        var parsed = JSON.parse(raw);
        var x = Number(parsed && parsed.x);
        var y = Number(parsed && parsed.y);
        if (!Number.isFinite(x) || !Number.isFinite(y)) return {
          x: defaultX,
          y: defaultY
        };
        return {
          x: x,
          y: y
        };
      } catch (e) {
        return {
          x: defaultX,
          y: defaultY
        };
      }
    }
    function saveBubblePosition(x, y) {
      try {
        cc.sys.localStorage.setItem("zyx_gm_bubble_pos_v1", JSON.stringify({
          x: x,
          y: y
        }));
      } catch (e) {}
    }
    function attachGmBubble(parent, hooks) {
      var _this = this;
      if (gmBubble && cc.isValid(gmBubble)) return;
      var safeArea = UIManager_1.uimanager.getSafeAreaMetrics();
      var bubbleWidth = 88;
      var bubbleHeight = 48;
      var halfW = bubbleWidth / 2;
      var halfH = bubbleHeight / 2;
      var defaultX = -cc.winSize.width / 2 + safeArea.left + halfW + 16;
      var defaultY = cc.winSize.height / 2 - safeArea.top - halfH - 8;
      var saved = loadBubblePosition(defaultX, defaultY);
      var bubble = UIManager_1.uimanager.createRect(parent, "gmFloatingBubble", bubbleWidth, bubbleHeight, new cc.Color(225, 127, 102), 255, 24, saved.x, saved.y);
      bubble.zIndex = 1e3;
      UIManager_1.uimanager.drawButtonSurface(bubble, bubbleWidth, bubbleHeight, new cc.Color(225, 127, 102), 24);
      var tail = new cc.Node("gmBubbleTail");
      tail.setPosition(-25, -26);
      tail.zIndex = -1;
      bubble.addChild(tail);
      var tailGraphics = tail.addComponent(cc.Graphics);
      tailGraphics.fillColor = new cc.Color(180, 82, 69);
      tailGraphics.moveTo(-7, 8);
      tailGraphics.lineTo(12, 8);
      tailGraphics.lineTo(-2, -8);
      tailGraphics.close();
      tailGraphics.fill();
      var label = UIManager_1.uimanager.createLabel(bubble, "GM", -5, 1, 24, UIManager_1.BUTTON_TEXT_COLOR, 54, 30);
      UIManager_1.uimanager.applyTypography(label, true);
      var dot = UIManager_1.uimanager.createCircle(bubble, "gmBubbleDot", 5, new cc.Color(255, 227, 115), 28, 13);
      dot.zIndex = 60;
      bubble.addComponent(cc.Button);
      var dragThreshold = 8;
      var dragging = false;
      var moved = false;
      var startLocal = cc.v2(0, 0);
      var origin = cc.v2(0, 0);
      var clampBubble = function(x, y) {
        var area = UIManager_1.uimanager.getSafeAreaMetrics();
        var minX = -cc.winSize.width / 2 + area.left + halfW + 8;
        var maxX = cc.winSize.width / 2 - area.right - halfW - 8;
        var minY = -cc.winSize.height / 2 + area.bottom + halfH + 8;
        var maxY = cc.winSize.height / 2 - area.top - halfH - 8;
        return cc.v2(Math.max(minX, Math.min(maxX, x)), Math.max(minY, Math.min(maxY, y)));
      };
      bubble.setPosition(clampBubble(bubble.x, bubble.y));
      bubble.on(cc.Node.EventType.TOUCH_START, function(event) {
        dragging = true;
        moved = false;
        startLocal = event.getLocation();
        origin = bubble.getPosition();
        cc.tween(bubble).stop();
        cc.tween(bubble).to(.07, {
          scale: .92
        }).start();
        event.stopPropagation();
      });
      bubble.on(cc.Node.EventType.TOUCH_MOVE, function(event) {
        if (!dragging) return;
        var loc = event.getLocation();
        var dx = loc.x - startLocal.x;
        var dy = loc.y - startLocal.y;
        if (!moved && dx * dx + dy * dy < dragThreshold * dragThreshold) return;
        moved = true;
        var next = clampBubble(origin.x + dx, origin.y + dy);
        bubble.setPosition(next);
        event.stopPropagation();
      });
      bubble.on(cc.Node.EventType.TOUCH_END, function(event) {
        dragging = false;
        cc.tween(bubble).stop();
        cc.tween(bubble).to(.1, {
          scale: 1
        }).start();
        moved ? saveBubblePosition(bubble.x, bubble.y) : GmPanel_1.showGmSupplyPanel(function() {
          return hooks.refreshInventoryDisplays();
        }, function() {
          return GmCloudApi_1.pushDebugProfileToCloud(hooks);
        }, function() {
          return __awaiter(_this, void 0, void 0, function() {
            var reset;
            return __generator(this, function(_a) {
              switch (_a.label) {
               case 0:
                return [ 4, GmCloudApi_1.resetCloudAccount(hooks) ];

               case 1:
                reset = _a.sent();
                reset && "undefined" !== typeof window && window.location.assign("" + window.location.origin + window.location.pathname + "?localApi=1&autostart=1");
                return [ 2 ];
              }
            });
          });
        });
        event.stopPropagation();
      });
      bubble.on(cc.Node.EventType.TOUCH_CANCEL, function() {
        dragging = false;
        cc.tween(bubble).stop();
        cc.tween(bubble).to(.1, {
          scale: 1
        }).start();
        moved && saveBubblePosition(bubble.x, bubble.y);
      });
      gmBubble = bubble;
    }
    exports.attachGmBubble = attachGmBubble;
    cc._RF.pop();
  }, {
    "../manager/UIManager": "UIManager",
    "./GmCloudApi": "GmCloudApi",
    "./GmPanel": "GmPanel"
  } ],
  GmCloudApi: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2f7abylcqhDUIQEuamjYs99", "GmCloudApi");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.resetCloudAccount = exports.pushDebugProfileToCloud = void 0;
    var CloudService_1 = require("../manager/CloudService");
    var ZyxGameModule_1 = require("../dataModule/ZyxGameModule");
    var UIManager_1 = require("../manager/UIManager");
    function pushDebugProfileToCloud(hooks) {
      return __awaiter(this, void 0, Promise, function() {
        var data, error_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
           case 0:
            if (!CloudService_1.isLocalApiOverrideActive()) {
              UIManager_1.uimanager.showToast("\u4ec5\u672c\u5730\u8c03\u8bd5\uff0c\u672a\u540c\u6b65\u4e91\u7aef");
              return [ 2 ];
            }
            _a.label = 1;

           case 1:
            _a.trys.push([ 1, 4, , 5 ]);
            return [ 4, hooks.ensureCloudProfileReady() ];

           case 2:
            _a.sent();
            return [ 4, CloudService_1.cloudService.postAuthenticated("/debug/profile", {
              moodBeanBalance: ZyxGameModule_1.zyxGameModule.moodBeanBalance,
              totalMoodBeans: ZyxGameModule_1.zyxGameModule.moodBeanBalance,
              level: ZyxGameModule_1.zyxGameModule.level,
              experience: ZyxGameModule_1.zyxGameModule.experience,
              highestSingleGameScore: ZyxGameModule_1.zyxGameModule.bestScore,
              hammerCount: ZyxGameModule_1.zyxGameModule.hammerCount,
              magicWandCount: ZyxGameModule_1.zyxGameModule.colorPurifierCount
            }) ];

           case 3:
            data = _a.sent();
            hooks.applyServerProfile(data.profile);
            return [ 3, 5 ];

           case 4:
            error_1 = _a.sent();
            UIManager_1.uimanager.showToast("\u672c\u5730\u5df2\u4fdd\u5b58\uff0c\u4e91\u7aef\u540c\u6b65\u5931\u8d25");
            return [ 3, 5 ];

           case 5:
            return [ 2 ];
          }
        });
      });
    }
    exports.pushDebugProfileToCloud = pushDebugProfileToCloud;
    function resetCloudAccount(hooks) {
      return __awaiter(this, void 0, Promise, function() {
        var data, error_2;
        return __generator(this, function(_a) {
          switch (_a.label) {
           case 0:
            if (!/^http:\/\/(localhost|127\.0\.0\.1):\d+\//.test(CloudService_1.getApiBase())) {
              UIManager_1.uimanager.showToast("\u8bf7\u5728\u672c\u5730\u9884\u89c8\u4e2d\u91cd\u7f6e\u8bd5\u73a9\u8d26\u53f7");
              return [ 2, false ];
            }
            _a.label = 1;

           case 1:
            _a.trys.push([ 1, 4, , 5 ]);
            return [ 4, hooks.ensureCloudProfileReady() ];

           case 2:
            _a.sent();
            return [ 4, CloudService_1.cloudService.postAuthenticated("/debug/reset", {}) ];

           case 3:
            data = _a.sent();
            ZyxGameModule_1.zyxGameModule.resetLocalAccount();
            [ "zyx_pending_start_round_id", "zyx_pending_stamina_share_id", "zyx_pending_tool_exchange", "zyx_tool_reward_hammer", "zyx_tool_reward_magicWand" ].forEach(function(key) {
              return cc.sys.localStorage.removeItem(key);
            });
            hooks.applyServerProfile(data.profile);
            hooks.refreshInventoryDisplays();
            UIManager_1.uimanager.showToast("\u8d26\u53f7\u5df2\u91cd\u7f6e");
            return [ 2, true ];

           case 4:
            error_2 = _a.sent();
            UIManager_1.uimanager.showToast("\u91cd\u7f6e\u672a\u786e\u8ba4\uff0c\u539f\u5b58\u6863\u5df2\u4fdd\u7559\uff0c\u8bf7\u8054\u7f51\u91cd\u8bd5");
            return [ 2, false ];

           case 5:
            return [ 2 ];
          }
        });
      });
    }
    exports.resetCloudAccount = resetCloudAccount;
    cc._RF.pop();
  }, {
    "../dataModule/ZyxGameModule": "ZyxGameModule",
    "../manager/CloudService": "CloudService",
    "../manager/UIManager": "UIManager"
  } ],
  GmPanel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "49f7b1JNEdJbKPMdhFFp2qo", "GmPanel");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.showGmSupplyPanel = void 0;
    var ZyxGameModule_1 = require("../dataModule/ZyxGameModule");
    var UIManager_1 = require("../manager/UIManager");
    var GameSettings_1 = require("../manager/GameSettings");
    var COCOA = new cc.Color(101, 70, 58);
    function createFlatButton(parent, name, text, x, y, width, height, color, onClick, _fontSize) {
      var button = UIManager_1.uimanager.createRect(parent, name, width, height, color, 255, Math.min(17, height / 2), x, y);
      button.addComponent(cc.Button);
      UIManager_1.uimanager.drawButtonSurface(button, width, height, color, Math.min(17, height / 2));
      var label = UIManager_1.uimanager.createLabel(button, text, 0, 1, 24, UIManager_1.BUTTON_TEXT_COLOR, width - 20, height - 8);
      UIManager_1.uimanager.applyTypography(label, true);
      button.on(cc.Node.EventType.TOUCH_START, function() {
        return cc.tween(button).to(.06, {
          scale: .96
        }).start();
      });
      button.on(cc.Node.EventType.TOUCH_END, function() {
        cc.tween(button).to(.1, {
          scale: 1
        }).start();
        onClick();
      });
      button.on(cc.Node.EventType.TOUCH_CANCEL, function() {
        return cc.tween(button).to(.1, {
          scale: 1
        }).start();
      });
      return button;
    }
    function showGmSupplyPanel(onInventoryChanged, onSyncCloud, onResetAccount) {
      var _this = this;
      var resetting = false;
      var render = function(panel, centerY) {
        var inventory = UIManager_1.uimanager.createRect(panel, "gmInventorySummary", 438, 84, new cc.Color(232, 241, 221), 255, 18, 0, centerY + 135);
        var inventoryLabel = UIManager_1.uimanager.createLabel(inventory, "", 0, 0, 18, COCOA, 410, 68);
        inventoryLabel.enableWrapText = true;
        var updateInventory = function() {
          inventoryLabel.string = "\u5f00\u5fc3\u8c46 " + ZyxGameModule_1.zyxGameModule.getDisplayMoodBeanBalance() + "   \xb7   Lv." + ZyxGameModule_1.zyxGameModule.getDisplayLevelAndExperience().level + "\n\u89e3\u538b\u9524 " + ZyxGameModule_1.zyxGameModule.hammerCount + "   \xb7   \u9b54\u6cd5\u68d2 " + ZyxGameModule_1.zyxGameModule.colorPurifierCount;
        };
        updateInventory();
        var afterGrant = function(toast, syncCloud) {
          GameSettings_1.gameSettings.vibrateLight();
          updateInventory();
          onInventoryChanged && onInventoryChanged();
          UIManager_1.uimanager.showToast(toast);
          syncCloud && onSyncCloud && Promise.resolve(onSyncCloud()).catch(function() {
            return;
          });
        };
        createFlatButton(panel, "grantMoodBeans", "\u5f00\u5fc3\u8c46  +500", -111, centerY + 35, 206, 58, new cc.Color(236, 177, 68), function() {
          if (resetting) return;
          ZyxGameModule_1.zyxGameModule.grantDebugInventory(500, 0, 0);
          afterGrant("\u5f00\u5fc3\u8c46 +500", true);
        }, 20);
        createFlatButton(panel, "grantMoodBeansLarge", "\u5f00\u5fc3\u8c46  +5000", 111, centerY + 35, 206, 58, new cc.Color(244, 196, 98), function() {
          if (resetting) return;
          ZyxGameModule_1.zyxGameModule.grantDebugInventory(5e3, 0, 0);
          afterGrant("\u5f00\u5fc3\u8c46 +5000", true);
        }, 20);
        createFlatButton(panel, "grantHammer", "\u89e3\u538b\u9524  +1", -111, centerY - 45, 206, 58, new cc.Color(124, 181, 145), function() {
          if (resetting) return;
          ZyxGameModule_1.zyxGameModule.grantDebugInventory(0, 1, 0);
          afterGrant("\u89e3\u538b\u9524 +1", true);
        }, 19);
        createFlatButton(panel, "grantMagicWand", "\u9b54\u6cd5\u68d2  +1", 111, centerY - 45, 206, 58, new cc.Color(105, 164, 186), function() {
          if (resetting) return;
          ZyxGameModule_1.zyxGameModule.grantDebugInventory(0, 0, 1);
          afterGrant("\u9b54\u6cd5\u68d2 +1", true);
        }, 19);
        createFlatButton(panel, "resetAccount", "\u91cd\u7f6e\u8d26\u53f7\u5e76\u4f53\u9a8c\u65b0\u624b", 0, centerY - 135, 438, 64, UIManager_1.BUTTON_COLORS.red, function() {
          return __awaiter(_this, void 0, void 0, function() {
            return __generator(this, function(_a) {
              switch (_a.label) {
               case 0:
                if (resetting || !onResetAccount) return [ 2 ];
                resetting = true;
                _a.label = 1;

               case 1:
                _a.trys.push([ 1, , 3, 4 ]);
                return [ 4, onResetAccount() ];

               case 2:
                _a.sent();
                return [ 3, 4 ];

               case 3:
                resetting = false;
                return [ 7 ];

               case 4:
                return [ 2 ];
              }
            });
          });
        }, 22);
        createFlatButton(panel, "heartRescuePreview", "\u7231\u5fc3\u6551\u573a\u6f14\u793a", 0, centerY - 285, 438, 64, UIManager_1.BUTTON_COLORS.yellow, function() {
          window.location.href = "/?localApi=1&balloonDemo=1&heartDemo=1";
        }, 22);
        UIManager_1.uimanager.createLabel(panel, "\u6e05\u7a7a\u8fdb\u5ea6\u3001\u8c46\u5b50\u548c\u9053\u5177 \xb7 \u6062\u590d10\u70b9\u4f53\u529b\n\u4ec5\u9650\u5f53\u524d\u672c\u5730\u8bd5\u73a9\u8d26\u53f7", 0, centerY - 202, 17, COCOA, 438, 52);
      };
      UIManager_1.uimanager.showModal("GM \u8865\u7ed9", "\u8865\u5145\u8d44\u6e90\uff0c\u6216\u4ece\u65b0\u624b\u7b2c\u4e00\u6b65\u91cd\u65b0\u4f53\u9a8c", [], render, 570, false, true);
    }
    exports.showGmSupplyPanel = showGmSupplyPanel;
    cc._RF.pop();
  }, {
    "../dataModule/ZyxGameModule": "ZyxGameModule",
    "../manager/GameSettings": "GameSettings",
    "../manager/UIManager": "UIManager"
  } ],
  HeartEffect: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a0a51DXkDdAvJ/RhSEX9F4j", "HeartEffect");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.playHeartWave = exports.createHeartToken = exports.drawHeart = void 0;
    function drawHeart(g, size, fill) {
      void 0 === fill && (fill = true);
      var s = size / 32;
      g.moveTo(0, -13 * s);
      g.bezierCurveTo(-23 * s, 0, -15 * s, 20 * s, 0, 9 * s);
      g.bezierCurveTo(15 * s, 20 * s, 23 * s, 0, 0, -13 * s);
      g.close();
      fill && g.fill();
      g.stroke();
    }
    exports.drawHeart = drawHeart;
    function createHeartToken(parent, size) {
      void 0 === size && (size = 32);
      var node = new cc.Node("heartToken");
      parent.addChild(node);
      node.setContentSize(size, size);
      var g = node.addComponent(cc.Graphics);
      g.fillColor = new cc.Color(249, 166, 166);
      g.strokeColor = new cc.Color(204, 99, 112);
      g.lineWidth = 1.5;
      drawHeart(g, size);
      return node;
    }
    exports.createHeartToken = createHeartToken;
    function playHeartWave(parent, center, cell) {
      var root = new cc.Node("heartWave");
      root.zIndex = 145;
      root.setPosition(center);
      parent.addChild(root);
      for (var ring = 0; ring < 2; ring++) {
        var outline = new cc.Node("heartRipple");
        root.addChild(outline);
        var g = outline.addComponent(cc.Graphics);
        g.strokeColor = new cc.Color(244, 132, 151, 210);
        g.lineWidth = 2.5;
        drawHeart(g, 38, false);
        outline.scale = .5;
        outline.opacity = 0;
        cc.tween(outline).delay(.16 * ring).to(.08, {
          opacity: 230
        }).to(.75, {
          scale: 2.8 * cell / 38,
          opacity: 0
        }, {
          easing: "sineOut"
        }).start();
      }
      for (var i = 0; i < 8; i++) {
        var heart = createHeartToken(root, i % 2 ? 12 : 17);
        var angle = i * Math.PI / 4;
        var distance = cell * (i % 2 ? 1.15 : 1.5);
        heart.scale = .4;
        cc.tween(heart).to(.7, {
          x: Math.cos(angle) * distance,
          y: Math.sin(angle) * distance,
          scale: 1,
          opacity: 0,
          angle: i % 2 ? 12 : -12
        }, {
          easing: "sineOut"
        }).start();
      }
      cc.tween(root).delay(1).call(function() {
        cc.isValid(root) && root.destroy();
      }).start();
    }
    exports.playHeartWave = playHeartWave;
    cc._RF.pop();
  }, {} ],
  HeartMessage: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "5d336RLNCZOaKFd9brF4WR4", "HeartMessage");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.showHeartLetter = void 0;
    var UIManager_1 = require("../manager/UIManager");
    var MoodArt_1 = require("./MoodArt");
    var HeartEffect_1 = require("./HeartEffect");
    function showHeartLetter(days, onAccept) {
      var root = UIManager_1.uimanager.showModal("", "", [], null, 200, false, false, 600);
      var bubble = root.getChildByName("panel");
      bubble.removeAllChildren();
      bubble.name = "heartSpeechBubble";
      var g = bubble.getComponent(cc.Graphics);
      g.clear();
      g.fillColor = new cc.Color(255, 248, 229);
      g.strokeColor = new cc.Color(175, 133, 96);
      g.lineWidth = 3;
      g.moveTo(-260, 246);
      g.lineTo(260, 246);
      g.quadraticCurveTo(296, 246, 296, 210);
      g.lineTo(296, -140);
      g.quadraticCurveTo(296, -176, 260, -176);
      g.lineTo(-165, -176);
      g.quadraticCurveTo(-207, -222, -255, -211);
      g.quadraticCurveTo(-225, -196, -229, -176);
      g.lineTo(-260, -176);
      g.quadraticCurveTo(-296, -176, -296, -140);
      g.lineTo(-296, 210);
      g.quadraticCurveTo(-296, 246, -260, 246);
      g.close();
      g.fill();
      g.stroke();
      MoodArt_1.createMoodBean(bubble, 1, -239, -233, 70);
      var lines = [ {
        text: "\u4f60\u7684\u5f00\u5fc3\u5728\u6211\u770b\u6765",
        y: 163,
        size: 28
      }, {
        text: "\u8fdc\u6bd4\u5e7f\u544a\u66f4\u91cd\u8981\uff0c",
        y: 109,
        size: 28
      }, {
        text: "\u8c22\u8c22\u4f60",
        y: 45,
        size: 28
      }, {
        text: days + "\u5929\u7684\u559c\u7231\uff01",
        y: -20,
        size: 42
      }, {
        text: "\u5269\u4e0b\u7684\u4ea4\u7ed9\u6211",
        y: -109,
        size: 28
      } ];
      var labels = lines.map(function(line, index) {
        var color = 3 === index ? new cc.Color(221, 114, 146) : new cc.Color(88, 61, 55);
        var label = UIManager_1.uimanager.createLabel(bubble, line.text, 25, line.y, line.size, color, 470, 60);
        label.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        if (3 === index) {
          label.node.name = "heartLetterDays";
          var outline = label.node.addComponent(cc.LabelOutline);
          outline.color = color;
          outline.width = 1.2;
        }
        label.string = "";
        return label;
      });
      var heart = HeartEffect_1.createHeartToken(bubble, 24);
      heart.setPosition(135, -109);
      heart.opacity = 0;
      var accepted = false;
      var button = UIManager_1.uimanager.createButton(bubble, "\u6536\u4e0b\u795d\u798f", 18, -276, 380, 76, UIManager_1.BUTTON_COLORS.green, function() {
        if (accepted) return;
        accepted = true;
        UIManager_1.uimanager.closeModal();
        onAccept();
      }, 28);
      button.name = "acceptHeartBlessing";
      button.opacity = 0;
      var control = button.getComponent(cc.Button);
      control.interactable = false;
      var time = .35;
      lines.forEach(function(line, row) {
        var chars = Array.from(line.text);
        chars.forEach(function(char, index) {
          time += /[\uff0c\uff01]/.test(char) ? .32 : [ .065, .11, .075, .14, .055 ][(index + row) % 5];
          cc.tween(labels[row].node).delay(time).call(function() {
            cc.isValid(root) && (labels[row].string = chars.slice(0, index + 1).join(""));
          }).start();
        });
        time += 2 === row || 3 === row ? .38 : .18;
      });
      cc.tween(heart).delay(time - .18).to(.3, {
        opacity: 255
      }).start();
      cc.tween(button).delay(time + .2).to(.8, {
        opacity: 255
      }, {
        easing: "sineInOut"
      }).call(function() {
        control.interactable = true;
        cc.tween(button).repeatForever(cc.tween().to(1.1, {
          scale: 1.035
        }, {
          easing: "sineInOut"
        }).to(1.1, {
          scale: 1
        }, {
          easing: "sineInOut"
        })).start();
      }).start();
      return root;
    }
    exports.showHeartLetter = showHeartLetter;
    cc._RF.pop();
  }, {
    "../manager/UIManager": "UIManager",
    "./HeartEffect": "HeartEffect",
    "./MoodArt": "MoodArt"
  } ],
  HomeFriendRanking: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "97783Y+pjVH87rAWE/qlbEG", "HomeFriendRanking");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var PlatformAdapter_1 = require("../manager/PlatformAdapter");
    var WeChatFriends_1 = require("../manager/WeChatFriends");
    var UIManager_1 = require("../manager/UIManager");
    var ShareReward_1 = require("../manager/ShareReward");
    var ccclass = cc._decorator.ccclass;
    var HomeFriendRanking = function(_super) {
      __extends(HomeFriendRanking, _super);
      function HomeFriendRanking() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.view = null;
        _this.placeholder = null;
        _this.generation = 0;
        _this.requesting = false;
        _this.sharedCanvas = null;
        _this.texture = null;
        _this.sprite = null;
        _this.elapsed = 0;
        _this.scrollTouch = null;
        _this.scrollY = 0;
        return _this;
      }
      HomeFriendRanking.prototype.onLoad = function() {
        var _this = this;
        var paper = new cc.Color(255, 250, 235);
        var ink = new cc.Color(106, 78, 62);
        var green = new cc.Color(218, 235, 204);
        var panel = UIManager_1.uimanager.createRect(this.node, "friendPaper", 438, 460, paper, 248, 24);
        var outline = panel.getComponent(cc.Graphics);
        outline.lineWidth = 2;
        outline.strokeColor = new cc.Color(176, 148, 112, 190);
        outline.roundRect(-218, -229, 436, 458, 24);
        outline.stroke();
        var title = UIManager_1.uimanager.createLabel(panel, "\u5fae\u4fe1\u597d\u53cb\u6700\u9ad8\u5206", 0, 195, 27, ink, 394, 36);
        title.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        this.view = new cc.Node("friendSharedCanvas");
        this.view.setContentSize(398, 320);
        this.view.setPosition(0, 10);
        panel.addChild(this.view);
        this.view.active = false;
        this.placeholder = new cc.Node("friendPermissionState");
        this.placeholder.setPosition(0, 10);
        panel.addChild(this.placeholder);
        this.view.on(cc.Node.EventType.TOUCH_START, function(event) {
          var point = _this.view.convertToNodeSpaceAR(event.getLocation());
          if (point.y < -74 || null !== _this.scrollTouch) return;
          _this.scrollTouch = event.getID();
          _this.scrollY = point.y;
        });
        this.view.on(cc.Node.EventType.TOUCH_MOVE, function(event) {
          if (_this.scrollTouch !== event.getID()) return;
          var y = _this.view.convertToNodeSpaceAR(event.getLocation()).y;
          WeChatFriends_1.postFriendMessage("friends:scroll", {
            delta: y - _this.scrollY
          });
          _this.scrollY = y;
        });
        var endScroll = function(event) {
          _this.scrollTouch === event.getID() && (_this.scrollTouch = null);
        };
        this.view.on(cc.Node.EventType.TOUCH_END, endScroll);
        this.view.on(cc.Node.EventType.TOUCH_CANCEL, endScroll);
        var invite = this.flatButton(panel, "\u9080\u8bf7\u597d\u53cb", 0, -192, 290, 48, green, function() {
          return ShareReward_1.inviteWeChatFriends();
        });
        invite.name = "inviteFriends";
        invite.getChildByName("label").x = -22;
        var share = new cc.Node("friendShareLine");
        share.setPosition(72, 0);
        invite.addChild(share);
        var pen = share.addComponent(cc.Graphics);
        pen.strokeColor = ink;
        pen.lineWidth = 2.2;
        pen.lineJoin = cc.Graphics.LineJoin.ROUND;
        pen.moveTo(-17, 3);
        pen.lineTo(17, 14);
        pen.lineTo(7, -16);
        pen.lineTo(-1, -5);
        pen.close();
        pen.stroke();
        pen.moveTo(-1, -5);
        pen.lineTo(17, 14);
        pen.stroke();
        this.refresh();
      };
      HomeFriendRanking.prototype.flatButton = function(parent, text, x, y, width, height, color, onClick) {
        var button = UIManager_1.uimanager.createRect(parent, "button_" + text, width, height, color, 255, 16, x, y);
        button.addComponent(cc.Button);
        var label = UIManager_1.uimanager.createLabel(button, text, 0, 0, 20, new cc.Color(106, 78, 62), width - 14, 32);
        label.enableWrapText = false;
        button.on(cc.Node.EventType.TOUCH_END, onClick);
        return button;
      };
      HomeFriendRanking.prototype.showState = function(message, action, onClick) {
        this.scrollTouch = null;
        this.view.active && WeChatFriends_1.postFriendMessage("friends:hide");
        this.view.active = false;
        this.placeholder.active = true;
        this.placeholder.removeAllChildren();
        UIManager_1.uimanager.createLabel(this.placeholder, message, 0, 30, 21, new cc.Color(130, 102, 80), 398, 88);
        action && this.flatButton(this.placeholder, action, 0, -49, 292, 54, new cc.Color(225, 237, 211), onClick);
      };
      HomeFriendRanking.prototype.refresh = function() {
        var _this = this;
        if (!cc.isValid(this.node) || this.requesting) return;
        var wxApi = PlatformAdapter_1.getWxApi();
        var generation = ++this.generation;
        if (!wxApi || "function" !== typeof wxApi.getOpenDataContext) {
          this.showState("\u5728\u5fae\u4fe1\u91cc\u770b\u770b\n\u8c01\u662f\u597d\u53cb\u4e2d\u7684\u6d88\u9664\u9ad8\u624b");
          return;
        }
        this.showState("\u6b63\u5728\u51c6\u5907\u597d\u53cb\u6392\u540d\u2026");
        if ("function" !== typeof wxApi.getSetting) {
          this.showState("\u8bf7\u5347\u7ea7\u5fae\u4fe1\u540e\u67e5\u770b\u597d\u53cb\u6392\u540d");
          return;
        }
        wxApi.getSetting({
          success: function(result) {
            if (!cc.isValid(_this.node) || generation !== _this.generation) return;
            var permission = result.authSetting && result.authSetting[WeChatFriends_1.FRIEND_SCOPE];
            true === permission ? _this.showRanking() : _this.showState("\u548c\u5fae\u4fe1\u597d\u53cb\u6bd4\u4e00\u6bd4\u5206\u6570\n\u5141\u8bb8\u4f7f\u7528\u670b\u53cb\u4fe1\u606f\u540e\u67e5\u770b", false === permission ? "\u5f00\u542f\u670b\u53cb\u6743\u9650" : "\u67e5\u770b\u597d\u53cb\u6392\u540d", function() {
              return _this.authorize(false === permission);
            });
          },
          fail: function() {
            cc.isValid(_this.node) && generation === _this.generation && _this.showState("\u6682\u65f6\u6ca1\u80fd\u8bfb\u53d6\u6388\u6743\u72b6\u6001", "\u70b9\u51fb\u91cd\u8bd5", function() {
              return _this.refresh();
            });
          }
        });
      };
      HomeFriendRanking.prototype.authorize = function(denied) {
        var _this = this;
        var wxApi = PlatformAdapter_1.getWxApi();
        if (!wxApi || this.requesting) return;
        this.requesting = true;
        var finish = function() {
          _this.requesting = false;
          cc.isValid(_this.node) && _this.refresh();
        };
        var api = denied ? "openSetting" : "authorize";
        if ("function" !== typeof wxApi[api]) {
          finish();
          return;
        }
        wxApi[api](denied ? {
          success: finish,
          fail: finish
        } : {
          scope: WeChatFriends_1.FRIEND_SCOPE,
          success: finish,
          fail: finish
        });
      };
      HomeFriendRanking.prototype.showRanking = function() {
        var _this = this;
        this.placeholder.active = false;
        this.view.active = true;
        try {
          this.sharedCanvas = PlatformAdapter_1.getWxApi().getOpenDataContext().canvas;
          if (!this.sharedCanvas) throw new Error("shared canvas unavailable");
          this.sharedCanvas.width !== this.view.width && (this.sharedCanvas.width = this.view.width);
          this.sharedCanvas.height !== this.view.height && (this.sharedCanvas.height = this.view.height);
          if (!WeChatFriends_1.postFriendMessage("friends:show")) throw new Error("shared canvas unavailable");
          this.elapsed = 1 / 8;
        } catch (_) {
          this.showState("\u597d\u53cb\u6392\u540d\u6682\u65f6\u4e0d\u53ef\u7528", "\u70b9\u51fb\u91cd\u8bd5", function() {
            return _this.refresh();
          });
        }
      };
      HomeFriendRanking.prototype.update = function(dt) {
        if (!this.view || !this.view.active || !this.sharedCanvas) return;
        this.elapsed += dt;
        if (this.elapsed < 1 / (null === this.scrollTouch ? 8 : 30)) return;
        this.elapsed = 0;
        if (this.sharedCanvas.width !== this.view.width || this.sharedCanvas.height !== this.view.height) return;
        if (!this.texture) {
          this.texture = new cc.Texture2D();
          this.texture.setPremultiplyAlpha(true);
          this.sprite = this.view.addComponent(cc.Sprite);
          this.sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
          this.sprite.srcBlendFactor = cc.macro.BlendFactor.ONE;
        }
        this.texture.initWithElement(this.sharedCanvas);
        this.texture._packable = false;
        this.sprite.spriteFrame ? this.sprite._activateMaterial() : this.sprite.spriteFrame = new cc.SpriteFrame(this.texture);
      };
      HomeFriendRanking.prototype.onDestroy = function() {
        this.generation++;
        if (this.sprite && this.sprite.spriteFrame) {
          var frame = this.sprite.spriteFrame;
          this.sprite.spriteFrame = null;
          frame.destroy();
        }
        this.texture && this.texture.destroy();
        this.sharedCanvas = null;
      };
      HomeFriendRanking = __decorate([ ccclass ], HomeFriendRanking);
      return HomeFriendRanking;
    }(cc.Component);
    exports.default = HomeFriendRanking;
    cc._RF.pop();
  }, {
    "../manager/PlatformAdapter": "PlatformAdapter",
    "../manager/ShareReward": "ShareReward",
    "../manager/UIManager": "UIManager",
    "../manager/WeChatFriends": "WeChatFriends"
  } ],
  LeaderboardPanel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "73825dVy3ZDU65VH3IHvPqG", "LeaderboardPanel");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.showLeaderboardPanel = void 0;
    var UIManager_1 = require("../manager/UIManager");
    var CloudService_1 = require("../manager/CloudService");
    var MoodArt_1 = require("./MoodArt");
    var AssetLoader_1 = require("../manager/AssetLoader");
    var LIST_WIDTH = 584;
    var ROW_HEIGHT = 82;
    var ROW_GAP = 10;
    var LIST_HEIGHT = 4.5 * ROW_HEIGHT + 4 * ROW_GAP;
    var GOLD = new cc.Color(248, 205, 103);
    var LEAF = new cc.Color(190, 218, 139);
    var CREAM = new cc.Color(255, 248, 228);
    var leaderboardOpening = false;
    function showLeaderboardPanel(ensureProfile, authorizeProfile) {
      return __awaiter(this, void 0, Promise, function() {
        var error_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
           case 0:
            if (leaderboardOpening) return [ 2 ];
            leaderboardOpening = true;
            _a.label = 1;

           case 1:
            _a.trys.push([ 1, 6, 7, 8 ]);
            return [ 4, ensureProfile() ];

           case 2:
            _a.sent();
            return [ 4, authorizeProfile() ];

           case 3:
            _a.sent();
            return [ 4, AssetLoader_1.prepareFeature("leaderboard") ];

           case 4:
            _a.sent();
            return [ 4, renderLeaderboard() ];

           case 5:
            _a.sent();
            return [ 3, 8 ];

           case 6:
            error_1 = _a.sent();
            UIManager_1.uimanager.showToast("\u6392\u884c\u699c\u8fde\u63a5\u4e2d\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5");
            return [ 3, 8 ];

           case 7:
            leaderboardOpening = false;
            return [ 7 ];

           case 8:
            return [ 2 ];
          }
        });
      });
    }
    exports.showLeaderboardPanel = showLeaderboardPanel;
    function renderLeaderboard() {
      return __awaiter(this, void 0, Promise, function() {
        var root, body, selected, requestId, top, tabs, clearBody, select;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
           case 0:
            root = null;
            body = null;
            selected = null;
            requestId = 0;
            top = 0;
            tabs = [];
            clearBody = function() {
              body.children.slice().forEach(function(child) {
                return child.destroy();
              });
              body.removeAllChildren();
            };
            select = function(type, retry) {
              void 0 === retry && (retry = false);
              return __awaiter(_this, void 0, Promise, function() {
                var id, result, error_2;
                return __generator(this, function(_a) {
                  switch (_a.label) {
                   case 0:
                    if (selected === type && !retry) return [ 2 ];
                    selected = type;
                    id = ++requestId;
                    tabs.forEach(function(tab) {
                      var active = tab.type === type;
                      var fill = active ? "beans" === type ? LEAF : GOLD : new cc.Color(255, 239, 206);
                      UIManager_1.uimanager.drawRect(tab.node, 286, 70, fill, 18);
                      active && UIManager_1.uimanager.drawButtonSurface(tab.node, 286, 70, fill, 18);
                    });
                    clearBody();
                    text(body, "\u6b63\u5728\u67e5\u770b\u6392\u884c\u699c\u2026", 0, top - 380, 24, 480, 42).node.name = "leaderboardLoading";
                    _a.label = 1;

                   case 1:
                    _a.trys.push([ 1, 3, , 4 ]);
                    return [ 4, CloudService_1.cloudService.getLeaderboard(type) ];

                   case 2:
                    result = _a.sent();
                    if (!cc.isValid(root, true) || selected !== type || id !== requestId) return [ 2 ];
                    clearBody();
                    body.name = "leaderboardBody_" + type;
                    if (result.entries.length) {
                      createPodium(body, result.entries.slice(0, 3), top, type);
                      createEntryList(body, result, top - 466 - LIST_HEIGHT / 2, type);
                    } else {
                      MoodArt_1.createMoodBeanMascot(body, 0, top - 320, 110);
                      text(body, "beans" === type ? "\u6536\u96c6\u5f00\u5fc3\u8c46\uff0c\u70b9\u4eae\u4f60\u7684\u540d\u6b21" : "\u6682\u65e0\u6392\u884c\uff0c\u5feb\u6765\u6311\u6218", 0, top - 425, 24, 480, 42);
                    }
                    createSelfItem(body, result, 76 - top, type);
                    return [ 3, 4 ];

                   case 3:
                    error_2 = _a.sent();
                    if (!cc.isValid(root, true) || selected !== type || id !== requestId) return [ 2 ];
                    clearBody();
                    text(body, "\u6392\u884c\u699c\u6682\u65f6\u6ca1\u6709\u8fde\u63a5\u4e0a", 0, top - 355, 24, 480, 42);
                    UIManager_1.uimanager.createButton(body, "\u91cd\u65b0\u67e5\u770b", 0, top - 430, 230, 64, UIManager_1.BUTTON_COLORS.green, function() {
                      void select(type, true);
                    });
                    return [ 3, 4 ];

                   case 4:
                    return [ 2 ];
                  }
                });
              });
            };
            root = UIManager_1.uimanager.showModal("\u6392\u884c\u699c", "", [], function(panel) {
              top = panel.height / 2;
              for (var _i = 0, _a = [ "modalTitleShadow", "modalTitlePlate" ]; _i < _a.length; _i++) {
                var name = _a[_i];
                var oldTitle = panel.getChildByName(name);
                if (oldTitle) {
                  oldTitle.removeFromParent();
                  oldTitle.destroy();
                }
              }
              var title = art(panel, "leaderboardTitle", AssetLoader_1.ASSET_PATHS.home.leaderboardTitle, 420, 140, 0, top - 4);
              title.addComponent(cc.BlockInputEvents);
              text(title, "\u6392\u884c\u699c", 34, 0, 44, 246, 54).node.name = "leaderboardTitleText";
              var track = UIManager_1.uimanager.createRect(panel, "leaderboardTabs", LIST_WIDTH, 80, new cc.Color(228, 193, 137), 255, 22, 0, top - 100);
              track.addComponent(cc.BlockInputEvents);
              var _loop_1 = function(type) {
                var tab = UIManager_1.uimanager.createRect(track, "leaderboardTab_" + type, 286, 70, CREAM, 255, 18, "power" === type ? -145 : 145, 2);
                tab.addComponent(cc.Button);
                var caption = text(tab, "power" === type ? "\u79ef\u5206\u699c" : "\u5f00\u5fc3\u699c", 0, 0, 25, 160, 46);
                caption.overflow = cc.Label.Overflow.NONE;
                UIManager_1.uimanager.applyTypography(caption, true);
                caption._forceUpdateRenderData();
                var iconSize = 46, gap = 10;
                var iconX = -(caption.node.width + gap) / 2;
                caption.node.x = (iconSize + gap) / 2;
                "beans" === type ? MoodArt_1.createMoodBeanMascot(tab, iconX, 0, iconSize) : createTrophy(tab, iconX, 0, iconSize);
                tab.on(cc.Node.EventType.TOUCH_END, function() {
                  void select(type);
                });
                tabs.push({
                  type: type,
                  node: tab
                });
              };
              for (var _b = 0, _c = [ "power", "beans" ]; _b < _c.length; _b++) {
                var type = _c[_b];
                _loop_1(type);
              }
              body = new cc.Node("leaderboardBody");
              panel.addChild(body);
            }, 740, false, true, 640, {
              closeOnBlank: true,
              onDismiss: function() {
                ++requestId;
                selected = null;
              }
            });
            return [ 4, select("power") ];

           case 1:
            _a.sent();
            return [ 2 ];
          }
        });
      });
    }
    function text(parent, value, x, y, size, width, height, nickname) {
      void 0 === height && (height = 40);
      void 0 === nickname && (nickname = false);
      var label = UIManager_1.uimanager.createLabel(parent, value, x, y, size, UIManager_1.BUTTON_TEXT_COLOR, width, height);
      label.enableWrapText = false;
      UIManager_1.uimanager.applyTypography(label, !nickname);
      nickname && (label.node.name = "leaderNickname");
      return label;
    }
    function number(value) {
      return String(Math.max(0, Math.floor(value || 0))).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    function art(parent, name, path, width, height, x, y) {
      var node = new cc.Node(name);
      parent.addChild(node);
      node.setPosition(x, y);
      var sprite = node.addComponent(cc.Sprite);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      sprite.trim = false;
      sprite.spriteFrame = AssetLoader_1.getSpriteFrame("home", path);
      node.setContentSize(width, height);
      return node;
    }
    function createTrophy(parent, x, y, size) {
      var node = art(parent, "leaderboardTrophy", AssetLoader_1.ASSET_PATHS.home.rankEntry, size, size, x, y);
      node.getComponent(cc.Sprite).trim = true;
      var frame = node.getComponent(cc.Sprite).spriteFrame;
      UIManager_1.uimanager.fitSpriteFrameInside(node, frame, size, size);
    }
    function createAvatar(parent, entry, x, y, size, withFrame) {
      void 0 === withFrame && (withFrame = true);
      withFrame && MoodArt_1.createAvatarFrame(parent, "leaderAvatarFrame", x, y, size);
      var mask = new cc.Node("leaderAvatarMask");
      var inner = withFrame ? size - 12 : size;
      mask.setContentSize(inner, inner);
      mask.setPosition(x, y);
      parent.addChild(mask);
      MoodArt_1.applyRoundedAvatarMask(mask, withFrame ? 15 / 64 : .16);
      withFrame || UIManager_1.uimanager.createRect(mask, "avatarFill", inner, inner, CREAM);
      MoodArt_1.createMoodBeanMascot(mask, 0, -2, inner - 4);
      entry.avatarUrl && AssetLoader_1.loadRemoteTexture(entry.avatarUrl).then(function(texture) {
        if (!cc.isValid(mask, true)) return;
        mask.children.slice().forEach(function(child) {
          if ("avatarFill" === child.name) return;
          child.removeFromParent();
          child.destroy();
        });
        var node = new cc.Node("leaderAvatar");
        mask.addChild(node);
        var sprite = node.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        sprite.spriteFrame = new cc.SpriteFrame(texture);
        var rect = sprite.spriteFrame.getRect();
        var scale = Math.max(inner / Math.max(1, rect.width), inner / Math.max(1, rect.height));
        node.setContentSize(rect.width * scale, rect.height * scale);
      }).catch(function() {
        return;
      });
    }
    function createValue(parent, value, type, x, y, size, maxWidth, rightAligned) {
      void 0 === rightAligned && (rightAligned = false);
      var group = new cc.Node("leaderboardValue");
      parent.addChild(group);
      group.setContentSize(1, size + 12);
      group.setAnchorPoint(rightAligned ? 1 : .5, .5);
      group.setPosition(x, y);
      var layout = group.addComponent(cc.Layout);
      layout.type = cc.Layout.Type.HORIZONTAL;
      layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
      layout.spacingX = 6;
      if ("beans" === type) {
        var icon = new cc.Node("valueBean");
        icon.setContentSize(.85 * size, size + 8);
        group.addChild(icon);
        MoodArt_1.createMoodBeanMascot(icon, 0, 0, .85 * size);
      }
      var label = text(group, number(value), 0, 0, size, 1, size + 12);
      label.overflow = cc.Label.Overflow.NONE;
      UIManager_1.uimanager.applyTypography(label, true);
      label.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
      var fit = function() {
        if (!cc.isValid(group, true)) return;
        layout.updateLayout();
        group.scale = Math.min(1, maxWidth / Math.max(1, group.width));
      };
      label.node.on(cc.Node.EventType.SIZE_CHANGED, fit);
      fit();
      return group;
    }
    var podiumAvatarOpening = null;
    function getPodiumAvatarOpening() {
      if (podiumAvatarOpening) return podiumAvatarOpening;
      var size = 128, width = 252, height = 244, radius = 44;
      var data = new Uint8Array(size * size * 4);
      for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
        var px = (x + .5) / size * width - width / 2;
        var py = (y + .5) / size * height - height / 2;
        var qx = Math.abs(px) - (width / 2 - radius);
        var qy = Math.abs(py) - (height / 2 - radius);
        var rounded = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) <= radius;
        var behindMedal = Math.hypot(px, py - 146) <= 50;
        var offset = 4 * (y * size + x);
        data[offset] = data[offset + 1] = data[offset + 2] = 255;
        data[offset + 3] = rounded && !behindMedal ? 255 : 0;
      }
      var texture = new cc.Texture2D();
      texture.initWithData(data, cc.Texture2D.PixelFormat.RGBA8888, size, size);
      podiumAvatarOpening = new cc.SpriteFrame(texture);
      return podiumAvatarOpening;
    }
    function createPodium(parent, entries, top, type) {
      var slots = [ {
        index: 1,
        x: -192,
        width: 184,
        path: AssetLoader_1.ASSET_PATHS.home.leaderboardSilver
      }, {
        index: 2,
        x: 192,
        width: 184,
        path: AssetLoader_1.ASSET_PATHS.home.leaderboardBronze
      }, {
        index: 0,
        x: 0,
        width: 202,
        path: AssetLoader_1.ASSET_PATHS.home.leaderboardGold
      } ];
      var _loop_2 = function(slot) {
        var entry = entries[slot.index];
        if (!entry) return "continue";
        var height = 704 * slot.width / 512;
        var podium = new cc.Node("leaderPodium_" + slot.index);
        parent.addChild(podium);
        podium.setContentSize(slot.width, height);
        podium.setPosition(slot.x, top - 418 + height / 2);
        podium.addComponent(cc.BlockInputEvents);
        var py = function(pixel) {
          return height / 2 - pixel / 704 * height;
        };
        var avatarX = -3 / 512 * slot.width, avatarY = py(232);
        createAvatar(podium, entry, avatarX, avatarY, 264 * slot.width / 512, false);
        var foreground = new cc.Node("leaderAvatarFrameOverlay");
        podium.addChild(foreground);
        foreground.zIndex = 1;
        foreground.setPosition(avatarX, avatarY);
        foreground.setContentSize(252 * slot.width / 512, 244 * height / 704);
        var frameMask = foreground.addComponent(cc.Mask);
        frameMask.type = cc.Mask.Type.IMAGE_STENCIL;
        frameMask.spriteFrame = getPodiumAvatarOpening();
        frameMask.alphaThreshold = .5;
        frameMask.inverted = true;
        art(foreground, "leaderPodiumArt", slot.path, slot.width, height, -avatarX, -avatarY);
        text(podium, String(entry.rank), 0, py(378), 24, 36, 36);
        createValue(podium, entry.value, type, 0, py(484), 0 === slot.index ? 32 : 28, .75 * slot.width).zIndex = 2;
        text(podium, UIManager_1.formatDisplayNickname(entry.nickname), 0, py(594), 0 === slot.index ? 21 : 20, .83 * slot.width, 32, true);
      };
      for (var _i = 0, slots_1 = slots; _i < slots_1.length; _i++) {
        var slot = slots_1[_i];
        _loop_2(slot);
      }
    }
    function createEntryList(parent, result, y, type) {
      var header = UIManager_1.uimanager.createRect(parent, "leaderboardColumns", LIST_WIDTH, 30, "beans" === type ? LEAF : GOLD, 255, 10, 0, y + LIST_HEIGHT / 2 + 20);
      var headerColor = new cc.Color(125, 91, 63);
      text(header, "\u6392\u540d", -263, 0, 20, 54, 28).node.color = headerColor;
      var userHeading = text(header, "\u7528\u6237", -163, 0, 20, 214, 28);
      userHeading.node.setAnchorPoint(0, .5);
      userHeading.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
      userHeading.node.color = headerColor;
      var valueHeading = text(header, "beans" === type ? "\u5f00\u5fc3\u8c46" : "\u79ef\u5206", 270, 0, 20, 158, 28);
      valueHeading.node.setAnchorPoint(1, .5);
      valueHeading.horizontalAlign = cc.Label.HorizontalAlign.RIGHT;
      valueHeading.node.color = headerColor;
      var view = new cc.Node("leaderboardScroll");
      view.setContentSize(LIST_WIDTH, LIST_HEIGHT);
      view.setPosition(0, y);
      parent.addChild(view);
      view.addComponent(cc.Mask).type = cc.Mask.Type.RECT;
      var scroll = view.addComponent(cc.ScrollView);
      scroll.horizontal = false;
      scroll.vertical = true;
      var content = new cc.Node("content");
      content.width = LIST_WIDTH;
      content.setAnchorPoint(.5, 1);
      view.addChild(content);
      var entries = result.entries.slice(3);
      content.height = Math.max(LIST_HEIGHT, entries.length * (ROW_HEIGHT + ROW_GAP) - ROW_GAP);
      entries.forEach(function(entry, index) {
        var isSelf = entry.playerId === result.self.playerId;
        var row = UIManager_1.uimanager.createRect(content, "leaderboard_" + entry.playerId, LIST_WIDTH, ROW_HEIGHT, isSelf ? new cc.Color(218, 234, 177) : new cc.Color(255, 234, 193), 255, 16, 0, -ROW_HEIGHT / 2 - index * (ROW_HEIGHT + ROW_GAP));
        var g = row.getComponent(cc.Graphics);
        g.strokeColor = isSelf ? new cc.Color(159, 186, 111) : new cc.Color(216, 177, 120);
        g.lineWidth = 2;
        g.roundRect(-291, -40, 582, 80, 15);
        g.stroke();
        text(row, String(entry.rank), -263, 0, 25, 42, 38);
        createAvatar(row, entry, -207, 0, 60);
        var nickname = text(row, UIManager_1.formatDisplayNickname(entry.nickname), -163, 0, 24, 214, 38, true);
        nickname.node.setAnchorPoint(0, .5);
        nickname.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        if (isSelf) {
          var me = UIManager_1.uimanager.createRect(row, "leaderboardMe", 29, 27, LEAF, 255, 11, 76, 0);
          text(me, "\u6211", 0, 0, 17, 27, 25);
        }
        createValue(row, entry.value, type, 270, 0, 27, 158, true);
      });
      content.y = LIST_HEIGHT / 2;
      scroll.content = content;
    }
    function createSelfItem(parent, result, y, type) {
      var self = result.self;
      var card = UIManager_1.uimanager.createRect(parent, "selfItem", LIST_WIDTH, 104, "beans" === type ? new cc.Color(219, 234, 181) : new cc.Color(255, 226, 154), 255, 20, 0, y);
      card.addComponent(cc.BlockInputEvents);
      var g = card.getComponent(cc.Graphics);
      g.strokeColor = "beans" === type ? new cc.Color(163, 185, 122) : new cc.Color(216, 169, 88);
      g.lineWidth = 2;
      g.roundRect(-291, -51, 582, 102, 19);
      g.stroke();
      createAvatar(card, self, -246, 0, 70);
      var caption = text(card, "\u6211\u7684\u6392\u540d", -192, 20, 19, 200, 28);
      caption.node.setAnchorPoint(0, .5);
      caption.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
      var ranking = text(card, self.onBoard && self.rank ? "\u7b2c " + self.rank + " \u540d" : "\u672a\u4e0a\u699c", -192, -16, 29, 200, 40);
      ranking.node.setAnchorPoint(0, .5);
      ranking.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
      g.strokeColor = "beans" === type ? new cc.Color(184, 203, 143) : new cc.Color(232, 189, 113);
      g.lineWidth = 1;
      g.moveTo(50, -31);
      g.lineTo(50, 31);
      g.stroke();
      text(card, "beans" === type ? "\u5f53\u524d\u62e5\u6709" : "\u6700\u9ad8\u5206", 163, 22, 19, 202, 28);
      var value = "beans" === type ? void 0 === self.moodBeanBalance ? self.value : self.moodBeanBalance : self.bestScore;
      createValue(card, value, type, 163, -17, 32, 202);
    }
    cc._RF.pop();
  }, {
    "../manager/AssetLoader": "AssetLoader",
    "../manager/CloudService": "CloudService",
    "../manager/UIManager": "UIManager",
    "./MoodArt": "MoodArt"
  } ],
  MoodArt: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "997c7QXPbpCAbMkP8ToMFp1", "MoodArt");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createMoodWatermarkWall = exports.createGameRoomBackground = exports.createMoodCanvasBackground = exports.drawMoodFace = exports.createExperienceToken = exports.createStaminaBolt = exports.createMoodBeanMascot = exports.createMoodBean = exports.createMoodStamp = exports.EXTRA_FACE_NAMES = exports.drawMoodBlockMaterial = exports.isPositiveMood = exports.getMoodName = exports.getMoodColor = exports.applyRoundedAvatarMask = exports.createAvatarFrame = exports.MOOD_COLORS = exports.MOOD_VISUALS = void 0;
    var AssetLoader_1 = require("../manager/AssetLoader");
    exports.MOOD_VISUALS = [ {
      name: "\u6b22\u559c",
      color: new cc.Color(241, 194, 85),
      positive: true
    }, {
      name: "\u5b89\u5fc3",
      color: new cc.Color(126, 190, 157),
      positive: true
    }, {
      name: "\u671f\u5f85",
      color: new cc.Color(239, 151, 105),
      positive: true
    }, {
      name: "\u6e29\u67d4",
      color: new cc.Color(228, 154, 151),
      positive: true
    }, {
      name: "\u5f97\u610f",
      color: new cc.Color(174, 199, 91),
      positive: true
    }, {
      name: "\u653e\u677e",
      color: new cc.Color(111, 171, 196),
      positive: true
    }, {
      name: "\u72b9\u7591",
      color: new cc.Color(226, 163, 86),
      positive: false
    }, {
      name: "\u70e6\u8e81",
      color: new cc.Color(205, 101, 96),
      positive: false
    }, {
      name: "\u59d4\u5c48",
      color: new cc.Color(137, 151, 191),
      positive: false
    }, {
      name: "\u90c1\u95f7",
      color: new cc.Color(151, 124, 132),
      positive: false
    } ];
    exports.MOOD_COLORS = {
      cream: new cc.Color(255, 246, 224),
      creamDeep: new cc.Color(245, 220, 177),
      honey: new cc.Color(242, 188, 72),
      apricot: new cc.Color(236, 143, 78),
      coral: new cc.Color(220, 111, 98),
      cocoa: new cc.Color(88, 61, 55),
      cocoaSoft: new cc.Color(119, 86, 73),
      sage: new cc.Color(126, 179, 146),
      mistBlue: new cc.Color(111, 164, 193),
      glow: new cc.Color(255, 224, 134)
    };
    function createAvatarFrame(parent, name, x, y, size) {
      void 0 === size && (size = 92);
      var frame = new cc.Node(name);
      frame.width = size;
      frame.height = size;
      frame.setPosition(x, y);
      parent.addChild(frame);
      var graphics = frame.addComponent(cc.Graphics);
      var rectSize = size - 2;
      graphics.fillColor = new cc.Color(255, 239, 190);
      graphics.strokeColor = exports.MOOD_COLORS.cocoaSoft;
      graphics.lineWidth = 4;
      graphics.roundRect(-rectSize / 2, -rectSize / 2, rectSize, rectSize, Math.min(28, 22 * rectSize / 90));
      graphics.fill();
      graphics.stroke();
      return frame;
    }
    exports.createAvatarFrame = createAvatarFrame;
    var roundedAvatarMaskFrames = {};
    function getRoundedAvatarMaskFrame(cornerRatio) {
      var size = 64;
      var radius = Math.max(0, Math.min(size / 2, Math.round(cornerRatio * size)));
      if (roundedAvatarMaskFrames[radius]) return roundedAvatarMaskFrames[radius];
      var data = new Uint8Array(size * size * 4);
      var samples = [ .125, .375, .625, .875 ];
      for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
        var coverage = 0;
        for (var _i = 0, samples_1 = samples; _i < samples_1.length; _i++) {
          var sampleY = samples_1[_i];
          for (var _a = 0, samples_2 = samples; _a < samples_2.length; _a++) {
            var sampleX = samples_2[_a];
            var px = x + sampleX - size / 2;
            var py = y + sampleY - size / 2;
            var qx = Math.abs(px) - (size / 2 - radius);
            var qy = Math.abs(py) - (size / 2 - radius);
            var distance = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0);
            distance <= radius && coverage++;
          }
        }
        var offset = 4 * (y * size + x);
        data[offset] = 255;
        data[offset + 1] = 255;
        data[offset + 2] = 255;
        data[offset + 3] = Math.round(255 * coverage / 16);
      }
      var texture = new cc.Texture2D();
      texture.initWithData(data, cc.Texture2D.PixelFormat.RGBA8888, size, size);
      var frame = new cc.SpriteFrame(texture);
      roundedAvatarMaskFrames[radius] = frame;
      return frame;
    }
    function applyRoundedAvatarMask(maskNode, cornerRatio) {
      void 0 === cornerRatio && (cornerRatio = 15 / 64);
      var mask = maskNode.getComponent(cc.Mask) || maskNode.addComponent(cc.Mask);
      mask.type = cc.Mask.Type.IMAGE_STENCIL;
      mask.spriteFrame = getRoundedAvatarMaskFrame(cornerRatio);
      mask.alphaThreshold = .05;
      return mask;
    }
    exports.applyRoundedAvatarMask = applyRoundedAvatarMask;
    function getMoodColor(index) {
      var mood = exports.MOOD_VISUALS[Math.max(0, Math.min(exports.MOOD_VISUALS.length - 1, index - 1))];
      return mood.color;
    }
    exports.getMoodColor = getMoodColor;
    function getMoodName(index) {
      var mood = exports.MOOD_VISUALS[Math.max(0, Math.min(exports.MOOD_VISUALS.length - 1, index - 1))];
      return mood.name;
    }
    exports.getMoodName = getMoodName;
    function isPositiveMood(index) {
      var mood = exports.MOOD_VISUALS[Math.max(0, Math.min(exports.MOOD_VISUALS.length - 1, index - 1))];
      return mood.positive;
    }
    exports.isPositiveMood = isPositiveMood;
    function drawMoodBlockMaterial(node, color, alpha) {
      void 0 === alpha && (alpha = 1);
      var safeAlpha = Math.max(0, Math.min(1, alpha));
      var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
      var width = node.width;
      var height = node.height;
      var radius = Math.min(15, .24 * height);
      var dark = new cc.Color(Math.round(.7 * color.r), Math.round(.7 * color.g), Math.round(.7 * color.b), Math.round(255 * safeAlpha));
      graphics.clear();
      graphics.fillColor = new cc.Color(73, 48, 43, Math.round(42 * safeAlpha));
      graphics.roundRect(-width / 2 + 1, -height / 2 - 4, width - 2, height, radius);
      graphics.fill();
      graphics.fillColor = dark;
      graphics.roundRect(-width / 2, -height / 2 - 1, width, height, radius);
      graphics.fill();
      graphics.fillColor = new cc.Color(color.r, color.g, color.b, Math.round(255 * safeAlpha));
      graphics.strokeColor = new cc.Color(84, 60, 54, Math.round(150 * safeAlpha));
      graphics.lineWidth = 2.3;
      graphics.roundRect(-width / 2, -height / 2 + 3, width, height - 5, radius);
      graphics.fill();
      graphics.stroke();
      graphics.fillColor = new cc.Color(255, 255, 255, Math.round(22 * safeAlpha));
      graphics.roundRect(-width / 2 + 5, -height / 2 + 9, width - 10, height - 15, Math.max(6, radius - 4));
      graphics.fill();
      graphics.fillColor = new cc.Color(dark.r, dark.g, dark.b, Math.round(62 * safeAlpha));
      graphics.roundRect(-width / 2 + 8, -height / 2 + 5, width - 16, 8, 4);
      graphics.fill();
      var shineX = -width / 2 + Math.min(18, .18 * width);
      var shineY = height / 2 - 12;
      graphics.fillColor = new cc.Color(255, 255, 255, Math.round(176 * safeAlpha));
      graphics.ellipse(shineX, shineY, Math.min(8, .09 * width), 4.5);
      graphics.fill();
      graphics.fillColor = new cc.Color(255, 255, 255, Math.round(92 * safeAlpha));
      graphics.ellipse(shineX + 8, shineY - 2, Math.min(5, .055 * width), 2.5);
      graphics.fill();
    }
    exports.drawMoodBlockMaterial = drawMoodBlockMaterial;
    exports.EXTRA_FACE_NAMES = [ "\u7728\u773c", "\u5077\u7b11", "\u5927\u7b11", "\u60ca\u559c", "\u661f\u661f\u773c", "\u7231\u5fc3\u773c", "\u5bb3\u7f9e", "\u9676\u9189", "\u5439\u53e3\u54e8", "\u9f13\u5634", "\u56f0\u56f0", "\u6253\u76f9", "\u597d\u5947", "\u601d\u8003", "\u4fcf\u76ae", "\u5c0f\u5f97\u610f", "\u4e13\u6ce8", "\u65e0\u8f9c", "\u5c0f\u59d4\u5c48", "\u677e\u53e3\u6c14" ];
    function createMoodStamp(parent, moodIndex, cellSize, stampCell, opacity, faceIndex) {
      void 0 === stampCell && (stampCell = 0);
      void 0 === opacity && (opacity = 128);
      void 0 === faceIndex && (faceIndex = moodIndex);
      var node = new cc.Node("moodStamp");
      node.width = 38;
      node.height = 38;
      node.opacity = Math.max(172, Math.min(235, opacity + 40));
      node.setAnchorPoint(.5, .5);
      node.setPosition(-parent.width / 2 + (stampCell + .5) * cellSize, -1);
      node.zIndex = 4;
      node.moodIndex = moodIndex;
      parent.addChild(node);
      var face = drawMoodFace(node, faceIndex, 31, new cc.Color(exports.MOOD_COLORS.cocoa.r, exports.MOOD_COLORS.cocoa.g, exports.MOOD_COLORS.cocoa.b, 248));
      var idleDelay = Math.abs(Math.round(node.x)) % 11 * .12 + .05 * moodIndex;
      cc.tween(face).delay(idleDelay).repeatForever(cc.tween().delay(1.7 + moodIndex % 3 * .22).to(.08, {
        scaleY: .78,
        y: -.5
      }, {
        easing: "sineIn"
      }).to(.12, {
        scaleY: 1.05,
        y: .25
      }, {
        easing: "sineOut"
      }).to(.15, {
        scaleY: 1,
        y: 0
      }, {
        easing: "sineInOut"
      })).start();
      return node;
    }
    exports.createMoodStamp = createMoodStamp;
    function createMoodBean(parent, moodIndex, x, y, size, opacity) {
      void 0 === size && (size = 40);
      void 0 === opacity && (opacity = 255);
      var node = new cc.Node("moodBean_" + moodIndex);
      node.opacity = opacity;
      node.setAnchorPoint(.5, .5);
      node.setPosition(x, y);
      node.zIndex = 80;
      node.moodIndex = moodIndex;
      parent.addChild(node);
      var sprite = node.addComponent(cc.Sprite);
      sprite.spriteFrame = AssetLoader_1.getSpriteFrame("game", AssetLoader_1.ASSET_PATHS.game.hudMascot);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      node.setContentSize(size, size);
      return node;
    }
    exports.createMoodBean = createMoodBean;
    function createMoodBeanMascot(parent, x, y, size, opacity) {
      void 0 === size && (size = 48);
      void 0 === opacity && (opacity = 255);
      var mascot = createMoodBean(parent, 1, x, y, size, opacity);
      mascot.name = "moodBeanMascot";
      return mascot;
    }
    exports.createMoodBeanMascot = createMoodBeanMascot;
    function createStaminaBolt(parent, x, y, size) {
      void 0 === size && (size = 42);
      var node = new cc.Node("staminaBolt");
      node.setContentSize(size, size);
      node.setPosition(x, y);
      node.zIndex = 80;
      parent.addChild(node);
      var g = node.addComponent(cc.Graphics);
      var unit = size / 42;
      var trace = function(offsetX, offsetY) {
        g.moveTo((-3 + offsetX) * unit, (18 + offsetY) * unit);
        g.quadraticCurveTo((-1 + offsetX) * unit, (21 + offsetY) * unit, (3 + offsetX) * unit, (19 + offsetY) * unit);
        g.lineTo((11 + offsetX) * unit, (18 + offsetY) * unit);
        g.quadraticCurveTo((15 + offsetX) * unit, (18 + offsetY) * unit, (12 + offsetX) * unit, (14 + offsetY) * unit);
        g.lineTo((6 + offsetX) * unit, (5 + offsetY) * unit);
        g.lineTo((13 + offsetX) * unit, (5 + offsetY) * unit);
        g.quadraticCurveTo((17 + offsetX) * unit, (5 + offsetY) * unit, (14 + offsetX) * unit, (0 + offsetY) * unit);
        g.lineTo((-7 + offsetX) * unit, (-19 + offsetY) * unit);
        g.quadraticCurveTo((-11 + offsetX) * unit, (-22 + offsetY) * unit, (-10 + offsetX) * unit, (-17 + offsetY) * unit);
        g.lineTo((-5 + offsetX) * unit, (-5 + offsetY) * unit);
        g.lineTo((-13 + offsetX) * unit, (-5 + offsetY) * unit);
        g.quadraticCurveTo((-17 + offsetX) * unit, (-5 + offsetY) * unit, (-15 + offsetX) * unit, (-1 + offsetY) * unit);
        g.close();
      };
      g.fillColor = new cc.Color(141, 93, 40, 55);
      trace(1.2, -2);
      g.fill();
      g.fillColor = new cc.Color(248, 199, 87);
      g.strokeColor = new cc.Color(177, 122, 54);
      g.lineWidth = Math.max(1.4, .05 * size);
      g.lineJoin = cc.Graphics.LineJoin.ROUND;
      trace(0, 0);
      g.fill();
      g.stroke();
      g.fillColor = new cc.Color(255, 239, 171, 215);
      g.moveTo(-12 * unit, -2 * unit);
      g.lineTo(-3 * unit, 16 * unit);
      g.quadraticCurveTo(-2 * unit, 18 * unit, 0, 17 * unit);
      g.lineTo(-8 * unit, -2 * unit);
      g.close();
      g.fill();
      g.fillColor = new cc.Color(255, 252, 229, 230);
      g.ellipse(0, 15 * unit, 3.7 * unit, 1.8 * unit);
      g.fill();
      g.fillColor = exports.MOOD_COLORS.cocoa;
      g.circle(-5 * unit, 7 * unit, 1.25 * unit);
      g.circle(1 * unit, 7 * unit, 1.25 * unit);
      g.fill();
      g.fillColor = new cc.Color(226, 131, 89, 165);
      g.ellipse(-7.5 * unit, 3.8 * unit, 1.7 * unit, .9 * unit);
      g.ellipse(3.5 * unit, 3.8 * unit, 1.7 * unit, .9 * unit);
      g.fill();
      g.strokeColor = exports.MOOD_COLORS.cocoa;
      g.lineWidth = Math.max(1, .032 * size);
      g.lineCap = cc.Graphics.LineCap.ROUND;
      g.moveTo(-4.5 * unit, 2.5 * unit);
      g.quadraticCurveTo(-2 * unit, -.5 * unit, .5 * unit, 2.5 * unit);
      g.stroke();
      return node;
    }
    exports.createStaminaBolt = createStaminaBolt;
    function createExperienceToken(parent, x, y, size, opacity) {
      void 0 === size && (size = 38);
      void 0 === opacity && (opacity = 255);
      var node = new cc.Node("experienceToken");
      node.width = size;
      node.height = size;
      node.opacity = opacity;
      node.setAnchorPoint(.5, .5);
      node.setPosition(x, y);
      node.zIndex = 90;
      parent.addChild(node);
      var g = node.addComponent(cc.Graphics);
      var radius = .43 * size;
      g.fillColor = new cc.Color(71, 52, 46, 48);
      g.circle(1.5, -2.2, radius + 1);
      g.fill();
      g.fillColor = new cc.Color(105, 181, 145);
      g.strokeColor = new cc.Color(255, 247, 222, 225);
      g.lineWidth = Math.max(1.5, .055 * size);
      g.circle(0, 0, radius);
      g.fill();
      g.stroke();
      g.fillColor = new cc.Color(255, 249, 220, 238);
      g.circle(0, 0, .68 * radius);
      g.fill();
      var star = .27 * size;
      var inner = .36 * star;
      g.fillColor = new cc.Color(244, 181, 60);
      g.strokeColor = new cc.Color(157, 105, 53, 205);
      g.lineWidth = Math.max(1.1, .034 * size);
      g.moveTo(0, star);
      g.lineTo(inner, inner);
      g.lineTo(star, 0);
      g.lineTo(inner, -inner);
      g.lineTo(0, -star);
      g.lineTo(-inner, -inner);
      g.lineTo(-star, 0);
      g.lineTo(-inner, inner);
      g.close();
      g.fill();
      g.stroke();
      g.fillColor = new cc.Color(255, 255, 255, 180);
      g.ellipse(.28 * -radius, .32 * radius, .18 * radius, .09 * radius);
      g.fill();
      return node;
    }
    exports.createExperienceToken = createExperienceToken;
    function drawMoodFace(parent, moodIndex, size, color) {
      var node = new cc.Node("faceLines");
      node.width = size;
      node.height = size;
      node.setAnchorPoint(.5, .5);
      node.zIndex = 3;
      parent.addChild(node);
      var g = node.addComponent(cc.Graphics);
      var s = size / 28;
      var lx = -5 * s;
      var rx = 5 * s;
      var eyeY = 3.5 * s;
      g.strokeColor = color;
      g.fillColor = color;
      g.lineWidth = Math.max(1.85, 2.45 * s);
      g.lineCap = cc.Graphics.LineCap.ROUND;
      g.lineJoin = cc.Graphics.LineJoin.ROUND;
      if (moodIndex > 10) {
        drawExtraMoodFace(g, moodIndex, s);
        return node;
      }
      switch (moodIndex) {
       case 1:
        g.arc(lx, eyeY, 2.6 * s, .08 * Math.PI, .92 * Math.PI, false);
        g.arc(rx, eyeY, 2.6 * s, .08 * Math.PI, .92 * Math.PI, false);
        g.moveTo(-6 * s, -3 * s);
        g.quadraticCurveTo(0, -10 * s, 7 * s, -2 * s);
        g.stroke();
        break;

       case 2:
        g.arc(lx, eyeY, 2.7 * s, 0, Math.PI, false);
        g.arc(rx, eyeY, 2.7 * s, 0, Math.PI, false);
        g.moveTo(-5 * s, -4 * s);
        g.quadraticCurveTo(0, -7 * s, 5 * s, -4 * s);
        g.stroke();
        break;

       case 3:
        g.circle(lx, eyeY, 1.7 * s);
        g.circle(rx, eyeY, 1.7 * s);
        g.fill();
        g.arc(0, -2 * s, 4.5 * s, .12 * Math.PI, .88 * Math.PI, false);
        g.stroke();
        break;

       case 4:
        g.arc(lx, eyeY, 2.5 * s, 0, Math.PI, false);
        g.circle(rx, eyeY, 1.5 * s);
        g.fill();
        g.moveTo(-5 * s, -4 * s);
        g.quadraticCurveTo(0, -8 * s, 6 * s, -3 * s);
        g.stroke();
        break;

       case 5:
        g.moveTo(-8 * s, eyeY + 1 * s);
        g.lineTo(-3 * s, eyeY - 1 * s);
        g.moveTo(3 * s, eyeY - 1 * s);
        g.lineTo(8 * s, eyeY + 1 * s);
        g.moveTo(-6 * s, -4 * s);
        g.quadraticCurveTo(1 * s, -9 * s, 7 * s, -2 * s);
        g.stroke();
        break;

       case 6:
        g.moveTo(-8 * s, eyeY);
        g.quadraticCurveTo(lx, eyeY - 2 * s, -2 * s, eyeY);
        g.moveTo(2 * s, eyeY);
        g.quadraticCurveTo(rx, eyeY - 2 * s, 8 * s, eyeY);
        g.moveTo(-4 * s, -4 * s);
        g.quadraticCurveTo(0, -6 * s, 4 * s, -4 * s);
        g.stroke();
        break;

       case 7:
        g.circle(-3 * s, eyeY, 1.4 * s);
        g.circle(7 * s, eyeY, 1.4 * s);
        g.fill();
        g.moveTo(-6 * s, -5 * s);
        g.quadraticCurveTo(-2 * s, -8 * s, 1 * s, -5 * s);
        g.quadraticCurveTo(4 * s, -2 * s, 7 * s, -5 * s);
        g.stroke();
        break;

       case 8:
        g.moveTo(-8 * s, 8 * s);
        g.lineTo(-2 * s, 5 * s);
        g.moveTo(8 * s, 8 * s);
        g.lineTo(2 * s, 5 * s);
        g.circle(lx, eyeY - 1 * s, 1.3 * s);
        g.circle(rx, eyeY - 1 * s, 1.3 * s);
        g.fill();
        g.moveTo(-5 * s, -6 * s);
        g.lineTo(5 * s, -6 * s);
        g.stroke();
        break;

       case 9:
        g.arc(lx, eyeY, 2.4 * s, Math.PI, 2 * Math.PI, false);
        g.arc(rx, eyeY, 2.4 * s, Math.PI, 2 * Math.PI, false);
        g.moveTo(-5 * s, -7 * s);
        g.quadraticCurveTo(0, -2 * s, 5 * s, -7 * s);
        g.stroke();
        break;

       default:
        g.moveTo(-8 * s, eyeY + 1 * s);
        g.lineTo(-3 * s, eyeY - 1 * s);
        g.moveTo(2 * s, eyeY - 1 * s);
        g.lineTo(7 * s, eyeY + 1 * s);
        g.moveTo(-5 * s, -6 * s);
        g.quadraticCurveTo(0, -3 * s, 5 * s, -6 * s);
        g.stroke();
      }
      return node;
    }
    exports.drawMoodFace = drawMoodFace;
    function drawExtraMoodFace(g, index, s) {
      var line = function(points) {
        g.moveTo(points[0] * s, points[1] * s);
        for (var i = 2; i < points.length; i += 2) g.lineTo(points[i] * s, points[i + 1] * s);
        g.stroke();
      };
      var curve = function(x, y, cx, cy, ex, ey) {
        g.moveTo(x * s, y * s);
        g.quadraticCurveTo(cx * s, cy * s, ex * s, ey * s);
        g.stroke();
      };
      var dot = function(x, y, r) {
        void 0 === r && (r = 1.4);
        g.circle(x * s, y * s, r * s);
        g.fill();
      };
      var eyes = function() {
        dot(-5, 3);
        dot(5, 3);
      };
      var smile = function() {
        return curve(-5, -4, 0, -9, 5, -4);
      };
      var closedEyes = function() {
        curve(-8, 4, -5, 0, -2, 4);
        curve(2, 4, 5, 0, 8, 4);
      };
      var cheeks = function() {
        line([ -10, -1, -11, -3 ]);
        line([ -7, -1, -8, -3 ]);
        line([ 8, -1, 7, -3 ]);
        line([ 11, -1, 10, -3 ]);
      };
      var oval = function(x, y, rx, ry) {
        g.ellipse(x * s, y * s, rx * s, ry * s);
        g.stroke();
      };
      g.lineWidth = Math.max(1.4, 1.75 * s);
      switch (index) {
       case 11:
        dot(-5, 3);
        curve(2, 3, 5, 6, 8, 3);
        smile();
        line([ 8, 7, 10, 8 ]);
        break;

       case 12:
        closedEyes();
        curve(-4, -3, 0, -6, 4, -3);
        oval(3, -6, 3, 2);
        break;

       case 13:
        closedEyes();
        curve(-5, -3, 0, -13, 5, -3);
        line([ -5, -3, 5, -3 ]);
        break;

       case 14:
        eyes();
        oval(0, -5, 2.5, 3);
        curve(-8, 8, -5, 10, -2, 8);
        curve(2, 8, 5, 10, 8, 8);
        break;

       case 15:
        [ -5, 5 ].forEach(function(x) {
          return line([ x, 7, x + 1.2, 4, x + 3, 3, x + 1.2, 2, x, -1, x - 1.2, 2, x - 3, 3, x - 1.2, 4, x, 7 ]);
        });
        smile();
        break;

       case 16:
        [ -5, 5 ].forEach(function(x) {
          curve(x, 1, x - 6, 5, x - 2, 7);
          curve(x - 2, 7, x, 8, x, 5);
          curve(x, 5, x + 3, 10, x + 3, 5);
          curve(x + 3, 5, x + 3, 3, x, 1);
        });
        smile();
        break;

       case 17:
        closedEyes();
        smile();
        cheeks();
        break;

       case 18:
        curve(-8, 4, -5, 7, -2, 4);
        curve(2, 4, 5, 7, 8, 4);
        curve(-4, -4, 0, -8, 4, -4);
        line([ -10, -1, -11, -3 ]);
        line([ 10, -1, 11, -3 ]);
        break;

       case 19:
        dot(-5, 4);
        dot(5, 4);
        oval(1, -4, 2, 1.6);
        line([ 8, -3, 10, -1, 10, 5, 13, 4 ]);
        dot(8, -3, 1);
        break;

       case 20:
        eyes();
        line([ -3, -4, 0, -3, 3, -4 ]);
        curve(-10, 0, -13, -4, -9, -6);
        curve(10, 0, 13, -4, 9, -6);
        break;

       case 21:
        line([ -8, 3, -2, 3 ]);
        line([ 2, 3, 8, 3 ]);
        oval(0, -5, 2, 3);
        line([ 7, 9, 11, 9, 7, 6, 11, 6 ]);
        break;

       case 22:
        closedEyes();
        line([ -3, -5, 3, -5 ]);
        oval(9, 5, 2, 3);
        line([ -10, 9, -7, 9, -10, 6, -7, 6 ]);
        break;

       case 23:
        dot(-5, 2);
        dot(5, 4, 1.8);
        curve(-8, 7, -5, 10, -2, 7);
        oval(0, -5, 1.8, 1.3);
        break;

       case 24:
        dot(-3, 3);
        dot(6, 3);
        line([ -8, 8, -2, 9 ]);
        line([ 3, 8, 8, 7 ]);
        curve(-4, -5, 0, -3, 4, -5);
        line([ 7, -7, 9, -3, 11, -4 ]);
        break;

       case 25:
        line([ -8, 5, -3, 3, -8, 1 ]);
        dot(5, 3);
        curve(-5, -3, 0, -7, 6, -3);
        curve(0, -6, 3, -11, 5, -5);
        break;

       case 26:
        line([ -8, 4, -2, 3 ]);
        line([ 2, 3, 8, 4 ]);
        curve(-4, -4, 2, -7, 7, -2);
        line([ -8, 8, -3, 9 ]);
        line([ 4, 9, 8, 8 ]);
        break;

       case 27:
        oval(-5, 3, 4, 3);
        oval(5, 3, 4, 3);
        line([ -1, 3, 1, 3 ]);
        eyes();
        line([ -3, -5, 3, -5 ]);
        break;

       case 28:
        oval(-5, 3, 2.5, 3);
        oval(5, 3, 2.5, 3);
        dot(-5, 2, .8);
        dot(5, 2, .8);
        curve(-3, -5, 0, -3, 3, -5);
        break;

       case 29:
        curve(-8, 8, -5, 5, -2, 8);
        curve(2, 8, 5, 5, 8, 8);
        eyes();
        curve(-4, -6, 0, -2, 4, -6);
        curve(10, 2, 7, -3, 10, -3);
        break;

       case 30:
        closedEyes();
        oval(0, -5, 2, 1.4);
        curve(7, -5, 14, -7, 11, -3);
        curve(8, -8, 15, -10, 13, -6);
      }
    }
    function sizeBackgroundIllustration(node, frame, width, height) {
      if (!frame) {
        node.setContentSize(width, height);
        return;
      }
      var rect = frame.getRect();
      var sourceWidth = Math.max(1, rect.width);
      var sourceHeight = Math.max(1, rect.height);
      var scale = width / height > .9 ? height / sourceHeight : Math.max(width / sourceWidth, height / sourceHeight);
      node.setContentSize(sourceWidth * scale, sourceHeight * scale);
    }
    function createMoodCanvasBackground(parent, width, height) {
      var root = new cc.Node("minimalMoodBackground");
      root.width = width;
      root.height = height;
      root.zIndex = -30;
      parent.addChild(root);
      var graphics = root.addComponent(cc.Graphics);
      graphics.fillColor = new cc.Color(250, 237, 211);
      graphics.rect(-width / 2, -height / 2, width, height);
      graphics.fill();
      graphics.fillColor = new cc.Color(255, 204, 117, 34);
      graphics.circle(.38 * -width, .36 * height, .42 * width);
      graphics.fill();
      graphics.fillColor = new cc.Color(126, 190, 157, 26);
      graphics.circle(.43 * width, .35 * -height, .48 * width);
      graphics.fill();
      graphics.fillColor = new cc.Color(239, 151, 105, 20);
      graphics.roundRect(.58 * -width, .11 * -height, 1.16 * width, 110, 55);
      graphics.fill();
      var illustration = new cc.Node("homeStudioIllustration");
      illustration.width = width;
      illustration.height = height;
      illustration.setAnchorPoint(.5, .5);
      illustration.opacity = 0;
      root.addChild(illustration);
      var sprite = illustration.addComponent(cc.Sprite);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      sprite.spriteFrame = AssetLoader_1.getSpriteFrame("home", AssetLoader_1.ASSET_PATHS.home.background);
      sizeBackgroundIllustration(illustration, sprite.spriteFrame, width, height);
      cc.tween(illustration).to(.2, {
        opacity: 255
      }, {
        easing: "sineOut"
      }).start();
      return root;
    }
    exports.createMoodCanvasBackground = createMoodCanvasBackground;
    function createGameRoomBackground(parent, width, height) {
      var root = new cc.Node("gameRoomBackground");
      root.width = width;
      root.height = height;
      root.zIndex = -30;
      parent.addChild(root);
      var fallback = root.addComponent(cc.Graphics);
      fallback.fillColor = new cc.Color(255, 239, 204);
      fallback.rect(-width / 2, -height / 2, width, height);
      fallback.fill();
      var illustration = new cc.Node("gameRoomIllustration");
      illustration.width = width;
      illustration.height = height;
      illustration.setAnchorPoint(.5, .5);
      illustration.opacity = 0;
      root.addChild(illustration);
      var sprite = illustration.addComponent(cc.Sprite);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      sprite.spriteFrame = AssetLoader_1.getSpriteFrame("game", AssetLoader_1.ASSET_PATHS.game.background);
      sizeBackgroundIllustration(illustration, sprite.spriteFrame, width, height);
      cc.tween(illustration).to(.2, {
        opacity: 255
      }, {
        easing: "sineOut"
      }).start();
      return root;
    }
    exports.createGameRoomBackground = createGameRoomBackground;
    function createMoodWatermarkWall(parent, width, height) {
      var root = new cc.Node("moodWatermarkWall");
      root.width = width;
      root.height = height;
      root.zIndex = -20;
      parent.addChild(root);
      var spacing = 202;
      var layerAngle = 21;
      var angleRadians = layerAngle * Math.PI / 180;
      var angleCos = Math.cos(angleRadians);
      var angleSin = Math.sin(angleRadians);
      var projectedWidth = Math.abs(width * angleCos) + Math.abs(height * angleSin);
      var projectedHeight = Math.abs(width * angleSin) + Math.abs(height * angleCos);
      var columns = Math.ceil(projectedWidth / spacing) + 3;
      var rows = Math.ceil(projectedHeight / spacing) + 3;
      var layer = new cc.Node("watermarkLayer");
      layer.width = columns * spacing;
      layer.height = rows * spacing;
      layer.angle = layerAngle;
      root.addChild(layer);
      var positiveMoods = [ 1, 2, 3, 4, 5, 6, 1, 2 ];
      var gentleNegativeMoods = [ 7, 8, 9, 10 ];
      for (var row = 0; row < rows; row++) for (var col = 0; col < columns; col++) {
        var diagonalSeed = row + col;
        var sizeVariation = (37 * diagonalSeed + 11) % 21 / 100;
        var size = 74 * (.9 + sizeVariation);
        var x = -layer.width / 2 + spacing / 2 + col * spacing;
        var y = layer.height / 2 - spacing / 2 - row * spacing;
        var tile = new cc.Node("watermarkMood");
        tile.width = size;
        tile.height = size;
        tile.setPosition(x, y);
        layer.addChild(tile);
        var moodIndex = diagonalSeed % 5 === 0 ? gentleNegativeMoods[diagonalSeed % gentleNegativeMoods.length] : positiveMoods[diagonalSeed % positiveMoods.length];
        var moodColor = getMoodColor(moodIndex);
        var bg = tile.addComponent(cc.Graphics);
        bg.fillColor = new cc.Color(moodColor.r, moodColor.g, moodColor.b, 64);
        bg.strokeColor = new cc.Color(Math.round(.66 * moodColor.r), Math.round(.66 * moodColor.g), Math.round(.66 * moodColor.b), 32);
        bg.lineWidth = 1.6;
        bg.roundRect(-size / 2, -size / 2, size, size, .25 * size);
        bg.fill();
        bg.stroke();
        drawMoodFace(tile, moodIndex, .46 * size, new cc.Color(88, 61, 55, 52));
      }
      var movementX = .78 * spacing;
      var movementY = -spacing;
      var startX = -movementX / 2;
      var startY = -movementY / 2;
      var driftSpeed = 15.75;
      var localShiftX = movementX * angleCos + movementY * angleSin;
      var localShiftY = -movementX * angleSin + movementY * angleCos;
      var halfLayerWidth = layer.width / 2;
      var halfLayerHeight = layer.height / 2;
      layer.setPosition(startX, startY);
      cc.tween(layer).repeatForever(cc.tween().to(spacing / driftSpeed, {
        x: startX + movementX,
        y: startY + movementY
      }).call(function() {
        for (var _i = 0, _a = layer.children; _i < _a.length; _i++) {
          var tile = _a[_i];
          var nextX = tile.x + localShiftX;
          var nextY = tile.y + localShiftY;
          nextX > halfLayerWidth && (nextX -= layer.width);
          nextY < -halfLayerHeight && (nextY += layer.height);
          tile.setPosition(nextX, nextY);
        }
        layer.setPosition(startX, startY);
      })).start();
      return root;
    }
    exports.createMoodWatermarkWall = createMoodWatermarkWall;
    cc._RF.pop();
  }, {
    "../manager/AssetLoader": "AssetLoader"
  } ],
  MoodBeanConfig: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d0551Lp8N5Ey7l66NGxpELK", "MoodBeanConfig");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.MAX_OFFLINE_SETTLEMENT_AGE_MS = exports.MAX_ROUND_DURATION_MS = exports.MIN_ROUND_DURATION_MS = exports.PENDING_ROUND_SETTLEMENTS_LIMIT = exports.DEAD_ROUND_SETTLEMENTS_KEY = exports.PENDING_ROUND_SETTLEMENTS_KEY = exports.MOOD_BEAN_BALANCE_KEY = exports.DATA_GENERATION = exports.DATA_GENERATION_KEY = exports.getMoodCollection = exports.MOOD_COLLECTION_RULE = exports.MOOD_BLOCKS_PER_BEAN = exports.MOOD_BLOCKS_PER_PERCENT = void 0;
    exports.MOOD_BLOCKS_PER_PERCENT = 1;
    exports.MOOD_BLOCKS_PER_BEAN = 100 * exports.MOOD_BLOCKS_PER_PERCENT;
    exports.MOOD_COLLECTION_RULE = "progress_v2";
    function getMoodCollection(collectedBlocks) {
      var blocks = Math.max(0, Math.floor(collectedBlocks || 0));
      var progress = blocks % exports.MOOD_BLOCKS_PER_BEAN;
      return {
        beans: Math.floor(blocks / exports.MOOD_BLOCKS_PER_BEAN),
        progress: progress,
        percent: String(progress / exports.MOOD_BLOCKS_PER_PERCENT) + "%"
      };
    }
    exports.getMoodCollection = getMoodCollection;
    exports.DATA_GENERATION_KEY = "zyx_data_generation";
    exports.DATA_GENERATION = "mood_bean_v5_20261112";
    exports.MOOD_BEAN_BALANCE_KEY = "zyx_mood_bean_balance";
    exports.PENDING_ROUND_SETTLEMENTS_KEY = "zyx_pending_round_settlements";
    exports.DEAD_ROUND_SETTLEMENTS_KEY = "zyx_dead_round_settlements";
    exports.PENDING_ROUND_SETTLEMENTS_LIMIT = 100;
    exports.MIN_ROUND_DURATION_MS = 5e3;
    exports.MAX_ROUND_DURATION_MS = 144e5;
    exports.MAX_OFFLINE_SETTLEMENT_AGE_MS = 6048e5;
    cc._RF.pop();
  }, {} ],
  PlatformAdapter: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f6b02WNtiBMyrMu2UygT6yH", "PlatformAdapter");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.vibrateShortLight = exports.requestWeChatUserProfile = exports.rememberWeChatProfileAuthorization = exports.hasWeChatProfileAuthorization = exports.getWxApi = void 0;
    function getWxApi() {
      try {
        if ("undefined" !== typeof wx && wx) return wx;
      } catch (error) {}
      if ("undefined" !== typeof window && window.wx) return window.wx;
      return null;
    }
    exports.getWxApi = getWxApi;
    function hasWeChatProfileAuthorization(playerId, avatarUrl) {
      if (!playerId) return false;
      if (avatarUrl) return true;
      try {
        var cached = JSON.parse(cc.sys.localStorage.getItem("zyx_wechat_profile") || "null");
        return !!cached && cached.playerId === playerId && true === cached.authorized;
      } catch (_) {
        return false;
      }
    }
    exports.hasWeChatProfileAuthorization = hasWeChatProfileAuthorization;
    function rememberWeChatProfileAuthorization(playerId) {
      try {
        cc.sys.localStorage.setItem("zyx_wechat_profile", JSON.stringify({
          playerId: playerId,
          authorized: true
        }));
      } catch (_) {}
    }
    exports.rememberWeChatProfileAuthorization = rememberWeChatProfileAuthorization;
    function parseWeChatUserInfo(info) {
      var nickName = info && "string" === typeof info.nickName ? info.nickName.trim() : "";
      var avatarUrl = info && "string" === typeof info.avatarUrl ? info.avatarUrl : "";
      if (!nickName) throw new Error("\u672a\u83b7\u53d6\u5230\u6709\u6548\u7684\u5fae\u4fe1\u6635\u79f0");
      return {
        nickName: nickName,
        avatarUrl: avatarUrl
      };
    }
    function parseUserInfoResult(result) {
      if (!result || !result.userInfo) throw new Error(result && result.errMsg ? result.errMsg : "\u5fae\u4fe1\u6388\u6743\u5df2\u53d6\u6d88");
      return parseWeChatUserInfo(result.userInfo);
    }
    function requestWithUserInfoButton(wxApi, presentAuthorizationSheet) {
      return new Promise(function(resolve, reject) {
        var hideAuthorizationSheet = presentAuthorizationSheet ? presentAuthorizationSheet() : function() {
          return;
        };
        var windowInfo = "function" === typeof wxApi.getWindowInfo ? wxApi.getWindowInfo() : "function" === typeof wxApi.getSystemInfoSync ? wxApi.getSystemInfoSync() : {};
        var windowWidth = windowInfo.windowWidth || 375;
        var windowHeight = windowInfo.windowHeight || 667;
        var button = null;
        try {
          button = wxApi.createUserInfoButton({
            type: "text",
            text: "",
            style: {
              left: 0,
              top: 0,
              width: windowWidth,
              height: windowHeight,
              lineHeight: windowHeight,
              backgroundColor: "rgba(0,0,0,0)",
              borderColor: "rgba(0,0,0,0)",
              borderWidth: 0,
              color: "rgba(0,0,0,0)",
              textAlign: "center",
              fontSize: 1
            }
          });
        } catch (error) {
          hideAuthorizationSheet();
          reject(error);
          return;
        }
        if (!button || "function" !== typeof button.onTap) {
          hideAuthorizationSheet();
          reject(new Error("\u5fae\u4fe1\u7528\u6237\u4fe1\u606f\u6309\u94ae\u521b\u5efa\u5931\u8d25"));
          return;
        }
        var settled = false;
        var finish = function(callback) {
          if (settled) return;
          settled = true;
          try {
            "function" === typeof button.destroy && button.destroy();
          } finally {
            hideAuthorizationSheet();
            callback();
          }
        };
        button.onTap(function(result) {
          try {
            var profile_1 = parseUserInfoResult(result);
            finish(function() {
              return resolve(profile_1);
            });
          } catch (error) {
            finish(function() {
              return reject(error);
            });
          }
        });
      });
    }
    function requestWithLegacyUserProfile(wxApi) {
      if (!wxApi || "function" !== typeof wxApi.getUserProfile) return Promise.reject(new Error("\u5f53\u524d\u73af\u5883\u4e0d\u652f\u6301\u5fae\u4fe1\u8d44\u6599\u6388\u6743"));
      return new Promise(function(resolve, reject) {
        wxApi.getUserProfile({
          desc: "\u7528\u4e8e\u5c55\u793a\u6e38\u620f\u6635\u79f0\u3001\u5934\u50cf\u548c\u6392\u884c\u699c\u4fe1\u606f",
          success: function(result) {
            try {
              resolve(parseUserInfoResult(result));
            } catch (error) {
              reject(error);
            }
          },
          fail: function(error) {
            return reject(new Error(error && error.errMsg ? error.errMsg : "\u5fae\u4fe1\u6388\u6743\u5df2\u53d6\u6d88"));
          }
        });
      });
    }
    function requestFirstAuthorization(wxApi, presentAuthorizationSheet) {
      if (wxApi && "function" === typeof wxApi.createUserInfoButton) return requestWithUserInfoButton(wxApi, presentAuthorizationSheet);
      return requestWithLegacyUserProfile(wxApi);
    }
    function requestWeChatUserProfile(presentAuthorizationSheet) {
      var wxApi = getWxApi();
      if (!wxApi || "function" !== typeof wxApi.getSetting || "function" !== typeof wxApi.getUserInfo) return requestFirstAuthorization(wxApi, presentAuthorizationSheet);
      return new Promise(function(resolve, reject) {
        var requestFirst = function() {
          requestFirstAuthorization(wxApi, presentAuthorizationSheet).then(resolve, reject);
        };
        wxApi.getSetting({
          success: function(setting) {
            if (!setting || !setting.authSetting || true !== setting.authSetting["scope.userInfo"]) {
              requestFirst();
              return;
            }
            wxApi.getUserInfo({
              success: function(result) {
                try {
                  resolve(parseUserInfoResult(result));
                } catch (error) {
                  reject(error);
                }
              },
              fail: function(error) {
                return reject(new Error(error && error.errMsg ? error.errMsg : "\u8bfb\u53d6\u5df2\u6388\u6743\u5fae\u4fe1\u8d44\u6599\u5931\u8d25"));
              }
            });
          },
          fail: requestFirst
        });
      });
    }
    exports.requestWeChatUserProfile = requestWeChatUserProfile;
    function vibrateShortLight() {
      var wxApi = getWxApi();
      if (!wxApi || "function" !== typeof wxApi.vibrateShort) return;
      try {
        wxApi.vibrateShort({
          type: "light"
        });
      } catch (error) {}
    }
    exports.vibrateShortLight = vibrateShortLight;
    cc._RF.pop();
  }, {} ],
  RankChaseView: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "57f683THTdPw46jQ1or3+kZ", "RankChaseView");
    "use strict";
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var UIManager_1 = require("../manager/UIManager");
    var AssetLoader_1 = require("../manager/AssetLoader");
    var RankChase_1 = require("../dataModule/RankChase");
    var ResponsiveLayout_1 = require("../manager/ResponsiveLayout");
    var MoodArt_1 = require("./MoodArt");
    var STEP = 112;
    var ROW_OFFSET = 16;
    var PANEL_HEIGHT = 420;
    var TOGGLE_Y = -181;
    var BOOKMARK_TRAVEL = 64;
    var panelFrame = null;
    function getPanelFrame() {
      if (panelFrame) return panelFrame;
      var size = 64;
      var radius = 22;
      var data = new Uint8Array(size * size * 4);
      for (var y = 0; y < size; y++) for (var x = 0; x < size; x++) {
        var dx = Math.max(Math.abs(x + .5 - size / 2) - (size / 2 - radius), 0);
        var dy = Math.max(Math.abs(y + .5 - size / 2) - (size / 2 - radius), 0);
        var offset = 4 * (y * size + x);
        data[offset] = data[offset + 1] = data[offset + 2] = 255;
        data[offset + 3] = Math.round(255 * Math.max(0, Math.min(1, radius + .5 - Math.hypot(dx, dy))));
      }
      var texture = new cc.Texture2D();
      texture.initWithData(data, cc.Texture2D.PixelFormat.RGBA8888, size, size);
      panelFrame = new cc.SpriteFrame(texture);
      panelFrame.insetTop = panelFrame.insetBottom = panelFrame.insetLeft = panelFrame.insetRight = radius;
      return panelFrame;
    }
    var RankChaseView = function() {
      function RankChaseView(parent, profile, snapshot, onToggle) {
        var _this = this;
        this.profile = profile;
        this.entries = null;
        this.score = 0;
        this.animating = false;
        this.disposed = false;
        this.bookmarkReveal = {
          progress: 0
        };
        this.bookmarkX = 0;
        this.root = new cc.Node("rankChase");
        this.root.setContentSize(ResponsiveLayout_1.GAME_RANK_PANEL_WIDTH, PANEL_HEIGHT);
        this.root.zIndex = 160;
        this.root.opacity = 0;
        parent.addChild(this.root);
        var shadow = this.createPlate(this.root, "chasePanelShadow", ResponsiveLayout_1.GAME_RANK_PANEL_WIDTH, PANEL_HEIGHT, new cc.Color(68, 92, 61), 0, -5);
        shadow.opacity = 38;
        shadow.zIndex = -3;
        var rim = this.createPlate(this.root, "chasePanelRim", ResponsiveLayout_1.GAME_RANK_PANEL_WIDTH, PANEL_HEIGHT, new cc.Color(123, 153, 107));
        rim.zIndex = -2;
        var panel = this.createPlate(this.root, "chasePanel", ResponsiveLayout_1.GAME_RANK_PANEL_WIDTH - 4, PANEL_HEIGHT - 4, new cc.Color(224, 237, 198), 0, 1);
        panel.zIndex = -1;
        var collapse = this.createPlate(this.root, "chaseCollapse", 52, 44, new cc.Color(202, 220, 171), 0, TOGGLE_Y);
        collapse.addComponent(cc.Button).transition = cc.Button.Transition.NONE;
        collapse.on(cc.Node.EventType.TOUCH_END, onToggle);
        UIManager_1.uimanager.createLabel(collapse, "\u2039", 0, 1, 34, MoodArt_1.MOOD_COLORS.cocoa, 44, 42);
        this.bookmark = new cc.Node("rankChaseBookmark");
        this.bookmark.setContentSize(64, 44);
        this.bookmark.zIndex = 160;
        this.bookmark.active = false;
        parent.addChild(this.bookmark);
        this.bookmark.addComponent(cc.Button).transition = cc.Button.Transition.NONE;
        UIManager_1.uimanager.drawButtonSurface(this.bookmark, 64, 44, new cc.Color(194, 217, 151), 12);
        this.bookmark.on(cc.Node.EventType.TOUCH_START, function() {
          cc.Tween.stopAllByTarget(_this.bookmark);
          cc.tween(_this.bookmark).to(.07, {
            scale: .94
          }).start();
        });
        this.bookmark.on(cc.Node.EventType.TOUCH_END, function() {
          cc.Tween.stopAllByTarget(_this.bookmark);
          cc.tween(_this.bookmark).to(.1, {
            scale: 1
          }).start();
          1 === _this.bookmarkReveal.progress && onToggle();
        });
        this.bookmark.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.Tween.stopAllByTarget(_this.bookmark);
          cc.tween(_this.bookmark).to(.1, {
            scale: 1
          }).start();
        });
        UIManager_1.uimanager.createLabel(this.bookmark, "\u203a", 0, 1, 32, MoodArt_1.MOOD_COLORS.cocoa, 40, 40);
        this.above = this.createSlot("chaseAbove", STEP + ROW_OFFSET);
        this.self = this.createSlot("chaseSelf", ROW_OFFSET);
        this.below = this.createSlot("chaseBelow", -STEP + ROW_OFFSET);
        this.above.opacity = 220;
        this.below.opacity = 170;
        this.selfAvatar = this.setAvatar(this.self, profile ? profile.avatarUrl : "", 64);
        var badge = UIManager_1.uimanager.createRect(this.self, "chaseSelfBadge", 28, 26, MoodArt_1.MOOD_COLORS.honey, 255, 12, 26, 27);
        badge.zIndex = 90;
        var me = UIManager_1.uimanager.createLabel(badge, "\u6211", 0, 0, 18, MoodArt_1.MOOD_COLORS.cocoa, 26, 26);
        UIManager_1.uimanager.applyTypography(me, true);
        this.selfScore = this.createScore(this.self, 0, -50, 26);
        snapshot.then(function(entries) {
          if (_this.disposed || !cc.isValid(_this.root)) return;
          _this.entries = entries.map(function(entry) {
            return __assign({}, entry);
          });
          _this.render();
        }).catch(function() {
          return;
        });
      }
      RankChaseView.prototype.setPosition = function(x, y) {
        this.root.setPosition(x, y);
      };
      RankChaseView.prototype.setExpansion = function(progress, bookmarkX, y) {
        this.root.active = progress > 0;
        this.root.opacity = Math.round(255 * progress);
        this.bookmarkX = bookmarkX;
        this.bookmark.y = y + TOGGLE_Y;
        this.updateBookmark();
      };
      RankChaseView.prototype.setBookmarkVisible = function(visible, onComplete) {
        var _this = this;
        void 0 === onComplete && (onComplete = null);
        if (this.disposed || visible && this.root.active) return;
        cc.Tween.stopAllByTarget(this.bookmarkReveal);
        var target = visible ? 1 : 0;
        if (this.bookmarkReveal.progress === target) {
          this.updateBookmark();
          onComplete && onComplete();
          return;
        }
        cc.tween(this.bookmarkReveal).to(visible ? .18 : .12, {
          progress: target
        }, {
          easing: "sineOut",
          onUpdate: function() {
            _this.disposed || _this.updateBookmark();
          }
        }).call(function() {
          if (_this.disposed) return;
          _this.updateBookmark();
          onComplete && onComplete();
        }).start();
      };
      RankChaseView.prototype.updateBookmark = function() {
        var progress = this.bookmarkReveal.progress;
        this.bookmark.active = progress > 0;
        this.bookmark.x = this.bookmarkX - BOOKMARK_TRAVEL * (1 - progress);
        this.bookmark.opacity = Math.round(255 * progress);
      };
      RankChaseView.prototype.updateScore = function(score) {
        if (this.disposed) return;
        var passed = this.entries && score > this.score ? RankChase_1.getOvertakenRivals(this.entries, this.profile ? this.profile.playerId : "", this.score, score).length : 0;
        this.score = score;
        this.selfScore.string = String(score);
        if (this.animating) return;
        passed > 0 ? this.playOvertake() : this.render();
      };
      RankChaseView.prototype.dispose = function() {
        this.disposed = true;
        cc.Tween.stopAllByTarget(this.bookmarkReveal);
        for (var _i = 0, _a = [ this.root, this.bookmark, this.selfAvatar, this.above, this.below ]; _i < _a.length; _i++) {
          var node = _a[_i];
          cc.Tween.stopAllByTarget(node);
        }
      };
      RankChaseView.prototype.createPlate = function(parent, name, width, height, color, x, y) {
        void 0 === x && (x = 0);
        void 0 === y && (y = 0);
        var node = new cc.Node(name);
        node.setContentSize(width, height);
        node.setPosition(x, y);
        node.color = color;
        parent.addChild(node);
        var sprite = node.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        sprite.spriteFrame = getPanelFrame();
        sprite.type = cc.Sprite.Type.SLICED;
        node.setContentSize(width, height);
        return node;
      };
      RankChaseView.prototype.createScore = function(parent, value, y, size) {
        void 0 === size && (size = 24);
        var label = UIManager_1.uimanager.createLabel(parent, String(value), 0, y, size, MoodArt_1.MOOD_COLORS.cocoa, 80, 34);
        UIManager_1.uimanager.applyTypography(label, true);
        return label;
      };
      RankChaseView.prototype.createSlot = function(name, y) {
        var slot = new cc.Node(name);
        slot.setPosition(0, y);
        this.root.addChild(slot);
        return slot;
      };
      RankChaseView.prototype.setAvatar = function(slot, url, size) {
        var _this = this;
        var frame = MoodArt_1.createAvatarFrame(slot, "chaseAvatar", 0, 0, size);
        var mask = new cc.Node("chaseAvatarMask");
        mask.setContentSize(size - 10, size - 10);
        frame.addChild(mask);
        MoodArt_1.applyRoundedAvatarMask(mask);
        MoodArt_1.createMoodBeanMascot(mask, 0, -1, size - 12);
        if (!url) return frame;
        AssetLoader_1.loadRemoteTexture(url).then(function(texture) {
          if (_this.disposed || !cc.isValid(mask)) return;
          for (var _i = 0, _a = mask.children.slice(); _i < _a.length; _i++) {
            var child = _a[_i];
            child.destroy();
          }
          mask.removeAllChildren();
          var node = new cc.Node("chaseRemoteAvatar");
          mask.addChild(node);
          var sprite = node.addComponent(cc.Sprite);
          sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
          sprite.spriteFrame = new cc.SpriteFrame(texture);
          UIManager_1.uimanager.fitSpriteFrameInside(node, sprite.spriteFrame, size - 10, size - 10);
        }).catch(function() {
          return;
        });
        return frame;
      };
      RankChaseView.prototype.renderRival = function(slot, entry, size) {
        var key = entry ? entry.playerId : "";
        if (slot.entryKey === key) return;
        slot.entryKey = key;
        for (var _i = 0, _a = slot.children.slice(); _i < _a.length; _i++) {
          var child = _a[_i];
          child.destroy();
        }
        slot.removeAllChildren();
        slot.active = !!entry;
        if (entry) {
          this.setAvatar(slot, entry.avatarUrl, size);
          this.createScore(slot, entry.value, -size / 2 - 19);
        }
      };
      RankChaseView.prototype.render = function() {
        if (!this.entries) return;
        var state = RankChase_1.getRankChaseState(this.entries, this.profile ? this.profile.playerId : "", this.score);
        this.renderRival(this.above, state.above, 56);
        this.renderRival(this.below, state.below, 52);
      };
      RankChaseView.prototype.playOvertake = function() {
        var _this = this;
        cc.Tween.stopAllByTarget(this.above);
        cc.Tween.stopAllByTarget(this.below);
        this.animating = true;
        this.self.zIndex = 80;
        cc.tween(this.above).to(.2, {
          y: STEP + ROW_OFFSET - 20,
          opacity: 0
        }, {
          easing: "sineInOut"
        }).start();
        cc.tween(this.below).to(.2, {
          y: -STEP + ROW_OFFSET - 16,
          opacity: 0
        }, {
          easing: "sineInOut"
        }).start();
        cc.tween(this.selfAvatar).to(.12, {
          scale: 1.12,
          y: 14
        }, {
          easing: "sineOut"
        }).to(.18, {
          y: STEP,
          scale: 1.08
        }, {
          easing: "sineOut"
        }).to(.22, {
          y: 0,
          scale: 1
        }, {
          easing: "sineInOut"
        }).call(function() {
          if (_this.disposed || !cc.isValid(_this.root)) return;
          _this.animating = false;
          _this.render();
          _this.above.setPosition(0, STEP + ROW_OFFSET + 8);
          _this.below.setPosition(0, -STEP + ROW_OFFSET + 8);
          cc.tween(_this.above).to(.18, {
            y: STEP + ROW_OFFSET,
            opacity: 220
          }, {
            easing: "sineOut"
          }).start();
          cc.tween(_this.below).to(.18, {
            y: -STEP + ROW_OFFSET,
            opacity: 170
          }, {
            easing: "sineOut"
          }).start();
        }).start();
      };
      return RankChaseView;
    }();
    exports.default = RankChaseView;
    cc._RF.pop();
  }, {
    "../dataModule/RankChase": "RankChase",
    "../manager/AssetLoader": "AssetLoader",
    "../manager/ResponsiveLayout": "ResponsiveLayout",
    "../manager/UIManager": "UIManager",
    "./MoodArt": "MoodArt"
  } ],
  RankChase: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "326b9na9vRJaKA7ZDHTuyOc", "RankChase");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.getOvertakenRivals = exports.getRankChaseState = void 0;
    function getRankChaseState(entries, playerId, score) {
      var rivals = entries.filter(function(entry) {
        return entry.playerId !== playerId && entry.value > 0;
      }).sort(function(a, b) {
        return b.value - a.value || a.rank - b.rank;
      });
      var ahead = rivals.filter(function(entry) {
        return entry.value >= score;
      });
      var above = ahead.length > 0 ? ahead[ahead.length - 1] : null;
      var below = rivals.find(function(entry) {
        return entry.value < score;
      }) || null;
      var outsideBoard = entries.length >= 200 && above === rivals[rivals.length - 1];
      return {
        above: above,
        below: below,
        rank: score > 0 && !outsideBoard ? ahead.length + 1 : null,
        gap: above ? above.value - score + 1 : 0
      };
    }
    exports.getRankChaseState = getRankChaseState;
    function getOvertakenRivals(entries, playerId, before, after) {
      return entries.filter(function(entry) {
        return entry.playerId !== playerId && entry.value >= before && entry.value < after;
      }).sort(function(a, b) {
        return a.value - b.value || b.rank - a.rank;
      });
    }
    exports.getOvertakenRivals = getOvertakenRivals;
    cc._RF.pop();
  }, {} ],
  RescueBalloon: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2b723Qgy9dB3pYjjjs/BsBQ", "RescueBalloon");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.drawBalloonFrame = exports.getBalloonBombPosition = exports.RescueBalloon = exports.BALLOON_FRAME_COUNT = exports.BALLOON_FRAME_RATE = exports.BALLOON_FLIGHT_SECONDS = void 0;
    exports.BALLOON_FLIGHT_SECONDS = 15;
    exports.BALLOON_FRAME_RATE = 12;
    exports.BALLOON_FRAME_COUNT = 24;
    var RescueBalloon = function() {
      function RescueBalloon(parent, cell, onTap, warm) {
        void 0 === warm && (warm = false);
        this.cell = cell;
        this.warm = warm;
        this.elapsed = 0;
        this.clock = 0;
        this.frame = -1;
        this.fadeElapsed = -1;
        this.root = new cc.Node("rescueBalloon");
        this.root.setContentSize(2 * cell, 2 * cell);
        this.root.zIndex = 160;
        parent.addChild(this.root);
        this.graphics = this.root.addComponent(cc.Graphics);
        this.root.on(cc.Node.EventType.TOUCH_END, function(event) {
          event.stopPropagation();
          onTap();
        });
        this.update(0, false);
      }
      RescueBalloon.prototype.update = function(dt, canFly) {
        canFly && (this.clock += dt);
        canFly && (this.elapsed = Math.min(exports.BALLOON_FLIGHT_SECONDS, this.elapsed + dt));
        this.warm && (this.elapsed = Math.min(6, this.elapsed));
        var progress = this.elapsed / exports.BALLOON_FLIGHT_SECONDS;
        this.root.x = (2 * progress - 1) * (4 * this.cell + this.cell);
        this.root.y = 4 * this.cell - 6 + Math.sin(progress * Math.PI * 4) * this.cell * .11;
        if (this.warm) {
          var arrival = Math.min(1, this.elapsed / 4);
          this.root.x = (7.2 * arrival - 5) * this.cell;
          this.root.y = 3.3 * this.cell + 9 * Math.sin(1.5 * this.clock);
        }
        this.root.angle = 3 * Math.sin(this.clock * Math.PI);
        this.fadeElapsed >= 0 && (this.fadeElapsed += dt);
        var fade = this.fadeElapsed < 0 ? 1 : Math.max(0, 1 - this.fadeElapsed / .32);
        this.root.opacity = Math.round(255 * (this.warm ? Math.min(1, this.elapsed / .35) : Math.min(1, progress / .07, (1 - progress) / .12)) * fade);
        var frame = Math.floor(this.clock * exports.BALLOON_FRAME_RATE) % exports.BALLOON_FRAME_COUNT;
        if (frame !== this.frame) {
          this.frame = frame;
          drawBalloonFrame(this.graphics, frame, this.warm);
        }
        return !this.warm && this.elapsed >= exports.BALLOON_FLIGHT_SECONDS;
      };
      RescueBalloon.prototype.fadeOut = function() {
        this.fadeElapsed = 0;
      };
      RescueBalloon.prototype.dispose = function() {
        if (!cc.isValid(this.root)) return;
        cc.Tween.stopAllByTarget(this.root);
        this.root.destroy();
      };
      return RescueBalloon;
    }();
    exports.RescueBalloon = RescueBalloon;
    function getBalloonBombPosition(start, end, t) {
      var controlY = Math.max(start.y, end.y) + 100 + Math.min(60, .2 * Math.abs(end.x - start.x));
      return cc.v2(start.x + (end.x - start.x) * t, (1 - t) * (1 - t) * start.y + 2 * (1 - t) * t * controlY + t * t * end.y);
    }
    exports.getBalloonBombPosition = getBalloonBombPosition;
    function oval(g, x, y, rx, ry, color) {
      g.fillColor = color;
      g.ellipse(x, y, rx, ry);
      g.fill();
    }
    function drawBalloonFrame(g, frame, warm) {
      void 0 === warm && (warm = false);
      var cream = new cc.Color(255, 247, 224);
      var sky = warm ? new cc.Color(255, 225, 163) : new cc.Color(185, 221, 236);
      var blueEdge = warm ? new cc.Color(204, 164, 105) : new cc.Color(130, 177, 194);
      var honey = new cc.Color(185, 143, 95);
      var t = frame / exports.BALLOON_FRAME_COUNT * Math.PI * 2;
      var sway = 1.5 * Math.sin(t);
      g.clear();
      g.lineWidth = 2.2;
      g.lineCap = cc.Graphics.LineCap.ROUND;
      g.lineJoin = cc.Graphics.LineJoin.ROUND;
      g.fillColor = sky;
      g.strokeColor = blueEdge;
      g.moveTo(0, 70);
      g.bezierCurveTo(39, 72, 57, 47, 54, 20);
      g.bezierCurveTo(52, -3, 31, -19, 17, -29);
      g.lineTo(-17, -29);
      g.bezierCurveTo(-31, -19, -52, -3, -54, 20);
      g.bezierCurveTo(-57, 47, -39, 72, 0, 70);
      g.close();
      g.fill();
      g.stroke();
      g.fillColor = warm ? new cc.Color(249, 205, 137) : new cc.Color(160, 204, 221);
      g.moveTo(29, 62);
      g.bezierCurveTo(53, 47, 58, 26, 47, 7);
      g.bezierCurveTo(36, -11, 24, -23, 17, -28);
      g.lineTo(8, -28);
      g.bezierCurveTo(31, -5, 45, 34, 29, 62);
      g.close();
      g.fill();
      g.fillColor = cream;
      g.moveTo(0, 69);
      g.bezierCurveTo(25, 65, 31, 20, 14, -28);
      g.lineTo(-14, -28);
      g.bezierCurveTo(-31, 20, -25, 65, 0, 69);
      g.close();
      g.fill();
      g.strokeColor = warm ? new cc.Color(210, 173, 111, 150) : new cc.Color(143, 185, 199, 150);
      g.lineWidth = 1.4;
      g.moveTo(-15, 66);
      g.bezierCurveTo(-39, 44, -38, 6, -19, -26);
      g.stroke();
      g.moveTo(15, 66);
      g.bezierCurveTo(39, 44, 38, 6, 19, -26);
      g.stroke();
      oval(g, -30, 48, 11, 5, new cc.Color(255, 255, 255, 145));
      oval(g, -17, 55, 4, 2.5, new cc.Color(255, 255, 255, 145));
      if (warm) {
        g.fillColor = new cc.Color(239, 159, 157);
        g.strokeColor = new cc.Color(205, 129, 126);
        g.lineWidth = 1.2;
        g.moveTo(0, 5);
        g.bezierCurveTo(-25, 21, -12, 43, 0, 30);
        g.bezierCurveTo(12, 43, 25, 21, 0, 5);
        g.close();
        g.fill();
        g.stroke();
      } else {
        var points = [];
        for (var i = 0; i < 10; i++) {
          var angle = Math.PI / 2 + i * Math.PI / 5;
          var radius = i % 2 ? 7 : 14;
          points.push([ Math.cos(angle) * radius, 22 + Math.sin(angle) * radius ]);
        }
        g.fillColor = new cc.Color(246, 204, 123);
        g.strokeColor = new cc.Color(217, 176, 107);
        g.lineWidth = 1.3;
        g.moveTo((points[9][0] + points[0][0]) / 2, (points[9][1] + points[0][1]) / 2);
        for (var i = 0; i < 10; i++) {
          var point = points[i], next = points[(i + 1) % 10];
          g.quadraticCurveTo(point[0], point[1], (point[0] + next[0]) / 2, (point[1] + next[1]) / 2);
        }
        g.close();
        g.fill();
        g.stroke();
        oval(g, -3, 28, 3, 2, new cc.Color(255, 248, 219, 190));
      }
      g.fillColor = cream;
      g.strokeColor = honey;
      g.lineWidth = 1.8;
      g.roundRect(-17, -31, 34, 7, 3);
      g.fill();
      g.stroke();
      for (var _i = 0, _a = [ -1, 1 ]; _i < _a.length; _i++) {
        var sign = _a[_i];
        g.moveTo(13 * sign, -31);
        g.lineTo(19 * sign + sway, -49);
        g.stroke();
      }
      g.fillColor = new cc.Color(251, 213, 130);
      g.moveTo(sway - 4, -43);
      g.quadraticCurveTo(sway - 6, -37, sway, 1.4 * Math.sin(2 * t) - 33);
      g.quadraticCurveTo(sway + 6, -37, sway + 4, -43);
      g.close();
      g.fill();
      g.fillColor = new cc.Color(224, 186, 139);
      g.roundRect(-25 + sway, -70, 50, 25, 8);
      g.fill();
      g.stroke();
      g.strokeColor = new cc.Color(195, 155, 112, 155);
      g.lineWidth = 1.2;
      for (var _b = 0, _c = [ -16, -6, 4, 14 ]; _b < _c.length; _b++) {
        var x = _c[_b];
        g.moveTo(x + sway, -51);
        g.lineTo(x + 6 + sway, -67);
        g.stroke();
      }
      for (var _d = 0, _e = [ -55, -61, -66 ]; _d < _e.length; _d++) {
        var y = _e[_d];
        g.moveTo(-20 + sway, y);
        g.lineTo(20 + sway, y);
        g.stroke();
      }
      g.fillColor = new cc.Color(255, 239, 203);
      g.strokeColor = honey;
      g.lineWidth = 1.7;
      g.roundRect(-26 + sway, -51, 52, 8, 4);
      g.fill();
      g.stroke();
      g.fillColor = sky;
      g.strokeColor = blueEdge;
      g.lineWidth = 1.3;
      g.moveTo(sway, -54);
      g.quadraticCurveTo(sway - 16, -47, sway - 9, -60);
      g.lineTo(sway, -56);
      g.lineTo(sway + 9, -60);
      g.quadraticCurveTo(sway + 16, -47, sway, -54);
      g.close();
      g.fill();
      g.stroke();
      oval(g, sway, -55, 3, 3.5, new cc.Color(220, 238, 242));
    }
    exports.drawBalloonFrame = drawBalloonFrame;
    cc._RF.pop();
  }, {} ],
  ResponsiveLayout: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "554f0Hi3U9BcrrD1k2wAFav", "ResponsiveLayout");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.insetGameRegion = exports.calculateGameHudLayout = exports.calculateGameLayout = exports.calculateStageLayout = exports.segmentToWorld = exports.chooseViewportSegment = exports.shouldFitHeight = exports.GAME_RANK_PANEL_WIDTH = exports.GAME_HUD_HEIGHT = exports.GAME_MIN_HEIGHT = exports.DESIGN_HEIGHT = exports.DESIGN_WIDTH = void 0;
    exports.DESIGN_WIDTH = 750;
    exports.DESIGN_HEIGHT = 1334;
    exports.GAME_MIN_HEIGHT = 1444;
    exports.GAME_HUD_HEIGHT = 148;
    exports.GAME_RANK_PANEL_WIDTH = 88;
    function shouldFitHeight(frameWidth, frameHeight) {
      return frameWidth / Math.max(1, frameHeight) > exports.DESIGN_WIDTH / exports.DESIGN_HEIGHT;
    }
    exports.shouldFitHeight = shouldFitHeight;
    function chooseViewportSegment(segments) {
      if (!segments || segments.length < 2) return null;
      var chosen = null;
      for (var _i = 0, segments_1 = segments; _i < segments_1.length; _i++) {
        var segment = segments_1[_i];
        if (!segment || !Number.isFinite(segment.x) || !Number.isFinite(segment.y) || !(segment.width > 0) || !(segment.height > 0) || !Number.isFinite(segment.width) || !Number.isFinite(segment.height)) continue;
        (!chosen || segment.width * segment.height > chosen.width * chosen.height) && (chosen = segment);
      }
      return chosen;
    }
    exports.chooseViewportSegment = chooseViewportSegment;
    function segmentToWorld(segment, viewportWidth, viewportHeight, worldWidth, worldHeight) {
      var scaleX = worldWidth / Math.max(1, viewportWidth);
      var scaleY = worldHeight / Math.max(1, viewportHeight);
      return {
        x: (segment.x + segment.width / 2 - viewportWidth / 2) * scaleX,
        y: (viewportHeight / 2 - segment.y - segment.height / 2) * scaleY,
        width: segment.width * scaleX,
        height: segment.height * scaleY
      };
    }
    exports.segmentToWorld = segmentToWorld;
    function calculateStageLayout(region, game) {
      var width = game ? exports.DESIGN_WIDTH : Math.max(exports.DESIGN_WIDTH, Math.min(900, region.width));
      var height = game ? Math.max(exports.GAME_MIN_HEIGHT, Math.min(1560, region.height)) : Math.max(exports.DESIGN_HEIGHT, region.height);
      var scale = Math.min(1, region.width / width, region.height / height);
      return {
        x: region.x,
        y: region.y,
        width: width,
        height: height,
        scale: scale
      };
    }
    exports.calculateStageLayout = calculateStageLayout;
    function calculateGameLayout(height, boardHeight) {
      var extraGap = Math.max(0, height - exports.GAME_MIN_HEIGHT) / 4;
      var top = height / 2 - 16;
      var hudY = top - (exports.GAME_HUD_HEIGHT + 12) / 2;
      var boardTop = top - exports.GAME_HUD_HEIGHT - 12 - 18 - extraGap;
      var boardY = boardTop - (boardHeight + 24) / 2;
      var nextTop = boardTop - boardHeight - 24 - 18 - extraGap;
      var nextY = nextTop - 60;
      var toolY = nextTop - 120 - 22 - 74 - extraGap;
      var footerY = -height / 2 + 20 + 40;
      var boardX = 50;
      var rankX = -exports.DESIGN_WIDTH / 2 + 16 + exports.GAME_RANK_PANEL_WIDTH / 2;
      return {
        hudY: hudY,
        boardX: boardX,
        rankX: rankX,
        boardY: boardY,
        nextY: nextY,
        toolY: toolY,
        footerY: footerY
      };
    }
    exports.calculateGameLayout = calculateGameLayout;
    function calculateGameHudLayout(stageWidth, boardWidth, expansion) {
      var progress = Math.max(0, Math.min(1, expansion));
      var boardHalf = (boardWidth + 18) / 2;
      var closedLeft = -boardHalf - 8;
      var expandedLeft = -stageWidth / 2 + 16 - 8;
      var left = closedLeft + (expandedLeft - closedLeft) * progress;
      var right = boardHalf + 50 * progress + 8;
      return {
        x: (left + right) / 2,
        width: right - left
      };
    }
    exports.calculateGameHudLayout = calculateGameHudLayout;
    function insetGameRegion(region, width, height, safe) {
      var left = Math.max(region.x - region.width / 2, -width / 2 + safe.left);
      var right = Math.min(region.x + region.width / 2, width / 2 - safe.right);
      var top = Math.min(region.y + region.height / 2, height / 2 - Math.max(safe.top, safe.menuBottom + (safe.menuBottom ? 12 : 0)));
      var bottom = Math.max(region.y - region.height / 2, -height / 2 + safe.bottom);
      return {
        x: (left + right) / 2,
        y: (top + bottom) / 2,
        width: Math.max(1, right - left),
        height: Math.max(1, top - bottom)
      };
    }
    exports.insetGameRegion = insetGameRegion;
    cc._RF.pop();
  }, {} ],
  RewardArt: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3ea73yXwhBN+K+s0USiqUZb", "RewardArt");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.createBombBadge = exports.createComboArt = exports.createScoreArt = void 0;
    var AssetLoader_1 = require("../manager/AssetLoader");
    var UIManager_1 = require("../manager/UIManager");
    var glyphFrames = {};
    var GLYPHS = "0123456789+\xd7";
    function createScoreArt(parent, text, height) {
      var node = new cc.Node("scoreArt");
      parent.addChild(node);
      if (!AssetLoader_1.isFeatureReady("effects")) return fallbackLabel(node, text, height, new cc.Color(83, 137, 63));
      var advance = .76 * height;
      node.setContentSize(text.length * advance, height);
      for (var index = 0; index < text.length; index++) {
        var char = text[index];
        var glyphIndex = GLYPHS.indexOf(char);
        if (glyphIndex < 0) continue;
        if (!glyphFrames[char]) {
          var texture = AssetLoader_1.getSpriteFrame("effects", AssetLoader_1.ASSET_PATHS.effects.scoreDigits).getTexture();
          glyphFrames[char] = new cc.SpriteFrame(texture, new cc.Rect(glyphIndex % 6 * 128, 144 * Math.floor(glyphIndex / 6), 128, 144));
        }
        var glyph = new cc.Node("scoreGlyph_" + char);
        node.addChild(glyph);
        glyph.setPosition((index - (text.length - 1) / 2) * advance, 0);
        var sprite = glyph.addComponent(cc.Sprite);
        sprite.spriteFrame = glyphFrames[char];
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        glyph.setContentSize(128 * height / 144, height);
      }
      return node;
    }
    exports.createScoreArt = createScoreArt;
    function createComboArt(parent, combo) {
      var paths = [ AssetLoader_1.ASSET_PATHS.effects.comboWow, AssetLoader_1.ASSET_PATHS.effects.comboGood, AssetLoader_1.ASSET_PATHS.effects.comboGreat, AssetLoader_1.ASSET_PATHS.effects.comboPerfect ];
      var node = new cc.Node("comboArt");
      parent.addChild(node);
      if (!AssetLoader_1.isFeatureReady("effects")) return fallbackLabel(node, [ "Wow!", "Good!", "Great!", "Perfect!" ][Math.max(0, Math.min(3, combo - 2))], 54, new cc.Color(237, 160, 61));
      var sprite = node.addComponent(cc.Sprite);
      sprite.spriteFrame = AssetLoader_1.getSpriteFrame("effects", paths[Math.max(0, Math.min(3, combo - 2))]);
      sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
      var rect = sprite.spriteFrame.getRect();
      var width = combo >= 5 ? 286 : 238;
      node.setContentSize(width, width * rect.height / rect.width);
      return node;
    }
    exports.createComboArt = createComboArt;
    function createBombBadge(parent) {
      var node = new cc.Node("bombBadge");
      parent.addChild(node);
      node.setPosition(0, -5);
      node.setContentSize(40, 44);
      node.zIndex = 6;
      var g = node.addComponent(cc.Graphics);
      g.lineWidth = 2.2;
      g.lineCap = cc.Graphics.LineCap.ROUND;
      g.strokeColor = new cc.Color(103, 75, 62);
      g.fillColor = new cc.Color(255, 243, 201, 238);
      g.circle(0, -2, 18);
      g.fill();
      g.fillColor = new cc.Color(99, 112, 132);
      g.circle(0, -2, 14);
      g.fill();
      g.stroke();
      g.fillColor = new cc.Color(126, 143, 157);
      g.ellipse(-3, 1, 9, 10);
      g.fill();
      g.fillColor = new cc.Color(255, 253, 228, 205);
      g.ellipse(-5, 5, 4, 2.5);
      g.fill();
      g.fillColor = new cc.Color(211, 168, 95);
      g.roundRect(-4, 10, 8, 5, 2);
      g.fill();
      g.stroke();
      g.moveTo(1, 15);
      g.quadraticCurveTo(2, 23, 9, 20);
      g.stroke();
      g.strokeColor = new cc.Color(244, 175, 68);
      g.moveTo(9, 17);
      g.lineTo(12, 24);
      g.moveTo(7, 22);
      g.lineTo(14, 19);
      g.moveTo(11, 17);
      g.lineTo(8, 25);
      g.stroke();
      return node;
    }
    exports.createBombBadge = createBombBadge;
    function fallbackLabel(node, text, height, color) {
      var label = node.addComponent(cc.Label);
      label.string = text;
      label.fontSize = .78 * height;
      label.lineHeight = height;
      UIManager_1.uimanager.applyTypography(label, true);
      node.color = color;
      var outline = node.addComponent(cc.LabelOutline);
      outline.color = new cc.Color(255, 247, 217);
      outline.width = 3;
      return node;
    }
    cc._RF.pop();
  }, {
    "../manager/AssetLoader": "AssetLoader",
    "../manager/UIManager": "UIManager"
  } ],
  RoundProgress: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "23906On0sZBo5FO920+6bck", "RoundProgress");
    "use strict";
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.roundProgress = exports.RoundProgress = void 0;
    var CloudService_1 = require("./CloudService");
    var RoundProgress = function() {
      function RoundProgress() {
        this.playerId = "";
        this.record = null;
        this.inFlight = null;
        this.forceRequested = false;
        this.retryAt = 0;
        this.stopped = false;
        this.storageFailed = false;
        this.onConflict = null;
        this.onStorageFailure = null;
      }
      RoundProgress.prototype.key = function() {
        return "zyx_round_progress_v1_" + CloudService_1.getApiBase() + "_" + this.playerId;
      };
      RoundProgress.prototype.bind = function(playerId) {
        if (this.playerId === playerId) return;
        this.playerId = playerId;
        this.record = null;
        this.stopped = false;
        try {
          var value = JSON.parse(cc.sys.localStorage.getItem(this.key()) || "null");
          if (value && value.playerId === playerId && value.environment === CloudService_1.getApiBase() && "string" === typeof value.roundId && "string" === typeof value.sessionToken && Array.isArray(value.actions) && value.actions.length <= 1e5 && Number.isSafeInteger(value.elapsedMs) && value.elapsedMs >= 0) {
            this.record = value;
            this.stopped = !!value.invalidated;
          }
        } catch (_) {}
      };
      RoundProgress.prototype.persist = function() {
        try {
          cc.sys.localStorage.setItem(this.key(), JSON.stringify(this.record));
          this.storageFailed = false;
        } catch (_) {
          !this.storageFailed && this.onStorageFailure && this.onStorageFailure();
          this.storageFailed = true;
        }
      };
      RoundProgress.prototype.begin = function(started, playerId) {
        this.bind(playerId);
        var restored = started;
        this.record = __assign(__assign({}, started), {
          invalidated: false,
          playerId: playerId,
          environment: CloudService_1.getApiBase(),
          sessionToken: started.sessionToken,
          actions: restored.actions || [ {
            type: "rules",
            version: started.rulesVersion
          } ],
          actionCount: restored.actionCount || 1,
          operationCount: restored.operationCount || 0,
          score: restored.score || 0,
          collectedMoodBeanCount: restored.collectedMoodBeanCount || 0,
          elapsedMs: restored.elapsedMs || 0,
          updatedAt: restored.updatedAt || Date.now(),
          acknowledgedActions: restored.actionCount || 1,
          acknowledgedOperations: restored.operationCount || 0
        });
        this.stopped = false;
        this.retryAt = 0;
        this.persist();
      };
      Object.defineProperty(RoundProgress.prototype, "token", {
        get: function() {
          return this.record && !this.stopped ? this.record.sessionToken : void 0;
        },
        enumerable: false,
        configurable: true
      });
      Object.defineProperty(RoundProgress.prototype, "roundId", {
        get: function() {
          return this.record && this.record.roundId;
        },
        enumerable: false,
        configurable: true
      });
      RoundProgress.prototype.getOfflineRound = function() {
        var record = this.record;
        if (!record || this.stopped || record.mode && "main" !== record.mode || ![ 10, 11, 12 ].includes(record.rulesVersion) || !record.sessionToken || !Number.isFinite(record.startedAt) || Date.now() - record.startedAt > 6048e5 || record.startedAt > Date.now() || record.elapsedMs > 144e5) return null;
        return __assign(__assign({}, record), {
          actions: record.actions.map(function(action) {
            return __assign({}, action);
          })
        });
      };
      RoundProgress.prototype.updateTools = function(tools) {
        if (!this.record || this.stopped || !tools) return;
        this.record.roundTools = tools;
        this.persist();
      };
      Object.defineProperty(RoundProgress.prototype, "canLeave", {
        get: function() {
          return !!this.record && (!this.storageFailed || this.record.acknowledgedActions >= this.record.actions.length);
        },
        enumerable: false,
        configurable: true
      });
      RoundProgress.prototype.invalidateSession = function() {
        if (this.stopped) return;
        this.stopped = true;
        if (this.record) {
          this.record.invalidated = true;
          this.persist();
        }
        this.onConflict && this.onConflict();
      };
      RoundProgress.prototype.capture = function(actions, operationCount, elapsedMs, force) {
        void 0 === force && (force = false);
        var record = this.record;
        if (!record || this.stopped || !record.sessionToken || actions.length < record.actions.length) return;
        if (record.actions.length !== actions.length || force) {
          record.actions = actions.map(function(action) {
            return __assign({}, action);
          });
          record.operationCount = operationCount;
          record.elapsedMs = Math.max(record.elapsedMs, Math.floor(elapsedMs));
          this.persist();
        }
        (force || operationCount - record.acknowledgedOperations >= 100 || this.storageFailed) && void this.sync(force);
      };
      RoundProgress.prototype.sync = function(force) {
        var _this = this;
        void 0 === force && (force = false);
        this.forceRequested = this.forceRequested || force;
        if (this.inFlight) return this.inFlight;
        if (!this.record || this.stopped || !force && Date.now() < this.retryAt) return Promise.resolve();
        this.inFlight = this.upload().finally(function() {
          _this.inFlight = null;
        });
        return this.inFlight;
      };
      RoundProgress.prototype.upload = function() {
        return __awaiter(this, void 0, Promise, function() {
          var record, request, saved, error_1;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              this.forceRequested = false;
              record = this.record;
              if (!record || this.stopped) return [ 2 ];
              request = {
                roundId: record.roundId,
                sessionToken: record.sessionToken,
                actions: record.actions.slice(),
                elapsedMs: record.elapsedMs
              };
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, , 4 ]);
              return [ 4, CloudService_1.cloudService.saveRoundProgress(request) ];

             case 2:
              saved = _a.sent();
              if (this.record !== record) return [ 2 ];
              record.acknowledgedActions = saved.actionCount;
              record.acknowledgedOperations = saved.operationCount;
              this.retryAt = 0;
              this.persist();
              return [ 3, 4 ];

             case 3:
              error_1 = _a.sent();
              if (this.record !== record) return [ 2 ];
              this.retryAt = Date.now() + 3e4;
              [ "ROUND_SESSION_CONFLICT", "PROGRESS_CONFLICT", "ROUND_NOT_ACTIVE", "SETTLEMENT_TOO_OLD" ].includes(error_1.businessCode) && this.invalidateSession();
              return [ 2 ];

             case 4:
              if (this.forceRequested || this.record && this.record.operationCount - this.record.acknowledgedOperations >= 100) return [ 3, 0 ];
              _a.label = 5;

             case 5:
              return [ 2 ];
            }
          });
        });
      };
      RoundProgress.prototype.clear = function(roundId) {
        if (!this.record || this.record.roundId !== roundId) return;
        this.record = null;
        this.stopped = false;
        try {
          cc.sys.localStorage.removeItem(this.key());
          cc.sys.localStorage.removeItem(this.key() + "_resume");
        } catch (_) {}
      };
      RoundProgress.prototype.message = function() {
        if (this.storageFailed) return "\u672c\u673a\u5b58\u50a8\u4e0d\u8db3\uff0c\u8bf7\u4fdd\u6301\u8054\u7f51\u4fdd\u5b58\u8fdb\u5ea6";
        if (!this.record) return "";
        if (this.record.acknowledgedActions >= this.record.actions.length) return "\u8fdb\u5ea6\u5df2\u540c\u6b65\uff0c\u4e0b\u6b21\u53ef\u4ee5\u63a5\u7740\u73a9";
        return this.retryAt > Date.now() ? "\u8fdb\u5ea6\u5df2\u4fdd\u5b58\u5728\u672c\u673a\uff0c\u8054\u7f51\u540e\u81ea\u52a8\u540c\u6b65" : "\u8fdb\u5ea6\u5df2\u4fdd\u5b58\u5728\u672c\u673a\uff0c\u6b63\u5728\u540c\u6b65";
      };
      RoundProgress.prototype.resume = function(active, cloudOnly) {
        void 0 === cloudOnly && (cloudOnly = false);
        return __awaiter(this, void 0, Promise, function() {
          var attemptKey, request, local, result, error_2;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              attemptKey = this.key() + "_resume";
              try {
                request = JSON.parse(cc.sys.localStorage.getItem(attemptKey) || "null");
              } catch (_) {}
              if (cloudOnly && request && request.actions || !request || request.roundId !== active.roundId || active.generation < request.expectedGeneration || active.generation > request.expectedGeneration + 1) {
                request = {
                  roundId: active.roundId,
                  expectedGeneration: active.generation,
                  requestId: "resume_" + Date.now() + "_" + Math.random().toString(36).slice(2)
                };
                local = this.record;
                if (!cloudOnly && local && local.roundId === active.roundId && local.generation === active.generation && local.actions.length >= active.actionCount) {
                  request.actions = local.actions;
                  request.elapsedMs = local.elapsedMs;
                }
                cc.sys.localStorage.setItem(attemptKey, JSON.stringify(request));
              }
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, , 4 ]);
              return [ 4, CloudService_1.cloudService.resumeRound(request) ];

             case 2:
              result = _a.sent();
              return [ 3, 4 ];

             case 3:
              error_2 = _a.sent();
              if ("ROUND_SESSION_CONFLICT" === error_2.businessCode) try {
                cc.sys.localStorage.removeItem(attemptKey);
              } catch (_) {}
              throw error_2;

             case 4:
              this.begin(result, this.playerId);
              if (!this.storageFailed) try {
                cc.sys.localStorage.removeItem(attemptKey);
              } catch (_) {}
              return [ 2, result ];
            }
          });
        });
      };
      return RoundProgress;
    }();
    exports.RoundProgress = RoundProgress;
    exports.roundProgress = new RoundProgress();
    cc._RF.pop();
  }, {
    "./CloudService": "CloudService"
  } ],
  RoundReplay: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "720e84DNL5H6p9rU4+d4vdx", "RoundReplay");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.rebuildRound = void 0;
    var BoardEngine_1 = require("./BoardEngine");
    function rebuildRound(seed, tutorial, actions, version, heartEligible) {
      var board = new BoardEngine_1.default();
      board.resetBoard(seed, tutorial, version, heartEligible);
      for (var _i = 0, _a = actions.slice(1); _i < _a.length; _i++) {
        var action = _a[_i];
        switch (action.type) {
         case "move":
          board.movePiece(action.id, action.offset);
          break;

         case "bomb":
          board.detonateBomb(action.id);
          break;

         case "hammer":
          board.hammerCount = 1;
          board.useHammer(action.id);
          break;

         case "purify":
          board.colorPurifierCount = 1;
          board.useColorPurifier(action.color);
          break;

         case "settle":
          board.applyGravity();
          board.eliminateFullRows();
          break;

         case "finish":
          board.finishPlayerAction();
          break;

         case "rise":
          board.appendTurnRows();
          break;

         case "append":
          board.appendNextRow();
          break;

         case "revive":
          board.removeTopRowsForRevive(action.rowCount);
          break;

         case "reviveCard":
          board.removeTopRowsForRevive(action.rowCount, true);
          break;

         case "rescueOffer":
          board.offerRoundRescue(action.elapsedMs);
          break;

         case "rescueDismiss":
          board.dismissRoundRescue();
          break;

         case "rescueClear":
          board.applyClearRescue();
          break;

         case "balloonOffer":
          board.offerBalloonRescue();
          break;

         case "balloonDismiss":
          board.dismissBalloonRescue();
          break;

         case "balloon":
          board.applyBalloonRescue();
          break;

         case "heartOffer":
          board.offerHeartRescue(action.elapsedMs);
          break;

         case "heartDismiss":
          board.dismissHeartRescue();
          break;

         case "heart":
          board.applyHeartRescue();
          break;

         default:
          throw new Error("\u4fdd\u5b58\u8bb0\u5f55\u5305\u542b\u4e0d\u652f\u6301\u7684\u64cd\u4f5c");
        }
      }
      return board;
    }
    exports.rebuildRound = rebuildRound;
    cc._RF.pop();
  }, {
    "./BoardEngine": "BoardEngine"
  } ],
  SettingsPanel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d2b8eneDmBJ7oqdveay1YSZ", "SettingsPanel");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.settingsPanel = void 0;
    var UIManager_1 = require("./UIManager");
    var GameSettings_1 = require("./GameSettings");
    var GlyphFactory_1 = require("../zyxGame/GlyphFactory");
    var COCOA = new cc.Color(101, 70, 58);
    var COCOA_SOFT = new cc.Color(123, 87, 66);
    var CREAM = new cc.Color(255, 251, 238);
    var SAGE = new cc.Color(111, 182, 139);
    var MUTED = new cc.Color(185, 165, 145);
    var SettingsPanel = function() {
      function SettingsPanel() {}
      Object.defineProperty(SettingsPanel, "instance", {
        get: function() {
          this._instance || (this._instance = new SettingsPanel());
          return this._instance;
        },
        enumerable: false,
        configurable: true
      });
      SettingsPanel.prototype.show = function(options) {
        var _this = this;
        void 0 === options && (options = {});
        var actions = options.actions && options.actions.length > 0 ? options.actions : [ {
          text: "\u5b8c\u6210",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return;
          },
          icon: function(button) {
            return GlyphFactory_1.decorateSettingsActionButton(button, "done");
          }
        } ];
        var twoRows = actions.length > 1;
        var render = function(panel) {
          var top = panel.height / 2;
          _this.createSoundRow(panel, top - 130);
          _this.createVolumeRow(panel, top - 242);
          _this.createVibrationRow(panel, top - 354);
          options.progressMessage && UIManager_1.uimanager.createLabel(panel, options.progressMessage, 0, top - 420, 18, COCOA_SOFT, 480, 30);
          actions.forEach(function(action, index) {
            var x = twoRows && (index < 2 || actions.length % 2 === 0) ? index % 2 === 0 ? -122 : 122 : 0;
            var y = top - 500 - (twoRows ? 126 * Math.floor(index / 2) : 0);
            var button = UIManager_1.uimanager.createButton(panel, action.text, x, y, 224, 100, action.color, function() {
              false !== action.closeOnClick && UIManager_1.uimanager.closeModal();
              action.onClick();
            }, 32);
            action.icon && action.icon(button);
          });
        };
        UIManager_1.uimanager.showModal("\u8bbe   \u7f6e", "", [], render, twoRows ? 450 : 324, false, true, 560, {
          onDismiss: options.onDismiss,
          closeOnBlank: true
        });
      };
      SettingsPanel.prototype.createSoundRow = function(parent, y) {
        var row = this.createSettingRow(parent, "\u58f0\u97f3", y);
        var state = UIManager_1.uimanager.createLabel(row, "", 67, 0, 24, COCOA_SOFT, 100, 36);
        var update = function() {
          state.string = GameSettings_1.gameSettings.soundEnabled ? "\u5df2\u5f00\u542f" : "\u5df2\u5173\u95ed";
        };
        update();
        this.createSwitch(row, 167, 0, GameSettings_1.gameSettings.soundEnabled, function(enabled) {
          GameSettings_1.gameSettings.setSoundEnabled(enabled);
          enabled && GameSettings_1.gameSettings.vibrateLight();
          update();
        });
      };
      SettingsPanel.prototype.createVolumeRow = function(parent, y) {
        var row = this.createSettingRow(parent, "\u97f3\u91cf", y);
        var value = UIManager_1.uimanager.createLabel(row, "", 178, 22, 24, COCOA_SOFT, 76, 34);
        var slider = new cc.Node("volumeSlider");
        var sliderWidth = 268;
        slider.width = sliderWidth;
        slider.height = 52;
        slider.setPosition(57, -16);
        slider.zIndex = 65;
        row.addChild(slider);
        slider.addComponent(cc.BlockInputEvents);
        UIManager_1.uimanager.createRect(slider, "volumeTrack", sliderWidth, 16, new cc.Color(209, 194, 169), 255, 8);
        var fill = UIManager_1.uimanager.createRect(slider, "volumeFill", 1, 16, UIManager_1.BUTTON_COLORS.yellow, 255, 8);
        var thumb = UIManager_1.uimanager.createCircle(slider, "volumeThumb", 18, new cc.Color(255, 249, 231));
        var thumbBorderNode = new cc.Node("volumeThumbBorder");
        thumb.addChild(thumbBorderNode);
        var thumbBorder = thumbBorderNode.addComponent(cc.Graphics);
        thumbBorder.strokeColor = new cc.Color(158, 111, 61, 215);
        thumbBorder.lineWidth = 1.7;
        thumbBorder.circle(0, 0, 17.1);
        thumbBorder.stroke();
        var update = function() {
          var volume = GameSettings_1.gameSettings.soundVolume;
          value.string = Math.round(100 * volume) + "%";
          var fillWidth = sliderWidth * volume;
          fill.active = fillWidth > .5;
          if (fill.active) {
            fill.width = fillWidth;
            fill.x = -sliderWidth / 2 + fillWidth / 2;
            UIManager_1.uimanager.drawRect(fill, fillWidth, 16, UIManager_1.BUTTON_COLORS.yellow, 8);
          }
          thumb.x = -sliderWidth / 2 + fillWidth;
        };
        var updateFromTouch = function(event) {
          var point = event.touch.getLocation();
          var local = slider.convertToNodeSpaceAR(point);
          var volume = Math.max(0, Math.min(1, (local.x + sliderWidth / 2) / sliderWidth));
          GameSettings_1.gameSettings.setSoundVolume(volume);
          update();
        };
        var dragging = false;
        slider.on(cc.Node.EventType.TOUCH_START, function(event) {
          dragging = true;
          updateFromTouch(event);
        });
        slider.on(cc.Node.EventType.TOUCH_MOVE, function(event) {
          dragging && updateFromTouch(event);
        });
        slider.on(cc.Node.EventType.TOUCH_END, function(event) {
          dragging && updateFromTouch(event);
          dragging = false;
          UIManager_1.uimanager.tapFeedback();
        });
        slider.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          return dragging = false;
        });
        update();
      };
      SettingsPanel.prototype.createVibrationRow = function(parent, y) {
        var row = this.createSettingRow(parent, "\u9707\u52a8", y);
        var state = UIManager_1.uimanager.createLabel(row, "", 67, 0, 24, COCOA_SOFT, 100, 36);
        var update = function() {
          state.string = GameSettings_1.gameSettings.vibrationEnabled ? "\u5df2\u5f00\u542f" : "\u5df2\u5173\u95ed";
        };
        update();
        this.createSwitch(row, 167, 0, GameSettings_1.gameSettings.vibrationEnabled, function(enabled) {
          GameSettings_1.gameSettings.setVibrationEnabled(enabled);
          enabled && GameSettings_1.gameSettings.vibrateLight();
          update();
        });
      };
      SettingsPanel.prototype.createSettingRow = function(parent, title, y) {
        var row = UIManager_1.uimanager.createRect(parent, "setting_" + title, 468, 94, new cc.Color(222, 194, 151), 255, 22, 0, y);
        row.addComponent(cc.BlockInputEvents);
        UIManager_1.uimanager.createRect(row, "settingRowSurface", 464, 88, CREAM, 255, 20, 0, 2);
        var label = UIManager_1.uimanager.createLabel(row, title, -154, 0, 30, COCOA, 96, 44);
        label.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        UIManager_1.uimanager.applyTypography(label, true);
        return row;
      };
      SettingsPanel.prototype.createSwitch = function(parent, x, y, initial, onChange) {
        var switchWidth = 88;
        var switchHeight = 48;
        var thumbTravel = 20;
        var node = UIManager_1.uimanager.createRect(parent, "settingSwitch", switchWidth, switchHeight, initial ? SAGE : MUTED, 255, 24, x, y);
        node.addComponent(cc.Button);
        var trackOutline = new cc.Node("switchTrackOutline");
        trackOutline.zIndex = 1;
        node.addChild(trackOutline);
        var trackGraphics = trackOutline.addComponent(cc.Graphics);
        trackGraphics.strokeColor = new cc.Color(101, 70, 58, 42);
        trackGraphics.lineWidth = 1.2;
        trackGraphics.roundRect(-switchWidth / 2 + .8, -switchHeight / 2 + .8, switchWidth - 1.6, switchHeight - 1.6, 23.2);
        trackGraphics.stroke();
        var thumb = new cc.Node("switchThumb");
        thumb.width = 36;
        thumb.height = 36;
        thumb.zIndex = 2;
        thumb.setPosition(initial ? thumbTravel : -thumbTravel, 0);
        node.addChild(thumb);
        var shadow = UIManager_1.uimanager.createCircle(thumb, "switchThumbShadow", 18, new cc.Color(91, 63, 50, 38), 0, -2);
        shadow.zIndex = -1;
        var surface = UIManager_1.uimanager.createCircle(thumb, "switchThumbSurface", 18, new cc.Color(255, 250, 237));
        surface.zIndex = 1;
        var outlineNode = new cc.Node("switchThumbOutline");
        outlineNode.zIndex = 2;
        thumb.addChild(outlineNode);
        var outline = outlineNode.addComponent(cc.Graphics);
        outline.strokeColor = new cc.Color(111, 81, 67, 90);
        outline.lineWidth = 1.2;
        outline.circle(0, 0, 17.3);
        outline.stroke();
        var highlight = UIManager_1.uimanager.createCircle(thumb, "switchThumbHighlight", 4, new cc.Color(255, 255, 255, 190), -6, 6);
        highlight.zIndex = 3;
        var enabled = initial;
        var paint = function() {
          UIManager_1.uimanager.drawRect(node, switchWidth, switchHeight, enabled ? SAGE : MUTED, switchHeight / 2);
          cc.Tween.stopAllByTarget(thumb);
          cc.tween(thumb).to(.14, {
            x: enabled ? thumbTravel : -thumbTravel
          }, {
            easing: "sineOut"
          }).start();
        };
        node.on(cc.Node.EventType.TOUCH_START, function() {
          cc.Tween.stopAllByTarget(node);
          cc.tween(node).to(.06, {
            scale: .96
          }).start();
        });
        node.on(cc.Node.EventType.TOUCH_END, function() {
          enabled = !enabled;
          paint();
          cc.Tween.stopAllByTarget(node);
          cc.tween(node).to(.12, {
            scale: 1
          }, {
            easing: "backOut"
          }).start();
          onChange(enabled);
        });
        node.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.Tween.stopAllByTarget(node);
          cc.tween(node).to(.1, {
            scale: 1
          }).start();
        });
      };
      return SettingsPanel;
    }();
    exports.default = SettingsPanel;
    exports.settingsPanel = SettingsPanel.instance;
    cc._RF.pop();
  }, {
    "../zyxGame/GlyphFactory": "GlyphFactory",
    "./GameSettings": "GameSettings",
    "./UIManager": "UIManager"
  } ],
  SettlementSync: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "b1f2ckEfj1KW5xtLo8KGzxV", "SettlementSync");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.flushPendingRoundSettlements = exports.isPendingSettlementRecordValid = exports.isPermanentSettlementError = exports.isAuthError = void 0;
    var ZyxGameModule_1 = require("../dataModule/ZyxGameModule");
    var MoodBeanConfig_1 = require("../dataModule/MoodBeanConfig");
    var flushInFlight = false;
    var PERMANENT_BUSINESS_CODES = new Set([ "INVALID_ROUND_TIME", "INVALID_ROUND_DURATION", "SETTLEMENT_TOO_OLD", "INVALID_BEAN_AMOUNT", "COLLECTION_COUNT_INVALID", "ROUND_PAYLOAD_CONFLICT", "ROUND_NOT_STARTED", "REPLAY_INVALID", "REPLAY_MISMATCH", "ROUND_SESSION_CONFLICT", "PROGRESS_CONFLICT", "PROGRESS_INVALID", "ROUND_NOT_ACTIVE", "ROUND_ALREADY_SETTLED" ]);
    function isAuthError(error) {
      var status = Number(error && (void 0 !== error.status ? error.status : error.statusCode));
      return 401 === status;
    }
    exports.isAuthError = isAuthError;
    function isPermanentSettlementError(error) {
      if (!error) return false;
      var status = Number(void 0 !== error.status ? error.status : error.statusCode);
      if (!Number.isFinite(status) || 0 === status) return false;
      if (401 === status) return false;
      if (408 === status || 425 === status || 429 === status) return false;
      if (status >= 500) return false;
      if (status >= 400 && status < 500) {
        var businessCode = error.businessCode;
        if (businessCode && PERMANENT_BUSINESS_CODES.has(businessCode)) return true;
        return false;
      }
      return false;
    }
    exports.isPermanentSettlementError = isPermanentSettlementError;
    function isPendingSettlementRecordValid(record) {
      if (!record || "string" !== typeof record.roundId || 0 === record.roundId.length) return false;
      var startedAt = Number(record.startedAt);
      var endedAt = Number(record.endedAt);
      if (!Number.isFinite(startedAt) || !Number.isFinite(endedAt)) return false;
      var duration = endedAt - startedAt;
      if (duration < MoodBeanConfig_1.MIN_ROUND_DURATION_MS || duration > MoodBeanConfig_1.MAX_ROUND_DURATION_MS) return false;
      if (!Number.isFinite(Number(record.score)) || Number(record.score) < 0) return false;
      if (!Number.isFinite(Number(record.collectedMoodBeanCount)) || Number(record.collectedMoodBeanCount) < 0) return false;
      if (startedAt < Date.now() - MoodBeanConfig_1.MAX_OFFLINE_SETTLEMENT_AGE_MS) return false;
      return true;
    }
    exports.isPendingSettlementRecordValid = isPendingSettlementRecordValid;
    function flushPendingRoundSettlements(submit, hooks) {
      void 0 === hooks && (hooks = {});
      return __awaiter(this, void 0, Promise, function() {
        var outcome, queue, record, reason, result, error_1, reason;
        return __generator(this, function(_a) {
          switch (_a.label) {
           case 0:
            if (flushInFlight) return [ 2, {
              alreadyRunning: true,
              submitted: 0,
              deadLettered: 0,
              blocked: false
            } ];
            flushInFlight = true;
            outcome = {
              alreadyRunning: false,
              submitted: 0,
              deadLettered: 0,
              blocked: false
            };
            _a.label = 1;

           case 1:
            _a.trys.push([ 1, , 8, 9 ]);
            _a.label = 2;

           case 2:
            false;
            queue = ZyxGameModule_1.zyxGameModule.getPendingRoundSettlements();
            if (0 === queue.length) return [ 3, 7 ];
            record = queue[0];
            if (!isPendingSettlementRecordValid(record)) {
              reason = "\u8bb0\u5f55\u5b57\u6bb5\u635f\u574f\u6216\u8d85\u51fa\u79bb\u7ebf\u8865\u4f20\u7a97\u53e3";
              ZyxGameModule_1.zyxGameModule.movePendingRoundSettlementToDeadLetter(record.roundId, reason);
              outcome.deadLettered++;
              hooks.onDeadLetter && hooks.onDeadLetter(record, reason);
              return [ 3, 2 ];
            }
            _a.label = 3;

           case 3:
            _a.trys.push([ 3, 5, , 6 ]);
            return [ 4, submit(record) ];

           case 4:
            result = _a.sent();
            ZyxGameModule_1.zyxGameModule.removePendingRoundSettlement(record.roundId);
            outcome.submitted++;
            hooks.onSettled && hooks.onSettled(record, result);
            return [ 3, 6 ];

           case 5:
            error_1 = _a.sent();
            if (isPermanentSettlementError(error_1)) {
              reason = error_1 && error_1.message ? error_1.message : "\u670d\u52a1\u7aef\u62d2\u7edd\u8be5\u8bb0\u5f55";
              ZyxGameModule_1.zyxGameModule.movePendingRoundSettlementToDeadLetter(record.roundId, reason);
              outcome.deadLettered++;
              hooks.onDeadLetter && hooks.onDeadLetter(record, reason);
              return [ 3, 2 ];
            }
            outcome.blocked = true;
            return [ 3, 7 ];

           case 6:
            return [ 3, 2 ];

           case 7:
            return [ 2, outcome ];

           case 8:
            flushInFlight = false;
            return [ 7 ];

           case 9:
            return [ 2 ];
          }
        });
      });
    }
    exports.flushPendingRoundSettlements = flushPendingRoundSettlements;
    cc._RF.pop();
  }, {
    "../dataModule/MoodBeanConfig": "MoodBeanConfig",
    "../dataModule/ZyxGameModule": "ZyxGameModule"
  } ],
  ShareConfig: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "2c7c8EHCSlBxaCrctNvOC4S", "ShareConfig");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.SHARE_CARDS = void 0;
    exports.SHARE_CARDS = [ {
      title: "\u8fd9\u4e00\u62d6\uff0c\u723d\u7ffb\u4e86\uff01",
      imageUrl: "https://cdn.tcjstory.cn/cocos-zyx/share/20261112/burst.114f9e07f6f2.jpg"
    }, {
      title: "\u5feb\u6ee1\u4e86\uff1f\u4e00\u62d6\u7ffb\u76d8\uff01",
      imageUrl: "https://cdn.tcjstory.cn/cocos-zyx/share/20261112/comeback.802a89bfbfe6.jpg"
    }, {
      title: "\u8fb9\u6d88\u8fb9\u51b2\u699c\uff0c\u4e0b\u4e00\u540d\u88ab\u6211\u8d85\u4e86\uff01",
      imageUrl: "https://cdn.tcjstory.cn/cocos-zyx/share/20261112/rank.a5408140d36d.jpg"
    } ];
    cc._RF.pop();
  }, {} ],
  ShareReward: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "d191c+NE5VFbZlRloW8tLxu", "ShareReward");
    "use strict";
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.requestShareReward = exports.requestRewardOffer = exports.getRewardOfferFailToast = exports.getRewardOfferActionText = exports.getRewardOfferIcon = exports.registerSystemShare = exports.inviteWeChatFriends = exports.SHARE_SUCCESS_MIN_MS = exports.REWARD_AD_UNITS = exports.REWARDED_VIDEO_AD_UNIT_ID = exports.REWARDED_VIDEO_ENABLED = void 0;
    var UIManager_1 = require("./UIManager");
    var PlatformAdapter_1 = require("./PlatformAdapter");
    var ShareConfig_1 = require("./ShareConfig");
    exports.REWARDED_VIDEO_ENABLED = false;
    exports.REWARDED_VIDEO_AD_UNIT_ID = "";
    exports.REWARD_AD_UNITS = {
      tool: "adunit-3251cf42a96b9395",
      rescue: "adunit-285b01479c4638f5",
      revive: "adunit-cb541c6faf1e1889"
    };
    exports.SHARE_SUCCESS_MIN_MS = 3e3;
    var pending = null;
    var onShowHooked = false;
    var systemShareRegistered = false;
    var shareImageFiles = {};
    var shareImageDownloads = {};
    function cacheShareImage(imageUrl) {
      if (shareImageFiles[imageUrl]) return Promise.resolve(shareImageFiles[imageUrl]);
      if (shareImageDownloads[imageUrl]) return shareImageDownloads[imageUrl];
      var wxApi = PlatformAdapter_1.getWxApi();
      var download = new Promise(function(resolve, reject) {
        wxApi.downloadFile({
          url: imageUrl,
          timeout: 2500,
          success: function(result) {
            200 === result.statusCode && result.tempFilePath ? resolve(result.tempFilePath) : reject(new Error("\u5206\u4eab\u56fe\u7247\u4e0b\u8f7d\u5931\u8d25"));
          },
          fail: reject
        });
      }).then(function(filePath) {
        shareImageFiles[imageUrl] = filePath;
        delete shareImageDownloads[imageUrl];
        return filePath;
      }, function(error) {
        delete shareImageDownloads[imageUrl];
        throw error;
      });
      shareImageDownloads[imageUrl] = download;
      return download;
    }
    function prepareShareMessage(message) {
      return cacheShareImage(message.imageUrl).then(function(imageUrl) {
        return __assign(__assign({}, message), {
          imageUrl: imageUrl
        });
      });
    }
    function createShareMessage(from) {
      var card = ShareConfig_1.SHARE_CARDS[Math.floor(Math.random() * ShareConfig_1.SHARE_CARDS.length)];
      return {
        title: card.title,
        imageUrl: shareImageFiles[card.imageUrl] || card.imageUrl,
        query: "from=" + from
      };
    }
    function inviteWeChatFriends() {
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!wxApi || "function" !== typeof wxApi.shareAppMessage) {
        UIManager_1.uimanager.showToast("\u8bf7\u5728\u5fae\u4fe1\u4e2d\u9080\u8bf7\u597d\u53cb\u4e00\u8d77\u73a9");
        return;
      }
      try {
        wxApi.shareAppMessage(createShareMessage("friend_invite"));
      } catch (_) {
        UIManager_1.uimanager.showToast("\u6682\u65f6\u65e0\u6cd5\u6253\u5f00\u5206\u4eab\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
      }
    }
    exports.inviteWeChatFriends = inviteWeChatFriends;
    function finishPending(rewarded, toastMessage) {
      void 0 === toastMessage && (toastMessage = "");
      if (!pending || pending.completed) return;
      pending.completed = true;
      if (pending.timeoutId) {
        clearTimeout(pending.timeoutId);
        pending.timeoutId = null;
      }
      var onResult = pending.onResult;
      pending = null;
      toastMessage && UIManager_1.uimanager.showToast(toastMessage);
      onResult(rewarded);
    }
    function resolvePendingFromShow() {
      if (!pending || pending.completed || !pending.startedAt) return;
      var elapsed = Date.now() - pending.startedAt;
      if (elapsed >= exports.SHARE_SUCCESS_MIN_MS) {
        finishPending(true);
        return;
      }
      finishPending(false);
    }
    function ensureOnShowHook() {
      if (onShowHooked) return;
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!wxApi || "function" !== typeof wxApi.onShow) return;
      wxApi.onShow(function() {
        return resolvePendingFromShow();
      });
      onShowHooked = true;
    }
    function registerSystemShare() {
      if (systemShareRegistered) return;
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!wxApi || "function" !== typeof wxApi.onShareAppMessage) return;
      try {
        "function" === typeof wxApi.showShareMenu && wxApi.showShareMenu({
          withShareTicket: true,
          menus: [ "shareAppMessage" ]
        });
        "function" === typeof wxApi.downloadFile && ShareConfig_1.SHARE_CARDS.forEach(function(card) {
          return cacheShareImage(card.imageUrl).catch(function() {
            return;
          });
        });
        wxApi.onShareAppMessage(function() {
          var message = createShareMessage("system_share");
          if ("function" !== typeof wxApi.downloadFile || !message.imageUrl.startsWith("https://")) return message;
          return __assign(__assign({}, message), {
            promise: prepareShareMessage(message).catch(function() {
              return message;
            })
          });
        });
        systemShareRegistered = true;
      } catch (error) {}
    }
    exports.registerSystemShare = registerSystemShare;
    function getRewardOfferIcon(placement) {
      void 0 === placement && (placement = "legacy");
      return "hammer" === placement ? "share" : "legacy" !== placement || exports.REWARDED_VIDEO_ENABLED ? "video" : "share";
    }
    exports.getRewardOfferIcon = getRewardOfferIcon;
    function getRewardOfferActionText(placement) {
      void 0 === placement && (placement = "legacy");
      return "video" === getRewardOfferIcon(placement) ? "\u770b\u89c6\u9891" : "\u5206\u4eab";
    }
    exports.getRewardOfferActionText = getRewardOfferActionText;
    function getRewardOfferFailToast(kind, placement) {
      void 0 === placement && (placement = "stamina" === kind ? "legacy" : kind);
      if ("share" === getRewardOfferIcon(placement)) {
        if ("revive" === kind) return "\u8fd9\u6b21\u5206\u4eab\u6ca1\u6709\u5b8c\u6210\uff0c\u518d\u8bd5\u4e00\u6b21\u5c31\u53ef\u4ee5\u590d\u6d3b\u5566";
        if ("rescue" === kind) return "\u8fd9\u6b21\u5206\u4eab\u6ca1\u6709\u5b8c\u6210\uff0c\u4e0b\u6b21\u673a\u4f1a\u518d\u8bd5\u8bd5\u5427";
        if ("stamina" === kind) return "\u5206\u4eab\u672a\u5b8c\u6210\uff0c\u4f53\u529b\u6ca1\u6709\u53d8\u5316";
        return "\u8fd9\u6b21\u5206\u4eab\u6ca1\u6709\u5b8c\u6210\uff0c\u518d\u8bd5\u4e00\u6b21\u5c31\u53ef\u4ee5\u83b7\u5f97\u4f7f\u7528\u673a\u4f1a";
      }
      if ("revive" === kind) return "\u5b8c\u6574\u770b\u5b8c\u89c6\u9891\u624d\u80fd\u590d\u6d3b";
      if ("rescue" === kind) return "\u5b8c\u6574\u770b\u5b8c\u89c6\u9891\u624d\u80fd\u83b7\u5f97\u5e2e\u52a9";
      if ("stamina" === kind) return "\u5b8c\u6574\u770b\u5b8c\u89c6\u9891\u624d\u80fd\u83b7\u5f97\u4f53\u529b";
      return "\u5b8c\u6574\u770b\u5b8c\u89c6\u9891\u624d\u80fd\u83b7\u5f97\u4f7f\u7528\u673a\u4f1a";
    }
    exports.getRewardOfferFailToast = getRewardOfferFailToast;
    function requestRewardOffer(onResult, rewardName, placement) {
      void 0 === rewardName && (rewardName = "\u4e00\u6b21\u673a\u4f1a");
      void 0 === placement && (placement = "legacy");
      if ("video" === getRewardOfferIcon(placement)) {
        requestRewardedVideoReward(onResult, rewardName, exports.REWARD_AD_UNITS[placement] || exports.REWARDED_VIDEO_AD_UNIT_ID);
        return;
      }
      requestShareReward(onResult, rewardName);
    }
    exports.requestRewardOffer = requestRewardOffer;
    function requestShareReward(onResult, rewardName) {
      void 0 === rewardName && (rewardName = "\u4e00\u6b21\u673a\u4f1a");
      pending && !pending.completed && finishPending(false);
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!wxApi || "function" !== typeof wxApi.shareAppMessage) {
        UIManager_1.uimanager.showModal("\u5206\u4eab\u83b7\u5f97" + rewardName, "\u7f51\u9875\u9884\u89c8\u4f7f\u7528\u6a21\u62df\u5206\u4eab\u3002\n\u5fae\u4fe1\u91cc\u4f1a\u76f4\u63a5\u62c9\u8d77\u5206\u4eab\u9762\u677f\u3002", [ {
          text: "\u6a21\u62df\u5206\u4eab\u6210\u529f",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return onResult(true);
          }
        }, {
          text: "\u6a21\u62df\u5206\u4eab\u672a\u5b8c\u6210",
          color: UIManager_1.BUTTON_COLORS.red,
          onClick: function() {
            return onResult(false);
          }
        } ], null, 0, false, true);
        return;
      }
      ensureOnShowHook();
      pending = {
        startedAt: 0,
        onResult: onResult,
        completed: false,
        timeoutId: setTimeout(function() {
          finishPending(false, "\u5206\u4eab\u5df2\u53d6\u6d88\u6216\u8d85\u65f6\uff0c\u8bf7\u518d\u8bd5\u4e00\u6b21");
        }, 6e4)
      };
      var request = pending;
      var share = function(message) {
        if (pending !== request || request.completed) return;
        try {
          request.startedAt = Date.now();
          wxApi.shareAppMessage(message);
        } catch (error) {
          finishPending(false, "\u5206\u4eab\u6682\u65f6\u4e0d\u53ef\u7528\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
        }
      };
      var message = createShareMessage("share_reward");
      "function" === typeof wxApi.downloadFile && message.imageUrl.startsWith("https://") ? prepareShareMessage(message).then(share).catch(function() {
        pending === request && finishPending(false, "\u5206\u4eab\u56fe\u7247\u6682\u65f6\u6ca1\u6709\u52a0\u8f7d\u597d\uff0c\u8bf7\u518d\u8bd5\u4e00\u6b21");
      }) : share(message);
    }
    exports.requestShareReward = requestShareReward;
    function requestRewardedVideoReward(onResult, rewardName, configuredId) {
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!wxApi) {
        UIManager_1.uimanager.showModal("\u770b\u89c6\u9891\u83b7\u5f97" + rewardName, "\u7f51\u9875\u9884\u89c8\u4f7f\u7528\u6a21\u62df\u5956\u52b1\uff1b\u5fae\u4fe1\u91cc\u4f1a\u64ad\u653e\u771f\u5b9e\u6fc0\u52b1\u89c6\u9891\u3002", [ {
          text: "\u6a21\u62df\u89c2\u770b\u5b8c\u6210",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return onResult(true);
          }
        }, {
          text: "\u6a21\u62df\u4e2d\u9014\u5173\u95ed",
          color: UIManager_1.BUTTON_COLORS.red,
          onClick: function() {
            return onResult(false);
          }
        } ]);
        return;
      }
      if ("function" !== typeof wxApi.createRewardedVideoAd) {
        UIManager_1.uimanager.showToast("\u5f53\u524d\u5fae\u4fe1\u7248\u672c\u6682\u4e0d\u652f\u6301\u6fc0\u52b1\u89c6\u9891");
        onResult(false);
        return;
      }
      var adUnitId = configuredId.trim();
      if (!adUnitId) {
        UIManager_1.uimanager.showToast("\u8bf7\u5148\u914d\u7f6e\u6fc0\u52b1\u89c6\u9891\u5e7f\u544a\u4f4d");
        onResult(false);
        return;
      }
      var ad = null;
      try {
        ad = wxApi.createRewardedVideoAd({
          adUnitId: adUnitId
        });
      } catch (error) {
        UIManager_1.uimanager.showToast("\u89c6\u9891\u7ec4\u4ef6\u521d\u59cb\u5316\u5931\u8d25\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
        onResult(false);
        return;
      }
      var completed = false;
      var cleanup = function() {
        if (!ad) return;
        "function" === typeof ad.offClose && ad.offClose(onClose);
        "function" === typeof ad.offError && ad.offError(onError);
      };
      var finish = function(rewarded, errorMessage) {
        void 0 === errorMessage && (errorMessage = "");
        if (completed) return;
        completed = true;
        cleanup();
        errorMessage && UIManager_1.uimanager.showToast(errorMessage);
        onResult(rewarded);
      };
      var onClose = function(result) {
        finish(!!result && true === result.isEnded);
      };
      var onError = function() {
        finish(false, "\u89c6\u9891\u6682\u65f6\u6ca1\u6709\u51c6\u5907\u597d\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5");
      };
      if (!ad || "function" !== typeof ad.onClose || "function" !== typeof ad.onError) {
        finish(false, "\u5f53\u524d\u5fae\u4fe1\u7248\u672c\u6682\u4e0d\u652f\u6301\u6fc0\u52b1\u89c6\u9891");
        return;
      }
      ad.onClose(onClose);
      ad.onError(onError);
      try {
        var showResult = ad.show();
        showResult && "function" === typeof showResult.catch && showResult.catch(function() {
          if (completed) return;
          try {
            var loadResult = ad.load();
            if (!loadResult || "function" !== typeof loadResult.then) {
              onError();
              return;
            }
            loadResult.then(function() {
              if (completed) return;
              var retryResult = ad.show();
              retryResult && "function" === typeof retryResult.catch && retryResult.catch(onError);
            }).catch(onError);
          } catch (error) {
            onError();
          }
        });
      } catch (error) {
        onError();
      }
    }
    cc._RF.pop();
  }, {
    "./PlatformAdapter": "PlatformAdapter",
    "./ShareConfig": "ShareConfig",
    "./UIManager": "UIManager"
  } ],
  ShopPanel: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "47ca7ApwaBIx6P/J4JK0nGT", "ShopPanel");
    "use strict";
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.drawShopBag = exports.showShopPanel = exports.refreshShopPanel = void 0;
    var UIManager_1 = require("../manager/UIManager");
    var CloudService_1 = require("../manager/CloudService");
    var AssetLoader_1 = require("../manager/AssetLoader");
    var ZyxGameModule_1 = require("../dataModule/ZyxGameModule");
    var MoodArt_1 = require("./MoodArt");
    var PENDING_KEY = "zyx_pending_tool_exchange";
    var PRICES = {
      hammer: 3,
      magicWand: 3,
      stamina: 3,
      reviveCard: 25
    };
    var exchanging = false;
    var refreshVisibleShop = null;
    function drawShopButton(node, color, width, height) {
      var surface = node.getComponent(cc.Graphics);
      surface.clear();
      surface.fillColor = color;
      surface.strokeColor = new cc.Color(132, 123, 88);
      surface.lineWidth = 2;
      surface.roundRect(-width / 2, -height / 2, width, height, 18);
      surface.fill();
      surface.stroke();
    }
    function refreshShopPanel() {
      refreshVisibleShop && refreshVisibleShop();
    }
    exports.refreshShopPanel = refreshShopPanel;
    function pendingExchange() {
      try {
        var value = JSON.parse(cc.sys.localStorage.getItem(PENDING_KEY) || "null");
        if (!value) return null;
        if ("string" === typeof value.actionId && value.playerId === ZyxGameModule_1.zyxGameModule.getPlayerId() && [ "stamina", "reviveCard" ].indexOf(value.item) >= 0) return value;
        cc.sys.localStorage.removeItem(PENDING_KEY);
        return null;
      } catch (_) {
        return null;
      }
    }
    function showShopPanel(ensureProfile, applyProfile, challenge) {
      var _this = this;
      if (exchanging) {
        UIManager_1.uimanager.showToast("\u6b63\u5728\u786e\u8ba4\u5151\u6362\uff0c\u8bf7\u7a0d\u5019");
        return;
      }
      var root = null;
      var status = null;
      var inventory = {};
      var buttons = [];
      var showSuccess = function(item) {
        refreshVisibleShop = null;
        var title = "hammer" === item ? "\u89e3\u538b\u9524" : "magicWand" === item ? "\u9b54\u6cd5\u68d2" : "reviveCard" === item ? "\u590d\u6d3b\u5361" : "\u4f53\u529b";
        var reward = UIManager_1.uimanager.showModal("\u606d\u559c\u83b7\u5f97", "", [ {
          text: "\u6536\u4e0b",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return showShopPanel(ensureProfile, applyProfile, challenge);
          }
        } ], function(panel, centerY) {
          var art = new cc.Node("shopRewardArt");
          panel.addChild(art);
          art.setPosition(0, centerY + 134);
          if ("stamina" === item) MoodArt_1.createStaminaBolt(art, 0, 0, 138); else {
            var sprite = art.addComponent(cc.Sprite);
            sprite.spriteFrame = AssetLoader_1.getSpriteFrame("reviveCard" === item ? "effects" : "game", "reviveCard" === item ? AssetLoader_1.ASSET_PATHS.effects.reviveCard : "hammer" === item ? AssetLoader_1.ASSET_PATHS.game.hammer : AssetLoader_1.ASSET_PATHS.game.magicWand);
            sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            UIManager_1.uimanager.fitSpriteFrameInside(art, sprite.spriteFrame, 148, 154);
          }
          var name = UIManager_1.uimanager.createLabel(panel, title + " \xd71", 0, centerY + 22, 34, MoodArt_1.MOOD_COLORS.cocoa, 420, 48);
          name.node.name = "shopRewardName";
          UIManager_1.uimanager.applyTypography(name, true);
          UIManager_1.uimanager.createLabel(panel, "stamina" === item ? "\u5151\u6362\u6210\u529f\uff0c\u4f53\u529b\u5df2\u5230\u8d26" : "\u5151\u6362\u6210\u529f\uff0c\u5df2\u653e\u5165\u9053\u5177\u80cc\u5305", 0, centerY - 34, 24, new cc.Color(65, 111, 69), 460, 40);
        }, 180);
        reward.name = "shopExchangeSuccess";
        drawShopButton(reward.getChildByName("panel").getChildByName("button_\u6536\u4e0b"), UIManager_1.BUTTON_COLORS.green, 420, 72);
      };
      var showInsufficientBeans = function(item) {
        var price = PRICES[item];
        if (!challenge) {
          UIManager_1.uimanager.showToast("\u5f00\u5fc3\u8c46\u4e0d\u8db3\uff0c\u9700\u8981" + price + "\u9897\u624d\u80fd\u5151\u6362");
          return;
        }
        var prompt = null;
        var staminaLabel = null;
        var starting = false;
        prompt = UIManager_1.uimanager.showModal("\u5f00\u5fc3\u8c46\u4e0d\u8db3", "\u5151\u6362" + ("stamina" === item ? "\u4f53\u529b" : "\u9053\u5177") + "\u9700\u8981" + price + "\u9897\u5f00\u5fc3\u8c46\u3002\n\u662f\u5426\u5feb\u901f\u5f00\u542f\u6311\u6218\uff0c\u7ee7\u7eed\u6536\u96c6\uff1f", [ {
          text: "\u8fd4\u56de\u5546\u57ce",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            return showShopPanel(ensureProfile, applyProfile, challenge);
          }
        }, {
          text: "\u5f00\u59cb\u6311\u6218",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return __awaiter(_this, void 0, void 0, function() {
              return __generator(this, function(_a) {
                switch (_a.label) {
                 case 0:
                  if (starting) return [ 2 ];
                  starting = true;
                  return [ 4, challenge.start() ];

                 case 1:
                  _a.sent();
                  return [ 2 ];
                }
              });
            });
          }
        } ], function(panel, centerY) {
          staminaLabel = UIManager_1.uimanager.createLabel(panel, challenge.staminaText(), 0, centerY + 10, 20, new cc.Color(89, 118, 80), 470, 44);
          staminaLabel.node.name = "shopChallengeStamina";
        }, 60, true);
        refreshVisibleShop = function() {
          prompt && cc.isValid(prompt, true) && (staminaLabel.string = challenge.staminaText());
        };
      };
      var refresh = function() {
        if (!root || !cc.isValid(root, true)) return;
        var balance = ZyxGameModule_1.zyxGameModule.getDisplayMoodBeanBalance();
        inventory.reviveCard.string = "\u5df2\u62e5\u6709 " + ZyxGameModule_1.zyxGameModule.reviveCardCount + " \u5f20";
        UIManager_1.uimanager.applyTypography(inventory.reviveCard);
        inventory.stamina.string = challenge && challenge.staminaAmount ? challenge.staminaAmount() : "\u6062\u590d\u540e\u7acb\u5373\u53ef\u7528";
        var pending = pendingExchange();
        buttons.forEach(function(button) {
          var retry = pending && pending.item === button.item;
          var available = !exchanging && (!pending || !!retry);
          button.node.getComponent(cc.Button).interactable = available;
          var action = exchanging && retry ? "\u786e\u8ba4\u4e2d\u2026" : retry ? "\u7ee7\u7eed\u786e\u8ba4" : "\u5151\u6362";
          button.label.string = action;
          button.price.string = String(PRICES[button.item]);
          button.price.node.color = balance < PRICES[button.item] ? new cc.Color(189, 64, 53) : new cc.Color(40, 118, 56);
          button.layout.updateLayout();
        });
        pending && !exchanging && (status.string = "\u6709\u4e00\u7b14\u5151\u6362\u5f85\u786e\u8ba4\uff0c\u70b9\u51fb\u300c\u7ee7\u7eed\u786e\u8ba4\u300d\u5373\u53ef");
        status.node.active = status.string.length > 0;
      };
      var exchange = function(item) {
        return __awaiter(_this, void 0, Promise, function() {
          var pending, request, result, message, error_1, code, permanent, message;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (exchanging) return [ 2 ];
              pending = pendingExchange();
              if (pending && pending.item !== item) return [ 2 ];
              if (!pending && ZyxGameModule_1.zyxGameModule.getDisplayMoodBeanBalance() < PRICES[item]) {
                showInsufficientBeans(item);
                return [ 2 ];
              }
              request = pending || {
                item: item,
                playerId: ZyxGameModule_1.zyxGameModule.getPlayerId(),
                actionId: "shop_" + Date.now() + "_" + Math.floor(1e9 * Math.random()).toString(36)
              };
              try {
                cc.sys.localStorage.setItem(PENDING_KEY, JSON.stringify(request));
              } catch (_) {
                UIManager_1.uimanager.showToast("\u5b58\u50a8\u7a7a\u95f4\u4e0d\u8db3\uff0c\u6682\u65f6\u65e0\u6cd5\u5151\u6362");
                return [ 2 ];
              }
              exchanging = true;
              status.string = "\u6b63\u5728\u786e\u8ba4\u5151\u6362\u2026";
              refresh();
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 4, 7, 8 ]);
              return [ 4, ensureProfile() ];

             case 2:
              _a.sent();
              return [ 4, CloudService_1.cloudService.exchangeTool(request.actionId, request.item) ];

             case 3:
              result = _a.sent();
              applyProfile(result.profile);
              cc.sys.localStorage.removeItem(PENDING_KEY);
              message = "stamina" === item ? "\u4f53\u529b +1\uff0c\u53ef\u4ee5\u7ee7\u7eed\u6311\u6218" : ("reviveCard" === item ? "\u590d\u6d3b\u5361" : "hammer" === item ? "\u89e3\u538b\u9524" : "\u9b54\u6cd5\u68d2") + " +1\uff0c\u5df2\u653e\u5165\u9053\u5177\u80cc\u5305";
              root && cc.isValid(root, true) && root.activeInHierarchy ? showSuccess(item) : UIManager_1.uimanager.showToast(message);
              return [ 3, 8 ];

             case 4:
              error_1 = _a.sent();
              code = error_1 && error_1.businessCode;
              permanent = [ "BEANS_INSUFFICIENT", "TOOL_REQUEST_INVALID", "TOOL_PAYLOAD_CONFLICT" ].indexOf(code) >= 0;
              permanent && cc.sys.localStorage.removeItem(PENDING_KEY);
              if (!("BEANS_INSUFFICIENT" === code)) return [ 3, 6 ];
              return [ 4, ensureProfile() ];

             case 5:
              _a.sent();
              root && cc.isValid(root, true) && showInsufficientBeans(item);
              return [ 2 ];

             case 6:
              message = permanent ? error_1.message : "\u7f51\u7edc\u6682\u672a\u786e\u8ba4\uff0c\u91cd\u8bd5\u8fd9\u7b14\u5151\u6362\u4e0d\u4f1a\u91cd\u590d\u6263\u8c46";
              root && cc.isValid(root) && (status.string = message);
              UIManager_1.uimanager.showToast(message);
              return [ 3, 8 ];

             case 7:
              exchanging = false;
              refresh();
              return [ 7 ];

             case 8:
              return [ 2 ];
            }
          });
        });
      };
      root = UIManager_1.uimanager.showModal("\u5546\u57ce", "", [], function(panel) {
        var items = [ {
          item: "stamina",
          title: "\u4f53\u529b",
          description: "\u6062\u590d1\u70b9\u4f53\u529b\uff0c\u7ee7\u7eed\u6311\u6218",
          path: "",
          color: UIManager_1.BUTTON_COLORS.yellow
        }, {
          item: "reviveCard",
          title: "\u590d\u6d3b\u5361",
          description: "\u5e7f\u544a\u590d\u6d3b\u540e\uff0c\u518d\u7eed\u4e00\u6b21\u673a\u4f1a",
          path: AssetLoader_1.ASSET_PATHS.effects.reviveCard,
          color: UIManager_1.BUTTON_COLORS.green
        } ];
        var view = new cc.Node("shopScrollView");
        view.setContentSize(570, 580);
        view.setPosition(0, -24);
        panel.addChild(view);
        view.addComponent(cc.Mask).type = cc.Mask.Type.RECT;
        var scrollContent = new cc.Node("shopScrollContent");
        scrollContent.setAnchorPoint(.5, 1);
        scrollContent.setContentSize(570, 302 * items.length - 36);
        scrollContent.setPosition(0, 290);
        view.addChild(scrollContent);
        var scroll = view.addComponent(cc.ScrollView);
        scroll.content = scrollContent;
        scroll.horizontal = false;
        scroll.vertical = true;
        scroll.inertia = true;
        scroll.elastic = true;
        items.forEach(function(item, index) {
          var card = UIManager_1.uimanager.createRect(scrollContent, "shopCard_" + item.item, 552, 266, [ new cc.Color(216, 231, 203), new cc.Color(209, 228, 237), new cc.Color(246, 221, 190), new cc.Color(235, 232, 208) ][index], 255, 22, 0, -133 - 302 * index);
          var edge = card.getComponent(cc.Graphics);
          edge.strokeColor = index ? new cc.Color(132, 165, 178) : new cc.Color(148, 169, 119);
          edge.lineWidth = 1.8;
          edge.roundRect(-275, -132, 550, 264, 22);
          edge.stroke();
          var pedestal = UIManager_1.uimanager.createRect(card, "toolPedestal", 126, 134, [ new cc.Color(186, 210, 162), new cc.Color(178, 207, 222), new cc.Color(235, 198, 150), new cc.Color(220, 224, 188) ][index], 255, 24, -194, 41);
          "stamina" === item.item && MoodArt_1.createStaminaBolt(pedestal, 0, 0, 96);
          var icon = new cc.Node("shopToolArt");
          pedestal.addChild(icon);
          if (item.path) {
            var sprite = icon.addComponent(cc.Sprite);
            sprite.spriteFrame = AssetLoader_1.getSpriteFrame("reviveCard" === item.item ? "effects" : "game", item.path);
            sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            UIManager_1.uimanager.fitSpriteFrameInside(icon, sprite.spriteFrame, 116, 124);
          }
          var title = UIManager_1.uimanager.createLabel(card, item.title + " \xd71", 56, 85, 28, MoodArt_1.MOOD_COLORS.cocoa, 310, 36);
          title.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
          UIManager_1.uimanager.applyTypography(title, true);
          var description = UIManager_1.uimanager.createLabel(card, item.description, 56, 35, 20, new cc.Color(64, 100, 112), 310, 28);
          description.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
          description.enableWrapText = false;
          inventory[item.item] = UIManager_1.uimanager.createLabel(card, "", 56, -12, 18, MoodArt_1.MOOD_COLORS.cocoa, 310, 26);
          inventory[item.item].horizontalAlign = cc.Label.HorizontalAlign.LEFT;
          var button = UIManager_1.uimanager.createButton(card, "", 0, -84, 488, 84, item.color, function() {
            return exchange(item.item);
          }, 27);
          button.name = "shopExchange_" + item.item;
          drawShopButton(button, item.color, 488, 84);
          button.getComponentInChildren(cc.Label).node.destroy();
          var content = new cc.Node("shopExchangeContent");
          button.addChild(content);
          content.setPosition(0, 0);
          content.setContentSize(0, 50);
          var layout = content.addComponent(cc.Layout);
          layout.type = cc.Layout.Type.HORIZONTAL;
          layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
          layout.spacingX = 12;
          var label = UIManager_1.uimanager.createLabel(content, "", 0, 0, 27, UIManager_1.BUTTON_TEXT_COLOR, 120, 50);
          label.node.name = "shopPurchaseText";
          label.overflow = cc.Label.Overflow.NONE;
          label.enableWrapText = false;
          UIManager_1.uimanager.applyTypography(label, true);
          label.lineHeight = 36;
          var price = UIManager_1.uimanager.createLabel(content, "", 0, 0, 32, MoodArt_1.MOOD_COLORS.cocoa, 36, 50);
          price.node.name = "shopPrice";
          price.overflow = cc.Label.Overflow.NONE;
          UIManager_1.uimanager.applyTypography(price, true);
          var coin = MoodArt_1.createMoodBeanMascot(content, 0, 0, 50);
          coin.name = "shopCurrencyIcon";
          coin.zIndex = label.node.zIndex;
          buttons.push({
            item: item.item,
            node: button,
            label: label,
            price: price,
            layout: layout
          });
        });
        status = UIManager_1.uimanager.createLabel(panel, "", 0, -350, 19, new cc.Color(139, 111, 85), 540, 46);
      }, 500, false, true, 640);
      refreshVisibleShop = refresh;
      refresh();
    }
    exports.showShopPanel = showShopPanel;
    function drawShopBag(parent) {
      var node = new cc.Node("shopBagArt");
      parent.addChild(node);
      node.setPosition(0, 3);
      node.zIndex = 9;
      var g = node.addComponent(cc.Graphics);
      g.lineJoin = cc.Graphics.LineJoin.ROUND;
      g.lineWidth = 3;
      g.strokeColor = new cc.Color(145, 94, 49);
      g.fillColor = new cc.Color(255, 244, 207);
      g.moveTo(-25, 16);
      g.lineTo(25, 16);
      g.lineTo(30, -25);
      g.quadraticCurveTo(0, -35, -30, -25);
      g.close();
      g.fill();
      g.stroke();
      g.moveTo(-12, 15);
      g.bezierCurveTo(-14, 44, 14, 44, 12, 15);
      g.stroke();
      MoodArt_1.createMoodBean(node, 1, 0, -7, 33);
    }
    exports.drawShopBag = drawShopBag;
    cc._RF.pop();
  }, {
    "../dataModule/ZyxGameModule": "ZyxGameModule",
    "../manager/AssetLoader": "AssetLoader",
    "../manager/CloudService": "CloudService",
    "../manager/UIManager": "UIManager",
    "./MoodArt": "MoodArt"
  } ],
  UIManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f6b0eaEb8lOraTr9sfkeyyf", "UIManager");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.uimanager = exports.formatDisplayNickname = exports.BUTTON_TEXT_COLOR = exports.BUTTON_COLORS = void 0;
    var GameSettings_1 = require("./GameSettings");
    var PlatformAdapter_1 = require("./PlatformAdapter");
    var AssetLoader_1 = require("./AssetLoader");
    exports.BUTTON_COLORS = {
      yellow: new cc.Color(244, 181, 60),
      green: new cc.Color(105, 181, 129),
      red: new cc.Color(226, 104, 95)
    };
    exports.BUTTON_TEXT_COLOR = new cc.Color(88, 61, 55);
    function formatDisplayNickname(nickname) {
      var characters = Array.from("string" === typeof nickname ? nickname.trim() : "");
      return characters.length > 7 ? characters.slice(0, 7).join("") + "..." : characters.join("");
    }
    exports.formatDisplayNickname = formatDisplayNickname;
    var UIManager = function() {
      function UIManager() {
        this.scene = null;
        this.modal = null;
        this.toast = null;
        this.hapticRoot = null;
        this.hapticTouchStart = null;
        this.hapticTouchMoved = false;
        this.typographyLineHeights = new WeakMap();
      }
      Object.defineProperty(UIManager, "instance", {
        get: function() {
          this._instance || (this._instance = new UIManager());
          return this._instance;
        },
        enumerable: false,
        configurable: true
      });
      UIManager.prototype.applyTypography = function(label, display) {
        void 0 === display && (display = false);
        if (!label || !AssetLoader_1.isTypographyReady()) return;
        var previous = this.typographyLineHeights.get(label);
        var lineHeight = previous && label.lineHeight === previous.applied ? previous.logical : label.lineHeight;
        var bitmap = AssetLoader_1.getBitmapFont("game", AssetLoader_1.ASSET_PATHS.game.uiBitmapFont);
        var glyphs = bitmap._fntConfig.fontDefDictionary;
        var covered = Array.from(label.string).every(function(char) {
          return /\s/.test(char) || !!glyphs[char.codePointAt(0)];
        });
        label.font = covered ? bitmap : AssetLoader_1.isFeatureReady("home") ? AssetLoader_1.getTTFFont("home", AssetLoader_1.ASSET_PATHS.home.leaderboardBodyFont) : null;
        label.useSystemFont = !label.font;
        label.enableBold = false;
        label.cacheMode = cc.Label.CacheMode.NONE;
        label.lineHeight = label.font instanceof cc.BitmapFont && label.overflow === cc.Label.Overflow.SHRINK && label.fontSize > 0 ? lineHeight * label.font.fontSize / label.fontSize : lineHeight;
        this.typographyLineHeights.set(label, {
          logical: lineHeight,
          applied: label.lineHeight
        });
      };
      UIManager.prototype.refreshTypography = function(root) {
        var _this = this;
        root.getComponentsInChildren(cc.Label).forEach(function(label) {
          _this.applyTypography(label, label.fontSize >= 30 || !!label.node.parent.getComponent(cc.Button));
        });
      };
      UIManager.prototype.init = function(scene) {
        this.scene = scene;
        if (this.hapticRoot === scene) return;
        this.unbindGlobalHaptics();
        this.hapticRoot = scene;
        if (!this.hapticRoot) return;
        this.hapticRoot.on(cc.Node.EventType.TOUCH_START, this.handleHapticTouchStart, this, true);
        this.hapticRoot.on(cc.Node.EventType.TOUCH_MOVE, this.handleHapticTouchMove, this, true);
        this.hapticRoot.on(cc.Node.EventType.TOUCH_END, this.handleHapticTouchEnd, this, true);
        this.hapticRoot.on(cc.Node.EventType.TOUCH_CANCEL, this.handleHapticTouchCancel, this, true);
      };
      UIManager.prototype.tapFeedback = function() {
        GameSettings_1.gameSettings.vibrateLight();
      };
      UIManager.prototype.unbindGlobalHaptics = function() {
        if (!this.hapticRoot || !cc.isValid(this.hapticRoot)) return;
        this.hapticRoot.off(cc.Node.EventType.TOUCH_START, this.handleHapticTouchStart, this, true);
        this.hapticRoot.off(cc.Node.EventType.TOUCH_MOVE, this.handleHapticTouchMove, this, true);
        this.hapticRoot.off(cc.Node.EventType.TOUCH_END, this.handleHapticTouchEnd, this, true);
        this.hapticRoot.off(cc.Node.EventType.TOUCH_CANCEL, this.handleHapticTouchCancel, this, true);
      };
      UIManager.prototype.handleHapticTouchStart = function(event) {
        this.hapticTouchStart = event.getLocation();
        this.hapticTouchMoved = false;
      };
      UIManager.prototype.handleHapticTouchMove = function(event) {
        if (!this.hapticTouchStart || this.hapticTouchMoved) return;
        var point = event.getLocation();
        var dx = point.x - this.hapticTouchStart.x;
        var dy = point.y - this.hapticTouchStart.y;
        this.hapticTouchMoved = dx * dx + dy * dy > 144;
      };
      UIManager.prototype.handleHapticTouchEnd = function(event) {
        !this.hapticTouchMoved && this.hasInteractiveButtonAncestor(event.target) && this.tapFeedback();
        this.resetHapticTouch();
      };
      UIManager.prototype.handleHapticTouchCancel = function() {
        this.resetHapticTouch();
      };
      UIManager.prototype.resetHapticTouch = function() {
        this.hapticTouchStart = null;
        this.hapticTouchMoved = false;
      };
      UIManager.prototype.hasInteractiveButtonAncestor = function(target) {
        var node = target;
        while (node) {
          var button = node.getComponent(cc.Button);
          if (button) return button.enabled && button.interactable;
          if (node === this.hapticRoot) break;
          node = node.parent;
        }
        return false;
      };
      UIManager.prototype.getSafeAreaMetrics = function() {
        var empty = {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
          menuBottom: 0,
          menuLeft: cc.winSize.width / 2
        };
        var wxApi = PlatformAdapter_1.getWxApi();
        if (!wxApi) return empty;
        var windowInfo = null;
        try {
          "function" === typeof wxApi.getWindowInfo ? windowInfo = wxApi.getWindowInfo() : "function" === typeof wxApi.getSystemInfoSync && (windowInfo = wxApi.getSystemInfoSync());
        } catch (error) {
          return empty;
        }
        if (!windowInfo || !windowInfo.windowWidth || !windowInfo.windowHeight) return empty;
        var scaleX = cc.winSize.width / windowInfo.windowWidth;
        var scaleY = cc.winSize.height / windowInfo.windowHeight;
        var safeArea = windowInfo.safeArea || {
          left: 0,
          top: 0,
          right: windowInfo.windowWidth,
          bottom: windowInfo.windowHeight
        };
        var menuBottom = 0;
        var menuLeft = cc.winSize.width / 2;
        try {
          if ("function" === typeof wxApi.getMenuButtonBoundingClientRect) {
            var menuRect = wxApi.getMenuButtonBoundingClientRect();
            if (menuRect && Number.isFinite(menuRect.bottom)) {
              menuBottom = menuRect.bottom * scaleY;
              menuLeft = menuRect.left * scaleX - cc.winSize.width / 2;
            }
          }
        } catch (error) {
          menuBottom = 0;
          menuLeft = cc.winSize.width / 2;
        }
        return {
          top: Math.max(0, Number(safeArea.top) || 0) * scaleY,
          bottom: Math.max(0, windowInfo.windowHeight - (Number(safeArea.bottom) || windowInfo.windowHeight)) * scaleY,
          left: Math.max(0, Number(safeArea.left) || 0) * scaleX,
          right: Math.max(0, windowInfo.windowWidth - (Number(safeArea.right) || windowInfo.windowWidth)) * scaleX,
          menuBottom: menuBottom,
          menuLeft: menuLeft
        };
      };
      UIManager.prototype.createRect = function(parent, name, width, height, color, opacity, radius, x, y) {
        void 0 === opacity && (opacity = 255);
        void 0 === radius && (radius = 0);
        void 0 === x && (x = 0);
        void 0 === y && (y = 0);
        var node = new cc.Node(name);
        node.width = width;
        node.height = height;
        node.opacity = opacity;
        node.setAnchorPoint(.5, .5);
        node.setPosition(x, y);
        parent.addChild(node);
        this.drawRect(node, width, height, color, radius, opacity);
        return node;
      };
      UIManager.prototype.createCircle = function(parent, name, radius, color, x, y) {
        void 0 === x && (x = 0);
        void 0 === y && (y = 0);
        var node = new cc.Node(name);
        node.width = 2 * radius;
        node.height = 2 * radius;
        node.setAnchorPoint(.5, .5);
        node.setPosition(x, y);
        parent.addChild(node);
        var graphics = node.addComponent(cc.Graphics);
        graphics.fillColor = color;
        graphics.circle(0, 0, radius);
        graphics.fill();
        return node;
      };
      UIManager.prototype.fitSpriteFrameInside = function(node, frame, maxWidth, maxHeight) {
        if (!node || !frame) return;
        var rect = frame.getRect();
        var sourceWidth = Math.max(1, rect.width);
        var sourceHeight = Math.max(1, rect.height);
        var scale = Math.min(maxWidth / sourceWidth, maxHeight / sourceHeight);
        node.setContentSize(sourceWidth * scale, sourceHeight * scale);
      };
      UIManager.prototype.createLabel = function(parent, text, x, y, fontSize, color, width, height) {
        void 0 === width && (width = 300);
        void 0 === height && (height = 54);
        if (fontSize <= 30) {
          fontSize = Math.max(24, Math.round(1.22 * fontSize));
          height = Math.max(fontSize + 8, Math.round(1.22 * height));
        }
        var node = new cc.Node("label");
        node.width = width;
        node.height = height;
        var buttonAncestor = parent;
        while (buttonAncestor && !buttonAncestor.getComponent(cc.Button)) buttonAncestor = buttonAncestor.parent;
        node.color = buttonAncestor ? exports.BUTTON_TEXT_COLOR : color;
        node.zIndex = 50;
        node.setAnchorPoint(.5, .5);
        node.setPosition(x, y);
        parent.addChild(node);
        var label = node.addComponent(cc.Label);
        label.string = text;
        label.fontSize = fontSize;
        label.lineHeight = Math.max(fontSize + 8, Math.min(height, 1.3 * fontSize));
        label.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        label.verticalAlign = cc.Label.VerticalAlign.CENTER;
        label.overflow = cc.Label.Overflow.SHRINK;
        label.enableWrapText = true;
        label.fontFamily = "PingFang SC";
        label.cacheMode = cc.Label.CacheMode.CHAR;
        label.isSystemFontUsed = true;
        this.applyTypography(label, !!buttonAncestor || fontSize >= 30 || /^[\d\s.,%+\-/]+$/.test(text));
        node.width = width;
        node.height = height;
        label._forceUpdateRenderData();
        return label;
      };
      UIManager.prototype.createButton = function(parent, text, x, y, width, height, color, onClick, fontSize) {
        void 0 === fontSize && (fontSize = 24);
        var button = this.createRect(parent, "button_" + text, width, height, color, 255, 16, x, y);
        button.addComponent(cc.Button);
        this.drawButtonSurface(button, width, height, color, Math.min(20, .26 * height));
        var label = this.createLabel(button, text, 0, 2, fontSize, exports.BUTTON_TEXT_COLOR, width - 24, height - 10);
        this.applyTypography(label, true);
        label.enableWrapText = false;
        button.on(cc.Node.EventType.TOUCH_START, function() {
          if (!button.getComponent(cc.Button).interactable) return;
          cc.tween(button).stop();
          cc.tween(button).to(.07, {
            scale: .95
          }).start();
        });
        button.on(cc.Node.EventType.TOUCH_END, function() {
          if (!button.getComponent(cc.Button).interactable) return;
          cc.tween(button).stop();
          cc.tween(button).to(.1, {
            scale: 1
          }).start();
          onClick();
        });
        button.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.tween(button).stop();
          cc.tween(button).to(.1, {
            scale: 1
          }).start();
        });
        return button;
      };
      UIManager.prototype.drawButtonSurface = function(node, width, height, color, radius) {
        void 0 === radius && (radius = 16);
        var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
        var dark = new cc.Color(Math.round(.66 * color.r), Math.round(.66 * color.g), Math.round(.66 * color.b));
        graphics.clear();
        graphics.fillColor = new cc.Color(64, 42, 36, 38);
        graphics.roundRect(-width / 2 + 2, -height / 2 - 5, width - 4, height, radius);
        graphics.fill();
        graphics.fillColor = dark;
        graphics.roundRect(-width / 2, -height / 2 - 1, width, height, radius);
        graphics.fill();
        graphics.fillColor = color;
        graphics.strokeColor = new cc.Color(dark.r, dark.g, dark.b, 225);
        graphics.lineWidth = 2.4;
        graphics.roundRect(-width / 2, -height / 2 + 5, width, height - 7, radius);
        graphics.fill();
        graphics.stroke();
        graphics.fillColor = new cc.Color(255, 255, 255, 26);
        graphics.roundRect(-width / 2 + 5, -height / 2 + 13, width - 10, height - 22, Math.max(7, radius - 5));
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 255, 255, 178);
        graphics.ellipse(-width / 2 + 20, height / 2 - 15, 9, 5);
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 255, 255, 88);
        graphics.ellipse(-width / 2 + 31, height / 2 - 17, 5, 2.6);
        graphics.fill();
      };
      UIManager.prototype.showToast = function(message) {
        if (!this.scene) return;
        this.toast && this.toast.isValid && this.toast.destroy();
        var toast = this.createRect(this.scene, "toast", 430, 70, new cc.Color(90, 64, 58), 238, 18, 0, 365);
        toast.zIndex = 3e3;
        this.createLabel(toast, message, 0, 0, 24, cc.Color.WHITE, 390, 52);
        this.toast = toast;
        toast.opacity = 0;
        toast.y -= 16;
        cc.tween(toast).to(.18, {
          opacity: 255,
          y: toast.y + 16
        }).delay(1.1).to(.18, {
          opacity: 0,
          y: toast.y + 28
        }).call(function() {
          return toast.destroy();
        }).start();
      };
      UIManager.prototype.showWeChatAuthorizationSheet = function() {
        if (!this.scene || !this.scene.isValid) return function() {
          return;
        };
        var root = new cc.Node("wechatAuthorizationSheet");
        root.width = this.scene.width;
        root.height = this.scene.height;
        root.zIndex = 2200;
        root.addComponent(cc.BlockInputEvents);
        this.scene.addChild(root);
        var mask = this.createRect(root, "mask", root.width, root.height, new cc.Color(35, 35, 35), 150);
        mask.addComponent(cc.BlockInputEvents);
        var safeArea = this.getSafeAreaMetrics();
        var panelBottom = -root.height / 2 + 24 + safeArea.bottom;
        var canvas = this.scene.getComponent(cc.Canvas) ? this.scene : this.scene.parent;
        if (canvas) {
          var bottomLeft = root.convertToNodeSpaceAR(canvas.convertToWorldSpaceAR(cc.v2(-cc.winSize.width / 2, -cc.winSize.height / 2)));
          var topRight = root.convertToNodeSpaceAR(canvas.convertToWorldSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2)));
          mask.setPosition((bottomLeft.x + topRight.x) / 2, (bottomLeft.y + topRight.y) / 2);
          mask.setContentSize(Math.abs(topRight.x - bottomLeft.x), Math.abs(topRight.y - bottomLeft.y));
          this.drawRect(mask, mask.width, mask.height, new cc.Color(35, 35, 35), 0, 150);
          panelBottom = bottomLeft.y + 24 + safeArea.bottom;
        }
        var panelHeight = 290;
        var panelY = panelBottom + panelHeight / 2;
        var panelWidth = Math.min(640, Math.max(320, root.width - 40));
        var panel = this.createRect(root, "authorizationPanel", panelWidth, panelHeight, new cc.Color(255, 252, 244), 255, 28, 0, panelY);
        this.createRect(panel, "sheetHandle", 64, 6, new cc.Color(215, 211, 204), 255, 3, 0, 121);
        var title = this.createLabel(panel, "\u5fae\u4fe1\u6388\u6743", 0, 72, 30, new cc.Color(45, 42, 39), 440, 42);
        this.applyTypography(title, true);
        this.createLabel(panel, "\u4f7f\u7528\u4f60\u7684\u5fae\u4fe1\u6635\u79f0\u548c\u5934\u50cf\n\u7528\u4e8e\u6e38\u620f\u8d44\u6599\u4e0e\u6392\u884c\u699c\u5c55\u793a", 0, 16, 22, new cc.Color(112, 105, 98), panelWidth - 80, 66);
        this.createButton(panel, "\u5fae\u4fe1\u4e00\u952e\u6388\u6743", 0, -82, Math.min(480, panelWidth - 80), 74, exports.BUTTON_COLORS.green, function() {
          return;
        }, 26);
        mask.opacity = 0;
        panel.y = panelY - 46;
        panel.opacity = 0;
        cc.tween(mask).to(.14, {
          opacity: 150
        }).start();
        cc.tween(panel).to(.18, {
          y: panelY,
          opacity: 255
        }, {
          easing: "quadOut"
        }).start();
        var closed = false;
        return function() {
          if (closed) return;
          closed = true;
          if (!cc.isValid(root)) return;
          cc.Tween.stopAllByTarget(panel);
          cc.Tween.stopAllByTarget(mask);
          cc.tween(panel).to(.14, {
            y: panelY - 32,
            opacity: 0
          }, {
            easing: "quadIn"
          }).start();
          cc.tween(mask).to(.14, {
            opacity: 0
          }).start();
          cc.tween(root).delay(.14).call(function() {
            cc.isValid(root) && root.destroy();
          }).start();
        };
      };
      UIManager.prototype.showModal = function(title, message, actions, decoration, contentHeight, horizontalActions, dismissible, panelWidth, dismissOptions) {
        var _this = this;
        void 0 === decoration && (decoration = null);
        void 0 === contentHeight && (contentHeight = 0);
        void 0 === horizontalActions && (horizontalActions = false);
        void 0 === dismissible && (dismissible = false);
        void 0 === panelWidth && (panelWidth = 560);
        void 0 === dismissOptions && (dismissOptions = {});
        if (!this.scene) return null;
        if (this.toast && this.toast.isValid) {
          cc.Tween.stopAllByTarget(this.toast);
          this.toast.destroy();
          this.toast = null;
        }
        this.closeModal();
        var root = new cc.Node("modal");
        root.width = this.scene.width;
        root.height = this.scene.height;
        root.setAnchorPoint(.5, .5);
        root.zIndex = 2e3;
        root.addComponent(cc.BlockInputEvents);
        this.scene.addChild(root);
        this.modal = root;
        var mask = this.createRect(root, "mask", root.width, root.height, new cc.Color(65, 46, 40), 190);
        mask.addComponent(cc.BlockInputEvents);
        this.refreshModalLayout();
        mask.opacity = 0;
        cc.tween(mask).to(.14, {
          opacity: 190
        }).start();
        var actionRows = 0 === actions.length ? 0 : horizontalActions ? 1 : actions.length;
        var panelHeight = 300 + 92 * actionRows + contentHeight;
        var panel = this.createRect(root, "panel", panelWidth, panelHeight, new cc.Color(211, 164, 98), 255, 26, 0, 0);
        if (dismissible) {
          var dismiss_1 = function() {
            if (_this.modal !== root) return;
            _this.closeModal();
            dismissOptions.onDismiss && dismissOptions.onDismiss();
          };
          mask.on(cc.Node.EventType.TOUCH_END, dismiss_1, this);
          panel.addComponent(cc.BlockInputEvents);
          this.createModalCloseButton(panel, panelHeight, dismiss_1);
          dismissOptions.closeOnBlank && panel.on(cc.Node.EventType.TOUCH_END, function(event) {
            event.target === panel && dismiss_1();
          }, this);
        }
        this.createRect(panel, "panelInner", panelWidth - 20, panelHeight - 20, new cc.Color(255, 244, 220), 255, 22);
        this.createModalTitlePlate(panel, title, panelHeight);
        this.createLabel(panel, message, 0, panelHeight / 2 - 150, 24, new cc.Color(124, 92, 76), panelWidth - 90, 82);
        var startY = panelHeight / 2 - 245;
        if (decoration && contentHeight > 0) {
          var contentCenterY = panelHeight / 2 - 235 - contentHeight / 2;
          decoration(panel, contentCenterY);
          startY = contentCenterY - contentHeight / 2 - 70;
        }
        if (horizontalActions && actions.length > 0) {
          var buttonWidth_1 = 2 === actions.length ? 214 : Math.min(420, Math.floor(480 / actions.length) - 12);
          var gap_1 = 18;
          var totalWidth = actions.length * buttonWidth_1 + (actions.length - 1) * gap_1;
          var left_1 = -totalWidth / 2 + buttonWidth_1 / 2;
          actions.forEach(function(action, index) {
            var button = null;
            button = _this.createButton(panel, action.text, left_1 + index * (buttonWidth_1 + gap_1), startY, buttonWidth_1, 72, action.color, function() {
              cc.Tween.stopAllByTarget(button);
              false !== action.closeOnClick && _this.closeModal();
              action.onClick();
            }, 24);
            action.icon && action.icon(button);
          });
        } else actions.forEach(function(action, index) {
          var button = null;
          button = _this.createButton(panel, action.text, 0, startY - 92 * index, 420, 72, action.color, function() {
            cc.Tween.stopAllByTarget(button);
            false !== action.closeOnClick && _this.closeModal();
            action.onClick();
          }, 24);
          action.icon && action.icon(button);
        });
        panel.scale = .82;
        panel.opacity = 0;
        cc.tween(panel).to(.18, {
          scale: 1,
          opacity: 255
        }, {
          easing: "backOut"
        }).start();
        return root;
      };
      UIManager.prototype.createModalCloseButton = function(panel, panelHeight, onClose) {
        var button = this.createRect(panel, "modalCloseButton", 56, 56, new cc.Color(255, 232, 176), 255, 17, panel.width / 2 - 25, panelHeight / 2 - 25);
        button.zIndex = 80;
        button.width = 72;
        button.height = 72;
        var graphics = button.getComponent(cc.Graphics);
        graphics.clear();
        graphics.fillColor = new cc.Color(88, 61, 55, 48);
        graphics.roundRect(-28, -30, 56, 56, 17);
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 232, 176);
        graphics.strokeColor = new cc.Color(137, 98, 76);
        graphics.lineWidth = 3;
        graphics.roundRect(-28, -28, 56, 56, 17);
        graphics.fill();
        graphics.stroke();
        graphics.strokeColor = new cc.Color(88, 61, 55);
        graphics.lineWidth = 4.5;
        graphics.lineCap = cc.Graphics.LineCap.ROUND;
        graphics.moveTo(-10, -10);
        graphics.lineTo(10, 10);
        graphics.moveTo(10, -10);
        graphics.lineTo(-10, 10);
        graphics.stroke();
        button.addComponent(cc.Button);
        button.on(cc.Node.EventType.TOUCH_START, function() {
          cc.Tween.stopAllByTarget(button);
          cc.tween(button).to(.06, {
            scale: .9
          }).start();
        }, this);
        button.on(cc.Node.EventType.TOUCH_END, function() {
          cc.Tween.stopAllByTarget(button);
          onClose();
        }, this);
        button.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.Tween.stopAllByTarget(button);
          cc.tween(button).to(.1, {
            scale: 1
          }).start();
        }, this);
      };
      UIManager.prototype.createModalTitlePlate = function(panel, title, panelHeight) {
        var plateWidth = Math.max(220, Math.min(500, 96 + 44 * title.length));
        var plateHeight = 76;
        var plateY = panelHeight / 2 - 4;
        var shadow = this.createRect(panel, "modalTitleShadow", plateWidth + 6, plateHeight + 4, new cc.Color(88, 61, 55), 118, 24, 0, plateY - 6);
        shadow.zIndex = 18;
        var plate = this.createRect(panel, "modalTitlePlate", plateWidth, plateHeight, new cc.Color(220, 155, 70), 255, 23, 0, plateY);
        plate.zIndex = 20;
        var inner = this.createRect(plate, "modalTitlePlateInner", plateWidth - 12, plateHeight - 12, new cc.Color(245, 199, 102), 255, 19, 0, 2);
        this.createCircle(plate, "modalTitleRivetLeft", 3.2, new cc.Color(255, 244, 220), -plateWidth / 2 + 22, 2);
        this.createCircle(plate, "modalTitleRivetRight", 3.2, new cc.Color(255, 244, 220), plateWidth / 2 - 22, 2);
        this.createLabel(inner, title, 0, 0, 36, new cc.Color(90, 64, 58), plateWidth - 54, 52);
      };
      UIManager.prototype.closeModal = function() {
        var root = this.modal;
        this.modal = null;
        if (!root || !root.isValid) return;
        var panel = root.getChildByName("panel");
        var mask = root.getChildByName("mask");
        if (!panel) {
          root.destroy();
          return;
        }
        root.zIndex = 1999;
        cc.Tween.stopAllByTarget(panel);
        cc.tween(panel).to(.14, {
          scale: .86,
          opacity: 0
        }, {
          easing: "quadIn"
        }).start();
        if (mask) {
          cc.Tween.stopAllByTarget(mask);
          cc.tween(mask).to(.14, {
            opacity: 0
          }).start();
        }
        cc.tween(root).delay(.14).call(function() {
          cc.isValid(root) && root.destroy();
        }).start();
      };
      UIManager.prototype.refreshModalLayout = function() {
        if (!this.modal || !this.modal.isValid || !this.scene) return;
        var mask = this.modal.getChildByName("mask");
        if (!mask) return;
        var canvas = this.scene.getComponent(cc.Canvas) ? this.scene : this.scene.parent;
        if (!canvas) return;
        var bottomLeft = this.modal.convertToNodeSpaceAR(canvas.convertToWorldSpaceAR(cc.v2(-cc.winSize.width / 2, -cc.winSize.height / 2)));
        var topRight = this.modal.convertToNodeSpaceAR(canvas.convertToWorldSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2)));
        mask.setPosition((bottomLeft.x + topRight.x) / 2, (bottomLeft.y + topRight.y) / 2);
        mask.setContentSize(Math.abs(topRight.x - bottomLeft.x), Math.abs(topRight.y - bottomLeft.y));
        this.drawRect(mask, mask.width, mask.height, new cc.Color(65, 46, 40), 0, 190);
      };
      UIManager.prototype.drawRect = function(node, width, height, color, radius, opacity) {
        void 0 === radius && (radius = 0);
        void 0 === opacity && (opacity = 255);
        var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
        graphics.clear();
        graphics.fillColor = new cc.Color(color.r, color.g, color.b, opacity);
        radius > 0 ? graphics.roundRect(-width / 2, -height / 2, width, height, radius) : graphics.rect(-width / 2, -height / 2, width, height);
        graphics.fill();
      };
      return UIManager;
    }();
    exports.default = UIManager;
    exports.uimanager = UIManager.instance;
    cc._RF.pop();
  }, {
    "./AssetLoader": "AssetLoader",
    "./GameSettings": "GameSettings",
    "./PlatformAdapter": "PlatformAdapter"
  } ],
  WeChatFriends: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "3563aiR2FZOqIWf0+3q9Dtd", "WeChatFriends");
    "use strict";
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.postFriendMessage = exports.syncConfirmedFriendScore = exports.friendScoreKey = exports.FRIEND_SCOPE = void 0;
    var PlatformAdapter_1 = require("./PlatformAdapter");
    exports.FRIEND_SCOPE = "scope.WxFriendInteraction";
    function friendScoreKey() {
      var wxApi = PlatformAdapter_1.getWxApi();
      try {
        var env = wxApi.getAccountInfoSync().miniProgram.envVersion;
        return "release" === env ? "zyx_best_score_v1" : "zyx_best_score_staging_v1";
      } catch (_) {
        return "zyx_best_score_staging_v1";
      }
    }
    exports.friendScoreKey = friendScoreKey;
    var writes = {};
    function syncConfirmedFriendScore(playerId, score, onSynced) {
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!playerId || !Number.isSafeInteger(score) || score < 0 || !wxApi || "function" !== typeof wxApi.setUserCloudStorage) return;
      var key = friendScoreKey();
      var identity = key + ":" + playerId;
      var state = writes[identity] || (writes[identity] = {
        desired: score,
        acknowledged: -1,
        writing: false
      });
      state.desired = Math.max(state.desired, score);
      if (state.writing || state.acknowledged >= state.desired) return;
      var write = function() {
        var value = state.desired;
        state.writing = true;
        var failed = function() {
          state.writing = false;
        };
        try {
          wxApi.setUserCloudStorage({
            KVDataList: [ {
              key: key,
              value: String(value)
            }, {
              key: key + "_owner",
              value: playerId
            } ],
            success: function() {
              state.acknowledged = value;
              state.writing = false;
              state.desired > value ? write() : onSynced && onSynced();
            },
            fail: failed
          });
        } catch (_) {
          failed();
        }
      };
      write();
    }
    exports.syncConfirmedFriendScore = syncConfirmedFriendScore;
    function postFriendMessage(type, extra) {
      void 0 === extra && (extra = {});
      var wxApi = PlatformAdapter_1.getWxApi();
      if (!wxApi || "function" !== typeof wxApi.getOpenDataContext) return false;
      try {
        wxApi.getOpenDataContext().postMessage(__assign({
          type: type,
          key: friendScoreKey()
        }, extra));
        return true;
      } catch (_) {
        return false;
      }
    }
    exports.postFriendMessage = postFriendMessage;
    cc._RF.pop();
  }, {
    "./PlatformAdapter": "PlatformAdapter"
  } ],
  ZyxGameModule: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "13772iquZdC5IRf5xG8UarI", "ZyxGameModule");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
      void 0 === k2 && (k2 = k);
      Object.defineProperty(o, k2, {
        enumerable: true,
        get: function() {
          return m[k];
        }
      });
    } : function(o, m, k, k2) {
      void 0 === k2 && (k2 = k);
      o[k2] = m[k];
    });
    var __exportStar = this && this.__exportStar || function(m, exports) {
      for (var p in m) "default" === p || Object.prototype.hasOwnProperty.call(exports, p) || __createBinding(exports, m, p);
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.zyxGameModule = exports.ensureDataGeneration = exports.CELL_SIZE = exports.BoardEngine = void 0;
    var MoodBeanConfig_1 = require("./MoodBeanConfig");
    var BoardEngine_1 = require("./BoardEngine");
    var RoundReplay_1 = require("./RoundReplay");
    __exportStar(require("./BoardEngine"), exports);
    var BoardEngine_2 = require("./BoardEngine");
    Object.defineProperty(exports, "BoardEngine", {
      enumerable: true,
      get: function() {
        return BoardEngine_2.default;
      }
    });
    exports.CELL_SIZE = 76;
    var TUTORIAL_CHALLENGE_COUNT_KEY = "zyx_tutorial_challenge_count";
    var KNOWN_STORAGE_KEYS = [ MoodBeanConfig_1.DATA_GENERATION_KEY, MoodBeanConfig_1.MOOD_BEAN_BALANCE_KEY, MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_KEY, MoodBeanConfig_1.DEAD_ROUND_SETTLEMENTS_KEY, "zyx_official_art_progress_cache", "zyx_pending_realm_action", TUTORIAL_CHALLENGE_COUNT_KEY, "zyx_level", "zyx_experience", "zyx_best_score", "zyx_hammer_inventory", "zyx_magic_wand_inventory", "zyx_revive_card_inventory", "zyx_cloud_token", "zyx_cloud_device_id", "zyx_pending_start_round_id", "zyx_pending_stamina_share_id", "zyx_pending_tool_exchange", "zyx_tool_reward_hammer", "zyx_tool_reward_magicWand", "zyx_wechat_profile", "zyx_game_settings_v1", "zyx_gm_bubble_pos_v1", "zyx_happy_bottle_count", "zyx_current_happy_bottle_progress", "zyx_unlocked_albums", "zyx_unlocked_album_arts", "zyx_pending_realm_unlocks", "zyx_daily_moods", "zyx_daily_wish" ];
    function ensureDataGeneration() {
      var storage = cc.sys.localStorage;
      if (storage.getItem(MoodBeanConfig_1.DATA_GENERATION_KEY) === MoodBeanConfig_1.DATA_GENERATION) return false;
      var apiBaseOverride = storage.getItem("zyx_api_base_override");
      var enumerable = storage;
      if ("number" === typeof enumerable.length && "function" === typeof enumerable.key) {
        var keys = [];
        for (var index = 0; index < enumerable.length; index++) {
          var key = enumerable.key(index);
          key && 0 === key.indexOf("zyx_") && keys.push(key);
        }
        keys.forEach(function(key) {
          return storage.removeItem(key);
        });
      } else KNOWN_STORAGE_KEYS.forEach(function(key) {
        return storage.removeItem(key);
      });
      storage.setItem(MoodBeanConfig_1.DATA_GENERATION_KEY, MoodBeanConfig_1.DATA_GENERATION);
      apiBaseOverride && storage.setItem("zyx_api_base_override", apiBaseOverride);
      return true;
    }
    exports.ensureDataGeneration = ensureDataGeneration;
    var ZyxGameModule = function(_super) {
      __extends(ZyxGameModule, _super);
      function ZyxGameModule() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.moodBeanBalance = 0;
        _this.reviveCardCount = 0;
        _this.level = 1;
        _this.experience = 0;
        _this.challengeCount = 0;
        _this.startingBestScore = 0;
        _this.roundStartedAt = 0;
        _this.roundSettled = false;
        _this.seedOverride = 0;
        _this.pendingServerSeed = 0;
        _this.pendingServerTutorial = null;
        _this.loggedInGameCount = 0;
        _this.sessionStartedRounds = 0;
        _this.hasGameCountBaseline = false;
        _this.cloudPlayerId = "";
        _this.assetRevision = -1;
        _this.cloudRoundId = "";
        _this.roundToolClaims = {
          hammer: 0,
          magicWand: 0
        };
        _this.pendingHeartEligible = false;
        _this.registeredAt = "";
        return _this;
      }
      ZyxGameModule.prototype.getPlayerId = function() {
        return this.cloudPlayerId;
      };
      ZyxGameModule.prototype.applyRoundTools = function(tools) {
        if (this.rulesVersion < 12 || !tools) return;
        this.roundToolClaims = {
          hammer: tools.hammer.acquired,
          magicWand: tools.magicWand.acquired
        };
        this.hammerCount = tools.hammer.owned;
        this.colorPurifierCount = tools.magicWand.owned;
      };
      ZyxGameModule.prototype.restoreRound = function(saved) {
        var board = RoundReplay_1.rebuildRound(saved.seed, saved.isTutorial, saved.actions, saved.rulesVersion, saved.heartRescueEligible);
        for (var _i = 0, _a = Object.keys(board); _i < _a.length; _i++) {
          var key = _a[_i];
          if ([ "hammerCount", "colorPurifierCount", "bestScore" ].includes(key)) continue;
          this[key] = board[key];
        }
        this.roundSettled = false;
        this.roundStartedAt = Date.now() - saved.elapsedMs;
        this.startingBestScore = this.bestScore;
        this.challengeCount = Math.max(1, this.loggedInGameCount + 1);
        this.cloudRoundId = saved.roundId;
        this.pendingServerSeed = 0;
        this.pendingServerTutorial = null;
        this.pendingHeartEligible = false;
        this.takeLightningEffects();
        this.applyRoundTools(saved.roundTools);
        this.dismissRoundRescue();
        this.dismissBalloonRescue();
        this.dismissHeartRescue();
      };
      ZyxGameModule.prototype.resetRound = function() {
        this.roundToolClaims = {
          hammer: 0,
          magicWand: 0
        };
        this.hammerCount = Math.max(0, this.readNumber("zyx_hammer_inventory", 0));
        this.colorPurifierCount = Math.max(0, this.readNumber("zyx_magic_wand_inventory", 0));
        this.reviveCardCount = Math.max(0, this.readNumber("zyx_revive_card_inventory", 0));
        this.roundSettled = false;
        this.roundStartedAt = Date.now();
        this.bestScore = this.readNumber("zyx_best_score", 0);
        this.startingBestScore = this.bestScore;
        this.roundSeed = this.pendingServerSeed || this.seedOverride || this.createRandomSeed();
        this.pendingServerSeed = 0;
        this.randomState = this.roundSeed;
        this.generationDebugLog = [];
        this.sessionStartedRounds++;
        var persistedChallengeCount = Math.max(0, Math.floor(this.readNumber(TUTORIAL_CHALLENGE_COUNT_KEY, 0)));
        this.challengeCount = Math.max(persistedChallengeCount + 1, this.loggedInGameCount + this.sessionStartedRounds);
        cc.sys.localStorage.setItem(TUTORIAL_CHALLENGE_COUNT_KEY, String(this.challengeCount));
        this.currentRoundIsTutorial = null === this.pendingServerTutorial ? this.challengeCount > 0 && this.challengeCount <= 2 : this.pendingServerTutorial;
        this.pendingServerTutorial = null;
        this.syncPersistentProgress();
        cc.log("[\u68cb\u76d8\u8c03\u8bd5] \u672c\u5c40\u968f\u673a\u79cd\u5b50 " + this.roundSeed);
        this.resetBoard(this.roundSeed, this.currentRoundIsTutorial, void 0, this.pendingHeartEligible);
        this.pendingHeartEligible = false;
      };
      ZyxGameModule.prototype.shouldEnterGameOnLaunch = function() {
        return !this.hasGameCountBaseline || 0 === this.loggedInGameCount;
      };
      ZyxGameModule.prototype.setRoundSeedOverride = function(seed) {
        var normalized = Math.floor(Number(seed)) >>> 0;
        this.seedOverride = normalized || 0;
      };
      ZyxGameModule.prototype.setRoundSeed = function(seed, isTutorial, heartEligible) {
        void 0 === heartEligible && (heartEligible = false);
        this.pendingHeartEligible = heartEligible;
        this.pendingServerSeed = seed >>> 0 || 1;
        "boolean" === typeof isTutorial && (this.pendingServerTutorial = isTutorial);
        this.roundSeed = this.pendingServerSeed;
        this.randomState = this.roundSeed;
      };
      ZyxGameModule.prototype.refreshPersistentProgress = function() {
        this.syncPersistentProgress();
        this.bestScore = Math.max(this.bestScore, this.readNumber("zyx_best_score", 0));
      };
      ZyxGameModule.prototype.finishRound = function() {
        var displayBalanceBefore = this.getDisplayMoodBeanBalance();
        var displayLevelBefore = this.getDisplayLevelAndExperience();
        if (this.roundSettled) return {
          roundScore: this.score,
          roundCollectedMoodBeans: 0,
          roundBonusMoodBeans: 0,
          roundEarnedMoodBeans: 0,
          gainedExperience: 0,
          levelUps: 0,
          moodBeanBalanceBefore: displayBalanceBefore,
          moodBeanBalanceAfter: displayBalanceBefore,
          levelBefore: displayLevelBefore.level,
          experienceBefore: displayLevelBefore.experience,
          experienceTargetBefore: displayLevelBefore.target,
          levelAfter: displayLevelBefore.level,
          experienceAfter: displayLevelBefore.experience,
          experienceTargetAfter: displayLevelBefore.target
        };
        this.roundSettled = true;
        this.score > this.bestScore && (this.bestScore = this.score);
        cc.sys.localStorage.setItem("zyx_best_score", String(this.bestScore));
        var roundCollectedMoodBeans = this.roundCollectedMoodBeans;
        var roundBonusMoodBeans = 0;
        var roundEarnedMoodBeans = MoodBeanConfig_1.getMoodCollection(roundCollectedMoodBeans).beans + roundBonusMoodBeans;
        var gainedExperience = roundCollectedMoodBeans;
        var levelAfter = displayLevelBefore.level;
        var experienceAfter = displayLevelBefore.experience + gainedExperience;
        var experienceTargetAfter = displayLevelBefore.target;
        while (experienceAfter >= experienceTargetAfter) {
          experienceAfter -= experienceTargetAfter;
          levelAfter++;
          experienceTargetAfter = this.getExperienceTargetForLevel(levelAfter);
        }
        return {
          roundScore: this.score,
          roundCollectedMoodBeans: roundCollectedMoodBeans,
          roundBonusMoodBeans: roundBonusMoodBeans,
          roundEarnedMoodBeans: roundEarnedMoodBeans,
          gainedExperience: gainedExperience,
          levelUps: levelAfter - displayLevelBefore.level,
          moodBeanBalanceBefore: displayBalanceBefore,
          moodBeanBalanceAfter: displayBalanceBefore,
          levelBefore: displayLevelBefore.level,
          experienceBefore: displayLevelBefore.experience,
          experienceTargetBefore: displayLevelBefore.target,
          levelAfter: levelAfter,
          experienceAfter: experienceAfter,
          experienceTargetAfter: experienceTargetAfter
        };
      };
      ZyxGameModule.prototype.applyCloudProfile = function(profile) {
        if (profile.playerId && profile.playerId !== this.cloudPlayerId) {
          this.cloudPlayerId = profile.playerId;
          this.assetRevision = -1;
        }
        if ("number" === typeof profile.assetRevision) {
          if (profile.assetRevision < this.assetRevision) return false;
          this.assetRevision = profile.assetRevision;
        } else if (this.assetRevision >= 0) return false;
        if (profile.inventory) {
          if (this.rulesVersion < 12) {
            this.hammerCount = Math.max(0, Math.floor(profile.inventory.hammer || 0));
            this.colorPurifierCount = Math.max(0, Math.floor(profile.inventory.magicWand || 0));
          }
          this.reviveCardCount = Math.max(0, Math.floor(profile.inventory.reviveCard || 0));
          this.saveToolInventory();
        }
        profile.registeredAt && (this.registeredAt = profile.registeredAt);
        this.level = Math.max(1, profile.level || 1);
        this.experience = Math.max(0, profile.experience || 0);
        this.moodBeanBalance = Math.max(0, Math.floor(profile.moodBeanBalance || 0));
        this.bestScore = Math.max(0, Math.floor(profile.highestSingleGameScore || 0));
        if (!this.hasGameCountBaseline) {
          this.loggedInGameCount = Math.max(0, Math.floor(profile.gameCount || 0));
          this.hasGameCountBaseline = true;
          var persistedChallengeCount = Math.max(0, Math.floor(this.readNumber(TUTORIAL_CHALLENGE_COUNT_KEY, 0)));
          this.challengeCount = Math.max(this.challengeCount, persistedChallengeCount, this.loggedInGameCount + this.sessionStartedRounds);
        }
        this.savePersistentProgress();
        cc.sys.localStorage.setItem("zyx_best_score", String(this.bestScore));
        return true;
      };
      ZyxGameModule.prototype.getDisplayMoodBeanBalance = function() {
        return Math.max(0, Math.floor(this.moodBeanBalance));
      };
      ZyxGameModule.prototype.getDisplayLevelAndExperience = function() {
        return {
          level: this.level,
          experience: this.experience,
          target: this.getExperienceTargetForLevel(this.level)
        };
      };
      ZyxGameModule.prototype.getExperienceTarget = function() {
        return this.getExperienceTargetForLevel(this.level);
      };
      ZyxGameModule.prototype.getExperienceTargetForLevel = function(level) {
        return Math.max(15, Math.ceil(15 * Math.pow(1.32, Math.max(1, level) - 1)));
      };
      ZyxGameModule.prototype.grantDebugInventory = function(moodBeans, hammers, magicWands) {
        var beanReward = Math.max(0, Math.floor(moodBeans));
        var hammerReward = Math.max(0, Math.floor(hammers));
        var wandReward = Math.max(0, Math.floor(magicWands));
        this.syncPersistentProgress();
        this.hammerCount = Math.max(0, this.readNumber("zyx_hammer_inventory", this.hammerCount));
        this.colorPurifierCount = Math.max(0, this.readNumber("zyx_magic_wand_inventory", this.colorPurifierCount));
        this.moodBeanBalance += beanReward;
        this.hammerCount += hammerReward;
        this.colorPurifierCount += wandReward;
        this.savePersistentProgress();
        this.saveToolInventory();
      };
      ZyxGameModule.prototype.resetLocalAccount = function() {
        this.level = 1;
        this.experience = 0;
        this.moodBeanBalance = 0;
        this.hammerCount = 0;
        this.colorPurifierCount = 0;
        this.reviveCardCount = 0;
        this.bestScore = 0;
        this.challengeCount = 0;
        this.loggedInGameCount = 0;
        this.sessionStartedRounds = 0;
        this.hasGameCountBaseline = false;
        cc.sys.localStorage.setItem(TUTORIAL_CHALLENGE_COUNT_KEY, "0");
        this.savePersistentProgress();
        this.saveToolInventory();
        cc.sys.localStorage.setItem("zyx_best_score", "0");
        cc.sys.localStorage.setItem(MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_KEY, "[]");
        cc.sys.localStorage.removeItem(MoodBeanConfig_1.DEAD_ROUND_SETTLEMENTS_KEY);
        cc.sys.localStorage.removeItem("zyx_first_round_bomb_guides_" + this.cloudPlayerId);
      };
      ZyxGameModule.prototype.getPendingRoundSettlements = function() {
        var raw = cc.sys.localStorage.getItem(MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_KEY);
        if (!raw) return [];
        try {
          var value = JSON.parse(raw);
          if (!Array.isArray(value)) return [];
          return value.filter(function(item) {
            return item && "string" === typeof item.roundId && item.roundId.length > 0;
          });
        } catch (error) {
          return [];
        }
      };
      ZyxGameModule.prototype.enqueuePendingRoundSettlement = function(record) {
        var queue = this.getPendingRoundSettlements();
        if (queue.some(function(item) {
          return item.roundId === record.roundId;
        })) return;
        if (queue.length >= MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_LIMIT) {
          cc.warn("[\u5f00\u5fc3\u8c46] \u5f85\u63d0\u4ea4\u7ed3\u7b97\u961f\u5217\u5df2\u8fbe\u4e0a\u9650\uff0c\u6700\u65b0\u4e00\u5c40 " + record.roundId + " \u6682\u4e0d\u8986\u76d6\u65e7\u8bb0\u5f55");
          return;
        }
        queue.push(record);
        cc.sys.localStorage.setItem(MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_KEY, JSON.stringify(queue));
      };
      ZyxGameModule.prototype.canAcceptPendingRoundSettlement = function() {
        return this.getPendingRoundSettlements().length < MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_LIMIT;
      };
      ZyxGameModule.prototype.movePendingRoundSettlementToDeadLetter = function(roundId, reason) {
        var queue = this.getPendingRoundSettlements();
        var target = queue.find(function(item) {
          return item.roundId === roundId;
        });
        if (!target) return;
        this.removePendingRoundSettlement(roundId);
        var dead = this.getDeadRoundSettlements();
        dead.push({
          record: target,
          reason: String(reason || "\u672a\u77e5\u9519\u8bef").slice(0, 120),
          deadAt: Date.now()
        });
        while (dead.length > 20) dead.shift();
        cc.sys.localStorage.setItem(MoodBeanConfig_1.DEAD_ROUND_SETTLEMENTS_KEY, JSON.stringify(dead));
      };
      ZyxGameModule.prototype.getDeadRoundSettlements = function() {
        var raw = cc.sys.localStorage.getItem(MoodBeanConfig_1.DEAD_ROUND_SETTLEMENTS_KEY);
        if (!raw) return [];
        try {
          var value = JSON.parse(raw);
          if (!Array.isArray(value)) return [];
          return value.filter(function(item) {
            return item && item.record && "string" === typeof item.record.roundId;
          });
        } catch (error) {
          return [];
        }
      };
      ZyxGameModule.prototype.removePendingRoundSettlement = function(roundId) {
        var queue = this.getPendingRoundSettlements().filter(function(item) {
          return item.roundId !== roundId;
        });
        cc.sys.localStorage.setItem(MoodBeanConfig_1.PENDING_ROUND_SETTLEMENTS_KEY, JSON.stringify(queue));
      };
      ZyxGameModule.prototype.createRandomSeed = function() {
        var seed = (Date.now() ^ Math.floor(4294967295 * Math.random())) >>> 0;
        return seed || 1;
      };
      ZyxGameModule.prototype.syncPersistentProgress = function() {
        this.moodBeanBalance = Math.max(0, Math.floor(this.readNumber(MoodBeanConfig_1.MOOD_BEAN_BALANCE_KEY, 0)));
        this.level = Math.max(1, this.readNumber("zyx_level", 1));
        this.experience = Math.max(0, this.readNumber("zyx_experience", 0));
      };
      ZyxGameModule.prototype.savePersistentProgress = function() {
        cc.sys.localStorage.setItem(MoodBeanConfig_1.MOOD_BEAN_BALANCE_KEY, String(this.moodBeanBalance));
        cc.sys.localStorage.setItem("zyx_level", String(this.level));
        cc.sys.localStorage.setItem("zyx_experience", String(this.experience));
      };
      ZyxGameModule.prototype.saveToolInventory = function() {
        cc.sys.localStorage.setItem("zyx_hammer_inventory", String(this.hammerCount));
        cc.sys.localStorage.setItem("zyx_magic_wand_inventory", String(this.colorPurifierCount));
        cc.sys.localStorage.setItem("zyx_revive_card_inventory", String(this.reviveCardCount));
      };
      ZyxGameModule.prototype.readNumber = function(key, fallback) {
        var raw = cc.sys.localStorage.getItem(key);
        if (null === raw || void 0 === raw || "" === raw) return fallback;
        var value = Number(raw);
        return Number.isFinite(value) ? value : fallback;
      };
      return ZyxGameModule;
    }(BoardEngine_1.default);
    exports.default = ZyxGameModule;
    ensureDataGeneration();
    exports.zyxGameModule = new ZyxGameModule();
    cc._RF.pop();
  }, {
    "./BoardEngine": "BoardEngine",
    "./MoodBeanConfig": "MoodBeanConfig",
    "./RoundReplay": "RoundReplay"
  } ],
  ZyxGame: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "227d6ZY3XNCDbSywxs/Ei3N", "ZyxGame");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __assign = this && this.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = this && this.__generator || function(thisArg, body) {
      var _ = {
        label: 0,
        sent: function() {
          if (1 & t[0]) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      }, f, y, t, g;
      return g = {
        next: verb(0),
        throw: verb(1),
        return: verb(2)
      }, "function" === typeof Symbol && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([ n, v ]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = 2 & op[0] ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 
          0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          (y = 0, t) && (op = [ 2 & op[0], t.value ]);
          switch (op[0]) {
           case 0:
           case 1:
            t = op;
            break;

           case 4:
            _.label++;
            return {
              value: op[1],
              done: false
            };

           case 5:
            _.label++;
            y = op[1];
            op = [ 0 ];
            continue;

           case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;

           default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (6 === op[0] || 2 === op[0])) {
              _ = 0;
              continue;
            }
            if (3 === op[0] && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (6 === op[0] && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            t[2] && _.ops.pop();
            _.trys.pop();
            continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [ 6, e ];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (5 & op[0]) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ZyxGameModule_1 = require("../dataModule/ZyxGameModule");
    var UIManager_1 = require("../manager/UIManager");
    var RoundProgress_1 = require("../manager/RoundProgress");
    var SettingsPanel_1 = require("../manager/SettingsPanel");
    var GameSettings_1 = require("../manager/GameSettings");
    var AudioManager_1 = require("../manager/AudioManager");
    var ShareReward_1 = require("../manager/ShareReward");
    var AssetLoader_1 = require("../manager/AssetLoader");
    var ZyxGridCom_1 = require("./ZyxGridCom");
    var GlyphFactory_1 = require("./GlyphFactory");
    var MoodArt_1 = require("./MoodArt");
    var ResponsiveLayout_1 = require("../manager/ResponsiveLayout");
    var CloudService_1 = require("../manager/CloudService");
    var RankChaseView_1 = require("./RankChaseView");
    var BeanCollectionHud_1 = require("./BeanCollectionHud");
    var RewardArt_1 = require("./RewardArt");
    var GamePanel_1 = require("./GamePanel");
    var RescueBalloon_1 = require("./RescueBalloon");
    var DangerGlow_1 = require("./DangerGlow");
    var HeartEffect_1 = require("./HeartEffect");
    var HeartMessage_1 = require("./HeartMessage");
    var BombEffect_1 = require("./BombEffect");
    var GAME_PLAY_TIPS = [ "\u5de6\u53f3\u62d6\u52a8\u5fc3\u60c5\u5757\uff0c\u586b\u6ee1\u4e00\u884c\u5c31\u80fd\u6d88\u9664", "\u5e26\u8868\u60c5\u7684\u5fc3\u60c5\u5757\u6d88\u9664\u540e\uff0c\u4f1a\u53d8\u6210\u5f00\u5fc3\u8c46\u98de\u8fdb\u6536\u96c6\u4f4d", "\u89e3\u538b\u9524\u80fd\u6572\u6389\u4e00\u4e2a\u6321\u8def\u7684\u5fc3\u60c5\u5757", "\u9b54\u6cd5\u68d2\u80fd\u8ba9\u573a\u4e0a\u5168\u90e8\u540c\u8272\u8272\u5757\u4e00\u8d77\u6d88\u5931", "\u4e24\u79d2\u6ca1\u64cd\u4f5c\u65f6\uff0c\u5c0f\u624b\u4f1a\u63d0\u793a\u4e00\u6b21\u53ef\u6d88\u9664\u79fb\u52a8", "\u7559\u610f\u4e0b\u4e00\u6392\uff0c\u63d0\u524d\u4e3a\u65b0\u8272\u5757\u817e\u51fa\u4f4d\u7f6e", "\u8fde\u7eed\u64cd\u4f5c\u90fd\u6d88\u9664\u5373\u53ef\u53e0\u52a0\u8fde\u6d88\uff0c\u6700\u9ad8 5 \u500d\u5206\u6570\uff01", "\u4e09\u8fde\u53ca\u4ee5\u4e0a\uff0c\u6bcf\u6b21\u6709\u6548\u8fde\u6d88\u90fd\u989d\u5916\u5956\u52b1\u70b8\u5f39", "\u53cc\u6392\u6216\u6389\u843d\u8fde\u6d88\u53ef\u83b7\u5f97\u70b8\u5f39\uff0c\u6d88\u9664\u70b8\u5f39\u4e5f\u80fd\u5f15\u7206" ];
    var GAME_WARM_TIPS = [ "\u4f60\u4e0d\u9700\u8981\u4e00\u76f4\u575a\u5f3a\uff0c\u6162\u4e00\u70b9\u4e5f\u6ca1\u5173\u7cfb", "\u4eca\u5929\u5df2\u7ecf\u5f88\u52aa\u529b\u4e86\uff0c\u5269\u4e0b\u7684\u4ea4\u7ed9\u660e\u5929", "\u771f\u6b63\u7684\u987a\u5229\uff0c\u662f\u5fc3\u91cc\u59cb\u7ec8\u6709\u4e00\u4e2a\u65b9\u5411", "\u6709\u4eba\u60e6\u8bb0\u7684\u665a\u98ce\uff0c\u603b\u4f1a\u6bd4\u522b\u5904\u6e29\u67d4", "\u628a\u590d\u6742\u7684\u4e8b\u4e00\u4ef6\u4ef6\u653e\u597d\uff0c\u751f\u6d3b\u4f1a\u6162\u6162\u6e05\u6670" ];
    var ccclass = cc._decorator.ccclass;
    var NEXT_PREVIEW_HEIGHT = 42;
    var NEXT_PREVIEW_OPACITY = 220;
    var TOOL_BUTTON_SIZE = 88;
    var HUD_VALUE_COLOR = new cc.Color(112, 78, 65);
    var HUD_LABEL_COLOR = new cc.Color(132, 96, 80);
    var rescueShadeFrame = null;
    var ZyxGame = function(_super) {
      __extends(ZyxGame, _super);
      function ZyxGame() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.rewardFeedback = null;
        _this.layout = null;
        _this.hudRoot = null;
        _this.footerRoot = null;
        _this.boardRoot = null;
        _this.pieceLayer = null;
        _this.nextLayer = null;
        _this.nextRowLabel = null;
        _this.bombGuideKey = "";
        _this.bombGuideCount = 0;
        _this.bombGuideIds = new Set();
        _this.firstGameBombGuide = false;
        _this.scoreLabel = null;
        _this.bestLabel = null;
        _this.beanCollectionHud = null;
        _this.recordTagLabel = null;
        _this.moodStageLabel = null;
        _this.hammerButton = null;
        _this.hammerIcon = null;
        _this.hammerCountLabel = null;
        _this.purifierButton = null;
        _this.purifierIcon = null;
        _this.purifierCountLabel = null;
        _this.moodBeanHudIcon = null;
        _this.toolDragFollower = null;
        _this.toolSelectionPrompt = null;
        _this.toolWiggleNodes = [];
        _this.hintHand = null;
        _this.hintPieceId = 0;
        _this.clearSpineData = null;
        _this.resolutionLocked = true;
        _this.bombAnimationLocks = 0;
        _this.hammerMode = false;
        _this.purifierMode = false;
        _this.toolDragging = false;
        _this.toolTouchStart = null;
        _this.rewardedAdLoading = false;
        _this.pauseMenuOpen = false;
        _this.pauseStartedAt = 0;
        _this.roundRescuePrompt = null;
        _this.roundRescueCountdownState = null;
        _this.roundRescueInteractive = false;
        _this.roundRescueGuideVisible = false;
        _this.rescueBalloon = null;
        _this.balloonPhase = "none";
        _this.balloonModal = null;
        _this.balloonInputShield = null;
        _this.boardDangerHalo = null;
        _this.dangerSeconds = 0;
        _this.warmBalloonActive = false;
        _this.reviveUsed = false;
        _this.reviveCardUsed = false;
        _this.pendingReviveCardRequest = null;
        _this.onSettlementExit = null;
        _this.onRoundFinished = null;
        _this.onRestartFromPause = null;
        _this.settlementReported = false;
        _this.pieceColors = {};
        _this.displayedRoundMoods = 0;
        _this.shardPool = [];
        _this.idleSeconds = 0;
        _this.rankChase = null;
        _this.rankChaseProfile = null;
        _this.rankChaseSnapshot = null;
        _this.rankExpanded = false;
        _this.rankExpansion = {
          progress: 0
        };
        _this.tipIndex = 0;
        _this.tipSeconds = 0;
        _this.tutorialStep = -1;
        _this.tutorialGuideRoot = null;
        _this.tutorialNpc = null;
        _this.tutorialBubbleGroup = null;
        _this.tutorialBubble = null;
        _this.tutorialSpeechLabel = null;
        _this.tutorialHand = null;
        _this.tutorialSourceMarker = null;
        _this.tutorialTargetMarker = null;
        _this.tutorialDimMask = null;
        _this.tutorialFocusPieceId = 0;
        _this.tutorialTypingState = null;
        _this.tutorialRestoreCallback = null;
        _this.savedActionLength = 0;
        _this.onSaveAndExit = null;
        return _this;
      }
      Object.defineProperty(ZyxGame.prototype, "locked", {
        get: function() {
          return this.resolutionLocked || this.bombAnimationLocks > 0 || [ "dialog", "sharing", "bombing" ].indexOf(this.balloonPhase) >= 0;
        },
        set: function(value) {
          this.resolutionLocked = value;
        },
        enumerable: false,
        configurable: true
      });
      ZyxGame.prototype.resumeAfterBackground = function(hiddenMs) {
        this.pauseMenuOpen || (ZyxGameModule_1.zyxGameModule.roundStartedAt += hiddenMs);
      };
      ZyxGame.prototype.captureProgress = function(force) {
        void 0 === force && (force = false);
        if (this.settlementReported || RoundProgress_1.roundProgress.roundId !== ZyxGameModule_1.zyxGameModule.cloudRoundId) return;
        var actions = ZyxGameModule_1.zyxGameModule.roundActions;
        if (!force && actions.length === this.savedActionLength) return;
        if (!ZyxGameModule_1.zyxGameModule.canCheckpoint() || ZyxGameModule_1.zyxGameModule.isTutorialRound() && 3 === ZyxGameModule_1.zyxGameModule.moveCount && 0 === ZyxGameModule_1.zyxGameModule.turn) {
          force && void RoundProgress_1.roundProgress.sync(true);
          return;
        }
        this.savedActionLength = actions.length;
        var pausedMs = this.pauseStartedAt ? Math.max(0, Date.now() - this.pauseStartedAt) : 0;
        RoundProgress_1.roundProgress.capture(actions, ZyxGameModule_1.zyxGameModule.difficultyActionCount, Date.now() - ZyxGameModule_1.zyxGameModule.roundStartedAt - pausedMs, force);
      };
      ZyxGame.prototype.initialize = function(onSettlementExit, onRoundFinished, onRestartFromPause, profile, restored, onSaveAndExit) {
        void 0 === profile && (profile = null);
        void 0 === restored && (restored = null);
        void 0 === onSaveAndExit && (onSaveAndExit = null);
        this.onSettlementExit = onSettlementExit;
        this.onRoundFinished = onRoundFinished;
        this.onSaveAndExit = onSaveAndExit;
        this.onRestartFromPause = onRestartFromPause;
        this.rankChaseProfile = profile;
        this.firstGameBombGuide = !!profile && 0 === profile.gameCount;
        this.bombGuideKey = "zyx_first_round_bomb_guides_" + (profile ? profile.playerId : "");
        this.bombGuideCount = Math.min(5, Math.max(0, Number(cc.sys.localStorage.getItem(this.bombGuideKey)) || 0));
        this.bombGuideIds.clear();
        this.rankChaseSnapshot = CloudService_1.cloudService.getLeaderboard("power").then(function(result) {
          return result.entries.map(function(entry) {
            return __assign({}, entry);
          });
        }).catch(function() {
          return [];
        });
        this.settlementReported = false;
        this.node.setAnchorPoint(.5, .5);
        UIManager_1.uimanager.init(this.node);
        restored ? ZyxGameModule_1.zyxGameModule.restoreRound(restored) : ZyxGameModule_1.zyxGameModule.resetRound();
        this.savedActionLength = 0;
        this.tutorialStep = ZyxGameModule_1.zyxGameModule.isTutorialRound() ? Math.min(3, ZyxGameModule_1.zyxGameModule.moveCount) : -1;
        this.rankExpanded = this.tutorialStep < 0 || this.tutorialStep >= 3;
        this.rankExpansion.progress = this.rankExpanded ? 1 : 0;
        this.reviveUsed = !!restored && restored.actions.some(function(action) {
          return "revive" === action.type;
        });
        this.reviveCardUsed = !!restored && restored.actions.some(function(action) {
          return "reviveCard" === action.type;
        });
        this.displayedRoundMoods = restored ? ZyxGameModule_1.zyxGameModule.roundCollectedMoodBeans : 0;
        this.loadEffectAssets();
        this.buildUI();
        this.scheduleOnce(function() {
          AssetLoader_1.prepareFeature("effects").catch(function() {
            return;
          });
        }, .25);
        this.isTutorialGuidedStep() || this.createRankChase();
        this.renderAll();
        restored && this.beanCollectionHud.complete(ZyxGameModule_1.zyxGameModule.roundCollectedMoodBeans);
        this.locked = false;
        this.captureProgress();
        restored && ZyxGameModule_1.zyxGameModule.isGameOver() ? this.handleChallengeFailed("\u6574\u7406\u53f0\u6682\u65f6\u653e\u6ee1\u4e86") : this.isTutorialGuidedStep() && this.showTutorialStep();
        restored && UIManager_1.uimanager.showToast("\u56de\u6765\u5566\uff0c\u63a5\u7740\u6162\u6162\u6574\u7406\u5427\uff5e");
      };
      ZyxGame.prototype.onDestroy = function() {
        this.rankChase && this.rankChase.dispose();
        this.beanCollectionHud && this.beanCollectionHud.dispose();
        cc.Tween.stopAllByTarget(this.rankExpansion);
        this.dismissRoundRescuePrompt(false);
        this.clearTutorialGuide();
        this.unscheduleAllCallbacks();
        this.node && cc.Tween.stopAllByTarget(this.node);
        for (var _i = 0, _a = this.shardPool; _i < _a.length; _i++) {
          var shard = _a[_i];
          cc.isValid(shard) && shard.destroy();
        }
        this.shardPool.length = 0;
      };
      ZyxGame.prototype.update = function(dt) {
        if (!this.node || !this.node.isValid) return;
        this.locked || this.captureProgress();
        if (this.rescueBalloon) {
          var ended = this.rescueBalloon.update(dt, "flying" === this.balloonPhase && !this.pauseMenuOpen && !this.rewardedAdLoading && !this.settlementReported);
          ended && this.dismissRoundRescuePrompt(false);
        }
        var countdown = this.roundRescueCountdownState;
        if (countdown && countdown.started && "flying" === this.balloonPhase && !this.pauseMenuOpen && !this.rewardedAdLoading && !this.settlementReported) {
          countdown.progress = Math.max(0, countdown.progress - dt / 10);
          countdown.redraw();
          0 === countdown.progress && this.dismissRoundRescuePrompt(true);
        }
        if (this.boardDangerHalo && !this.pauseMenuOpen && !this.rewardedAdLoading && !this.settlementReported) {
          this.dangerSeconds += dt;
          this.dangerSeconds >= 2 && !this.locked && !this.isTutorialGuidedStep() && !this.roundRescueGuideVisible && ZyxGameModule_1.zyxGameModule.canOfferHeartRescue() && this.showWarmHeartBalloon();
        }
        this.updateRotatingTip(dt);
        if (this.isTutorialGuidedStep()) return;
        if (this.locked || this.roundRescueGuideVisible || this.hammerMode || this.purifierMode || this.hintHand) return;
        this.idleSeconds += dt;
        if (this.idleSeconds >= ZyxGameModule_1.zyxGameModule.getHintDelay()) {
          this.idleSeconds = 0;
          this.playEliminationHint();
        }
      };
      ZyxGame.prototype.refreshInventoryHud = function() {
        this.updateHud();
      };
      ZyxGame.prototype.refreshLayout = function() {
        if (!this.layout || !this.boardRoot) return;
        var previous = this.layout;
        this.layout = ResponsiveLayout_1.calculateGameLayout(this.node.height, ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE);
        this.hudRoot.y = this.layout.hudY;
        this.footerRoot.y = this.layout.footerY;
        this.boardRoot.y = this.layout.boardY;
        for (var _i = 0, _a = [ "boardShadow", "boardFrame" ]; _i < _a.length; _i++) {
          var name = _a[_i];
          var node = this.node.getChildByName(name);
          node && (node.y += this.layout.boardY - previous.boardY);
        }
        this.tutorialGuideRoot && (this.tutorialGuideRoot.y += this.layout.boardY - previous.boardY);
        for (var _b = 0, _c = [ "nextRow" ]; _b < _c.length; _b++) {
          var name = _c[_b];
          var node = this.node.getChildByName(name);
          node && (node.y = this.layout.nextY);
        }
        for (var _d = 0, _e = [ "toolDock", "toolDockShadow" ]; _d < _e.length; _d++) {
          var name = _e[_d];
          var node = this.node.getChildByName(name);
          node && (node.y += this.layout.toolY - previous.toolY);
        }
        this.boardDangerHalo && (this.boardDangerHalo.y = this.layout.boardY);
        this.applyRankLayout();
        this.refreshRoundRescueLayout();
      };
      ZyxGame.prototype.applyRankLayout = function() {
        var progress = this.rankExpansion.progress;
        var x = this.layout.boardX * progress;
        if (this.hudRoot && this.beanCollectionHud) {
          var hud = ResponsiveLayout_1.calculateGameHudLayout(this.node.width, ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE, progress);
          this.hudRoot.x = hud.x;
          this.hudRoot.setContentSize(hud.width, 148);
          var scoreWidth = 180;
          var gap = 12;
          var scoreCard = this.hudRoot.getChildByName("scoreCompareCard");
          scoreCard.x = -hud.width / 2 + scoreWidth / 2;
          var beanWidth = hud.width - scoreWidth - gap;
          this.beanCollectionHud.root.x = hud.width / 2 - beanWidth / 2;
          this.beanCollectionHud.resize(beanWidth);
        }
        for (var _i = 0, _a = [ this.boardRoot, this.boardDangerHalo, this.tutorialGuideRoot, this.node.getChildByName("boardShadow"), this.node.getChildByName("boardFrame"), this.node.getChildByName("nextRow") ]; _i < _a.length; _i++) {
          var node = _a[_i];
          node && (node.x = x);
        }
        if (this.rankChase) {
          var hiddenX = -this.node.width / 2 - this.rankChase.root.width / 2 - 12;
          this.rankChase.setPosition(hiddenX + (this.layout.rankX - hiddenX) * progress, this.layout.boardY);
          this.rankChase.setExpansion(progress, -this.node.width / 2 + 40, this.layout.boardY);
        }
      };
      ZyxGame.prototype.setRankExpanded = function(expanded, duration) {
        var _this = this;
        void 0 === duration && (duration = .42);
        this.createRankChase();
        if (this.rankExpanded === expanded) return;
        this.rankExpanded = expanded;
        cc.Tween.stopAllByTarget(this.rankExpansion);
        this.rankChase.setBookmarkVisible(false, function() {
          if (!cc.isValid(_this.node) || _this.rankExpanded !== expanded) return;
          cc.tween(_this.rankExpansion).to(duration, {
            progress: expanded ? 1 : 0
          }, {
            easing: "sineInOut",
            onUpdate: function() {
              cc.isValid(_this.node) && _this.applyRankLayout();
            }
          }).call(function() {
            if (!cc.isValid(_this.node) || _this.rankExpanded !== expanded) return;
            _this.applyRankLayout();
            expanded || _this.rankChase.setBookmarkVisible(true);
          }).start();
        });
      };
      ZyxGame.prototype.createRankChase = function() {
        var _this = this;
        if (this.rankChase) return;
        this.rankChase = new RankChaseView_1.default(this.node, this.rankChaseProfile, this.rankChaseSnapshot, function() {
          _this.tutorialStep < 0 && _this.setRankExpanded(!_this.rankExpanded);
        });
        this.applyRankLayout();
        this.rankChase.updateScore(ZyxGameModule_1.zyxGameModule.score);
      };
      ZyxGame.prototype.buildUI = function() {
        var _this = this;
        this.clearTutorialGuide();
        this.stopBoardDangerGlow();
        this.node.removeAllChildren();
        this.layout = ResponsiveLayout_1.calculateGameLayout(this.node.height, ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE);
        this.hudRoot = new cc.Node("gameHud");
        this.hudRoot.setPosition(0, this.layout.hudY);
        this.node.addChild(this.hudRoot);
        this.footerRoot = new cc.Node("gameFooter");
        this.footerRoot.setPosition(0, this.layout.footerY);
        this.node.addChild(this.footerRoot);
        var topY = 0;
        var bottomTipY = 0;
        var hudGap = 12;
        var hudWidth = ResponsiveLayout_1.calculateGameHudLayout(this.node.width, ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE, this.rankExpansion.progress).width;
        var scoreCardWidth = 180;
        var beanCardWidth = hudWidth - scoreCardWidth - hudGap;
        var pauseWidth = 80;
        var hudLeft = -hudWidth / 2;
        var leftCardX = hudLeft + scoreCardWidth / 2;
        var beanCardX = hudLeft + scoreCardWidth + hudGap + beanCardWidth / 2;
        var pauseX = this.node.width / 2 - 16 - pauseWidth / 2;
        var scoreCard = GamePanel_1.createGamePanel(this.hudRoot, "scoreCompareCard", scoreCardWidth, 148, leftCardX);
        var caption = UIManager_1.uimanager.createLabel(scoreCard, "\u672c\u5c40\u5f97\u5206", 0, 46, 24, HUD_LABEL_COLOR, scoreCardWidth - 20, 32);
        this.scoreLabel = UIManager_1.uimanager.createLabel(scoreCard, "0", 0, 5, 46, HUD_VALUE_COLOR, scoreCardWidth - 32, 56);
        this.bestLabel = UIManager_1.uimanager.createLabel(scoreCard, "\u6700\u9ad8 0", 0, -46, 20, HUD_LABEL_COLOR, scoreCardWidth - 20, 28);
        for (var _i = 0, _a = [ caption, this.scoreLabel, this.bestLabel ]; _i < _a.length; _i++) {
          var label = _a[_i];
          BeanCollectionHud_1.applyHudFont(label);
        }
        this.recordTagLabel = caption;
        this.beanCollectionHud = new BeanCollectionHud_1.default(this.hudRoot, beanCardX, beanCardWidth);
        this.moodBeanHudIcon = this.beanCollectionHud.icon;
        var pauseButton = UIManager_1.uimanager.createButton(this.footerRoot, "", pauseX, bottomTipY, pauseWidth, pauseWidth, UIManager_1.BUTTON_COLORS.red, function() {
          return _this.pauseGame();
        }, 24);
        pauseButton.name = "pauseButton";
        pauseButton.zIndex = 180;
        GlyphFactory_1.createPauseGlyph(pauseButton, 0, 1, .82);
        var tipWidth = Math.min(566, this.node.width - pauseWidth - 50);
        var tipRight = pauseX - pauseWidth / 2 - 14;
        var tipX = tipRight - tipWidth / 2;
        var tipPill = UIManager_1.uimanager.createRect(this.footerRoot, "tipPill", tipWidth, 48, new cc.Color(255, 249, 232), 218, 22, tipX, bottomTipY);
        this.moodStageLabel = UIManager_1.uimanager.createLabel(tipPill, "\u62d6\u52a8\u5fc3\u60c5\u5757\u5de6\u53f3\u79fb\u52a8\uff0c\u586b\u6ee1\u4e00\u884c\u5c31\u80fd\u6d88\u9664", 0, 0, 18, HUD_VALUE_COLOR, tipWidth - 36, 34);
        this.makeLabelBold(this.moodStageLabel);
        this.createBoard();
        this.createNextRowPreview();
        this.createToolBar();
        this.tutorialStep >= 0 && this.createTutorialNpcGuide();
        this.applyRankLayout();
      };
      ZyxGame.prototype.createBoard = function() {
        var boardWidth = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        var boardHeight = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE;
        var boardY = this.layout.boardY;
        var shadow = UIManager_1.uimanager.createRect(this.node, "boardShadow", boardWidth + 12, boardHeight + 12, new cc.Color(69, 46, 41), 34, 20, this.layout.boardX, boardY - 6);
        shadow.zIndex = 5;
        this.boardRoot = new cc.Node("boardViewport");
        this.boardRoot.width = boardWidth;
        this.boardRoot.height = boardHeight;
        this.boardRoot.setAnchorPoint(.5, .5);
        this.boardRoot.setPosition(this.layout.boardX, boardY);
        this.boardRoot.zIndex = 20;
        this.node.addChild(this.boardRoot);
        var viewportMask = this.boardRoot.addComponent(cc.Mask);
        viewportMask.type = cc.Mask.Type.RECT;
        var surface = new cc.Node("boardSurface");
        surface.width = boardWidth;
        surface.height = boardHeight;
        surface.zIndex = 0;
        this.boardRoot.addChild(surface);
        this.drawBoardSurface(surface, boardWidth, boardHeight);
        this.pieceLayer = new cc.Node("pieces");
        this.pieceLayer.width = boardWidth;
        this.pieceLayer.height = boardHeight;
        this.pieceLayer.setAnchorPoint(.5, .5);
        this.pieceLayer.zIndex = 10;
        this.boardRoot.addChild(this.pieceLayer);
        var frame = new cc.Node("boardFrame");
        frame.width = boardWidth + 18;
        frame.height = boardHeight + 18;
        frame.setPosition(this.layout.boardX, boardY);
        frame.zIndex = 100;
        this.node.addChild(frame);
        this.drawBoardFrame(frame, boardWidth, boardHeight);
      };
      ZyxGame.prototype.createTutorialNpcGuide = function() {
        var root = new cc.Node("tutorialGuide");
        root.width = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        root.height = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE;
        root.setAnchorPoint(.5, .5);
        root.zIndex = 190;
        root.x = this.layout.boardX;
        this.node.addChild(root);
        this.tutorialGuideRoot = root;
        var guideY = this.layout.boardY + ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE / 2 - 174;
        var npc = new cc.Node("happyBlockGuide");
        npc.width = 70;
        npc.height = 70;
        npc.setPosition(-252, guideY);
        npc.zIndex = 30;
        root.addChild(npc);
        MoodArt_1.drawMoodBlockMaterial(npc, MoodArt_1.getMoodColor(1));
        npc.tutorialBaseY = guideY;
        this.drawHappyTutorialFace(npc);
        this.tutorialNpc = npc;
        this.startTutorialNpcIdle();
        var bubbleGroup = new cc.Node("tutorialBubbleGroup");
        bubbleGroup.width = root.width;
        bubbleGroup.height = root.height;
        bubbleGroup.zIndex = 20;
        root.addChild(bubbleGroup);
        this.tutorialBubbleGroup = bubbleGroup;
        UIManager_1.uimanager.createRect(bubbleGroup, "tutorialBubbleShadow", 438, 98, new cc.Color(72, 48, 43), 54, 24, 43, guideY - 5);
        var bubble = UIManager_1.uimanager.createRect(bubbleGroup, "tutorialBubble", 432, 92, new cc.Color(255, 249, 232), 252, 22, 40, guideY);
        bubble.zIndex = 20;
        var bubbleGraphics = bubble.getComponent(cc.Graphics);
        bubbleGraphics.strokeColor = new cc.Color(239, 151, 105, 188);
        bubbleGraphics.lineWidth = 2.5;
        bubbleGraphics.roundRect(-214, -44, 428, 88, 21);
        bubbleGraphics.stroke();
        this.tutorialBubble = bubble;
        var tail = new cc.Node("tutorialBubbleTail");
        tail.setPosition(-180, guideY - 7);
        tail.zIndex = 21;
        bubbleGroup.addChild(tail);
        var tailGraphics = tail.addComponent(cc.Graphics);
        tailGraphics.fillColor = new cc.Color(255, 249, 232);
        tailGraphics.strokeColor = new cc.Color(239, 151, 105, 188);
        tailGraphics.lineWidth = 2.5;
        tailGraphics.moveTo(0, 15);
        tailGraphics.lineTo(-27, -1);
        tailGraphics.lineTo(0, -14);
        tailGraphics.close();
        tailGraphics.fill();
        tailGraphics.stroke();
        this.tutorialSpeechLabel = UIManager_1.uimanager.createLabel(bubble, "", 0, -1, 20, HUD_VALUE_COLOR, 382, 70);
        this.makeLabelBold(this.tutorialSpeechLabel);
      };
      ZyxGame.prototype.drawHappyTutorialFace = function(parent) {
        var face = new cc.Node("happyGuideFace");
        face.width = 52;
        face.height = 46;
        face.setPosition(0, -1);
        face.zIndex = 8;
        parent.addChild(face);
        var graphics = face.addComponent(cc.Graphics);
        graphics.strokeColor = new cc.Color(92, 63, 55);
        graphics.lineWidth = 3.2;
        graphics.lineCap = cc.Graphics.LineCap.ROUND;
        graphics.moveTo(-16, 7);
        graphics.bezierCurveTo(-13, 13, -8, 13, -5, 7);
        graphics.moveTo(5, 7);
        graphics.bezierCurveTo(8, 13, 13, 13, 16, 7);
        graphics.stroke();
        graphics.fillColor = new cc.Color(105, 68, 60);
        graphics.moveTo(-12, -3);
        graphics.bezierCurveTo(-7, -1, 7, -1, 12, -3);
        graphics.bezierCurveTo(10, -15, -10, -15, -12, -3);
        graphics.close();
        graphics.fill();
        graphics.fillColor = new cc.Color(242, 135, 125);
        graphics.ellipse(0, -11, 6.5, 2.8);
        graphics.fill();
        graphics.fillColor = new cc.Color(242, 151, 124, 172);
        graphics.ellipse(-19, -4, 5, 2.5);
        graphics.ellipse(19, -4, 5, 2.5);
        graphics.fill();
      };
      ZyxGame.prototype.startTutorialNpcIdle = function() {
        var npc = this.tutorialNpc;
        if (!npc || !cc.isValid(npc)) return;
        var baseY = Number(npc.tutorialBaseY) || npc.y;
        cc.Tween.stopAllByTarget(npc);
        npc.y = baseY;
        npc.scaleX = 1;
        npc.scaleY = 1;
        cc.tween(npc).repeatForever(cc.tween().to(.86, {
          y: baseY + 3,
          scale: 1.025
        }, {
          easing: "sineInOut"
        }).to(.86, {
          y: baseY,
          scale: 1
        }, {
          easing: "sineInOut"
        })).start();
      };
      ZyxGame.prototype.playTutorialNpcBounce = function() {
        var _this = this;
        var npc = this.tutorialNpc;
        if (!npc || !cc.isValid(npc)) return;
        var baseY = Number(npc.tutorialBaseY) || npc.y;
        cc.Tween.stopAllByTarget(npc);
        npc.y = baseY;
        npc.scaleX = 1;
        npc.scaleY = 1;
        cc.tween(npc).to(.11, {
          y: baseY + 28,
          scaleX: .92,
          scaleY: 1.12
        }, {
          easing: "quadOut"
        }).to(.13, {
          y: baseY - 2,
          scaleX: 1.1,
          scaleY: .9
        }, {
          easing: "quadIn"
        }).to(.09, {
          y: baseY + 12,
          scaleX: .96,
          scaleY: 1.06
        }, {
          easing: "quadOut"
        }).to(.12, {
          y: baseY,
          scaleX: 1,
          scaleY: 1
        }, {
          easing: "backOut"
        }).call(function() {
          return _this.startTutorialNpcIdle();
        }).start();
      };
      ZyxGame.prototype.playTutorialCompletionTransition = function() {
        var _this = this;
        var group = this.tutorialBubbleGroup;
        var bubble = this.tutorialBubble;
        var npc = this.tutorialNpc;
        if (!group || !bubble || !npc || !cc.isValid(group) || !cc.isValid(npc)) {
          this.finishTutorialTransition();
          return;
        }
        this.tutorialTypingState && cc.Tween.stopAllByTarget(this.tutorialTypingState);
        this.tutorialTypingState = null;
        this.tutorialSpeechLabel && (this.tutorialSpeechLabel.string = "");
        cc.Tween.stopAllByTarget(group);
        cc.Tween.stopAllByTarget(npc);
        group.opacity = 255;
        group.scale = 1;
        npc.opacity = 255;
        cc.tween(npc).to(.44, {
          y: 0,
          scale: 1.08
        }, {
          easing: "backOut"
        }).start();
        cc.tween(group).to(.44, {
          x: -bubble.x,
          y: -bubble.y,
          scale: 1.1
        }, {
          easing: "backOut"
        }).call(function() {
          _this.setTutorialSpeech("\u63a5\u4e0b\u6765\u5f00\u59cb\u4f60\u7684\u5feb\u4e50\u65f6\u95f4\u5427\uff01");
          _this.scheduleOnce(function() {
            return _this.playTutorialFarewell();
          }, 1.35);
        }).start();
      };
      ZyxGame.prototype.playTutorialFarewell = function() {
        var _this = this;
        this.setRankExpanded(true, .76);
        var group = this.tutorialBubbleGroup;
        var npc = this.tutorialNpc;
        var mask = this.tutorialDimMask;
        if (mask && cc.isValid(mask)) {
          cc.Tween.stopAllByTarget(mask);
          cc.tween(mask).to(.76, {
            opacity: 0
          }, {
            easing: "sineOut"
          }).call(function() {
            cc.isValid(mask) && mask.destroy();
            _this.tutorialDimMask === mask && (_this.tutorialDimMask = null);
          }).start();
        }
        if (group && cc.isValid(group)) {
          cc.Tween.stopAllByTarget(group);
          cc.tween(group).to(.12, {
            scale: 1.15
          }, {
            easing: "quadOut"
          }).to(.14, {
            scale: 1.1
          }, {
            easing: "quadIn"
          }).to(.12, {
            scale: 1.15
          }, {
            easing: "quadOut"
          }).to(.14, {
            scale: 1.1
          }, {
            easing: "quadIn"
          }).to(.24, {
            opacity: 0,
            scale: .92
          }, {
            easing: "quadIn"
          }).start();
        }
        if (!npc || !cc.isValid(npc)) {
          this.scheduleOnce(function() {
            return _this.finishTutorialTransition();
          }, .76);
          return;
        }
        cc.Tween.stopAllByTarget(npc);
        var baseY = npc.y;
        cc.tween(npc).to(.12, {
          y: baseY + 30,
          scaleX: .92,
          scaleY: 1.12
        }, {
          easing: "quadOut"
        }).to(.14, {
          y: baseY,
          scaleX: 1.08,
          scaleY: .92
        }, {
          easing: "quadIn"
        }).to(.12, {
          y: baseY + 24,
          scaleX: .94,
          scaleY: 1.1
        }, {
          easing: "quadOut"
        }).to(.14, {
          y: baseY,
          scaleX: 1.06,
          scaleY: .94
        }, {
          easing: "quadIn"
        }).to(.24, {
          opacity: 0,
          scale: .82
        }, {
          easing: "quadIn"
        }).call(function() {
          return _this.finishTutorialTransition();
        }).start();
      };
      ZyxGame.prototype.finishTutorialTransition = function() {
        this.tutorialStep = -1;
        this.clearTutorialGuide();
        this.setRankExpanded(true, .76);
        if (this.moodStageLabel) {
          this.moodStageLabel.string = "\u5feb\u4e50\u65f6\u95f4\u5f00\u59cb\u5566\uff1a\u7559\u610f\u4e0b\u4e00\u6392\uff0c\u7ee7\u7eed\u586b\u6ee1\u6574\u884c";
          this.moodStageLabel.node.opacity = 255;
        }
        this.updateHud();
        this.appendTutorialOpeningRows();
      };
      ZyxGame.prototype.appendTutorialOpeningRows = function() {
        var _this = this;
        ZyxGameModule_1.zyxGameModule.actionAppends = 0;
        for (var index = 0; index < 3; index++) if (!ZyxGameModule_1.zyxGameModule.appendNextRow()) {
          this.handleChallengeFailed("\u6574\u7406\u53f0\u6682\u65f6\u653e\u6ee1\u4e86");
          return;
        }
        this.animateAppendedRow(function() {
          _this.resolveStableBoard(function() {
            if (ZyxGameModule_1.zyxGameModule.isGameOver()) {
              _this.handleChallengeFailed("\u6574\u7406\u53f0\u6682\u65f6\u653e\u6ee1\u4e86");
              return;
            }
            _this.completePlayerAction();
            for (var _i = 0, _a = ZyxGameModule_1.zyxGameModule.pieces.filter(function(value) {
              return value.bomb;
            }); _i < _a.length; _i++) {
              var piece = _a[_i];
              var node = _this.pieceLayer.getChildByName("piece_" + piece.id);
              node && _this.showBombGuide(node, piece);
            }
            _this.locked = false;
            _this.idleSeconds = 0;
          });
        });
      };
      ZyxGame.prototype.isTutorialGuidedStep = function() {
        return this.tutorialStep >= 0 && this.tutorialStep < 3 && !!ZyxGameModule_1.zyxGameModule.getTutorialMove(this.tutorialStep);
      };
      ZyxGame.prototype.getTutorialSpeech = function() {
        var messages = [ "\u7b2c 1 \u6b65\uff1a\u628a 3 \u683c\u5757\u5411\u5de6\u62d6\uff0c\u8865\u6ee1\u7b2c\u4e8c\u6392\u3002", "\u7b2c 2 \u6b65\uff1a\u628a 2 \u683c\u5757\u5411\u53f3\u62d6\uff0c\u8865\u6ee1\u4e0b\u4e00\u6392\u3002", "\u7b2c 3 \u6b65\uff1a\u628a 1 \u683c\u5757\u5411\u5de6\u62d6\uff0c\u8865\u6ee1\u6700\u540e\u4e00\u6392\u3002" ];
        return messages[this.tutorialStep] || "";
      };
      ZyxGame.prototype.showTutorialStep = function() {
        if (!this.isTutorialGuidedStep()) return;
        if (this.tutorialRestoreCallback) {
          this.unschedule(this.tutorialRestoreCallback);
          this.tutorialRestoreCallback = null;
        }
        this.clearTutorialMoveGuide();
        this.setTutorialSpeech(this.getTutorialSpeech());
        this.showTutorialMoveGuide(ZyxGameModule_1.zyxGameModule.getTutorialMove(this.tutorialStep));
        this.updateHud();
      };
      ZyxGame.prototype.showTutorialMoveGuide = function(move) {
        if (!move || !this.boardRoot || !this.pieceLayer) return;
        var piece = ZyxGameModule_1.zyxGameModule.getPiece(move.id);
        var pieceNode = this.pieceLayer.getChildByName("piece_" + move.id);
        if (!piece || !pieceNode) return;
        var dimMask = this.createRoundRescueShade(this.pieceLayer, "tutorialDimMask", new cc.Color(25, 20, 18));
        dimMask.width = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        dimMask.height = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE;
        dimMask.zIndex = 50;
        dimMask.opacity = 148;
        this.tutorialDimMask = dimMask;
        this.tutorialFocusPieceId = move.id;
        pieceNode.zIndex = 90;
        var target = this.getPiecePosition(move.targetRow, move.targetCol, move.pieceSize);
        var targetMarker = new cc.Node("tutorialTargetMarker");
        targetMarker.width = move.pieceSize * ZyxGameModule_1.CELL_SIZE - 12;
        targetMarker.height = ZyxGameModule_1.CELL_SIZE - 12;
        targetMarker.setPosition(target);
        targetMarker.zIndex = 70;
        this.pieceLayer.addChild(targetMarker);
        var targetGraphics = targetMarker.addComponent(cc.Graphics);
        targetGraphics.fillColor = new cc.Color(255, 221, 104, 72);
        targetGraphics.strokeColor = new cc.Color(239, 151, 105, 238);
        targetGraphics.lineWidth = 4;
        targetGraphics.roundRect(-targetMarker.width / 2, -targetMarker.height / 2, targetMarker.width, targetMarker.height, 14);
        targetGraphics.fill();
        targetGraphics.stroke();
        cc.tween(targetMarker).repeatForever(cc.tween().to(.48, {
          opacity: 150,
          scale: .96
        }, {
          easing: "sineInOut"
        }).to(.48, {
          opacity: 255,
          scale: 1.03
        }, {
          easing: "sineInOut"
        })).start();
        this.tutorialTargetMarker = targetMarker;
        var origin = this.getPiecePosition(piece.row, piece.col, piece.size);
        var sourceMarker = new cc.Node("tutorialSourceMarker");
        sourceMarker.width = pieceNode.width + 16;
        sourceMarker.height = pieceNode.height + 16;
        sourceMarker.setPosition(0, 0);
        sourceMarker.zIndex = -1;
        pieceNode.addChild(sourceMarker);
        var sourceGraphics = sourceMarker.addComponent(cc.Graphics);
        sourceGraphics.strokeColor = new cc.Color(255, 203, 104, 92);
        sourceGraphics.lineWidth = 12;
        sourceGraphics.roundRect(-sourceMarker.width / 2, -sourceMarker.height / 2, sourceMarker.width, sourceMarker.height, 20);
        sourceGraphics.stroke();
        sourceGraphics.strokeColor = new cc.Color(255, 244, 196, 210);
        sourceGraphics.lineWidth = 3;
        sourceGraphics.roundRect(-sourceMarker.width / 2 + 3, -sourceMarker.height / 2 + 3, sourceMarker.width - 6, sourceMarker.height - 6, 17);
        sourceGraphics.stroke();
        sourceMarker.opacity = 190;
        cc.tween(sourceMarker).repeatForever(cc.tween().to(.5, {
          opacity: 118,
          scale: 1.045
        }, {
          easing: "sineInOut"
        }).to(.5, {
          opacity: 210,
          scale: 1
        }, {
          easing: "sineInOut"
        })).start();
        this.tutorialSourceMarker = sourceMarker;
        var hand = this.createHintHand(this.pieceLayer, origin.x, origin.y + 44);
        hand.name = "tutorialDragHand";
        this.tutorialHand = hand;
        var targetX = origin.x + move.offset * ZyxGameModule_1.CELL_SIZE;
        cc.tween(hand).repeatForever(cc.tween().to(.16, {
          y: origin.y + 24,
          scale: .9,
          opacity: 255
        }, {
          easing: "quadOut"
        }).to(.64, {
          x: targetX,
          y: origin.y + 24
        }, {
          easing: "cubicInOut"
        }).to(.13, {
          y: origin.y + 42,
          scale: 1
        }, {
          easing: "backOut"
        }).delay(.34).to(.3, {
          x: origin.x,
          opacity: 0
        }, {
          easing: "quadIn"
        }).call(function() {
          if (!cc.isValid(hand)) return;
          hand.setPosition(origin.x, origin.y + 44);
          hand.opacity = 255;
        }).delay(.22)).start();
      };
      ZyxGame.prototype.setTutorialSpeech = function(message) {
        var _this = this;
        if (!this.tutorialSpeechLabel) return;
        this.tutorialTypingState && cc.Tween.stopAllByTarget(this.tutorialTypingState);
        var state = {
          value: 0
        };
        this.tutorialTypingState = state;
        this.tutorialSpeechLabel.string = "";
        cc.tween(state).to(Math.max(.45, Math.min(1.5, .055 * message.length)), {
          value: message.length
        }, {
          easing: "linear",
          onUpdate: function() {
            if (!_this.tutorialSpeechLabel || _this.tutorialTypingState !== state) return;
            _this.tutorialSpeechLabel.string = message.slice(0, Math.floor(state.value));
          }
        }).call(function() {
          _this.tutorialSpeechLabel && _this.tutorialTypingState === state && (_this.tutorialSpeechLabel.string = message);
        }).start();
      };
      ZyxGame.prototype.showTutorialCorrection = function(message, resetBoard) {
        var _this = this;
        if (!this.isTutorialGuidedStep()) return;
        this.tutorialRestoreCallback && this.unschedule(this.tutorialRestoreCallback);
        this.clearTutorialMoveGuide();
        resetBoard && this.renderBoard();
        this.setTutorialSpeech(message);
        this.showTutorialMoveGuide(ZyxGameModule_1.zyxGameModule.getTutorialMove(this.tutorialStep));
        if (this.tutorialBubble && cc.isValid(this.tutorialBubble)) {
          var bubble = this.tutorialBubble;
          var originY = bubble.y;
          cc.Tween.stopAllByTarget(bubble);
          bubble.scale = 1;
          cc.tween(bubble).to(.11, {
            y: originY + 6,
            scale: 1.025
          }, {
            easing: "quadOut"
          }).to(.16, {
            y: originY,
            scale: 1
          }, {
            easing: "backOut"
          }).start();
        }
        this.tutorialRestoreCallback = function() {
          _this.tutorialRestoreCallback = null;
          _this.showTutorialStep();
        };
        this.scheduleOnce(this.tutorialRestoreCallback, 1.65);
      };
      ZyxGame.prototype.cancelTutorialRestore = function() {
        if (!this.tutorialRestoreCallback) return;
        this.unschedule(this.tutorialRestoreCallback);
        this.tutorialRestoreCallback = null;
      };
      ZyxGame.prototype.cancelTutorialHand = function() {
        if (this.tutorialHand && cc.isValid(this.tutorialHand)) {
          cc.Tween.stopAllByTarget(this.tutorialHand);
          this.tutorialHand.destroy();
        }
        this.tutorialHand = null;
      };
      ZyxGame.prototype.clearTutorialMoveGuide = function(preserveDimMask) {
        void 0 === preserveDimMask && (preserveDimMask = false);
        this.cancelTutorialHand();
        if (this.tutorialFocusPieceId > 0 && this.pieceLayer && cc.isValid(this.pieceLayer)) {
          var focus = this.pieceLayer.getChildByName("piece_" + this.tutorialFocusPieceId);
          focus && (focus.zIndex = 10);
        }
        var guideNodes = [ this.tutorialSourceMarker, this.tutorialTargetMarker ];
        preserveDimMask || guideNodes.push(this.tutorialDimMask);
        guideNodes.forEach(function(node) {
          if (!node || !cc.isValid(node)) return;
          cc.Tween.stopAllByTarget(node);
          node.destroy();
        });
        this.tutorialSourceMarker = null;
        this.tutorialTargetMarker = null;
        preserveDimMask || (this.tutorialDimMask = null);
        this.tutorialFocusPieceId = 0;
      };
      ZyxGame.prototype.clearTutorialGuide = function() {
        this.tutorialRestoreCallback && this.unschedule(this.tutorialRestoreCallback);
        this.tutorialRestoreCallback = null;
        this.clearTutorialMoveGuide();
        this.tutorialTypingState && cc.Tween.stopAllByTarget(this.tutorialTypingState);
        this.tutorialTypingState = null;
        this.tutorialGuideRoot && cc.isValid(this.tutorialGuideRoot) && this.tutorialGuideRoot.destroy();
        this.tutorialGuideRoot = null;
        this.tutorialNpc = null;
        this.tutorialBubbleGroup = null;
        this.tutorialBubble = null;
        this.tutorialSpeechLabel = null;
      };
      ZyxGame.prototype.drawBoardSurface = function(node, width, height) {
        var graphics = node.addComponent(cc.Graphics);
        graphics.fillColor = new cc.Color(249, 239, 220);
        graphics.roundRect(-width / 2, -height / 2, width, height, 18);
        graphics.fill();
        graphics.strokeColor = new cc.Color(111, 83, 72, 88);
        graphics.lineWidth = 3.15;
        for (var col = 1; col < ZyxGameModule_1.BOARD_COLS; col++) {
          var x = -width / 2 + col * ZyxGameModule_1.CELL_SIZE;
          graphics.moveTo(x, -height / 2);
          graphics.lineTo(x, height / 2);
        }
        for (var row = 1; row < ZyxGameModule_1.BOARD_ROWS; row++) {
          var y = height / 2 - row * ZyxGameModule_1.CELL_SIZE;
          graphics.moveTo(-width / 2, y);
          graphics.lineTo(width / 2, y);
        }
        graphics.stroke();
      };
      ZyxGame.prototype.drawBoardFrame = function(node, width, height) {
        var graphics = node.addComponent(cc.Graphics);
        graphics.strokeColor = new cc.Color(91, 65, 57, 232);
        graphics.lineWidth = 12;
        graphics.roundRect(-width / 2, -height / 2, width, height, 18);
        graphics.stroke();
        graphics.strokeColor = new cc.Color(255, 244, 218, 86);
        graphics.lineWidth = 1.5;
        graphics.roundRect(-width / 2 + 7, -height / 2 + 7, width - 14, height - 14, 11);
        graphics.stroke();
      };
      ZyxGame.prototype.createNextRowPreview = function() {
        var boardWidth = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        var root = new cc.Node("nextRow");
        root.width = boardWidth + 32;
        root.height = 114;
        root.setAnchorPoint(.5, .5);
        root.setPosition(this.layout.boardX, this.layout.nextY);
        root.zIndex = 80;
        this.node.addChild(root);
        GamePanel_1.createGamePanel(root, "nextPreviewShield", boardWidth + 24, 112);
        this.nextLayer = new cc.Node("nextPieces");
        this.nextLayer.width = boardWidth;
        this.nextLayer.height = NEXT_PREVIEW_HEIGHT;
        this.nextLayer.setAnchorPoint(.5, .5);
        this.nextLayer.setPosition(0, 22);
        this.nextLayer.zIndex = 5;
        root.addChild(this.nextLayer);
        UIManager_1.uimanager.createRect(root, "nextRowLabelBg", 128, 32, new cc.Color(255, 249, 232), 255, 16, 0, -34);
        var nextLabel = this.nextRowLabel = UIManager_1.uimanager.createLabel(root, "\u4e0b\u4e00\u6392", 0, -34, 18, new cc.Color(45, 42, 39), 120, 30);
        this.makeLabelBold(nextLabel);
      };
      ZyxGame.prototype.createToolBar = function() {
        var dockY = this.layout.toolY;
        var dock = GamePanel_1.createGamePanel(this.node, "toolDock", 292, 128, 0, dockY);
        dock.zIndex = 90;
        this.hammerButton = UIManager_1.uimanager.createRect(dock, "reliefToolButton", TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, UIManager_1.BUTTON_COLORS.yellow, 255, 23, -53, -10);
        UIManager_1.uimanager.drawButtonSurface(this.hammerButton, TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, UIManager_1.BUTTON_COLORS.yellow, 23);
        this.hammerButton.addComponent(cc.Button);
        this.hammerButton.name = "hammerToolButton";
        this.hammerIcon = GlyphFactory_1.createHammerGlyph(this.hammerButton, 0, -1, .84);
        this.hammerCountLabel = this.createToolCountBadge(this.hammerButton, "hammerCountBadge");
        this.purifierButton = UIManager_1.uimanager.createRect(dock, "purifierToolButton", TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, UIManager_1.BUTTON_COLORS.green, 255, 23, 53, -10);
        UIManager_1.uimanager.drawButtonSurface(this.purifierButton, TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, UIManager_1.BUTTON_COLORS.green, 23);
        this.purifierButton.addComponent(cc.Button);
        this.purifierIcon = GlyphFactory_1.createPurifierGlyph(this.purifierButton, 0, -1, .84);
        this.purifierCountLabel = this.createToolCountBadge(this.purifierButton, "purifierCountBadge");
        for (var _i = 0, _a = [ this.hammerButton, this.purifierButton ]; _i < _a.length; _i++) {
          var button = _a[_i];
          var shade = UIManager_1.uimanager.createRect(button, "toolUsedShade", TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, new cc.Color(45, 39, 46), 125, 23);
          shade.zIndex = 20;
          shade.active = false;
        }
        this.bindToolGestures();
        this.bindPurifierGesture();
      };
      ZyxGame.prototype.createToolCountBadge = function(button, name) {
        var badge = UIManager_1.uimanager.createCircle(button, name, 17, MoodArt_1.MOOD_COLORS.cocoaSoft, 35, 34);
        var badgeGraphics = badge.getComponent(cc.Graphics);
        badgeGraphics.strokeColor = cc.Color.WHITE;
        badgeGraphics.lineWidth = 2;
        badgeGraphics.circle(0, 0, 16);
        badgeGraphics.stroke();
        var label = UIManager_1.uimanager.createLabel(badge, "0", 0, 0, 17, cc.Color.WHITE, 26, 24);
        this.makeLabelBold(label);
        return label;
      };
      ZyxGame.prototype.makeLabelBold = function(label) {
        label && UIManager_1.uimanager.applyTypography(label, true);
      };
      ZyxGame.prototype.bindToolGestures = function() {
        var _this = this;
        this.hammerButton.on(cc.Node.EventType.TOUCH_START, function(event) {
          if (_this.locked) return;
          if (_this.isTutorialGuidedStep()) {
            _this.showTutorialCorrection("\u5148\u5b8c\u6210\u5f53\u524d\u62d6\u62fd\uff0c\u5de5\u5177\u7a0d\u540e\u5c31\u80fd\u4f7f\u7528\u3002", false);
            return;
          }
          _this.markInteraction();
          _this.toolDragging = false;
          _this.toolTouchStart = event.touch.getLocation();
          cc.tween(_this.hammerButton).stop();
          cc.tween(_this.hammerButton).to(.07, {
            scale: .96
          }).start();
        }, this);
        this.hammerButton.on(cc.Node.EventType.TOUCH_MOVE, function(event) {
          if (!_this.toolTouchStart || _this.locked || ZyxGameModule_1.zyxGameModule.hammerCount <= 0) return;
          var point = event.touch.getLocation();
          var dx = point.x - _this.toolTouchStart.x;
          var dy = point.y - _this.toolTouchStart.y;
          if (!_this.toolDragging) {
            if (dx * dx + dy * dy < 196) return;
            _this.toolDragging = true;
            _this.setToolSelectionMode("hammer");
          }
          _this.showToolDragFollower(point);
        }, this);
        this.hammerButton.on(cc.Node.EventType.TOUCH_END, function(event) {
          cc.tween(_this.hammerButton).stop();
          cc.tween(_this.hammerButton).to(.1, {
            scale: 1
          }).start();
          if (!_this.toolTouchStart) return;
          if (_this.toolDragging) {
            var targetId = _this.findPieceAtWorldPoint(event.touch.getLocation());
            _this.clearToolDragFollower();
            _this.toolTouchStart = null;
            _this.toolDragging = false;
            if (targetId > 0) _this.useReliefTool(targetId); else {
              _this.setToolSelectionMode(null);
              UIManager_1.uimanager.showToast("\u628a\u89e3\u538b\u9524\u653e\u5230\u4e00\u4e2a\u5fc3\u60c5\u5757\u4e0a");
            }
            return;
          }
          _this.toolTouchStart = null;
          _this.showHammerInfoModal();
        }, this);
        this.hammerButton.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          _this.toolTouchStart = null;
          _this.toolDragging = false;
          _this.clearToolDragFollower();
          cc.tween(_this.hammerButton).stop();
          cc.tween(_this.hammerButton).to(.1, {
            scale: 1
          }).start();
        }, this);
      };
      ZyxGame.prototype.bindPurifierGesture = function() {
        var _this = this;
        this.purifierButton.on(cc.Node.EventType.TOUCH_START, function() {
          if (_this.locked) return;
          if (_this.isTutorialGuidedStep()) {
            _this.showTutorialCorrection("\u5148\u5b8c\u6210\u5f53\u524d\u62d6\u62fd\uff0c\u5de5\u5177\u7a0d\u540e\u5c31\u80fd\u4f7f\u7528\u3002", false);
            return;
          }
          _this.markInteraction();
          cc.tween(_this.purifierButton).stop();
          cc.tween(_this.purifierButton).to(.07, {
            scale: .96
          }).start();
        }, this);
        this.purifierButton.on(cc.Node.EventType.TOUCH_END, function() {
          cc.tween(_this.purifierButton).stop();
          cc.tween(_this.purifierButton).to(.1, {
            scale: 1
          }).start();
          _this.locked || _this.isTutorialGuidedStep() || _this.showPurifierInfoModal();
        }, this);
        this.purifierButton.on(cc.Node.EventType.TOUCH_CANCEL, function() {
          cc.tween(_this.purifierButton).stop();
          cc.tween(_this.purifierButton).to(.1, {
            scale: 1
          }).start();
        }, this);
      };
      ZyxGame.prototype.showToolDragFollower = function(worldPoint) {
        if (!this.toolDragFollower || !cc.isValid(this.toolDragFollower)) {
          this.toolDragFollower = GlyphFactory_1.createHammerGlyph(this.node, 0, 0, .72);
          this.toolDragFollower.name = "toolDragFollower";
          this.toolDragFollower.zIndex = 1200;
        }
        var local = this.node.convertToNodeSpaceAR(worldPoint);
        this.toolDragFollower.setPosition(local.x + 20, local.y + 24);
      };
      ZyxGame.prototype.clearToolDragFollower = function() {
        this.toolDragFollower && cc.isValid(this.toolDragFollower) && this.toolDragFollower.destroy();
        this.toolDragFollower = null;
      };
      ZyxGame.prototype.setToolSelectionMode = function(mode) {
        this.stopToolSelectionFeedback();
        this.hammerMode = "hammer" === mode;
        this.purifierMode = "magicWand" === mode;
        this.updateHud();
        if (!mode) {
          this.restoreDefaultPlayTip();
          return;
        }
        var prompt = "hammer" === mode ? "\u8bf7\u9009\u62e9\u8981\u6572\u6389\u7684\u683c\u5b50" : "\u8bf7\u9009\u62e9\u8981\u6d88\u9664\u989c\u8272\u7684\u8272\u5757";
        this.showToolSelectionPrompt(prompt);
        this.startPieceSelectionWiggle();
      };
      ZyxGame.prototype.showToolSelectionPrompt = function(message) {
        this.toolSelectionPrompt && cc.isValid(this.toolSelectionPrompt) && this.toolSelectionPrompt.destroy();
        var prompt = UIManager_1.uimanager.createRect(this.node, "toolSelectionPrompt", 430, 66, new cc.Color(83, 61, 53), 224, 24, 0, 0);
        prompt.zIndex = 1400;
        var label = UIManager_1.uimanager.createLabel(prompt, message, 0, 0, 24, cc.Color.WHITE, 390, 42);
        this.makeLabelBold(label);
        this.toolSelectionPrompt = prompt;
        cc.tween(prompt).repeatForever(cc.tween().to(.62, {
          opacity: 255,
          scale: 1.025
        }, {
          easing: "sineInOut"
        }).to(.62, {
          opacity: 184,
          scale: .985
        }, {
          easing: "sineInOut"
        })).start();
      };
      ZyxGame.prototype.startPieceSelectionWiggle = function() {
        var _this = this;
        this.stopPieceSelectionWiggle();
        if (!this.pieceLayer) return;
        var pieces = this.pieceLayer.children.filter(function(node) {
          return 0 === node.name.indexOf("piece_");
        });
        pieces.forEach(function(node, index) {
          var direction = index % 2 === 0 ? 1 : -1;
          node.angle = .8 * direction;
          _this.toolWiggleNodes.push(node);
          cc.tween(node).delay(index % 6 * .018).repeatForever(cc.tween().to(.13, {
            angle: 1.25 * -direction
          }, {
            easing: "sineInOut"
          }).to(.13, {
            angle: 1.05 * direction
          }, {
            easing: "sineInOut"
          })).start();
        });
      };
      ZyxGame.prototype.stopPieceSelectionWiggle = function() {
        var nodes = this.toolWiggleNodes.slice();
        this.pieceLayer && cc.isValid(this.pieceLayer) && this.pieceLayer.children.forEach(function(node) {
          if (0 !== node.name.indexOf("piece_") || nodes.indexOf(node) >= 0) return;
          nodes.push(node);
        });
        nodes.forEach(function(node) {
          if (!node || !cc.isValid(node)) return;
          cc.Tween.stopAllByTarget(node);
          node.angle = 0;
          node.scale = 1;
        });
        this.toolWiggleNodes = [];
      };
      ZyxGame.prototype.stopToolSelectionFeedback = function() {
        this.stopPieceSelectionWiggle();
        if (this.toolSelectionPrompt && cc.isValid(this.toolSelectionPrompt)) {
          cc.Tween.stopAllByTarget(this.toolSelectionPrompt);
          this.toolSelectionPrompt.destroy();
        }
        this.toolSelectionPrompt = null;
      };
      ZyxGame.prototype.findPieceAtWorldPoint = function(worldPoint) {
        if (!this.pieceLayer) return 0;
        for (var _i = 0, _a = this.pieceLayer.children; _i < _a.length; _i++) {
          var node = _a[_i];
          if (0 !== node.name.indexOf("piece_")) continue;
          if (node.getBoundingBoxToWorld().contains(worldPoint)) return Number(node.name.substring(6)) || 0;
        }
        return 0;
      };
      ZyxGame.prototype.loadEffectAssets = function() {
        this.clearSpineData = AssetLoader_1.getSkeletonData("game", AssetLoader_1.ASSET_PATHS.game.rewardSpine);
      };
      ZyxGame.prototype.renderAll = function() {
        this.renderBoard();
        this.renderNextRow();
        this.updateHud();
      };
      ZyxGame.prototype.renderBoard = function() {
        if (!this.pieceLayer) return;
        this.stopPieceSelectionWiggle();
        this.pieceLayer.removeAllChildren();
        this.pieceColors = {};
        for (var _i = 0, _a = ZyxGameModule_1.zyxGameModule.pieces; _i < _a.length; _i++) {
          var piece = _a[_i];
          this.createPieceView(piece);
        }
        (this.hammerMode || this.purifierMode) && this.startPieceSelectionWiggle();
      };
      ZyxGame.prototype.createPieceView = function(piece, startRow) {
        var _this = this;
        void 0 === startRow && (startRow = piece.row);
        var width = piece.size * ZyxGameModule_1.CELL_SIZE - 4;
        var height = ZyxGameModule_1.CELL_SIZE - 4;
        var node = new cc.Node("piece_" + piece.id);
        node.width = width;
        node.height = height;
        node.setAnchorPoint(.5, .5);
        node.setPosition(this.getPiecePosition(startRow, piece.col, piece.size));
        node.zIndex = 10;
        this.pieceLayer.addChild(node);
        var color = piece.lightning ? new cc.Color(193, 220, 233) : this.getPieceColor(piece.color);
        this.pieceColors[piece.id] = color;
        this.drawPiece(node, color, 1);
        if (piece.stampMood > 0) {
          var faceIndex = (7 * piece.id + 11 * piece.stampMood) % 30 + 1;
          MoodArt_1.createMoodStamp(node, piece.stampMood, ZyxGameModule_1.CELL_SIZE, piece.stampCell, 132, faceIndex);
        }
        piece.lightning ? this.decorateLightningPiece(node) : piece.bomb && this.decorateBombPiece(node, piece);
        var component = node.addComponent(ZyxGridCom_1.default);
        component.initialize(piece.id, ZyxGameModule_1.CELL_SIZE, {
          canInteract: function() {
            return !_this.locked;
          },
          onInteract: function() {
            return _this.markInteraction();
          },
          getMoveRange: function(id) {
            return ZyxGameModule_1.zyxGameModule.getMoveRange(id);
          },
          onMove: function(id, offset) {
            return _this.movePiece(id, offset);
          },
          onTap: function(id) {
            return _this.tapPiece(id);
          }
        });
        node.scale = .95;
        cc.tween(node).to(.12, {
          scale: 1
        }).start();
        return node;
      };
      ZyxGame.prototype.decorateLightningPiece = function(node) {
        var surface = node.getComponent(cc.Graphics);
        surface.clear();
        surface.fillColor = new cc.Color(193, 220, 233);
        surface.strokeColor = new cc.Color(104, 154, 177);
        surface.lineWidth = 1.8;
        surface.roundRect(-node.width / 2, -node.height / 2, node.width, node.height, 12);
        surface.fill();
        surface.stroke();
        var face = node.getChildByName("moodStamp");
        face && (face.active = false);
        var bolt = new cc.Node("lightningGlyph");
        node.addChild(bolt);
        var g = bolt.addComponent(cc.Graphics);
        g.fillColor = new cc.Color(247, 218, 133);
        g.strokeColor = new cc.Color(168, 136, 73);
        g.lineWidth = 1.5;
        g.moveTo(6, 24);
        g.lineTo(-15, -1);
        g.lineTo(-2, -1);
        g.lineTo(-8, -24);
        g.lineTo(16, 5);
        g.lineTo(3, 5);
        g.close();
        g.fill();
        g.stroke();
        cc.tween(bolt).repeatForever(cc.tween().to(1.1, {
          opacity: 150
        }, {
          easing: "sineInOut"
        }).to(1.1, {
          opacity: 255
        }, {
          easing: "sineInOut"
        })).start();
      };
      ZyxGame.prototype.playLightningDischarges = function(effects, onComplete) {
        var _this = this;
        effects.forEach(function(effect, index) {
          var start = _this.getPiecePosition(effect.source.row, effect.source.col, effect.source.size);
          var glow = UIManager_1.uimanager.createCircle(_this.pieceLayer, "lightningCharge", 24, new cc.Color(174, 221, 244), start.x, start.y);
          glow.opacity = 0;
          glow.zIndex = 80;
          cc.tween(glow).delay(.12 * index).to(.12, {
            opacity: 155,
            scale: 1.3
          }).to(.28, {
            opacity: 0,
            scale: 1.65
          }).call(function() {
            cc.isValid(glow) && glow.destroy();
          }).start();
          effect.targets.forEach(function(target) {
            var end = _this.getPiecePosition(target.original.row, target.original.col, target.original.size);
            var ray = new cc.Node("lightningArc");
            _this.pieceLayer.addChild(ray);
            ray.zIndex = 85;
            var g = ray.addComponent(cc.Graphics);
            var state = {
              t: 0
            };
            cc.tween(state).delay(.12 * index + .1).to(.23, {
              t: 1
            }, {
              onUpdate: function() {
                if (!cc.isValid(ray)) return;
                g.clear();
                var dx = (end.x - start.x) * state.t, dy = (end.y - start.y) * state.t;
                var length = Math.sqrt(dx * dx + dy * dy) || 1;
                for (var _i = 0, _a = [ 7, 2.3 ]; _i < _a.length; _i++) {
                  var width = _a[_i];
                  g.strokeColor = 7 === width ? new cc.Color(113, 186, 227, 85) : new cc.Color(199, 238, 255);
                  g.lineWidth = width;
                  g.moveTo(start.x, start.y);
                  for (var step = 1; step <= 7; step++) {
                    var offset = 7 === step ? 0 : [ 0, 7, -6, 9, -8, 5, -4 ][step] * state.t;
                    g.lineTo(start.x + dx * step / 7 - dy / length * offset, start.y + dy * step / 7 + dx / length * offset);
                  }
                  g.stroke();
                }
              }
            }).call(function() {
              if (!cc.isValid(_this.node)) return;
              var original = _this.pieceLayer.getChildByName("piece_" + target.original.id);
              if (original) {
                _this.drawPieceCracks(original);
                cc.tween(original).to(.08, {
                  opacity: 130
                }).start();
              }
            }).delay(.12).call(function() {
              cc.isValid(ray) && ray.destroy();
            }).start();
          });
        });
        this.scheduleOnce(function() {
          if (!cc.isValid(_this.node) || _this.settlementReported) return;
          _this.renderBoard();
          onComplete();
        }, .52 + .12 * Math.max(0, effects.length - 1));
      };
      ZyxGame.prototype.decorateBombPiece = function(node, piece) {
        if (node.getChildByName("bombBadge")) {
          this.showBombGuide(node, piece);
          return;
        }
        var badge = RewardArt_1.createBombBadge(node);
        badge.y += 4;
        var stamp = node.getChildByName("moodStamp");
        stamp && Math.abs(stamp.x) < 30 && (stamp.active = false);
        cc.tween(badge).repeatForever(cc.tween().delay(1.1).to(.08, {
          angle: -12
        }, {
          easing: "sineInOut"
        }).to(.08, {
          angle: 12
        }, {
          easing: "sineInOut"
        }).to(.08, {
          angle: -9
        }, {
          easing: "sineInOut"
        }).to(.08, {
          angle: 9
        }, {
          easing: "sineInOut"
        }).to(.08, {
          angle: 0
        }, {
          easing: "sineInOut"
        })).start();
        this.showBombGuide(node, piece);
      };
      ZyxGame.prototype.showBombGuide = function(node, piece) {
        var _this = this;
        if (!this.firstGameBombGuide || this.isTutorialGuidedStep() || node.getChildByName("bombTapGuide")) return;
        if (!this.bombGuideIds.has(piece.id)) {
          if (this.bombGuideCount >= 5) return;
          this.bombGuideIds.add(piece.id);
          this.bombGuideCount++;
          try {
            cc.sys.localStorage.setItem(this.bombGuideKey, String(this.bombGuideCount));
          } catch (_) {}
        }
        var below = piece.row < 2;
        var x = Math.max(-ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE / 2 + 50, Math.min(ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE / 2 - 50, node.x)) - node.x;
        var bubble = UIManager_1.uimanager.createRect(node, "bombTapGuide", 96, 30, new cc.Color(255, 247, 215), 255, 12, x, below ? -47 : 49);
        bubble.zIndex = 30;
        var g = bubble.getComponent(cc.Graphics);
        g.strokeColor = new cc.Color(173, 126, 73);
        g.lineWidth = 1.5;
        g.roundRect(-48, -15, 96, 30, 12);
        g.stroke();
        g.fillColor = new cc.Color(255, 247, 215);
        var direction = below ? 1 : -1;
        g.moveTo(-5, 14 * direction);
        g.lineTo(0, 22 * direction);
        g.lineTo(5, 14 * direction);
        g.fill();
        UIManager_1.uimanager.createLabel(bubble, "\u70b9\u6211\u5f15\u7206", 0, 0, 18, MoodArt_1.MOOD_COLORS.cocoa, 92, 28);
        bubble.on(cc.Node.EventType.TOUCH_END, function(event) {
          event.stopPropagation();
          _this.locked || _this.isTutorialGuidedStep() || _this.useBomb(piece.id);
        });
        cc.tween(bubble).delay(5).to(.25, {
          opacity: 0
        }).call(function() {
          cc.isValid(bubble, true) && bubble.destroy();
        }).start();
      };
      ZyxGame.prototype.drawPiece = function(node, color, alpha) {
        MoodArt_1.drawMoodBlockMaterial(node, color, alpha);
      };
      ZyxGame.prototype.getPiecePosition = function(row, col, size) {
        var boardWidth = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        var boardHeight = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE;
        return new cc.Vec2(-boardWidth / 2 + col * ZyxGameModule_1.CELL_SIZE + size * ZyxGameModule_1.CELL_SIZE / 2, boardHeight / 2 - row * ZyxGameModule_1.CELL_SIZE - ZyxGameModule_1.CELL_SIZE / 2);
      };
      ZyxGame.prototype.renderNextRow = function() {
        if (!this.nextLayer) return;
        this.nextLayer.removeAllChildren();
        var nodes = this.createNextRowPreviewNodes(NEXT_PREVIEW_OPACITY);
        for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
          var node = nodes_1[_i];
          this.startNextRowPulse(node);
        }
      };
      ZyxGame.prototype.createNextRowPreviewNodes = function(initialOpacity) {
        var _this = this;
        var nodes = [];
        if (!this.nextLayer) return nodes;
        var previewWidth = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        this.nextRowLabel && (this.nextRowLabel.string = "\u4e0b\u4e00\u6392");
        var previews = [ ZyxGameModule_1.zyxGameModule.nextPieces ];
        previews.forEach(function(pieces, index) {
          return pieces.forEach(function(piece) {
            var preview = new cc.Node("next_" + index + "_" + piece.col);
            preview.width = piece.size * ZyxGameModule_1.CELL_SIZE - 12;
            preview.height = NEXT_PREVIEW_HEIGHT;
            preview.opacity = initialOpacity;
            preview.setAnchorPoint(.5, .5);
            preview.setPosition(-previewWidth / 2 + piece.col * ZyxGameModule_1.CELL_SIZE + piece.size * ZyxGameModule_1.CELL_SIZE / 2, 0);
            MoodArt_1.drawMoodBlockMaterial(preview, MoodArt_1.getMoodColor(piece.color));
            if (piece.lightning) {
              _this.decorateLightningPiece(preview);
              preview.getChildByName("lightningGlyph").scale = .65;
            }
            _this.nextLayer.addChild(preview);
            nodes.push(preview);
          });
        });
        return nodes;
      };
      ZyxGame.prototype.animateAppendedRow = function(onComplete, riseRows) {
        var _this = this;
        void 0 === riseRows && (riseRows = 1);
        var previousNodes = this.nextLayer ? this.nextLayer.children.slice() : [];
        var _loop_1 = function(node) {
          cc.Tween.stopAllByTarget(node);
          cc.tween(node).to(.18, {
            opacity: 0,
            scaleY: .82
          }, {
            easing: "sineIn"
          }).call(function() {
            return node.destroy();
          }).start();
        };
        for (var _i = 0, previousNodes_1 = previousNodes; _i < previousNodes_1.length; _i++) {
          var node = previousNodes_1[_i];
          _loop_1(node);
        }
        var nextNodes = this.createNextRowPreviewNodes(0);
        var _loop_2 = function(node) {
          node.scaleY = .82;
          cc.tween(node).delay(.16).to(.22, {
            opacity: NEXT_PREVIEW_OPACITY,
            scaleY: 1
          }, {
            easing: "sineOut"
          }).call(function() {
            return _this.startNextRowPulse(node);
          }).start();
        };
        for (var _a = 0, nextNodes_1 = nextNodes; _a < nextNodes_1.length; _a++) {
          var node = nextNodes_1[_a];
          _loop_2(node);
        }
        for (var _b = 0, _c = ZyxGameModule_1.zyxGameModule.pieces; _b < _c.length; _b++) {
          var piece = _c[_b];
          var node = this.pieceLayer.getChildByName("piece_" + piece.id);
          node || (node = this.createPieceView(piece, 2 === riseRows ? piece.row + riseRows : ZyxGameModule_1.BOARD_ROWS));
          var target = this.getPiecePosition(piece.row, piece.col, piece.size);
          cc.Tween.stopAllByTarget(node);
          node.angle = 0;
          node.scale = 1;
          cc.tween(node).to(.44, {
            x: target.x,
            y: target.y
          }, {
            easing: "cubicInOut"
          }).start();
        }
        this.scheduleOnce(onComplete, .46);
      };
      ZyxGame.prototype.startNextRowPulse = function(node) {
        if (!node || !cc.isValid(node)) return;
        var pulse = function() {
          if (!cc.isValid(node)) return;
          cc.tween(node).to(.52, {
            opacity: 255,
            scaleY: 1.1
          }, {
            easing: "sineInOut"
          }).to(.52, {
            opacity: 178,
            scaleY: .98
          }, {
            easing: "sineInOut"
          }).call(pulse).start();
        };
        pulse();
      };
      ZyxGame.prototype.animateGravityMoves = function(moves, onComplete) {
        var longestDuration = 0;
        for (var _i = 0, moves_1 = moves; _i < moves_1.length; _i++) {
          var move = moves_1[_i];
          var piece = ZyxGameModule_1.zyxGameModule.getPiece(move.id);
          var node = this.pieceLayer.getChildByName("piece_" + move.id);
          if (!piece || !node) continue;
          var distance = move.toRow - move.fromRow;
          var duration = Math.min(.18, .055 + .02 * distance);
          var target = this.getPiecePosition(piece.row, piece.col, piece.size);
          longestDuration = Math.max(longestDuration, duration);
          cc.Tween.stopAllByTarget(node);
          node.angle = 0;
          node.scale = 1;
          cc.tween(node).to(duration, {
            x: target.x,
            y: target.y
          }).start();
        }
        longestDuration > 0 ? this.scheduleOnce(onComplete, longestDuration) : onComplete();
      };
      ZyxGame.prototype.animatePieceRemoval = function(pieceIds, onComplete) {
        var _this = this;
        var hasAnimation = false;
        var _loop_3 = function(id) {
          var node = this_1.pieceLayer.getChildByName("piece_" + id);
          if (!node) return "continue";
          hasAnimation = true;
          cc.Tween.stopAllByTarget(node);
          node.opacity = 255;
          cc.tween(node).to(.3, {
            opacity: 0,
            scale: .78
          }, {
            easing: "sineIn"
          }).call(function() {
            delete _this.pieceColors[id];
            cc.isValid(node) && node.destroy();
          }).start();
        };
        var this_1 = this;
        for (var _i = 0, pieceIds_1 = pieceIds; _i < pieceIds_1.length; _i++) {
          var id = pieceIds_1[_i];
          _loop_3(id);
        }
        hasAnimation ? this.scheduleOnce(onComplete, .32) : onComplete();
      };
      ZyxGame.prototype.animateColorPurifierRemoval = function(pieceIds, colorIndex, onComplete) {
        var _this = this;
        var color = this.getPieceColor(colorIndex);
        var pulse = new cc.Node("colorPurifierWave");
        pulse.width = 150;
        pulse.height = 150;
        pulse.zIndex = 24;
        pulse.scale = .4;
        pulse.opacity = 190;
        this.boardRoot.addChild(pulse);
        var pulseGraphics = pulse.addComponent(cc.Graphics);
        pulseGraphics.strokeColor = new cc.Color(color.r, color.g, color.b, 138);
        pulseGraphics.lineWidth = 12;
        pulseGraphics.circle(0, 0, 62);
        pulseGraphics.stroke();
        pulseGraphics.strokeColor = new cc.Color(255, 247, 220, 116);
        pulseGraphics.lineWidth = 4;
        pulseGraphics.circle(0, 0, 48);
        pulseGraphics.stroke();
        cc.tween(pulse).to(.46, {
          scale: 4.8,
          opacity: 0
        }, {
          easing: "quadOut"
        }).call(function() {
          return pulse.destroy();
        }).start();
        var longestDelay = 0;
        pieceIds.forEach(function(id, index) {
          var node = _this.pieceLayer.getChildByName("piece_" + id);
          if (!node) return;
          var delay = .018 * Math.min(index, 10);
          longestDelay = Math.max(longestDelay, delay);
          var direction = index % 2 === 0 ? 1 : -1;
          var state = {
            alpha: 1,
            scale: 1,
            rotation: 0
          };
          var update = function() {
            if (!cc.isValid(node)) return;
            node.opacity = Math.round(255 * state.alpha);
            node.scale = state.scale;
            node.angle = -state.rotation;
          };
          cc.Tween.stopAllByTarget(node);
          cc.tween(state).delay(delay).to(.09, {
            scale: 1.1
          }, {
            easing: "quadOut",
            onUpdate: update
          }).to(.25, {
            alpha: 0,
            scale: .18,
            rotation: 28 * direction
          }, {
            easing: "backIn",
            onUpdate: update
          }).call(function() {
            delete _this.pieceColors[id];
            cc.isValid(node) && node.destroy();
          }).start();
        });
        this.scheduleOnce(onComplete, longestDelay + .36);
      };
      ZyxGame.prototype.playRowClearEffects = function(rows) {
        for (var _i = 0, rows_1 = rows; _i < rows_1.length; _i++) {
          var row = rows_1[_i];
          this.playRowClearEffect(row);
        }
      };
      ZyxGame.prototype.playRowClearEffect = function(row) {
        if (!this.boardRoot) return;
        var boardWidth = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        var rowY = this.getPiecePosition(row, 0, 1).y;
        var flash = new cc.Node("rowFlash_" + row);
        flash.width = boardWidth;
        flash.height = ZyxGameModule_1.CELL_SIZE - 4;
        flash.setAnchorPoint(.5, .5);
        flash.setPosition(0, rowY);
        flash.zIndex = 30;
        this.boardRoot.addChild(flash);
        var flashState = {
          alpha: 0,
          scaleX: .16
        };
        this.drawRowFlash(flash, 1);
        flash.opacity = 0;
        flash.scaleX = flashState.scaleX;
        cc.tween(flash).to(.08, {
          opacity: Math.round(183.6),
          scaleX: 1
        }, {
          easing: "quadOut"
        }).to(.22, {
          opacity: 0,
          scaleX: 1.04
        }, {
          easing: "quadIn"
        }).call(function() {
          return flash.destroy();
        }).start();
        if (this.playSpineRowBurst(rowY, boardWidth)) return;
        this.playFallbackRowSweep(rowY, boardWidth, row);
      };
      ZyxGame.prototype.playSpineRowBurst = function(rowY, boardWidth) {
        if (!this.clearSpineData) return false;
        var positions = [ .24 * -boardWidth, .24 * boardWidth ];
        var _loop_4 = function(index) {
          var node = new cc.Node("rowSpine_" + index);
          node.setPosition(positions[index], rowY);
          node.opacity = 175;
          node.scaleX = .78;
          node.scaleY = .42;
          node.zIndex = 34;
          this_2.boardRoot.addChild(node);
          var skeleton = node.addComponent(sp.Skeleton);
          skeleton.skeletonData = this_2.clearSpineData;
          skeleton.premultipliedAlpha = false;
          skeleton.timeScale = 1.7;
          skeleton.setAnimation(0, 0 === index ? "action" : "action2", false);
          skeleton.setCompleteListener(function() {
            cc.isValid(node) && node.destroy();
          });
          this_2.scheduleOnce(function() {
            cc.isValid(node) && node.destroy();
          }, .62);
        };
        var this_2 = this;
        for (var index = 0; index < positions.length; index++) _loop_4(index);
        return true;
      };
      ZyxGame.prototype.playFallbackRowSweep = function(rowY, boardWidth, row) {
        var sweepWidth = 1.55 * ZyxGameModule_1.CELL_SIZE;
        var sweep = new cc.Node("rowSweep_" + row);
        sweep.width = sweepWidth;
        sweep.height = ZyxGameModule_1.CELL_SIZE - 10;
        sweep.setAnchorPoint(.5, .5);
        sweep.zIndex = 31;
        this.boardRoot.addChild(sweep);
        var startX = -boardWidth / 2 - sweepWidth / 2;
        var endX = boardWidth / 2 + sweepWidth / 2;
        this.drawRowSweep(sweep, 1);
        sweep.opacity = 0;
        sweep.setPosition(startX, rowY);
        cc.tween(sweep).to(.05, {
          opacity: Math.round(183.6),
          x: startX + 34
        }, {
          easing: "quadOut"
        }).to(.2, {
          opacity: Math.round(173.4),
          x: endX - 34
        }, {
          easing: "sineInOut"
        }).to(.05, {
          opacity: 0,
          x: endX
        }, {
          easing: "quadIn"
        }).call(function() {
          return sweep.destroy();
        }).start();
      };
      ZyxGame.prototype.drawRowFlash = function(node, alpha) {
        var safeAlpha = Math.max(0, Math.min(1, alpha));
        var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
        var width = node.width;
        var height = node.height;
        graphics.clear();
        graphics.fillColor = new cc.Color(244, 190, 77, Math.round(72 * safeAlpha));
        graphics.roundRect(-width / 2, -height / 2, width, height, 16);
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 226, 151, Math.round(126 * safeAlpha));
        graphics.roundRect(-width / 2, -9, width, 18, 9);
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 255, 255, Math.round(230 * safeAlpha));
        graphics.roundRect(-width / 2, -2, width, 4, 2);
        graphics.fill();
      };
      ZyxGame.prototype.drawRowSweep = function(node, alpha) {
        var safeAlpha = Math.max(0, Math.min(1, alpha));
        var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
        var width = node.width;
        var height = node.height;
        graphics.clear();
        graphics.fillColor = new cc.Color(239, 161, 91, Math.round(48 * safeAlpha));
        graphics.roundRect(-width / 2, -height / 2, width, height, 20);
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 225, 146, Math.round(116 * safeAlpha));
        graphics.roundRect(.28 * -width, -height / 2, .56 * width, height, 16);
        graphics.fill();
        graphics.fillColor = new cc.Color(255, 255, 255, Math.round(238 * safeAlpha));
        graphics.roundRect(-6, -height / 2, 12, height, 6);
        graphics.fill();
      };
      ZyxGame.prototype.animateHammerRemoval = function(id, onComplete) {
        var _this = this;
        var pieceNode = this.pieceLayer.getChildByName("piece_" + id);
        var color = this.pieceColors[id];
        if (!pieceNode || !color) {
          onComplete();
          return;
        }
        cc.Tween.stopAllByTarget(pieceNode);
        var strike = GlyphFactory_1.createHammerGlyph(this.pieceLayer, pieceNode.x + 42, pieceNode.y + 62, .88);
        strike.name = "hammerStrike_" + id;
        strike.angle = 68;
        strike.zIndex = 45;
        cc.tween(pieceNode).to(.1, {
          scale: 1.08
        }, {
          easing: "quadOut"
        }).start();
        cc.tween(strike).to(.1, {
          x: pieceNode.x + 7,
          y: pieceNode.y + 13,
          angle: 12,
          scale: 1.08
        }, {
          easing: "quadIn"
        }).call(function() {
          if (!cc.isValid(pieceNode)) return;
          _this.drawPieceCracks(pieceNode);
          _this.playHammerImpact(pieceNode.x, pieceNode.y);
        }).delay(.065).call(function() {
          if (!cc.isValid(pieceNode)) return;
          _this.spawnPieceShards(pieceNode, color, id, false);
          delete _this.pieceColors[id];
          pieceNode.destroy();
        }).to(.12, {
          y: pieceNode.y + 42,
          angle: 32,
          scale: .72
        }, {
          easing: "quadOut"
        }).call(function() {
          return strike.destroy();
        }).start();
        this.scheduleOnce(onComplete, .67);
      };
      ZyxGame.prototype.drawPieceCracks = function(node) {
        var graphics = node.getComponent(cc.Graphics);
        if (!graphics) return;
        var width = node.width;
        var height = node.height;
        graphics.strokeColor = new cc.Color(255, 250, 224, 235);
        graphics.lineWidth = 3;
        graphics.moveTo(4, height / 2 - 5);
        graphics.lineTo(-5, 12);
        graphics.lineTo(7, 2);
        graphics.lineTo(-8, -11);
        graphics.lineTo(-2, -height / 2 + 4);
        graphics.moveTo(-5, 12);
        graphics.lineTo(-Math.min(width / 2 - 6, 34), 2);
        graphics.moveTo(7, 2);
        graphics.lineTo(Math.min(width / 2 - 6, 42), -8);
        graphics.stroke();
      };
      ZyxGame.prototype.acquireShard = function() {
        var shard = this.shardPool.pop() || new cc.Node("pieceShard");
        shard.getComponent(cc.Graphics) || shard.addComponent(cc.Graphics);
        return shard;
      };
      ZyxGame.prototype.releaseShard = function(shard) {
        if (!cc.isValid(shard)) return;
        cc.Tween.stopAllByTarget(shard);
        shard.removeFromParent(false);
        this.shardPool.length < 96 ? this.shardPool.push(shard) : shard.destroy();
      };
      ZyxGame.prototype.spawnPieceShards = function(pieceNode, color, id, rowClear, blastCenter) {
        var _this = this;
        void 0 === blastCenter && (blastCenter = null);
        var width = pieceNode.width * Math.abs(pieceNode.scaleX);
        var height = pieceNode.height * Math.abs(pieceNode.scaleY);
        var columns = Math.max(3, Math.min(rowClear ? 9 : 8, Math.ceil(width / (rowClear ? 26 : 30))));
        var rows = 3;
        var shardWidth = width / columns;
        var shardHeight = height / rows;
        var gravity = rowClear ? 1400 : 1550;
        for (var row = 0; row < rows; row++) {
          var _loop_5 = function(col) {
            var index = row * columns + col;
            var shard = this_3.acquireShard();
            shard.name = "pieceShard_" + id + "_" + index;
            shard.width = shardWidth * (.82 + .2 * Math.random());
            shard.height = shardHeight * (.82 + .2 * Math.random());
            shard.setAnchorPoint(.5, .5);
            var localX = (col + .5) / columns * 2 - 1;
            var localY = 1 - (row + .5) / rows * 2;
            var startX = pieceNode.x + localX * width / 2;
            var startY = pieceNode.y + localY * height / 2;
            var startAngle = pieceNode.angle + 22 * (Math.random() - .5);
            var dx = blastCenter ? startX - blastCenter.x : 0;
            var dy = blastCenter ? startY - blastCenter.y : 0;
            var distance = Math.max(1, Math.sqrt(dx * dx + dy * dy));
            var velocityX = localX * (rowClear ? 150 : 220) + 75 * (Math.random() - .5) + dx / distance * 160;
            var velocityY = (blastCenter ? 160 : rowClear ? 235 : 320) + 85 * localY + 90 * (Math.random() - .5) + dy / distance * 230;
            var angularVelocity = .7 * velocityX + 340 * (Math.random() - .5);
            var drag = .65 + .45 * Math.random();
            var lifetime = (rowClear ? .62 : .72) + .16 * Math.random();
            var endScale = .72 + .18 * Math.random();
            shard.setPosition(startX, startY);
            shard.zIndex = 28;
            shard.opacity = 255;
            shard.scale = 1;
            shard.angle = startAngle;
            shard.shardFlightTime = 0;
            this_3.pieceLayer.addChild(shard);
            this_3.drawPieceShard(shard, color, 1, index);
            cc.tween(shard).to(lifetime, {
              shardFlightTime: lifetime
            }, {
              easing: "linear",
              onUpdate: function() {
                if (!cc.isValid(shard)) return;
                var time = shard.shardFlightTime;
                var progress = Math.min(1, time / lifetime);
                var fade = Math.max(0, (progress - .64) / .36);
                shard.setPosition(startX + velocityX * (1 - Math.exp(-drag * time)) / drag, startY + velocityY * time - gravity * time * time / 2);
                shard.angle = startAngle + angularVelocity * time;
                shard.scale = 1 - (1 - endScale) * progress;
                shard.opacity = Math.round(255 * (1 - fade * fade));
              }
            }).call(function() {
              return _this.releaseShard(shard);
            }).start();
          };
          var this_3 = this;
          for (var col = 0; col < columns; col++) _loop_5(col);
        }
      };
      ZyxGame.prototype.drawPieceShard = function(node, color, alpha, index) {
        var safeAlpha = Math.max(0, Math.min(1, alpha));
        var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
        var width = node.width;
        var height = node.height;
        var edge = Math.min(width, height);
        var cutA = edge * (.16 + 5 * index % 7 * .045);
        var cutB = edge * (.12 + 7 * index % 5 * .055);
        var tone = 7 * (3 * index % 5 - 2);
        var red = Math.max(0, Math.min(255, color.r + tone));
        var green = Math.max(0, Math.min(255, color.g + tone));
        var blue = Math.max(0, Math.min(255, color.b + tone));
        graphics.clear();
        graphics.fillColor = new cc.Color(red, green, blue, Math.round(255 * safeAlpha));
        graphics.moveTo(-width / 2 + cutA, -height / 2);
        graphics.lineTo(width / 2 - cutB, -height / 2 + .25 * cutA);
        graphics.lineTo(width / 2, height / 2 - cutA);
        graphics.lineTo(.25 * cutB, height / 2);
        graphics.lineTo(-width / 2 + cutB, height / 2 - .25 * cutB);
        graphics.lineTo(-width / 2, -cutA);
        graphics.lineTo(-width / 2 + cutA, -height / 2);
        graphics.fill();
        graphics.fillColor = new cc.Color(Math.round(.72 * red), Math.round(.72 * green), Math.round(.72 * blue), Math.round(100 * safeAlpha));
        graphics.moveTo(-width / 2 + cutA, -height / 2);
        graphics.lineTo(width / 2 - cutB, -height / 2 + .25 * cutA);
        graphics.lineTo(width / 2, height / 2 - cutA);
        graphics.lineTo(.06 * width, .08 * -height);
        graphics.close();
        graphics.fill();
        graphics.strokeColor = new cc.Color(255, 255, 255, Math.round(92 * safeAlpha));
        graphics.lineWidth = 1.3;
        graphics.moveTo(-width / 2 + cutB + 1, height / 2 - .25 * cutB - 1);
        graphics.lineTo(.25 * cutB, height / 2 - 1);
        graphics.lineTo(width / 2 - 1, height / 2 - cutA);
        graphics.stroke();
        graphics.strokeColor = new cc.Color(Math.round(.62 * color.r), Math.round(.62 * color.g), Math.round(.62 * color.b), Math.round(78 * safeAlpha));
        graphics.lineWidth = 1;
        graphics.moveTo(-width / 2 + cutA, -height / 2 + 1);
        graphics.lineTo(width / 2 - cutB, -height / 2 + .25 * cutA + 1);
        graphics.stroke();
        if (index % 4 === 0) {
          graphics.fillColor = new cc.Color(255, 255, 255, Math.round(145 * safeAlpha));
          graphics.circle(.12 * width, .08 * height, Math.max(.9, .06 * Math.min(width, height)));
          graphics.fill();
        }
      };
      ZyxGame.prototype.createHammerToolDemo = function(panel, centerY) {
        var _this = this;
        var stage = UIManager_1.uimanager.createRect(panel, "hammerDemoStage", 430, 132, new cc.Color(255, 250, 234), 255, 24, 0, centerY);
        var block = new cc.Node("hammerDemoBlock");
        block.width = 112;
        block.height = 66;
        block.setPosition(62, -9);
        stage.addChild(block);
        var color = MoodArt_1.getMoodColor(3);
        MoodArt_1.drawMoodBlockMaterial(block, color);
        var hammer = GlyphFactory_1.createHammerGlyph(stage, -72, 31, .72);
        hammer.angle = 54;
        var play = function() {
          if (!cc.isValid(stage) || !cc.isValid(hammer) || !cc.isValid(block)) return;
          cc.Tween.stopAllByTarget(block);
          block.opacity = 255;
          block.scale = 1;
          block.angle = 0;
          hammer.setPosition(-72, 31);
          hammer.angle = 54;
          hammer.scale = .72;
          cc.tween(hammer).delay(.26).to(.32, {
            x: 35,
            y: 12,
            angle: 8,
            scale: .82
          }, {
            easing: "quadIn"
          }).call(function() {
            if (!cc.isValid(block)) return;
            block.scale = 1.08;
            _this.spawnToolDemoShards(stage, block.x, block.y, color, 12);
            cc.tween(block).to(.1, {
              scale: .82,
              opacity: 0
            }, {
              easing: "quadIn"
            }).start();
          }).to(.2, {
            x: -20,
            y: 42,
            angle: 32,
            scale: .7
          }, {
            easing: "quadOut"
          }).delay(.78).call(play).start();
        };
        play();
      };
      ZyxGame.prototype.createMagicWandToolDemo = function(panel, centerY) {
        var _this = this;
        var stage = UIManager_1.uimanager.createRect(panel, "magicWandDemoStage", 430, 132, new cc.Color(255, 250, 234), 255, 24, 0, centerY);
        var matchingColor = MoodArt_1.getMoodColor(2);
        var otherColor = MoodArt_1.getMoodColor(4);
        var positions = [ -132, -45, 42, 129 ];
        var blocks = positions.map(function(x, index) {
          var block = new cc.Node("magicDemoBlock_" + index);
          block.width = 66;
          block.height = 52;
          block.setPosition(x, -23);
          stage.addChild(block);
          MoodArt_1.drawMoodBlockMaterial(block, 1 === index ? otherColor : matchingColor);
          return block;
        });
        var wand = GlyphFactory_1.createPurifierGlyph(stage, -126, 35, .68);
        wand.angle = 8;
        var play = function() {
          if (!cc.isValid(stage) || !cc.isValid(wand)) return;
          blocks.forEach(function(block) {
            if (!cc.isValid(block)) return;
            cc.Tween.stopAllByTarget(block);
            block.opacity = 255;
            block.scale = 1;
          });
          wand.setPosition(-126, 35);
          wand.angle = 8;
          wand.scale = .68;
          cc.tween(wand).delay(.28).to(.58, {
            x: 122,
            y: 35,
            angle: -8,
            scale: .74
          }, {
            easing: "sineInOut"
          }).call(function() {
            [ blocks[0], blocks[2], blocks[3] ].forEach(function(block, index) {
              if (!cc.isValid(block)) return;
              cc.tween(block).delay(.045 * index).to(.1, {
                scale: 1.12
              }, {
                easing: "quadOut"
              }).call(function() {
                return _this.spawnToolDemoShards(stage, block.x, block.y, matchingColor, 8);
              }).to(.14, {
                scale: .76,
                opacity: 0
              }, {
                easing: "quadIn"
              }).start();
            });
          }).to(.2, {
            y: 48,
            scale: .62
          }, {
            easing: "quadOut"
          }).delay(.88).call(play).start();
        };
        play();
      };
      ZyxGame.prototype.spawnToolDemoShards = function(parent, x, y, color, count) {
        var _this = this;
        var _loop_6 = function(index) {
          var shard = new cc.Node("toolDemoShard_" + index);
          shard.width = 10 + index % 3 * 3;
          shard.height = 8 + index % 2 * 4;
          shard.setPosition(x + 17 * index % 24 - 12, y + 11 * index % 18 - 9);
          shard.zIndex = 20;
          parent.addChild(shard);
          var state = {
            x: shard.x,
            y: shard.y,
            rotation: 19 * index % 32 - 16,
            scale: 1,
            alpha: 1
          };
          var direction = index % 2 === 0 ? 1 : -1;
          var update = function() {
            if (!cc.isValid(shard)) return;
            shard.setPosition(state.x, state.y);
            shard.angle = -state.rotation;
            shard.scale = state.scale;
            _this.drawPieceShard(shard, color, state.alpha, index);
          };
          update();
          cc.tween(state).to(.12, {
            x: state.x + direction * (18 + index % 4 * 6),
            y: state.y + 16 + index % 3 * 6,
            rotation: direction * (44 + 7 * index)
          }, {
            easing: "quadOut",
            onUpdate: update
          }).to(.44, {
            x: state.x + direction * (31 + index % 4 * 8),
            y: state.y - 48 - index % 3 * 12,
            rotation: direction * (96 + 11 * index),
            scale: .28,
            alpha: 0
          }, {
            easing: "quadIn",
            onUpdate: update
          }).call(function() {
            return shard.destroy();
          }).start();
        };
        for (var index = 0; index < count; index++) _loop_6(index);
      };
      ZyxGame.prototype.playHammerImpact = function(x, y) {
        var impact = new cc.Node("hammerImpact");
        impact.width = 108;
        impact.height = 108;
        impact.setAnchorPoint(.5, .5);
        impact.setPosition(x, y);
        impact.zIndex = 44;
        this.pieceLayer.addChild(impact);
        var impactState = {
          alpha: 1,
          scale: .34
        };
        var updateImpact = function() {
          if (!cc.isValid(impact)) return;
          impact.scale = impactState.scale;
          var graphics = impact.getComponent(cc.Graphics) || impact.addComponent(cc.Graphics);
          graphics.clear();
          graphics.strokeColor = new cc.Color(255, 225, 127, Math.round(235 * impactState.alpha));
          graphics.lineWidth = 5;
          graphics.circle(0, 0, 28);
          graphics.stroke();
          graphics.strokeColor = new cc.Color(255, 255, 255, Math.round(190 * impactState.alpha));
          graphics.lineWidth = 3;
          for (var index = 0; index < 8; index++) {
            var angle = index * Math.PI / 4;
            graphics.moveTo(35 * Math.cos(angle), 35 * Math.sin(angle));
            graphics.lineTo(50 * Math.cos(angle), 50 * Math.sin(angle));
          }
          graphics.stroke();
        };
        updateImpact();
        cc.tween(impactState).to(.22, {
          alpha: 0,
          scale: 1.3
        }, {
          easing: "quadOut",
          onUpdate: updateImpact
        }).call(function() {
          return impact.destroy();
        }).start();
      };
      ZyxGame.prototype.animateRowShatter = function(pieceIds, bombs, simultaneous) {
        var _this = this;
        void 0 === bombs && (bombs = []);
        void 0 === simultaneous && (simultaneous = false);
        var _loop_7 = function(id) {
          var node = this_4.pieceLayer.getChildByName("piece_" + id);
          var color = this_4.pieceColors[id];
          if (!node || !color) return "continue";
          var ownBlast = bombs.findIndex(function(bomb) {
            return bomb.id === id;
          });
          var hitIndex = ownBlast >= 0 ? ownBlast : bombs.findIndex(function(bomb) {
            return bomb.affectedPieceIds.indexOf(id) >= 0;
          });
          var center = hitIndex >= 0 ? this_4.getPiecePosition(bombs[hitIndex].row, bombs[hitIndex].col, bombs[hitIndex].size) : null;
          var dx = center ? node.x - center.x : 0;
          var dy = center ? node.y - center.y : 0;
          var distance = Math.max(1, Math.sqrt(dx * dx + dy * dy));
          var delay = center ? (simultaneous ? 0 : BombEffect_1.BOMB_PRIME_TIME + hitIndex * BombEffect_1.BOMB_CHAIN_INTERVAL) + (ownBlast >= 0 ? 0 : .035 * Math.min(1, distance / (1.5 * ZyxGameModule_1.CELL_SIZE))) : 0;
          cc.Tween.stopAllByTarget(node);
          if (center) {
            var flash = new cc.Node("bombHitFlash");
            flash.zIndex = 20;
            flash.opacity = 0;
            node.addChild(flash);
            var glow = flash.addComponent(cc.Graphics);
            glow.fillColor = new cc.Color(255, 237, 170, 200);
            glow.strokeColor = new cc.Color(255, 255, 230, 245);
            glow.lineWidth = 3;
            glow.roundRect(-node.width / 2 + 2, -node.height / 2 + 2, node.width - 4, node.height - 4, 10);
            glow.fill();
            glow.stroke();
            simultaneous ? cc.tween(flash).to(.025, {
              opacity: 255
            }).start() : cc.tween(flash).delay(hitIndex * BombEffect_1.BOMB_CHAIN_INTERVAL).to(.055, {
              opacity: 85
            }).delay(delay - hitIndex * BombEffect_1.BOMB_CHAIN_INTERVAL - .055).to(.025, {
              opacity: 255
            }).start();
          }
          cc.tween(node).delay(delay).call(function() {
            center && cc.isValid(node) && _this.drawPieceCracks(node);
          }).to(center ? .06 : .045, {
            x: node.x + dx / distance * 7,
            y: node.y + dy / distance * 5,
            scaleX: center ? 1.1 : 1.03,
            scaleY: center ? .78 : .84
          }, {
            easing: "quadOut"
          }).call(function() {
            if (!cc.isValid(node)) return;
            _this.playMoodCollect([ id ]);
            _this.spawnPieceShards(node, color, id, !center, center);
            delete _this.pieceColors[id];
            node.destroy();
          }).start();
        };
        var this_4 = this;
        for (var _i = 0, pieceIds_2 = pieceIds; _i < pieceIds_2.length; _i++) {
          var id = pieceIds_2[_i];
          _loop_7(id);
        }
      };
      ZyxGame.prototype.animateElimination = function(result, onComplete) {
        this.updateHud();
        AudioManager_1.audioManager.playSound("break");
        this.playTutorialNpcBounce();
        this.playRowClearEffects(result.clearedRowIndexes);
        this.animateBombBlasts(result);
        this.animateRowShatter(result.removedPieceIds, result.detonatedBombs);
        this.playScoreFeedback(result);
        this.scheduleOnce(onComplete, BombEffect_1.bombResolutionDelay((result.detonatedBombs || []).length));
      };
      ZyxGame.prototype.playScoreFeedback = function(result) {
        if (result.gainedScore <= 0) return;
        this.rewardFeedback && cc.isValid(this.rewardFeedback) && this.rewardFeedback.destroy();
        var root = new cc.Node("eliminationReward");
        root.zIndex = 160;
        this.boardRoot.addChild(root);
        this.rewardFeedback = root;
        var combo = result.combo || 1;
        if (combo >= 2) {
          root.setPosition(0, -38);
          root.opacity = 0;
        } else if (result.clearedRows > 0) {
          var row = result.clearedRowIndexes.reduce(function(sum, value) {
            return sum + value;
          }, 0) / result.clearedRows;
          var y = this.getPiecePosition(row, 0, 1).y;
          var feedbackLimit = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE / 2 - 150;
          root.setPosition(0, Math.max(-feedbackLimit, Math.min(feedbackLimit, y + 70)));
        }
        if (combo >= 2) {
          var word = RewardArt_1.createComboArt(root, combo);
          word.y = 45;
        }
        var score = RewardArt_1.createScoreArt(root, "+" + result.gainedScore, combo >= 2 ? 58 : 48);
        score.y = combo >= 2 ? -34 : 0;
        root.scale = .5;
        combo >= 2 && cc.tween(root).to(.28, {
          y: 0,
          opacity: 255
        }, {
          easing: "quadOut"
        }).start();
        cc.tween(root).to(.18, {
          scale: 1.12
        }, {
          easing: "backOut"
        }).to(.1, {
          scale: 1
        }, {
          easing: "sineOut"
        }).delay(.65).by(.28, {
          y: 38,
          opacity: -255
        }, {
          easing: "quadIn"
        }).call(function() {
          cc.isValid(root) && root.destroy();
        }).start();
      };
      ZyxGame.prototype.playToolScoreFeedback = function(gainedScore) {
        this.updateHud();
        this.playScoreFeedback({
          gainedScore: gainedScore,
          clearedRows: 0,
          clearedRowIndexes: [],
          removedPieceIds: [],
          collectedMoodTypes: []
        });
      };
      ZyxGame.prototype.playMoodCollect = function(pieceIds) {
        var _this = this;
        var rewardIndex = 0;
        var _loop_8 = function(id) {
          var pieceNode = this_5.pieceLayer.getChildByName("piece_" + id);
          var stamp = pieceNode ? pieceNode.getChildByName("moodStamp") : null;
          if (!pieceNode || !stamp) return "continue";
          var moodIndex = Number(stamp.moodIndex) || 1;
          var worldStart = pieceNode.convertToWorldSpaceAR(stamp.getPosition());
          var start = this_5.node.convertToNodeSpaceAR(worldStart);
          var token = MoodArt_1.createMoodBean(this_5.node, moodIndex, start.x, start.y, 40, 0);
          token.zIndex = 900;
          var target = this_5.moodBeanHudIcon ? this_5.node.convertToNodeSpaceAR(this_5.moodBeanHudIcon.parent.convertToWorldSpaceAR(this_5.moodBeanHudIcon.getPosition())) : new cc.Vec2(30, this_5.layout.hudY);
          var control = new cc.Vec2(start.x + .42 * (target.x - start.x) + (rewardIndex % 2 === 0 ? -55 : 55), Math.max(start.y, target.y) + 150);
          var state = {
            t: 0
          };
          var delay = Math.min(.28, .025 * rewardIndex);
          rewardIndex++;
          cc.tween(token).delay(delay).to(.08, {
            opacity: 255,
            scale: 1.18
          }, {
            easing: "backOut"
          }).start();
          cc.tween(state).delay(delay + .04).to(.52, {
            t: 1
          }, {
            easing: "quadIn",
            onUpdate: function() {
              if (!cc.isValid(token)) return;
              var oneMinus = 1 - state.t;
              token.x = oneMinus * oneMinus * start.x + 2 * oneMinus * state.t * control.x + state.t * state.t * target.x;
              token.y = oneMinus * oneMinus * start.y + 2 * oneMinus * state.t * control.y + state.t * state.t * target.y;
              token.scale = 1.18 - .55 * state.t;
              token.angle = 220 * -state.t;
            }
          }).call(function() {
            if (_this.settlementReported || !cc.isValid(_this.node)) {
              token.destroy();
              return;
            }
            _this.displayedRoundMoods++;
            _this.beanCollectionHud.collectTo(_this.displayedRoundMoods);
            if (_this.moodBeanHudIcon && cc.isValid(_this.moodBeanHudIcon)) {
              cc.Tween.stopAllByTarget(_this.moodBeanHudIcon);
              cc.tween(_this.moodBeanHudIcon).to(.07, {
                scale: 1.18
              }, {
                easing: "backOut"
              }).to(.12, {
                scale: 1
              }, {
                easing: "sineOut"
              }).start();
            }
            cc.isValid(token) && token.destroy();
          }).start();
        };
        var this_5 = this;
        for (var _i = 0, pieceIds_3 = pieceIds; _i < pieceIds_3.length; _i++) {
          var id = pieceIds_3[_i];
          _loop_8(id);
        }
      };
      ZyxGame.prototype.resolveStableBoard = function(onStable, clearedRows) {
        var _this = this;
        void 0 === clearedRows && (clearedRows = 0);
        var lightning = ZyxGameModule_1.zyxGameModule.takeLightningEffects();
        if (lightning.length) {
          this.playLightningDischarges(lightning, function() {
            return _this.resolveStableBoard(onStable, clearedRows);
          });
          return;
        }
        var gravityMoves = ZyxGameModule_1.zyxGameModule.applyGravity();
        if (gravityMoves.length > 0) {
          this.animateGravityMoves(gravityMoves, function() {
            return _this.resolveStableBoard(onStable, clearedRows);
          });
          return;
        }
        var elimination = ZyxGameModule_1.zyxGameModule.eliminateFullRows();
        if (elimination.clearedRows > 0) {
          GameSettings_1.gameSettings.vibrateLight();
          this.animateElimination(elimination, function() {
            return _this.resolveStableBoard(onStable, clearedRows + elimination.clearedRows);
          });
          return;
        }
        this.updateBoardDangerState();
        onStable();
      };
      ZyxGame.prototype.appendNextRowAndResolve = function(refill) {
        var _this = this;
        void 0 === refill && (refill = true);
        var riseRows = ZyxGameModule_1.zyxGameModule.getRiseRowCount();
        if (!ZyxGameModule_1.zyxGameModule.appendTurnRows()) {
          this.handleChallengeFailed("\u6574\u7406\u53f0\u6682\u65f6\u653e\u6ee1\u4e86");
          return;
        }
        this.animateAppendedRow(function() {
          _this.resolveStableBoard(function() {
            _this.ensureMinimumOccupiedRows(refill ? ZyxGameModule_1.zyxGameModule.getRefillRowTarget() : 0, function() {
              _this.completePlayerAction();
              if (ZyxGameModule_1.zyxGameModule.isGameOver()) {
                _this.handleChallengeFailed("\u6574\u7406\u53f0\u6682\u65f6\u653e\u6ee1\u4e86");
                return;
              }
              if (_this.tryShowRoundRescue()) return;
              _this.locked = false;
              _this.idleSeconds = 0;
            });
          });
        }, riseRows);
      };
      ZyxGame.prototype.ensureMinimumOccupiedRows = function(minimumRows, onReady) {
        var _this = this;
        if (ZyxGameModule_1.zyxGameModule.getOccupiedRowCount() >= minimumRows || ZyxGameModule_1.zyxGameModule.actionAppends >= ZyxGameModule_1.MAX_ACTION_APPENDS) {
          onReady();
          return;
        }
        if (!ZyxGameModule_1.zyxGameModule.appendNextRow()) {
          this.handleChallengeFailed("\u6574\u7406\u53f0\u6682\u65f6\u653e\u6ee1\u4e86");
          return;
        }
        this.animateAppendedRow(function() {
          _this.resolveStableBoard(function() {
            return _this.ensureMinimumOccupiedRows(minimumRows, onReady);
          });
        });
      };
      ZyxGame.prototype.tryShowRoundRescue = function() {
        var _this = this;
        if (this.rescueBalloon || this.roundRescuePrompt || this.settlementReported) return false;
        if (ZyxGameModule_1.zyxGameModule.canOfferHeartRescue()) return false;
        var elapsedMs = Math.max(0, Date.now() - ZyxGameModule_1.zyxGameModule.roundStartedAt);
        var kind = ZyxGameModule_1.zyxGameModule.offerRoundRescue(elapsedMs);
        if (!kind) return false;
        this.balloonPhase = "flying";
        if ("balloon" === kind) this.rescueBalloon = new RescueBalloon_1.RescueBalloon(this.boardRoot, ZyxGameModule_1.CELL_SIZE, function() {
          return _this.handleRoundRescueClick();
        }); else {
          this.markInteraction();
          this.showScreenClearRescuePrompt();
        }
        this.locked = false;
        this.idleSeconds = 0;
        return true;
      };
      ZyxGame.prototype.showScreenClearRescuePrompt = function() {
        var _this = this;
        this.roundRescueInteractive = false;
        this.roundRescueGuideVisible = true;
        var prompt = new cc.Node("roundRescuePrompt");
        prompt.setContentSize(this.node.width, this.node.height);
        prompt.zIndex = 720;
        this.node.addChild(prompt);
        this.roundRescuePrompt = prompt;
        var mask = this.createRoundRescueShade(prompt, "roundRescueMask", new cc.Color(30, 25, 24));
        mask.addComponent(cc.BlockInputEvents);
        var wash = this.createRoundRescueShade(prompt, "roundRescueLight", new cc.Color(255, 233, 169));
        wash.zIndex = 1;
        var drawer = new cc.Node("roundRescueDrawer");
        drawer.zIndex = 2;
        prompt.addChild(drawer);
        this.refreshRoundRescueLayout();
        var dockX = this.node.width / 2 - 66;
        var offscreenX = mask.x + mask.width / 2 + 480;
        drawer.x = offscreenX;
        var icon = new cc.Node("roundRescueCountdownButton");
        icon.setContentSize(122, 122);
        drawer.addChild(icon);
        var iconButton = icon.addComponent(cc.Button);
        iconButton.transition = cc.Button.Transition.NONE;
        iconButton.interactable = false;
        icon.on(cc.Node.EventType.TOUCH_END, function(event) {
          event.stopPropagation();
          _this.handleScreenClearRescueClick();
        }, this);
        var halo = UIManager_1.uimanager.createCircle(icon, "roundRescueFocus", 66, new cc.Color(255, 223, 136, 60));
        halo.zIndex = -1;
        var lightning = new cc.Node("roundRescueLightning");
        icon.addChild(lightning);
        this.drawRoundRescueLightning(lightning);
        var ring = new cc.Node("roundRescueCountdownRing");
        icon.addChild(ring);
        var countdownLabel = UIManager_1.uimanager.createLabel(icon, "10\u79d2", 0, -80, 24, MoodArt_1.MOOD_COLORS.cream, 108, 38);
        this.makeLabelBold(countdownLabel);
        var explanation = new cc.Node("roundRescueExplanation");
        explanation.opacity = 0;
        drawer.addChild(explanation);
        UIManager_1.uimanager.createRect(explanation, "roundRescueBubbleShadow", 334, 126, new cc.Color(62, 43, 36), 54, 22, -242, 26);
        var bubble = UIManager_1.uimanager.createRect(explanation, "roundRescueBubble", 330, 122, MoodArt_1.MOOD_COLORS.cream, 255, 22, -242, 32);
        var text = UIManager_1.uimanager.createLabel(bubble, "video" === ShareReward_1.getRewardOfferIcon("rescue") ? "\u5b8c\u6574\u770b\u89c6\u9891\n\u6e05\u7a7a\u5168\u90e8\u8272\u5757" : "\u5206\u4eab\u7ed9\u597d\u53cb\n\u6e05\u7a7a\u5168\u90e8\u8272\u5757", 0, 0, 26, MoodArt_1.MOOD_COLORS.cocoa, 298, 84);
        this.makeLabelBold(text);
        var pointer = new cc.Node("roundRescuePointer");
        pointer.setPosition(-70, 28);
        explanation.addChild(pointer);
        var graphics = pointer.addComponent(cc.Graphics);
        graphics.fillColor = MoodArt_1.MOOD_COLORS.cream;
        graphics.moveTo(-10, -10);
        graphics.lineTo(4, 0);
        graphics.lineTo(-10, 10);
        graphics.close();
        graphics.fill();
        var accept = UIManager_1.uimanager.createButton(explanation, "\u6211\u53ef\u4ee5", -242, -70, 202, 60, UIManager_1.BUTTON_COLORS.yellow, function() {
          return _this.acknowledgeRoundRescue();
        }, 26);
        accept.name = "roundRescueAccept";
        var acceptButton = accept.getComponent(cc.Button);
        acceptButton.interactable = false;
        var countdownState = {
          progress: 1,
          started: false,
          redraw: null
        };
        this.roundRescueCountdownState = countdownState;
        var updateCountdown = function() {
          if (!cc.isValid(ring) || _this.roundRescueCountdownState !== countdownState) return;
          _this.drawRoundRescueCountdown(ring, countdownState.progress);
          var text = Math.max(0, Math.ceil(10 * countdownState.progress)) + "\u79d2";
          countdownLabel.string !== text && (countdownLabel.string = text);
        };
        countdownState.redraw = updateCountdown;
        updateCountdown();
        cc.tween(wash).to(.12, {
          opacity: 48
        }, {
          easing: "sineOut"
        }).to(.28, {
          opacity: 0
        }, {
          easing: "sineInOut"
        }).start();
        cc.tween(drawer).to(.34, {
          x: dockX
        }, {
          easing: "sineOut"
        }).call(function() {
          if (_this.roundRescuePrompt !== prompt || !cc.isValid(prompt)) return;
          cc.tween(mask).to(.18, {
            opacity: 178
          }, {
            easing: "sineInOut"
          }).start();
          cc.tween(explanation).to(.18, {
            opacity: 255
          }, {
            easing: "sineOut"
          }).call(function() {
            if (_this.roundRescuePrompt !== prompt || !cc.isValid(prompt)) return;
            _this.roundRescueInteractive = true;
            iconButton.interactable = true;
            acceptButton.interactable = true;
            countdownState.started = true;
          }).start();
        }).start();
      };
      ZyxGame.prototype.refreshRoundRescueLayout = function() {
        var prompt = this.roundRescuePrompt;
        if (!prompt) return;
        var canvas = this.node;
        while (canvas.parent && !canvas.getComponent(cc.Canvas)) canvas = canvas.parent;
        var bottomLeft = prompt.convertToNodeSpaceAR(canvas.convertToWorldSpaceAR(cc.v2(-cc.winSize.width / 2, -cc.winSize.height / 2)));
        var topRight = prompt.convertToNodeSpaceAR(canvas.convertToWorldSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2)));
        for (var _i = 0, _a = [ "roundRescueMask", "roundRescueLight" ]; _i < _a.length; _i++) {
          var name = _a[_i];
          var layer = prompt.getChildByName(name);
          layer.setPosition((bottomLeft.x + topRight.x) / 2, (bottomLeft.y + topRight.y) / 2);
          layer.setContentSize(topRight.x - bottomLeft.x, topRight.y - bottomLeft.y);
        }
        var drawer = prompt.getChildByName("roundRescueDrawer");
        drawer.y = Math.min(150, .1 * this.node.height);
        this.roundRescueInteractive && (drawer.x = this.node.width / 2 - 66);
      };
      ZyxGame.prototype.acknowledgeRoundRescue = function() {
        var _this = this;
        if (!this.roundRescueGuideVisible || !this.roundRescueInteractive || !this.roundRescuePrompt) return;
        this.roundRescueInteractive = false;
        var prompt = this.roundRescuePrompt;
        var drawer = prompt.getChildByName("roundRescueDrawer");
        var explanation = drawer.getChildByName("roundRescueExplanation");
        var mask = prompt.getChildByName("roundRescueMask");
        cc.Tween.stopAllByTarget(explanation);
        cc.tween(explanation).to(.26, {
          x: this.node.width / 2 - drawer.x + 440
        }, {
          easing: "sineIn"
        }).call(function() {
          if (_this.roundRescuePrompt !== prompt || !cc.isValid(prompt)) return;
          explanation.destroy();
          cc.tween(mask).to(.18, {
            opacity: 0
          }, {
            easing: "sineInOut"
          }).call(function() {
            if (_this.roundRescuePrompt !== prompt || !cc.isValid(prompt)) return;
            mask.active = false;
            _this.roundRescueGuideVisible = false;
            _this.roundRescueInteractive = true;
            _this.idleSeconds = 0;
          }).start();
        }).start();
      };
      ZyxGame.prototype.drawRoundRescueLightning = function(node) {
        var graphics = node.addComponent(cc.Graphics);
        graphics.fillColor = new cc.Color(105, 70, 58, 78);
        graphics.circle(2, -4, 43);
        graphics.fill();
        graphics.fillColor = new cc.Color(91, 181, 128, 255);
        graphics.circle(0, 0, 43);
        graphics.fill();
        graphics.strokeColor = new cc.Color(218, 246, 207, 255);
        graphics.lineWidth = 4;
        graphics.circle(0, 0, 40);
        graphics.stroke();
        graphics.fillColor = new cc.Color(255, 224, 99, 255);
        graphics.moveTo(7, 31);
        graphics.lineTo(-17, 2);
        graphics.lineTo(-4, 2);
        graphics.lineTo(-12, -31);
        graphics.lineTo(20, 7);
        graphics.lineTo(6, 7);
        graphics.close();
        graphics.fill();
        graphics.strokeColor = new cc.Color(255, 249, 221, 255);
        graphics.lineWidth = 3;
        graphics.moveTo(7, 31);
        graphics.lineTo(-17, 2);
        graphics.lineTo(-4, 2);
        graphics.lineTo(-12, -31);
        graphics.lineTo(20, 7);
        graphics.lineTo(6, 7);
        graphics.close();
        graphics.stroke();
      };
      ZyxGame.prototype.drawRoundRescueCountdown = function(node, progress) {
        var graphics = node.getComponent(cc.Graphics) || node.addComponent(cc.Graphics);
        var safeProgress = Math.max(0, Math.min(1, progress));
        graphics.clear();
        graphics.lineCap = cc.Graphics.LineCap.ROUND;
        graphics.strokeColor = new cc.Color(86, 59, 51, 94);
        graphics.lineWidth = 9;
        graphics.circle(0, 0, 53);
        graphics.stroke();
        if (safeProgress <= 0) return;
        graphics.strokeColor = safeProgress > .34 ? new cc.Color(255, 214, 96, 255) : new cc.Color(255, 104, 78, 255);
        graphics.lineWidth = 9;
        graphics.arc(0, 0, 53, Math.PI / 2, Math.PI / 2 - 2 * Math.PI * safeProgress, false);
        graphics.stroke();
      };
      ZyxGame.prototype.handleRoundRescueClick = function() {
        var _this = this;
        if (this.warmBalloonActive) {
          this.showHeartMessage();
          return;
        }
        if ("flying" !== this.balloonPhase || this.locked || this.rewardedAdLoading) return;
        this.balloonPhase = "dialog";
        var balloon = this.rescueBalloon;
        this.markInteraction();
        this.setToolSelectionMode(null);
        var resume = function() {
          if (_this.rescueBalloon !== balloon || "dialog" !== _this.balloonPhase) return;
          _this.balloonModal = null;
          _this.balloonPhase = "flying";
          _this.idleSeconds = 0;
        };
        var decorate = function(button, faceIndex) {
          var label = button.children.find(function(child) {
            return !!child.getComponent(cc.Label);
          });
          if (label) {
            label.x = -22;
            label.width = 132;
          }
          var face = MoodArt_1.drawMoodFace(button, faceIndex, 42, MoodArt_1.MOOD_COLORS.cocoa);
          face.name = 26 === faceIndex ? "arrogantBlockFace" : "pitifulBlockFace";
          face.setPosition(64, 2);
        };
        this.balloonModal = UIManager_1.uimanager.showModal("\u6c14\u7403\u70b8\u5f39", "video" === ShareReward_1.getRewardOfferIcon("rescue") ? "\u89c2\u770b\u89c6\u9891\u5373\u53ef\u5feb\u901f\u6d88\u9664" : "\u5206\u4eab\u597d\u53cb\u5373\u53ef\u5feb\u901f\u6d88\u9664", [ {
          text: "\u624d\u4e0d\u8981",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: resume,
          icon: function(button) {
            return decorate(button, 26);
          }
        }, {
          text: "\u5e2e\u5e2e\u6211",
          color: UIManager_1.BUTTON_COLORS.green,
          icon: function(button) {
            return decorate(button, 29);
          },
          onClick: function() {
            _this.balloonModal = null;
            _this.requestRoundRescue();
          }
        } ], function(panel, centerY) {
          UIManager_1.uimanager.createLabel(panel, "\u968f\u673a\u6295\u5f39\uff0c\u70b8\u5f00\u5468\u56f4\u8272\u5757", 0, centerY + 4, 21, MoodArt_1.MOOD_COLORS.cocoaSoft, 410, 32);
        }, 36, true, true, 560, {
          onDismiss: resume
        });
      };
      ZyxGame.prototype.handleScreenClearRescueClick = function() {
        var _this = this;
        var prompt = this.roundRescuePrompt;
        if (!prompt || !this.roundRescueInteractive || "flying" !== this.balloonPhase || this.locked || this.rewardedAdLoading) return;
        this.balloonPhase = "dialog";
        this.markInteraction();
        this.setToolSelectionMode(null);
        this.roundRescueInteractive = false;
        var drawer = prompt.getChildByName("roundRescueDrawer");
        var mask = prompt.getChildByName("roundRescueMask");
        cc.Tween.stopAllByTarget(drawer);
        cc.Tween.stopAllByTarget(mask);
        var explanation = drawer.getChildByName("roundRescueExplanation");
        explanation && cc.Tween.stopAllByTarget(explanation);
        cc.tween(drawer).to(.28, {
          x: mask.x + mask.width / 2 + 480
        }, {
          easing: "sineIn"
        }).call(function() {
          if (_this.roundRescuePrompt !== prompt || "dialog" !== _this.balloonPhase) return;
          cc.tween(mask).to(.18, {
            opacity: 0
          }).call(function() {
            if (_this.roundRescuePrompt !== prompt || "dialog" !== _this.balloonPhase) return;
            prompt.active = false;
            _this.requestRoundRescue();
          }).start();
        }).start();
      };
      ZyxGame.prototype.dismissRoundRescuePrompt = function(animated) {
        ZyxGameModule_1.zyxGameModule.dismissBalloonRescue();
        this.warmBalloonActive && ZyxGameModule_1.zyxGameModule.dismissHeartRescue();
        this.warmBalloonActive = false;
        this.rescueBalloon && this.rescueBalloon.dispose();
        this.rescueBalloon = null;
        this.balloonPhase = "none";
        this.balloonModal && cc.isValid(this.balloonModal) && this.balloonModal.destroy();
        this.balloonModal = null;
        this.balloonInputShield && cc.isValid(this.balloonInputShield) && this.balloonInputShield.destroy();
        this.balloonInputShield = null;
        var prompt = this.roundRescuePrompt;
        this.roundRescuePrompt = null;
        this.roundRescueCountdownState = null;
        this.roundRescueInteractive = this.roundRescueGuideVisible = false;
        if (!prompt || !cc.isValid(prompt)) return;
        var drawer = prompt.getChildByName("roundRescueDrawer");
        var mask = prompt.getChildByName("roundRescueMask");
        var explanation = drawer.getChildByName("roundRescueExplanation");
        for (var _i = 0, _a = [ prompt, drawer, mask, explanation, prompt.getChildByName("roundRescueLight") ]; _i < _a.length; _i++) {
          var node = _a[_i];
          node && cc.Tween.stopAllByTarget(node);
        }
        if (!animated) {
          prompt.destroy();
          return;
        }
        cc.tween(drawer).to(.28, {
          x: mask.x + mask.width / 2 + 480
        }, {
          easing: "sineIn"
        }).call(function() {
          if (!cc.isValid(prompt)) return;
          cc.tween(mask).to(.18, {
            opacity: 0
          }).call(function() {
            cc.isValid(prompt) && prompt.destroy();
          }).start();
        }).start();
      };
      ZyxGame.prototype.requestRoundRescue = function() {
        var _this = this;
        if (this.rewardedAdLoading || "dialog" !== this.balloonPhase || !this.rescueBalloon && !this.roundRescuePrompt) return;
        var balloon = this.rescueBalloon;
        var prompt = this.roundRescuePrompt;
        this.balloonPhase = "sharing";
        this.rewardedAdLoading = true;
        var shield = new cc.Node("balloonInputShield");
        shield.setContentSize(2 * this.node.width, 2 * this.node.height);
        shield.zIndex = 1900;
        shield.addComponent(cc.BlockInputEvents);
        this.node.addChild(shield);
        this.balloonInputShield = shield;
        this.showRewardOffer(function(rewarded) {
          if (!cc.isValid(_this.node) || _this.rescueBalloon !== balloon || _this.roundRescuePrompt !== prompt || "sharing" !== _this.balloonPhase) return;
          _this.rewardedAdLoading = false;
          if (!rewarded) {
            _this.balloonPhase = "flying";
            shield.destroy();
            _this.balloonInputShield = null;
            if (prompt) {
              prompt.active = true;
              _this.roundRescueInteractive = true;
              _this.refreshRoundRescueLayout();
              var mask = prompt.getChildByName("roundRescueMask");
              mask.active = _this.roundRescueGuideVisible;
              mask.opacity = _this.roundRescueGuideVisible ? 178 : 0;
            }
            _this.idleSeconds = 0;
            UIManager_1.uimanager.showToast(ShareReward_1.getRewardOfferFailToast("rescue"));
            return;
          }
          balloon ? _this.applyRoundRescue() : _this.applyScreenClearRescue();
        });
      };
      ZyxGame.prototype.applyScreenClearRescue = function() {
        var _this = this;
        var previousScore = ZyxGameModule_1.zyxGameModule.score;
        var ids = ZyxGameModule_1.zyxGameModule.applyClearRescue();
        this.dismissRoundRescuePrompt(false);
        if (!ids) return;
        this.locked = true;
        this.playEmergencyClearEffect(ids, function() {
          _this.playToolScoreFeedback(ZyxGameModule_1.zyxGameModule.score - previousScore);
          _this.resolveStableBoard(function() {
            _this.updateHud();
            _this.appendNextRowAndResolve(false);
          });
        });
      };
      ZyxGame.prototype.applyRoundRescue = function() {
        var _this = this;
        var balloon = this.rescueBalloon;
        if (!balloon) return;
        this.locked = true;
        var warm = this.warmBalloonActive;
        this.balloonPhase = "bombing";
        var targets = ZyxGameModule_1.zyxGameModule.getBalloonTargets().map(function(piece) {
          return __assign({}, piece);
        });
        var origin = this.pieceLayer.convertToNodeSpaceAR(balloon.root.convertToWorldSpaceAR(cc.v2(0, -54)));
        var lastLanding = 0;
        var drops = [];
        targets.forEach(function(piece, index) {
          var center = _this.getPiecePosition(piece.row, piece.col, piece.size);
          var bomb = warm ? HeartEffect_1.createHeartToken(_this.pieceLayer, 34) : RewardArt_1.createBombBadge(_this.pieceLayer);
          bomb.name = warm ? "balloonDroppedHeart" : "balloonDroppedBomb";
          bomb.zIndex = 150;
          bomb.opacity = 0;
          bomb.setPosition(origin);
          drops.push(bomb);
          var state = {
            progress: 0
          };
          var delay = .13 * index;
          var flight = .7 + Math.abs(center.y - origin.y) / (ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE) * .25;
          lastLanding = Math.max(lastLanding, delay + flight);
          cc.tween(state).delay(delay).to(flight, {
            progress: 1
          }, {
            onUpdate: function() {
              if (!cc.isValid(bomb)) return;
              var t = state.progress;
              bomb.opacity = 255;
              bomb.setPosition(RescueBalloon_1.getBalloonBombPosition(origin, center, t));
              bomb.angle = Math.sin(t * Math.PI) * (index % 2 ? -28 : 28);
            }
          }).start();
        });
        this.scheduleOnce(function() {
          if (_this.rescueBalloon !== balloon) return;
          var result = warm ? ZyxGameModule_1.zyxGameModule.applyHeartRescue() : ZyxGameModule_1.zyxGameModule.applyBalloonRescue();
          drops.forEach(function(drop) {
            cc.isValid(drop) && drop.destroy();
          });
          if (!result) {
            _this.dismissRoundRescuePrompt(false);
            return;
          }
          if (warm) {
            (result.detonatedBombs || []).forEach(function(piece) {
              return HeartEffect_1.playHeartWave(_this.pieceLayer, _this.getPiecePosition(piece.row, piece.col, piece.size), ZyxGameModule_1.CELL_SIZE);
            });
            _this.playMoodCollect(result.removedPieceIds);
            _this.animatePieceRemoval(result.removedPieceIds, function() {});
            GameSettings_1.gameSettings.vibrateLight();
          } else {
            (result.detonatedBombs || []).forEach(function(piece, index) {
              BombEffect_1.playBombEffect(_this.pieceLayer, _this.getPiecePosition(piece.row, piece.col, piece.size), ZyxGameModule_1.CELL_SIZE, 0, function() {
                if (0 === index) {
                  AudioManager_1.audioManager.playSound("bomb");
                  GameSettings_1.gameSettings.vibrateLight();
                }
              }, true);
            });
            _this.animateRowShatter(result.removedPieceIds, result.detonatedBombs, true);
          }
          _this.playToolScoreFeedback(result.gainedScore);
          balloon.fadeOut();
          _this.scheduleOnce(function() {
            _this.resolveStableBoard(function() {
              _this.dismissRoundRescuePrompt(false);
              _this.appendNextRowAndResolve(false);
            });
          }, BombEffect_1.bombPlaybackDuration(1));
        }, lastLanding + .2);
      };
      ZyxGame.prototype.createRoundRescueShade = function(parent, name, color) {
        if (!rescueShadeFrame) {
          var texture = new cc.Texture2D();
          texture.initWithData(new Uint8Array([ 255, 255, 255, 255 ]), cc.Texture2D.PixelFormat.RGBA8888, 1, 1);
          rescueShadeFrame = new cc.SpriteFrame(texture);
        }
        var layer = new cc.Node(name);
        parent.addChild(layer);
        var sprite = layer.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        sprite.spriteFrame = rescueShadeFrame;
        layer.color = color;
        layer.opacity = 0;
        return layer;
      };
      ZyxGame.prototype.updateBoardDangerState = function() {
        if (ZyxGameModule_1.zyxGameModule.hasEnteredRescueZone(2)) {
          this.startBoardDangerGlow();
          ZyxGameModule_1.zyxGameModule.canOfferHeartRescue() && (this.rescueBalloon || this.roundRescuePrompt) && this.dismissRoundRescuePrompt(false);
        } else this.stopBoardDangerGlow();
      };
      ZyxGame.prototype.startBoardDangerGlow = function() {
        if (this.boardDangerHalo && cc.isValid(this.boardDangerHalo)) return;
        if (!this.boardRoot || !cc.isValid(this.boardRoot)) return;
        this.dangerSeconds = 0;
        this.boardDangerHalo = DangerGlow_1.createDangerGlow(this.node, ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE, ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE);
        this.boardDangerHalo.setPosition(this.boardRoot.x, this.layout.boardY);
      };
      ZyxGame.prototype.showWarmHeartBalloon = function() {
        var _this = this;
        this.dismissRoundRescuePrompt(false);
        var elapsedMs = Math.max(0, Date.now() - ZyxGameModule_1.zyxGameModule.roundStartedAt);
        if (!ZyxGameModule_1.zyxGameModule.offerHeartRescue(elapsedMs)) return;
        this.warmBalloonActive = true;
        this.balloonPhase = "flying";
        this.rescueBalloon = new RescueBalloon_1.RescueBalloon(this.boardRoot, ZyxGameModule_1.CELL_SIZE, function() {
          return _this.handleRoundRescueClick();
        }, true);
      };
      ZyxGame.prototype.showHeartMessage = function() {
        var _this = this;
        if (!this.warmBalloonActive || "flying" !== this.balloonPhase || this.locked) return;
        this.markInteraction();
        this.setToolSelectionMode(null);
        this.balloonPhase = "dialog";
        var day = 864e5;
        var registered = Date.parse(ZyxGameModule_1.zyxGameModule.registeredAt);
        var today = Math.floor((Date.now() + 288e5) / day);
        var first = Number.isFinite(registered) ? Math.floor((registered + 288e5) / day) : today;
        var days = Math.max(1, today - first + 1);
        this.balloonModal = HeartMessage_1.showHeartLetter(days, function() {
          _this.balloonModal = null;
          _this.applyRoundRescue();
        });
      };
      ZyxGame.prototype.stopBoardDangerGlow = function() {
        var halo = this.boardDangerHalo;
        this.boardDangerHalo = null;
        this.dangerSeconds = 0;
        if (!halo || !cc.isValid(halo)) return;
        cc.Tween.stopAllByTarget(halo);
        halo.destroy();
      };
      ZyxGame.prototype.updateHud = function() {
        this.rankChase && this.rankChase.updateScore(ZyxGameModule_1.zyxGameModule.score);
        var isNewRecord = ZyxGameModule_1.zyxGameModule.score > ZyxGameModule_1.zyxGameModule.startingBestScore;
        var scoreColor = isNewRecord ? MoodArt_1.MOOD_COLORS.coral : HUD_VALUE_COLOR;
        this.setLabelTone(this.scoreLabel, scoreColor, 1.1);
        this.setLabelTone(this.bestLabel, HUD_LABEL_COLOR, 1.1);
        this.updateHudNumber(this.scoreLabel, ZyxGameModule_1.zyxGameModule.score);
        this.bestLabel.string = "\u6700\u9ad8 " + BeanCollectionHud_1.formatHudScore(ZyxGameModule_1.zyxGameModule.bestScore);
        this.scoreLabel.fontSize = this.scoreLabel.string.length >= 6 ? 34 : 46;
        this.updateRecordTag(isNewRecord);
        var hammerColor = this.hammerMode ? UIManager_1.BUTTON_COLORS.green : UIManager_1.BUTTON_COLORS.yellow;
        UIManager_1.uimanager.drawButtonSurface(this.hammerButton, TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, hammerColor, 23);
        this.hammerIcon && (this.hammerIcon.angle = this.hammerMode ? -8 : 0);
        this.hammerCountLabel && (this.hammerCountLabel.string = ZyxGameModule_1.zyxGameModule.hammerCount > 0 ? String(ZyxGameModule_1.zyxGameModule.hammerCount) : "+");
        var purifierColor = this.purifierMode ? UIManager_1.BUTTON_COLORS.yellow : UIManager_1.BUTTON_COLORS.green;
        UIManager_1.uimanager.drawButtonSurface(this.purifierButton, TOOL_BUTTON_SIZE, TOOL_BUTTON_SIZE, purifierColor, 23);
        this.purifierIcon && (this.purifierIcon.angle = this.purifierMode ? -8 : 0);
        this.purifierCountLabel && (this.purifierCountLabel.string = ZyxGameModule_1.zyxGameModule.colorPurifierCount > 0 ? String(ZyxGameModule_1.zyxGameModule.colorPurifierCount) : "+");
        for (var _i = 0, _a = [ [ this.hammerButton, this.hammerCountLabel, 0 === ZyxGameModule_1.zyxGameModule.hammerCount && ZyxGameModule_1.zyxGameModule.roundToolClaims.hammer >= 3 ], [ this.purifierButton, this.purifierCountLabel, 0 === ZyxGameModule_1.zyxGameModule.colorPurifierCount && ZyxGameModule_1.zyxGameModule.roundToolClaims.magicWand >= 1 ] ]; _i < _a.length; _i++) {
          var _b = _a[_i], button = _b[0], label = _b[1], exhausted = _b[2];
          button.getChildByName("toolUsedShade").active = exhausted;
          label.node.parent.active = !exhausted;
        }
        var toolOpacity = this.isTutorialGuidedStep() ? 118 : 255;
        this.hammerButton && (this.hammerButton.opacity = toolOpacity);
        this.purifierButton && (this.purifierButton.opacity = toolOpacity);
      };
      ZyxGame.prototype.setLabelTone = function(label, color, outlineWidth) {
        if (!label || !label.node) return;
        label.node.color = color;
        this.makeLabelBold(label);
      };
      ZyxGame.prototype.updateHudNumber = function(label, value) {
        if (!label || !label.node) return;
        var nextValue = BeanCollectionHud_1.formatHudScore(value);
        if (label.string === nextValue) return;
        label.string = nextValue;
        var node = label.node;
        cc.Tween.stopAllByTarget(node);
        node.scale = 1;
        var pulseScale = nextValue.length >= 5 ? 1.04 : 1.14;
        cc.tween(node).to(.1, {
          scale: pulseScale
        }, {
          easing: "quadOut"
        }).to(.12, {
          scale: .97
        }, {
          easing: "quadInOut"
        }).to(.12, {
          scale: 1
        }, {
          easing: "backOut"
        }).start();
      };
      ZyxGame.prototype.updateRecordTag = function(isNewRecord) {
        if (!this.recordTagLabel) return;
        this.recordTagLabel.string = isNewRecord ? "\u672c\u5c40\u65b0\u7eaa\u5f55" : "\u672c\u5c40\u5f97\u5206";
        this.recordTagLabel.node.color = isNewRecord ? MoodArt_1.MOOD_COLORS.coral : HUD_LABEL_COLOR;
      };
      ZyxGame.prototype.movePiece = function(id, offset) {
        if (this.locked) return;
        if (this.hammerMode || this.purifierMode) {
          this.renderBoard();
          this.hammerMode && UIManager_1.uimanager.showToast("\u89e3\u538b\u9524\u5df2\u5c31\u7eea\uff0c\u8bf7\u70b9\u4e00\u4e0b\u76ee\u6807\u683c\u5b50");
          this.purifierMode && UIManager_1.uimanager.showToast("\u9b54\u6cd5\u68d2\u5df2\u5c31\u7eea\uff0c\u8bf7\u70b9\u4e00\u4e0b\u76ee\u6807\u989c\u8272");
          return;
        }
        if (this.isTutorialGuidedStep()) {
          var expected = ZyxGameModule_1.zyxGameModule.getTutorialMove(this.tutorialStep);
          if (!expected || expected.id !== id) {
            var size = expected ? expected.pieceSize : 1;
            this.showTutorialCorrection("\u8fd9\u5757\u5148\u4f11\u606f\u4e00\u4e0b\u5427\uff5e\u8bf7\u62d6\u52a8\u4eae\u4eae\u7684 " + size + " \u683c\u5757\uff0c\u8ddf\u7740\u5c0f\u624b\u8d70\uff01", true);
            return;
          }
          if (expected.offset !== offset) {
            this.showTutorialCorrection("\u65b9\u5411\u5dee\u4e00\u70b9\u70b9\uff5e\u8ddf\u7740\u5c0f\u624b\u628a\u4eae\u4eae\u7684\u8272\u5757\u62d6\u8fc7\u53bb\u5427\uff01", true);
            return;
          }
          this.cancelTutorialRestore();
          this.clearTutorialMoveGuide(2 === this.tutorialStep);
          if (!ZyxGameModule_1.zyxGameModule.movePiece(id, offset)) {
            this.showTutorialCorrection("\u5dee\u4e00\u70b9\u70b9\u5c31\u5230\u5566\uff5e\u628a\u4eae\u4eae\u7684\u8272\u5757\u5b8c\u6574\u653e\u8fdb\u7a7a\u4f4d\u5427\uff01", true);
            return;
          }
          AudioManager_1.audioManager.playSound("move");
          this.resolveTutorialTurn();
          return;
        }
        if (!ZyxGameModule_1.zyxGameModule.movePiece(id, offset)) {
          this.renderBoard();
          return;
        }
        AudioManager_1.audioManager.playSound("move");
        this.resolveTurn();
      };
      ZyxGame.prototype.tapPiece = function(id) {
        if (this.locked) return;
        if (this.isTutorialGuidedStep()) {
          var expected = ZyxGameModule_1.zyxGameModule.getTutorialMove(this.tutorialStep);
          var size = expected ? expected.pieceSize : 1;
          this.showTutorialCorrection("\u8f7b\u8f7b\u6309\u4f4f\u4eae\u4eae\u7684 " + size + " \u683c\u5757\uff0c\u518d\u8ddf\u7740\u5c0f\u624b\u62d6\u4e00\u5c0f\u6b65\u54e6\uff5e", true);
          return;
        }
        if (this.purifierMode) {
          this.useColorPurifierTool(id);
          return;
        }
        if (!this.hammerMode && ZyxGameModule_1.zyxGameModule.getPiece(id) && ZyxGameModule_1.zyxGameModule.getPiece(id).bomb) {
          this.useBomb(id);
          return;
        }
        if (!this.hammerMode) {
          UIManager_1.uimanager.showToast("\u6309\u4f4f\u8272\u5757\u5de6\u53f3\u62d6\u52a8");
          return;
        }
        this.useReliefTool(id);
      };
      ZyxGame.prototype.useBomb = function(id) {
        var _this = this;
        if (this.locked || this.settlementReported) return;
        var piece = ZyxGameModule_1.zyxGameModule.getPiece(id);
        if (!piece) return;
        var blast = ZyxGameModule_1.zyxGameModule.detonateBomb(id);
        if (!blast) return;
        this.locked = true;
        this.markInteraction();
        this.animateBombBlasts(blast);
        this.animateRowShatter(blast.removedPieceIds, blast.detonatedBombs);
        this.playToolScoreFeedback(blast.gainedScore);
        this.scheduleOnce(function() {
          return _this.resolveStableBoard(function() {
            return _this.appendNextRowAndResolve();
          });
        }, BombEffect_1.bombResolutionDelay((blast.detonatedBombs || []).length));
      };
      ZyxGame.prototype.animateBombBlasts = function(result) {
        var _this = this;
        var bombs = result.detonatedBombs || [];
        if (bombs.length) {
          this.bombAnimationLocks++;
          this.scheduleOnce(function() {
            _this.bombAnimationLocks--;
          }, BombEffect_1.bombPlaybackDuration(bombs.length));
        }
        bombs.forEach(function(bomb, index) {
          var original = _this.pieceLayer.getChildByName("piece_" + bomb.id);
          var badge = original && original.getChildByName("bombBadge");
          badge && cc.tween(badge).delay(index * BombEffect_1.BOMB_CHAIN_INTERVAL).to(.025, {
            opacity: 0
          }).start();
          var center = _this.getPiecePosition(bomb.row, bomb.col, bomb.size);
          BombEffect_1.playBombEffect(_this.pieceLayer, center, ZyxGameModule_1.CELL_SIZE, index * BombEffect_1.BOMB_CHAIN_INTERVAL, function() {
            AudioManager_1.audioManager.playSound("bomb");
            GameSettings_1.gameSettings.vibrateLight();
          });
        });
      };
      ZyxGame.prototype.completePlayerAction = function() {
        var rewards = ZyxGameModule_1.zyxGameModule.finishPlayerAction();
        for (var _i = 0, rewards_1 = rewards; _i < rewards_1.length; _i++) {
          var bomb = rewards_1[_i];
          if (bomb.lightning) continue;
          var node = this.pieceLayer.getChildByName("piece_" + bomb.id);
          node ? this.decorateBombPiece(node, bomb) : this.createPieceView(bomb);
        }
        rewards.some(function(piece) {
          return piece.lightning;
        }) && this.renderBoard();
        this.restoreDefaultPlayTip();
        this.renderNextRow();
        this.updateHud();
        this.captureProgress();
      };
      ZyxGame.prototype.useReliefTool = function(id) {
        return __awaiter(this, void 0, Promise, function() {
          var result, previousScore;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.locked || !ZyxGameModule_1.zyxGameModule.getPiece(id)) return [ 2 ];
              this.locked = true;
              return [ 4, this.confirmToolUse("hammer", id, function() {
                return _this.useReliefTool(id);
              }) ];

             case 1:
              result = _a.sent();
              if (!result || !this.node || !cc.isValid(this.node)) return [ 2 ];
              ZyxGameModule_1.zyxGameModule.applyCloudProfile(result.profile);
              ZyxGameModule_1.zyxGameModule.hammerCount++;
              previousScore = ZyxGameModule_1.zyxGameModule.score;
              if (!ZyxGameModule_1.zyxGameModule.useHammer(id)) {
                UIManager_1.uimanager.showToast("\u672c\u5c40\u89e3\u538b\u9524\u5df2\u7ecf\u7528\u5b8c");
                this.setToolSelectionMode(null);
                return [ 2 ];
              }
              this.setToolSelectionMode(null);
              this.markInteraction();
              AudioManager_1.audioManager.playSound("hammer");
              GameSettings_1.gameSettings.vibrateLight();
              UIManager_1.uimanager.showToast("\u8fd9\u4e2a\u5fc3\u7ed3\u5df2\u7ecf\u6572\u5f00\u4e86");
              this.playToolScoreFeedback(ZyxGameModule_1.zyxGameModule.score - previousScore);
              this.resolveTurn([ id ], true);
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.useColorPurifierTool = function(id) {
        return __awaiter(this, void 0, Promise, function() {
          var piece, colorIndex, result, previousScore, removedPieceIds;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.locked) return [ 2 ];
              piece = ZyxGameModule_1.zyxGameModule.getPiece(id);
              if (!piece) return [ 2 ];
              colorIndex = piece.color;
              this.locked = true;
              return [ 4, this.confirmToolUse("magicWand", colorIndex, function() {
                return _this.useColorPurifierTool(id);
              }) ];

             case 1:
              result = _a.sent();
              if (!result || !this.node || !cc.isValid(this.node)) return [ 2 ];
              ZyxGameModule_1.zyxGameModule.applyCloudProfile(result.profile);
              ZyxGameModule_1.zyxGameModule.colorPurifierCount++;
              previousScore = ZyxGameModule_1.zyxGameModule.score;
              removedPieceIds = ZyxGameModule_1.zyxGameModule.useColorPurifier(colorIndex);
              if (0 === removedPieceIds.length) {
                UIManager_1.uimanager.showToast("\u672c\u5c40\u9b54\u6cd5\u68d2\u5df2\u7ecf\u7528\u5b8c");
                this.setToolSelectionMode(null);
                return [ 2 ];
              }
              this.setToolSelectionMode(null);
              this.markInteraction();
              this.locked = true;
              AudioManager_1.audioManager.playSound("magicWand");
              GameSettings_1.gameSettings.vibrateLight();
              UIManager_1.uimanager.showToast(MoodArt_1.getMoodName(colorIndex) + "\u8272\u5757\u5df2\u5168\u90e8\u51c0\u7a7a");
              this.playToolScoreFeedback(ZyxGameModule_1.zyxGameModule.score - previousScore);
              this.animateColorPurifierRemoval(removedPieceIds, colorIndex, function() {
                _this.resolveStableBoard(function() {
                  return _this.appendNextRowAndResolve();
                });
              });
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.confirmToolUse = function(item, target, retry) {
        return __awaiter(this, void 0, Promise, function() {
          var result, error_1;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              _a.trys.push([ 0, 2, , 3 ]);
              return [ 4, CloudService_1.cloudService.useTool(ZyxGameModule_1.zyxGameModule.cloudRoundId, item, ZyxGameModule_1.zyxGameModule.roundActions.length, target, RoundProgress_1.roundProgress.token) ];

             case 1:
              result = _a.sent();
              ZyxGameModule_1.zyxGameModule.applyRoundTools(result.roundTools);
              RoundProgress_1.roundProgress.updateTools(result.roundTools);
              return [ 2, result ];

             case 2:
              error_1 = _a.sent();
              if (!this.node || !cc.isValid(this.node)) return [ 2, null ];
              if (error_1 && "ROUND_SESSION_CONFLICT" === error_1.businessCode) {
                RoundProgress_1.roundProgress.invalidateSession();
                return [ 2, null ];
              }
              if (error_1 && [ "TOOL_INSUFFICIENT", "ROUND_NOT_ACTIVE", "TOOL_PAYLOAD_CONFLICT", "TOOL_REQUEST_INVALID", "ACCOUNT_CHANGED" ].indexOf(error_1.businessCode) >= 0) {
                this.locked = false;
                this.setToolSelectionMode(null);
                UIManager_1.uimanager.showToast(error_1.message);
                return [ 2, null ];
              }
              UIManager_1.uimanager.showModal("\u9053\u5177\u5f85\u786e\u8ba4", "\u7f51\u7edc\u6682\u672a\u786e\u8ba4\u8fd9\u6b21\u4f7f\u7528\uff0c\u91cd\u65b0\u786e\u8ba4\u540e\u7ee7\u7eed\u3002\u4e0d\u4f1a\u91cd\u590d\u6263\u9664\u9053\u5177\u3002", [ {
                text: "\u91cd\u65b0\u786e\u8ba4",
                color: UIManager_1.BUTTON_COLORS.green,
                onClick: function() {
                  _this.locked = false;
                  retry();
                }
              } ]);
              return [ 2, null ];

             case 3:
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.confirmRewardedTool = function(item) {
        return __awaiter(this, void 0, Promise, function() {
          var key, claim, result, error_2;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              key = "zyx_tool_reward_" + item;
              try {
                claim = cc.sys.localStorage.getItem(key);
                if (!claim || 0 !== claim.indexOf(ZyxGameModule_1.zyxGameModule.cloudRoundId + ":")) {
                  claim = ZyxGameModule_1.zyxGameModule.cloudRoundId + ":reward:" + item + ":" + Date.now();
                  cc.sys.localStorage.setItem(key, claim);
                }
              } catch (_) {
                this.locked = false;
                UIManager_1.uimanager.showToast("\u5b58\u50a8\u7a7a\u95f4\u4e0d\u8db3\uff0c\u6e05\u7406\u540e\u518d\u9886\u53d6");
                return [ 2 ];
              }
              this.locked = true;
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, , 4 ]);
              return [ 4, CloudService_1.cloudService.claimToolReward(ZyxGameModule_1.zyxGameModule.cloudRoundId, item, claim, RoundProgress_1.roundProgress.token) ];

             case 2:
              result = _a.sent();
              cc.sys.localStorage.removeItem(key);
              ZyxGameModule_1.zyxGameModule.applyCloudProfile(result.profile);
              ZyxGameModule_1.zyxGameModule.applyRoundTools(result.roundTools);
              RoundProgress_1.roundProgress.updateTools(result.roundTools);
              if (this.node && cc.isValid(this.node)) {
                this.locked = false;
                this.updateHud();
                this.setToolSelectionMode(null);
                UIManager_1.uimanager.showToast("\u5df2\u83b7\u5f97\u9053\u5177\uff0c\u70b9\u51fb\u56fe\u6807\u4f7f\u7528");
              }
              return [ 3, 4 ];

             case 3:
              error_2 = _a.sent();
              if (!this.node || !cc.isValid(this.node)) return [ 2 ];
              if (error_2 && "ROUND_SESSION_CONFLICT" === error_2.businessCode) {
                RoundProgress_1.roundProgress.invalidateSession();
                return [ 2 ];
              }
              if (error_2 && [ "TOOL_REWARD_LIMIT", "TOOL_ALREADY_OWNED", "ROUND_NOT_ACTIVE", "TOOL_PAYLOAD_CONFLICT", "TOOL_REQUEST_INVALID", "ACCOUNT_CHANGED" ].indexOf(error_2.businessCode) >= 0) {
                cc.sys.localStorage.removeItem(key);
                this.locked = false;
                UIManager_1.uimanager.showToast(error_2.message);
                return [ 2 ];
              }
              UIManager_1.uimanager.showModal("\u8865\u7ed9\u5f85\u786e\u8ba4", "\u8865\u7ed9\u5df2\u5b8c\u6210\uff0c\u8054\u7f51\u786e\u8ba4\u540e\u5373\u53ef\u4f7f\u7528\u3002", [ {
                text: "\u91cd\u65b0\u786e\u8ba4",
                color: UIManager_1.BUTTON_COLORS.green,
                onClick: function() {
                  return _this.confirmRewardedTool(item);
                }
              } ]);
              return [ 3, 4 ];

             case 4:
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.showHammerInfoModal = function() {
        var _this = this;
        if (this.locked) return;
        if (ZyxGameModule_1.zyxGameModule.hammerCount > 0) {
          this.toggleHammer();
          return;
        }
        if (ZyxGameModule_1.zyxGameModule.roundToolClaims.hammer >= 3) {
          UIManager_1.uimanager.showToast("\u89e3\u538b\u9524\u6bcf\u5c40\u4ec5\u53ef\u83b7\u5f973\u6b21");
          return;
        }
        this.setToolSelectionMode(null);
        this.markInteraction();
        this.locked = true;
        UIManager_1.uimanager.showModal("\u89e3\u538b\u9524", "\u6572\u6389\u9009\u4e2d\u7684\u4e00\u4e2a\u8272\u5757", [ {
          text: "\u5206\u4eab\u83b7\u5f97\uff08" + (3 - ZyxGameModule_1.zyxGameModule.roundToolClaims.hammer) + "/3\uff09",
          color: UIManager_1.BUTTON_COLORS.green,
          icon: function(button) {
            return GlyphFactory_1.decorateActionButton(button, "share");
          },
          onClick: function() {
            _this.locked = false;
            _this.requestRewardedHammer();
          }
        }, {
          text: "\u4e0d\uff0c\u8c22\u8c22",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            _this.locked = false;
          }
        } ], function(panel, centerY) {
          return _this.createHammerToolDemo(panel, centerY);
        }, 148, false, true, 560, {
          onDismiss: function() {
            _this.locked = false;
          }
        });
      };
      ZyxGame.prototype.toggleHammer = function() {
        if (this.locked) return;
        if (ZyxGameModule_1.zyxGameModule.hammerCount <= 0) {
          this.requestRewardedHammer();
          return;
        }
        this.markInteraction();
        var nextMode = this.hammerMode ? null : "hammer";
        this.setToolSelectionMode(nextMode);
        nextMode || UIManager_1.uimanager.showToast("\u5df2\u6536\u8d77\u89e3\u538b\u9524");
      };
      ZyxGame.prototype.requestRewardedHammer = function() {
        var _this = this;
        if (this.locked || this.rewardedAdLoading) return;
        if (ZyxGameModule_1.zyxGameModule.hammerCount > 0) {
          this.setToolSelectionMode("hammer");
          return;
        }
        if (!ZyxGameModule_1.zyxGameModule.pieces.length) {
          UIManager_1.uimanager.showToast("\u5f53\u524d\u6ca1\u6709\u53ef\u7528\u76ee\u6807");
          return;
        }
        var pendingClaim = cc.sys.localStorage.getItem("zyx_tool_reward_hammer");
        if (pendingClaim && 0 === pendingClaim.indexOf(ZyxGameModule_1.zyxGameModule.cloudRoundId + ":")) {
          void this.confirmRewardedTool("hammer");
          return;
        }
        this.markInteraction();
        this.rewardedAdLoading = true;
        this.locked = true;
        this.showRewardOffer(function(rewarded) {
          _this.rewardedAdLoading = false;
          _this.locked = false;
          if (!rewarded) {
            UIManager_1.uimanager.showToast(ShareReward_1.getRewardOfferFailToast("tool", "hammer"));
            return;
          }
          _this.confirmRewardedTool("hammer");
        }, "hammer");
      };
      ZyxGame.prototype.showPurifierInfoModal = function() {
        var _this = this;
        if (this.locked) return;
        if (ZyxGameModule_1.zyxGameModule.colorPurifierCount > 0) {
          this.toggleColorPurifier();
          return;
        }
        if (ZyxGameModule_1.zyxGameModule.roundToolClaims.magicWand >= 1) {
          UIManager_1.uimanager.showToast("\u9b54\u6cd5\u68d2\u6bcf\u5c40\u4ec5\u53ef\u83b7\u5f97\u4e00\u6b21");
          return;
        }
        this.setToolSelectionMode(null);
        this.markInteraction();
        this.locked = true;
        UIManager_1.uimanager.showModal("\u9b54\u6cd5\u68d2", "\u9009\u4e2d\u4e00\u79cd\u989c\u8272\uff0c\u540c\u8272\u8272\u5757\u4e00\u8d77\u6d88\u5931", [ {
          text: "\u89c6\u9891\u83b7\u5f97\uff081/1\uff09",
          color: UIManager_1.BUTTON_COLORS.green,
          icon: function(button) {
            return GlyphFactory_1.decorateActionButton(button, "video");
          },
          onClick: function() {
            _this.locked = false;
            _this.requestRewardedColorPurifier();
          }
        }, {
          text: "\u4e0d\uff0c\u8c22\u8c22",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            _this.locked = false;
          }
        } ], function(panel, centerY) {
          return _this.createMagicWandToolDemo(panel, centerY);
        }, 148, false, true, 560, {
          onDismiss: function() {
            _this.locked = false;
          }
        });
      };
      ZyxGame.prototype.toggleColorPurifier = function() {
        if (this.locked) return;
        if (ZyxGameModule_1.zyxGameModule.colorPurifierCount <= 0) {
          this.requestRewardedColorPurifier();
          return;
        }
        this.markInteraction();
        var nextMode = this.purifierMode ? null : "magicWand";
        this.setToolSelectionMode(nextMode);
        nextMode || UIManager_1.uimanager.showToast("\u5df2\u6536\u8d77\u9b54\u6cd5\u68d2");
      };
      ZyxGame.prototype.requestRewardedColorPurifier = function() {
        var _this = this;
        if (this.locked || this.rewardedAdLoading) return;
        if (ZyxGameModule_1.zyxGameModule.colorPurifierCount > 0) {
          this.setToolSelectionMode("magicWand");
          return;
        }
        if (!ZyxGameModule_1.zyxGameModule.pieces.length) {
          UIManager_1.uimanager.showToast("\u5f53\u524d\u6ca1\u6709\u53ef\u7528\u76ee\u6807");
          return;
        }
        var pendingClaim = cc.sys.localStorage.getItem("zyx_tool_reward_magicWand");
        if (pendingClaim && 0 === pendingClaim.indexOf(ZyxGameModule_1.zyxGameModule.cloudRoundId + ":")) {
          void this.confirmRewardedTool("magicWand");
          return;
        }
        this.markInteraction();
        this.rewardedAdLoading = true;
        this.locked = true;
        this.showRewardOffer(function(rewarded) {
          _this.rewardedAdLoading = false;
          _this.locked = false;
          if (!rewarded) {
            UIManager_1.uimanager.showToast(ShareReward_1.getRewardOfferFailToast("tool"));
            return;
          }
          _this.confirmRewardedTool("magicWand");
        }, "tool");
      };
      ZyxGame.prototype.showRewardOffer = function(onResult, placement) {
        var _this = this;
        void 0 === placement && (placement = "rescue");
        var roundId = ZyxGameModule_1.zyxGameModule.cloudRoundId;
        var token = RoundProgress_1.roundProgress.token;
        ShareReward_1.requestRewardOffer(function(rewarded) {
          if (!_this.node || !cc.isValid(_this.node) || _this.settlementReported || roundId !== ZyxGameModule_1.zyxGameModule.cloudRoundId || token !== RoundProgress_1.roundProgress.token) return;
          onResult(rewarded);
        }, "\u4e00\u6b21\u673a\u4f1a", placement);
      };
      ZyxGame.prototype.markInteraction = function() {
        this.idleSeconds = 0;
        this.cancelEliminationHint();
        this.isTutorialGuidedStep() && this.cancelTutorialHand();
      };
      ZyxGame.prototype.playEliminationHint = function() {
        var _this = this;
        if (this.locked || this.hammerMode || this.purifierMode || this.isTutorialGuidedStep() || !this.pieceLayer) return;
        var hint = ZyxGameModule_1.zyxGameModule.findEliminationHint();
        if (!hint) return;
        var piece = ZyxGameModule_1.zyxGameModule.getPiece(hint.id);
        var node = this.pieceLayer.getChildByName("piece_" + hint.id);
        if (!piece || !node) return;
        this.cancelEliminationHint();
        this.hintPieceId = hint.id;
        var origin = this.getPiecePosition(piece.row, piece.col, piece.size);
        var targetX = origin.x + hint.offset * ZyxGameModule_1.CELL_SIZE;
        this.hintHand = this.createHintHand(this.pieceLayer, origin.x, origin.y + 42);
        var hand = this.hintHand;
        cc.tween(hand).to(.18, {
          y: origin.y + 22,
          scale: .9
        }, {
          easing: "quadOut"
        }).to(.55, {
          x: targetX,
          y: origin.y + 22
        }, {
          easing: "cubicInOut"
        }).to(.13, {
          y: origin.y + 39,
          scale: 1
        }, {
          easing: "backOut"
        }).delay(.24).to(.38, {
          x: origin.x,
          opacity: 0
        }, {
          easing: "quadIn"
        }).call(function() {
          return _this.finishEliminationHint();
        }).start();
        cc.tween(node).delay(.18).to(.55, {
          x: targetX
        }, {
          easing: "cubicInOut"
        }).delay(.2).to(.46, {
          x: origin.x
        }, {
          easing: "cubicInOut"
        }).start();
      };
      ZyxGame.prototype.createHintHand = function(parent, x, y) {
        var node = new cc.Node("eliminationHintHand");
        node.width = 62;
        node.height = 72;
        node.setPosition(x, y);
        node.zIndex = 400;
        parent.addChild(node);
        var halo = new cc.Node("hintHandHalo");
        halo.width = 80;
        halo.height = 80;
        halo.zIndex = -1;
        node.addChild(halo);
        var haloGraphics = halo.addComponent(cc.Graphics);
        haloGraphics.fillColor = new cc.Color(239, 151, 105, 74);
        haloGraphics.circle(0, 0, 34);
        haloGraphics.fill();
        cc.tween(halo).repeatForever(cc.tween().to(.45, {
          scale: 1.18,
          opacity: 80
        }).to(.45, {
          scale: .9,
          opacity: 220
        })).start();
        var g = node.addComponent(cc.Graphics);
        g.fillColor = new cc.Color(80, 55, 49, 38);
        g.circle(5, -7, 21);
        g.fill();
        g.fillColor = new cc.Color(255, 248, 224);
        g.strokeColor = new cc.Color(105, 76, 64);
        g.lineWidth = 2.5;
        g.circle(0, -3, 19);
        g.fill();
        g.stroke();
        g.roundRect(-7, -4, 14, 43, 7);
        g.fill();
        g.stroke();
        g.fillColor = new cc.Color(241, 183, 124);
        g.circle(0, 30, 5);
        g.fill();
        return node;
      };
      ZyxGame.prototype.cancelEliminationHint = function() {
        if (this.hintPieceId > 0 && this.pieceLayer) {
          var piece = ZyxGameModule_1.zyxGameModule.getPiece(this.hintPieceId);
          var node = this.pieceLayer.getChildByName("piece_" + this.hintPieceId);
          if (piece && node) {
            cc.Tween.stopAllByTarget(node);
            node.setPosition(this.getPiecePosition(piece.row, piece.col, piece.size));
          }
        }
        if (this.hintHand && cc.isValid(this.hintHand)) {
          cc.Tween.stopAllByTarget(this.hintHand);
          this.hintHand.destroy();
        }
        this.hintHand = null;
        this.hintPieceId = 0;
      };
      ZyxGame.prototype.finishEliminationHint = function() {
        var hand = this.hintHand;
        this.hintHand = null;
        this.hintPieceId = 0;
        hand && cc.isValid(hand) && hand.destroy();
        this.idleSeconds = 0;
      };
      ZyxGame.prototype.restoreDefaultPlayTip = function() {
        if (!this.moodStageLabel || this.moodStageLabel.string) return;
        this.moodStageLabel.string = "\u5de6\u53f3\u62d6\u52a8\u5fc3\u60c5\u5757\uff0c\u586b\u6ee1\u4e00\u884c\u5c31\u80fd\u6d88\u9664";
        this.moodStageLabel.node.opacity = 0;
        this.tipSeconds = 0;
      };
      ZyxGame.prototype.updateRotatingTip = function(dt) {
        if (!this.moodStageLabel || this.hammerMode || this.purifierMode || this.isTutorialGuidedStep()) return;
        if (this.pauseMenuOpen || this.rewardedAdLoading || this.settlementReported) return;
        var beginner = ZyxGameModule_1.zyxGameModule.challengeCount <= 10;
        var source = beginner ? GAME_PLAY_TIPS : GAME_WARM_TIPS;
        var previous = this.tipSeconds;
        this.tipSeconds += dt;
        if (this.tipSeconds >= 8) {
          this.tipSeconds %= 8;
          this.tipIndex = (this.tipIndex + 1) % source.length;
          this.moodStageLabel.string = source[this.tipIndex];
        } else 0 === previous && (this.moodStageLabel.string = source[this.tipIndex % source.length]);
        var t = this.tipSeconds;
        var progress = t < 1.5 ? t / 1.5 : t <= 6.5 ? 1 : (8 - t) / 1.5;
        var alpha = .5 - Math.cos(Math.PI * progress) / 2;
        this.moodStageLabel.node.opacity = Math.round(255 * alpha);
      };
      ZyxGame.prototype.resolveTurn = function(removedPieceIds, shatter) {
        var _this = this;
        void 0 === removedPieceIds && (removedPieceIds = []);
        void 0 === shatter && (shatter = false);
        this.locked = true;
        this.updateHud();
        var beginResolution = function() {
          _this.resolveStableBoard(function() {
            return _this.appendNextRowAndResolve();
          });
        };
        removedPieceIds.length > 0 ? shatter ? this.animateHammerRemoval(removedPieceIds[0], beginResolution) : this.animatePieceRemoval(removedPieceIds, beginResolution) : beginResolution();
      };
      ZyxGame.prototype.resolveTutorialTurn = function() {
        var _this = this;
        this.locked = true;
        this.updateHud();
        var clearedRowsBefore = ZyxGameModule_1.zyxGameModule.roundClearedRows;
        this.resolveStableBoard(function() {
          _this.completePlayerAction();
          if (ZyxGameModule_1.zyxGameModule.roundClearedRows <= clearedRowsBefore) {
            cc.error("[\u65b0\u624b\u6559\u5b66] \u7b2c " + (_this.tutorialStep + 1) + " \u6b65\u6ca1\u6709\u4ea7\u751f\u6d88\u9664");
            _this.locked = false;
            _this.showTutorialCorrection("\u5dee\u4e00\u70b9\u70b9\u5c31\u6210\u529f\u5566\uff5e\u8ba9\u4eae\u4eae\u7684\u8272\u5757\u5b8c\u6574\u4f4f\u8fdb\u7a7a\u4f4d\u5427\uff01", true);
            return;
          }
          _this.tutorialStep++;
          _this.idleSeconds = 0;
          if (_this.isTutorialGuidedStep()) {
            _this.locked = false;
            _this.showTutorialStep();
            return;
          }
          _this.playTutorialCompletionTransition();
        });
      };
      ZyxGame.prototype.handleChallengeFailed = function(reason) {
        this.captureProgress(true);
        AudioManager_1.audioManager.setGamePaused(true);
        this.dismissRoundRescuePrompt(false);
        this.cancelEliminationHint();
        this.setToolSelectionMode(null);
        this.locked = true;
        if (this.reviveUsed) {
          if (ZyxGameModule_1.zyxGameModule.rulesVersion >= 11 && !this.reviveCardUsed && ZyxGameModule_1.zyxGameModule.reviveCardCount > 0) {
            this.showReviveCardModal(reason);
            return;
          }
          this.finishGame(reason);
          return;
        }
        this.showReviveModal(reason);
      };
      ZyxGame.prototype.showReviveCardModal = function(reason) {
        var _this = this;
        this.locked = true;
        UIManager_1.uimanager.showModal("\u590d\u6d3b\u5361", "\u7528\u4e00\u5f20\u590d\u6d3b\u5361\uff0c\u518d\u7ed9\u81ea\u5df1\u4e00\u6b21\u673a\u4f1a", [ {
          text: "\u672c\u5c40\u7ed3\u7b97",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            return _this.finishGame(reason);
          }
        }, {
          text: "\u4f7f\u7528\u590d\u6d3b\u5361",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            void _this.requestReviveCard(reason);
          }
        } ], function(panel, centerY) {
          var art = new cc.Node("reviveCardArt");
          panel.addChild(art);
          art.setPosition(0, centerY + 36);
          var sprite = art.addComponent(cc.Sprite);
          sprite.spriteFrame = AssetLoader_1.getSpriteFrame("effects", AssetLoader_1.ASSET_PATHS.effects.reviveCard);
          sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
          UIManager_1.uimanager.fitSpriteFrameInside(art, sprite.spriteFrame, 196, 132);
          UIManager_1.uimanager.createLabel(panel, "\u5df2\u62e5\u6709 " + ZyxGameModule_1.zyxGameModule.reviveCardCount + " \u5f20 \xb7 \u672c\u5c40\u4ec5\u53ef\u4f7f\u7528\u4e00\u6b21", 0, centerY - 58, 20, HUD_LABEL_COLOR, 470, 36);
        }, 180, true);
      };
      ZyxGame.prototype.requestReviveCard = function(reason) {
        return __awaiter(this, void 0, Promise, function() {
          var result_1, removed, error_3;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              if (this.rewardedAdLoading || this.reviveCardUsed || this.settlementReported) return [ 2 ];
              this.rewardedAdLoading = true;
              this.locked = true;
              if (!this.pendingReviveCardRequest) {
                this.captureProgress(true);
                this.pendingReviveCardRequest = {
                  roundId: ZyxGameModule_1.zyxGameModule.cloudRoundId,
                  sessionToken: RoundProgress_1.roundProgress.token,
                  actions: ZyxGameModule_1.zyxGameModule.roundActions.map(function(action) {
                    return __assign({}, action);
                  }),
                  elapsedMs: Math.max(0, Math.floor(Date.now() - ZyxGameModule_1.zyxGameModule.roundStartedAt))
                };
              }
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, 4, 5 ]);
              return [ 4, CloudService_1.cloudService.useReviveCard(this.pendingReviveCardRequest) ];

             case 2:
              result_1 = _a.sent();
              if (!cc.isValid(this.node)) return [ 2 ];
              ZyxGameModule_1.zyxGameModule.applyCloudProfile(result_1.profile);
              RoundProgress_1.roundProgress.begin(result_1.round, ZyxGameModule_1.zyxGameModule.getPlayerId());
              this.pendingReviveCardRequest = null;
              this.reviveCardUsed = true;
              removed = ZyxGameModule_1.zyxGameModule.pieces.filter(function(piece) {
                return piece.row < 8;
              }).map(function(piece) {
                return piece.id;
              });
              this.playEmergencyClearEffect(removed, function() {
                ZyxGameModule_1.zyxGameModule.restoreRound(result_1.round);
                _this.renderAll();
                _this.beanCollectionHud.complete(ZyxGameModule_1.zyxGameModule.roundCollectedMoodBeans);
                _this.captureProgress();
                AudioManager_1.audioManager.setGamePaused(false);
                _this.locked = false;
                _this.idleSeconds = 0;
                UIManager_1.uimanager.showToast("\u590d\u6d3b\u5361\u5df2\u4f7f\u7528\uff0c\u63a5\u7740\u6162\u6162\u6574\u7406\u5427");
                ZyxGameModule_1.zyxGameModule.isGameOver() && _this.finishGame(reason);
              });
              return [ 3, 5 ];

             case 3:
              error_3 = _a.sent();
              if (!cc.isValid(this.node)) return [ 2 ];
              if ([ "ROUND_SESSION_CONFLICT", "ROUND_NOT_ACTIVE", "PROGRESS_CONFLICT", "ACCOUNT_CHANGED" ].includes(error_3.businessCode)) {
                RoundProgress_1.roundProgress.invalidateSession();
                return [ 2 ];
              }
              if ([ "TOOL_INSUFFICIENT", "REVIVE_CARD_UNAVAILABLE", "PROGRESS_INVALID", "SETTLEMENT_TOO_OLD" ].includes(error_3.businessCode)) {
                this.pendingReviveCardRequest = null;
                UIManager_1.uimanager.showToast(error_3.message);
                this.finishGame(reason);
                return [ 2 ];
              }
              UIManager_1.uimanager.showModal("\u590d\u6d3b\u5f85\u786e\u8ba4", "\u8054\u7f51\u786e\u8ba4\u540e\u5373\u53ef\u7ee7\u7eed\uff0c\u91cd\u8bd5\u4e0d\u4f1a\u91cd\u590d\u6d88\u8017\u590d\u6d3b\u5361", [ {
                text: "\u91cd\u65b0\u786e\u8ba4",
                color: UIManager_1.BUTTON_COLORS.green,
                onClick: function() {
                  void _this.requestReviveCard(reason);
                }
              } ]);
              return [ 3, 5 ];

             case 4:
              this.rewardedAdLoading = false;
              return [ 7 ];

             case 5:
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.showReviveModal = function(reason) {
        var _this = this;
        this.locked = true;
        var videoEnabled = "video" === ShareReward_1.getRewardOfferIcon("rescue");
        UIManager_1.uimanager.showModal("\u590d\u6d3b", videoEnabled ? "\u5b8c\u6574\u770b\u5b8c\u89c6\u9891\u5373\u53ef\u7ee7\u7eed\u6e38\u620f\uff0c\u6311\u6218\u9ad8\u5206" : "\u5206\u4eab\u597d\u53cb\u5373\u53ef\u7ee7\u7eed\u6e38\u620f\uff0c\u6311\u6218\u9ad8\u5206", [ {
          text: ShareReward_1.getRewardOfferActionText("rescue") + "\u590d\u6d3b",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            return _this.requestRevive(reason);
          },
          icon: function(button) {
            return GlyphFactory_1.decorateActionButton(button, ShareReward_1.getRewardOfferIcon("rescue"));
          }
        }, {
          text: "\u4e0d\u9700\u8981",
          color: UIManager_1.BUTTON_COLORS.red,
          onClick: function() {
            return _this.finishGame(reason);
          }
        } ]);
      };
      ZyxGame.prototype.requestRevive = function(reason) {
        var _this = this;
        if (this.rewardedAdLoading) return;
        this.rewardedAdLoading = true;
        this.locked = true;
        this.showRewardOffer(function(rewarded) {
          _this.rewardedAdLoading = false;
          if (!rewarded) {
            UIManager_1.uimanager.showToast(ShareReward_1.getRewardOfferFailToast("revive"));
            _this.showReviveModal(reason);
            return;
          }
          _this.reviveUsed = true;
          _this.performRevive();
        }, "revive");
      };
      ZyxGame.prototype.performRevive = function() {
        var _this = this;
        var removedPieceIds = ZyxGameModule_1.zyxGameModule.removeTopRowsForRevive(8);
        this.setToolSelectionMode(null);
        this.locked = true;
        this.playEmergencyClearEffect(removedPieceIds, function() {
          _this.resolveStableBoard(function() {
            _this.updateHud();
            UIManager_1.uimanager.showToast("\u5df2\u6e05\u7406\u9876\u90e8 8 \u6392\uff0c\u81ea\u52a8\u8865\u5165\u4e00\u6392");
            AudioManager_1.audioManager.setGamePaused(false);
            _this.appendNextRowAndResolve();
          });
        });
      };
      ZyxGame.prototype.playEmergencyClearEffect = function(pieceIds, onComplete) {
        this.playEmergencyLightning();
        this.playEmergencyClouds();
        this.animateEmergencyShatter(pieceIds);
        this.scheduleOnce(onComplete, 1.18);
      };
      ZyxGame.prototype.playEmergencyLightning = function() {
        var _this = this;
        if (!this.boardRoot || !cc.isValid(this.boardRoot)) return;
        var boardWidth = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        var boardHeight = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE;
        var flash = new cc.Node("emergencyBoardFlash");
        flash.width = boardWidth;
        flash.height = boardHeight;
        flash.setPosition(0, 0);
        flash.zIndex = 68;
        flash.opacity = 0;
        this.boardRoot.addChild(flash);
        var flashGraphics = flash.addComponent(cc.Graphics);
        flashGraphics.fillColor = new cc.Color(255, 239, 153, 148);
        flashGraphics.rect(-boardWidth / 2, -boardHeight / 2, boardWidth, boardHeight);
        flashGraphics.fill();
        cc.tween(flash).delay(.04).to(.07, {
          opacity: 220
        }).to(.055, {
          opacity: 38
        }).to(.07, {
          opacity: 245
        }).to(.055, {
          opacity: 42
        }).to(.08, {
          opacity: 255
        }).to(.24, {
          opacity: 0
        }, {
          easing: "quadOut"
        }).call(function() {
          cc.isValid(flash) && flash.destroy();
        }).start();
        var strikeXs = [ -196, 0, 196 ];
        strikeXs.forEach(function(x, index) {
          var bolt = new cc.Node("emergencyLightning_" + index);
          bolt.setPosition(x, 28);
          bolt.zIndex = 98;
          bolt.opacity = 0;
          bolt.scale = .82;
          _this.boardRoot.addChild(bolt);
          var graphics = bolt.addComponent(cc.Graphics);
          var drawBolt = function(color, width) {
            graphics.strokeColor = color;
            graphics.lineWidth = width;
            graphics.lineCap = cc.Graphics.LineCap.ROUND;
            graphics.moveTo(22, 330);
            graphics.lineTo(-28, 224);
            graphics.lineTo(22, 224);
            graphics.lineTo(-30, 92);
            graphics.lineTo(26, 92);
            graphics.lineTo(-24, -58);
            graphics.lineTo(18, -58);
            graphics.lineTo(-18, -296);
            graphics.stroke();
          };
          drawBolt(new cc.Color(215, 126, 30, 145), 42);
          drawBolt(new cc.Color(249, 194, 53, 248), 25);
          drawBolt(new cc.Color(255, 255, 224, 255), 9);
          graphics.fillColor = new cc.Color(255, 228, 114, 245);
          graphics.circle(-42, 178, 11);
          graphics.circle(38, 72, 9);
          graphics.circle(-34, -122, 8);
          graphics.fill();
          cc.tween(bolt).delay(.03 + .055 * index).to(.07, {
            opacity: 255,
            scale: 1.2
          }, {
            easing: "backOut"
          }).to(.055, {
            opacity: 66,
            scale: .98
          }).to(.07, {
            opacity: 255,
            scale: 1.14
          }).to(.055, {
            opacity: 62,
            scale: .99
          }).to(.08, {
            opacity: 255,
            scale: 1.24
          }).delay(.08).to(.2, {
            opacity: 0,
            scale: 1.34
          }, {
            easing: "quadOut"
          }).call(function() {
            cc.isValid(bolt) && bolt.destroy();
          }).start();
          _this.playEmergencySpineBurst(x, 116, index);
          _this.playEmergencySpineBurst(.72 * x, -154, index + 3);
        });
        cc.Tween.stopAllByTarget(this.boardRoot);
        var originX = this.boardRoot.x;
        cc.tween(this.boardRoot).delay(.08).to(.045, {
          x: originX - 18
        }).to(.045, {
          x: originX + 17
        }).to(.045, {
          x: originX - 14
        }).to(.045, {
          x: originX + 12
        }).to(.045, {
          x: originX - 9
        }).to(.045, {
          x: originX + 7
        }).to(.065, {
          x: originX
        }).start();
      };
      ZyxGame.prototype.playEmergencyClouds = function() {
        if (!this.boardRoot || !cc.isValid(this.boardRoot)) return;
        var boardHeight = ZyxGameModule_1.BOARD_ROWS * ZyxGameModule_1.CELL_SIZE;
        var cloudRoot = new cc.Node("emergencyCloudBank");
        cloudRoot.width = ZyxGameModule_1.BOARD_COLS * ZyxGameModule_1.CELL_SIZE;
        cloudRoot.height = boardHeight;
        cloudRoot.setPosition(0, 0);
        cloudRoot.zIndex = 86;
        this.boardRoot.addChild(cloudRoot);
        var clouds = [ {
          x: -205,
          y: 232,
          radius: 150,
          delay: 0,
          drift: -26
        }, {
          x: 18,
          y: 214,
          radius: 178,
          delay: .025,
          drift: 18
        }, {
          x: 222,
          y: 156,
          radius: 152,
          delay: .05,
          drift: 28
        }, {
          x: -216,
          y: -46,
          radius: 166,
          delay: .035,
          drift: -22
        }, {
          x: 12,
          y: -92,
          radius: 188,
          delay: .01,
          drift: 16
        }, {
          x: 226,
          y: -122,
          radius: 158,
          delay: .06,
          drift: 30
        } ];
        clouds.forEach(function(config, index) {
          var cloud = new cc.Node("emergencyCloud_" + index);
          cloud.setPosition(config.x, config.y);
          cloud.opacity = 0;
          cloud.scale = .5;
          cloudRoot.addChild(cloud);
          var graphics = cloud.addComponent(cc.Graphics);
          var radius = config.radius;
          graphics.fillColor = new cc.Color(220, 207, 177, 36);
          graphics.circle(.3 * -radius, .2 * -radius, .72 * radius);
          graphics.circle(.32 * radius, .2 * -radius, .68 * radius);
          graphics.fill();
          graphics.fillColor = new cc.Color(250, 246, 224, 244);
          graphics.circle(.48 * -radius, .02 * -radius, .48 * radius);
          graphics.circle(.14 * -radius, .22 * radius, .66 * radius);
          graphics.circle(.28 * radius, .17 * radius, .58 * radius);
          graphics.circle(.48 * radius, .12 * -radius, .48 * radius);
          graphics.circle(.02 * radius, .24 * -radius, .7 * radius);
          graphics.fill();
          graphics.fillColor = new cc.Color(255, 254, 242, 150);
          graphics.circle(.22 * -radius, .34 * radius, .3 * radius);
          graphics.circle(.25 * radius, .3 * radius, .2 * radius);
          graphics.fill();
          cc.tween(cloud).delay(config.delay).to(.18, {
            opacity: 242,
            scale: 1.08
          }, {
            easing: "backOut"
          }).delay(.32).to(.44, {
            x: config.x + config.drift,
            y: config.y + 48,
            opacity: 0,
            scale: 1.38
          }, {
            easing: "quadOut"
          }).start();
        });
        this.scheduleOnce(function() {
          cc.isValid(cloudRoot) && cloudRoot.destroy();
        }, 1.05);
      };
      ZyxGame.prototype.playEmergencySpineBurst = function(x, y, index) {
        if (!this.clearSpineData || !this.boardRoot) return;
        var node = new cc.Node("emergencySpine_" + index);
        node.setPosition(x, y);
        node.opacity = 245;
        node.scaleX = 1.42;
        node.scaleY = 1.22;
        node.zIndex = 94;
        this.boardRoot.addChild(node);
        var skeleton = node.addComponent(sp.Skeleton);
        skeleton.skeletonData = this.clearSpineData;
        skeleton.premultipliedAlpha = false;
        skeleton.timeScale = 1.65;
        skeleton.setAnimation(0, index % 2 === 0 ? "action" : "action2", false);
        skeleton.setCompleteListener(function() {
          cc.isValid(node) && node.destroy();
        });
        this.scheduleOnce(function() {
          cc.isValid(node) && node.destroy();
        }, .86);
      };
      ZyxGame.prototype.animateEmergencyShatter = function(pieceIds) {
        var _this = this;
        if (!this.pieceLayer || 0 === pieceIds.length) return;
        var targets = pieceIds.map(function(id) {
          return {
            id: id,
            node: _this.pieceLayer.getChildByName("piece_" + id),
            color: _this.pieceColors[id]
          };
        }).filter(function(target) {
          return !!target.node;
        }).sort(function(left, right) {
          return right.node.y - left.node.y;
        });
        if (0 === targets.length) return;
        targets.forEach(function(target, index) {
          var delay = .075 + index % 3 * .012;
          cc.Tween.stopAllByTarget(target.node);
          cc.tween(target.node).to(.055, {
            scale: 1.16,
            angle: index % 2 === 0 ? -4 : 4
          }, {
            easing: "quadOut"
          }).start();
          _this.scheduleOnce(function() {
            if (!cc.isValid(target.node)) return;
            target.node.scaleX = 1.18;
            target.node.scaleY = .68;
            _this.spawnPieceShards(target.node, target.color, target.id, false);
            delete _this.pieceColors[target.id];
            target.node.destroy();
          }, delay);
        });
      };
      ZyxGame.prototype.pauseGame = function() {
        var _this = this;
        if (this.locked) return;
        this.captureProgress(true);
        this.markInteraction();
        this.setToolSelectionMode(null);
        this.locked = true;
        this.pauseMenuOpen = true;
        this.pauseStartedAt = Date.now();
        AudioManager_1.audioManager.setGamePaused(true);
        var resume = function() {
          _this.pauseStartedAt && (ZyxGameModule_1.zyxGameModule.roundStartedAt += Math.max(0, Date.now() - _this.pauseStartedAt));
          _this.pauseStartedAt = 0;
          _this.pauseMenuOpen = false;
          AudioManager_1.audioManager.setGamePaused(false);
          _this.locked = false;
          _this.idleSeconds = 0;
          _this.isTutorialGuidedStep() && _this.showTutorialStep();
        };
        SettingsPanel_1.settingsPanel.show({
          progressMessage: RoundProgress_1.roundProgress.message(),
          onDismiss: resume,
          actions: [ {
            text: "\u91cd\u65b0\u5f00\u59cb",
            color: UIManager_1.BUTTON_COLORS.yellow,
            onClick: function() {
              return _this.restartFromPause();
            },
            icon: function(button) {
              return GlyphFactory_1.decorateSettingsActionButton(button, "restart");
            }
          }, {
            text: "\u7ee7\u7eed",
            color: UIManager_1.BUTTON_COLORS.green,
            onClick: resume,
            icon: function(button) {
              return GlyphFactory_1.decorateSettingsActionButton(button, "play");
            }
          }, {
            text: "\u7ed3\u7b97\u9000\u51fa",
            color: UIManager_1.BUTTON_COLORS.red,
            onClick: function() {
              return _this.finishGame("\u4eca\u5929\u5148\u6574\u7406\u5230\u8fd9\u91cc");
            },
            icon: function(button) {
              return GlyphFactory_1.decorateSettingsActionButton(button, "exit");
            }
          }, {
            text: "\u4fdd\u5b58\u8fd4\u56de",
            color: UIManager_1.BUTTON_COLORS.green,
            onClick: function() {
              void _this.saveAndReturnHome();
            },
            icon: function(button) {
              return GlyphFactory_1.decorateActionButton(button, "back", 30);
            }
          } ]
        });
      };
      ZyxGame.prototype.saveAndReturnHome = function() {
        return __awaiter(this, void 0, Promise, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              this.locked = true;
              this.captureProgress(true);
              if (!!RoundProgress_1.roundProgress.canLeave) return [ 3, 2 ];
              UIManager_1.uimanager.showToast("\u6b63\u5728\u4fdd\u5b58\u8fdb\u5ea6\u2026");
              return [ 4, RoundProgress_1.roundProgress.sync(true) ];

             case 1:
              _a.sent();
              if (!RoundProgress_1.roundProgress.canLeave) {
                this.pauseMenuOpen = false;
                this.locked = false;
                AudioManager_1.audioManager.setGamePaused(false);
                UIManager_1.uimanager.showToast("\u6682\u65f6\u65e0\u6cd5\u4fdd\u5b58\uff0c\u8bf7\u4fdd\u6301\u672c\u5c40\u5e76\u68c0\u67e5\u7f51\u7edc\u6216\u672c\u673a\u5b58\u50a8");
                return [ 2 ];
              }
              _a.label = 2;

             case 2:
              this.onSaveAndExit && this.onSaveAndExit();
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.finishGame = function(_reason) {
        var _this = this;
        if (this.settlementReported) return;
        AudioManager_1.audioManager.enterScene("silent");
        this.dismissRoundRescuePrompt(false);
        this.stopBoardDangerGlow();
        this.cancelEliminationHint();
        this.setToolSelectionMode(null);
        this.locked = true;
        var settlement = ZyxGameModule_1.zyxGameModule.finishRound();
        this.beanCollectionHud.complete(ZyxGameModule_1.zyxGameModule.roundCollectedMoodBeans);
        this.settlementReported = true;
        this.onRoundFinished && this.onRoundFinished(settlement, ZyxGameModule_1.zyxGameModule.roundStartedAt);
        this.updateHud();
        UIManager_1.uimanager.showModal("\u672c\u5c40\u7ed3\u7b97", this.getSettlementMessage(settlement), [ {
          text: "\u8fd4\u56de",
          color: UIManager_1.BUTTON_COLORS.yellow,
          onClick: function() {
            return _this.leaveSettlement(false, settlement);
          },
          icon: function(button) {
            return GlyphFactory_1.decorateActionButton(button, "back", 30);
          }
        }, {
          text: "\u518d\u6765\u4e00\u6b21",
          color: UIManager_1.BUTTON_COLORS.green,
          onClick: function() {
            return _this.leaveSettlement(true, settlement);
          },
          icon: function(button) {
            return GlyphFactory_1.decorateActionButton(button, "restart", 30);
          }
        } ], function(panel, centerY) {
          var scoreCaption = UIManager_1.uimanager.createLabel(panel, "\u672c\u5c40\u5f97\u5206", 0, centerY + 120, 28, HUD_LABEL_COLOR, 320, 40);
          _this.makeLabelBold(scoreCaption);
          var score = UIManager_1.uimanager.createLabel(panel, String(settlement.roundScore), 0, centerY + 48, 88, HUD_VALUE_COLOR, 420, 108);
          _this.makeLabelBold(score);
          score.node.scale = .72;
          cc.tween(score.node).to(.3, {
            scale: 1
          }, {
            easing: "backOut"
          }).start();
          var moodChip = UIManager_1.uimanager.createRect(panel, "settlementMoodReward", 260, 84, new cc.Color(255, 239, 203), 255, 20, 0, centerY - 112);
          var rewardCaption = UIManager_1.uimanager.createLabel(panel, "\u672c\u5c40\u6536\u83b7 \xb7 \u5f00\u5fc3\u8c46", 0, centerY - 44, 28, HUD_LABEL_COLOR, 360, 40);
          _this.makeLabelBold(rewardCaption);
          var rewardContent = new cc.Node("settlementRewardContent");
          moodChip.addChild(rewardContent);
          var beanSize = 56;
          var gap = 10;
          var bean = MoodArt_1.createMoodBean(rewardContent, 1, 0, 0, beanSize);
          var moodValue = UIManager_1.uimanager.createLabel(rewardContent, "\xd7" + settlement.roundEarnedMoodBeans, 0, 0, 36, HUD_VALUE_COLOR, 160, 48);
          moodValue.overflow = cc.Label.Overflow.NONE;
          moodValue.enableWrapText = false;
          _this.makeLabelBold(moodValue);
          moodValue._forceUpdateRenderData();
          var contentWidth = beanSize + gap + moodValue.node.width;
          rewardContent.scale = Math.min(1, (moodChip.width - 32) / contentWidth);
          bean.x = -(moodValue.node.width + gap) / 2;
          moodValue.node.x = (beanSize + gap) / 2;
          if (settlement.roundBonusMoodBeans > 0) {
            var bonus = UIManager_1.uimanager.createLabel(panel, "\u542b\u7ed3\u7b97\u989d\u5916\u5956\u52b1 +" + settlement.roundBonusMoodBeans, 0, centerY - 174, 21, HUD_LABEL_COLOR, 380, 30);
            _this.makeLabelBold(bonus);
          }
        }, 340, true);
      };
      ZyxGame.prototype.leaveSettlement = function(restart, settlement) {
        this.onSettlementExit && this.onSettlementExit({
          restart: restart,
          settlement: settlement
        });
      };
      ZyxGame.prototype.restartFromPause = function() {
        return __awaiter(this, void 0, Promise, function() {
          var restore, started, _1;
          var _this = this;
          return __generator(this, function(_a) {
            switch (_a.label) {
             case 0:
              restore = function() {
                if (!_this.node || !_this.node.isValid) return;
                _this.pauseMenuOpen = false;
                AudioManager_1.audioManager.setGamePaused(false);
                _this.locked = false;
                _this.isTutorialGuidedStep() && _this.showTutorialStep();
              };
              if (!this.onRestartFromPause) {
                restore();
                return [ 2 ];
              }
              _a.label = 1;

             case 1:
              _a.trys.push([ 1, 3, , 4 ]);
              return [ 4, this.onRestartFromPause() ];

             case 2:
              started = _a.sent();
              started || restore();
              return [ 3, 4 ];

             case 3:
              _1 = _a.sent();
              restore();
              return [ 3, 4 ];

             case 4:
              return [ 2 ];
            }
          });
        });
      };
      ZyxGame.prototype.getPieceColor = function(index) {
        return MoodArt_1.getMoodColor(index);
      };
      ZyxGame.prototype.getSettlementMessage = function(settlement) {
        var moods = settlement.roundCollectedMoodBeans;
        var praise = moods > 0 ? "\u4f60\u628a\u7eb7\u4e71\u4e00\u70b9\u70b9\u6574\u7406\u597d\u4e86\uff0c\u771f\u7684\u5f88\u68d2" : "\u613f\u610f\u518d\u8bd5\u4e00\u6b21\uff0c\u672c\u8eab\u5c31\u5df2\u7ecf\u5f88\u4e86\u4e0d\u8d77";
        return praise;
      };
      ZyxGame = __decorate([ ccclass ], ZyxGame);
      return ZyxGame;
    }(cc.Component);
    exports.default = ZyxGame;
    cc._RF.pop();
  }, {
    "../dataModule/ZyxGameModule": "ZyxGameModule",
    "../manager/AssetLoader": "AssetLoader",
    "../manager/AudioManager": "AudioManager",
    "../manager/CloudService": "CloudService",
    "../manager/GameSettings": "GameSettings",
    "../manager/ResponsiveLayout": "ResponsiveLayout",
    "../manager/RoundProgress": "RoundProgress",
    "../manager/SettingsPanel": "SettingsPanel",
    "../manager/ShareReward": "ShareReward",
    "../manager/UIManager": "UIManager",
    "./BeanCollectionHud": "BeanCollectionHud",
    "./BombEffect": "BombEffect",
    "./DangerGlow": "DangerGlow",
    "./GamePanel": "GamePanel",
    "./GlyphFactory": "GlyphFactory",
    "./HeartEffect": "HeartEffect",
    "./HeartMessage": "HeartMessage",
    "./MoodArt": "MoodArt",
    "./RankChaseView": "RankChaseView",
    "./RescueBalloon": "RescueBalloon",
    "./RewardArt": "RewardArt",
    "./ZyxGridCom": "ZyxGridCom"
  } ],
  ZyxGridCom: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "91c73UehBpGm6f6owMD6XWE", "ZyxGridCom");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) Object.prototype.hasOwnProperty.call(b, p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var ccclass = cc._decorator.ccclass;
    var DRAG_SNAP_THRESHOLD = .4;
    var ZyxGridCom = function(_super) {
      __extends(ZyxGridCom, _super);
      function ZyxGridCom() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.pieceId = 0;
        _this.cellSize = 0;
        _this.callbacks = null;
        _this.touching = false;
        _this.originTouchX = 0;
        _this.originNodeX = 0;
        _this.offset = 0;
        _this.range = {
          min: 0,
          max: 0
        };
        return _this;
      }
      ZyxGridCom.prototype.onLoad = function() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
      };
      ZyxGridCom.prototype.onDestroy = function() {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
      };
      ZyxGridCom.prototype.initialize = function(pieceId, cellSize, callbacks) {
        this.pieceId = pieceId;
        this.cellSize = cellSize;
        this.callbacks = callbacks;
      };
      ZyxGridCom.prototype.onTouchStart = function(event) {
        if (!this.callbacks || !this.callbacks.canInteract()) return;
        this.callbacks.onInteract();
        this.touching = true;
        this.offset = 0;
        this.originTouchX = this.node.parent.convertToNodeSpaceAR(event.touch.getLocation()).x;
        this.originNodeX = this.node.x;
        this.range = this.callbacks.getMoveRange(this.pieceId);
        this.node.zIndex = 100;
        var stamp = this.node.getChildByName("moodStamp");
        stamp && cc.tween(stamp).to(.08, {
          opacity: 222,
          scale: 1.12
        }).start();
        cc.tween(this.node).to(.06, {
          scale: 1.04
        }).start();
      };
      ZyxGridCom.prototype.onTouchMove = function(event) {
        if (!this.canContinueTouch()) return;
        this.updateDragPosition(event);
      };
      ZyxGridCom.prototype.canContinueTouch = function() {
        if (!this.touching) return false;
        if (this.callbacks && this.callbacks.canInteract()) return true;
        this.touching = false;
        this.node.zIndex = 10;
        return false;
      };
      ZyxGridCom.prototype.updateDragPosition = function(event) {
        var dx = this.node.parent.convertToNodeSpaceAR(event.touch.getLocation()).x - this.originTouchX;
        var cellOffset = dx / this.cellSize;
        var direction = cellOffset < 0 ? -1 : 1;
        var requested = Math.abs(cellOffset) < DRAG_SNAP_THRESHOLD ? 0 : direction * Math.floor(Math.abs(cellOffset) + 1 - DRAG_SNAP_THRESHOLD);
        this.offset = Math.max(this.range.min, Math.min(this.range.max, requested));
        var visualOffset = Math.max(this.range.min, Math.min(this.range.max, cellOffset));
        this.node.x = this.originNodeX + visualOffset * this.cellSize;
      };
      ZyxGridCom.prototype.onTouchEnd = function(event) {
        if (!this.canContinueTouch()) return;
        this.updateDragPosition(event);
        this.finishTouch(0 !== this.offset, 0 === this.offset);
      };
      ZyxGridCom.prototype.finishTouch = function(commitMove, triggerTap) {
        this.touching = false;
        this.node.zIndex = 10;
        this.node.x = this.originNodeX + (commitMove ? this.offset * this.cellSize : 0);
        var stamp = this.node.getChildByName("moodStamp");
        stamp && cc.tween(stamp).to(.08, {
          opacity: 172,
          scale: 1
        }).start();
        cc.tween(this.node).to(.08, {
          scale: 1
        }).start();
        commitMove ? this.callbacks.onMove(this.pieceId, this.offset) : triggerTap && this.callbacks.onTap(this.pieceId);
      };
      ZyxGridCom.prototype.onTouchCancel = function(event) {
        if (!this.canContinueTouch()) return;
        this.updateDragPosition(event);
        this.finishTouch(0 !== this.offset, false);
      };
      ZyxGridCom = __decorate([ ccclass ], ZyxGridCom);
      return ZyxGridCom;
    }(cc.Component);
    exports.default = ZyxGridCom;
    cc._RF.pop();
  }, {} ]
}, {}, [ "GameMainScene", "BoardEngine", "MoodBeanConfig", "RankChase", "RoundReplay", "ZyxGameModule", "GmBubble", "GmCloudApi", "GmPanel", "AssetLoader", "AudioManager", "CloudService", "GameSettings", "GmAccess", "PlatformAdapter", "ResponsiveLayout", "RoundProgress", "SettingsPanel", "SettlementSync", "ShareConfig", "ShareReward", "UIManager", "WeChatFriends", "BeanCollectionHud", "BombEffect", "DangerGlow", "GamePanel", "GlyphFactory", "HeartEffect", "HeartMessage", "HomeFriendRanking", "LeaderboardPanel", "MoodArt", "RankChaseView", "RescueBalloon", "RewardArt", "ShopPanel", "ZyxGame", "ZyxGridCom" ]);