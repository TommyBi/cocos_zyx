'use strict';

function readScore(list, key) {
    const item = (Array.isArray(list) ? list : []).find(entry => entry && entry.key === key);
    if (!item || typeof item.value !== 'string' || !/^\d+$/.test(item.value)) return null;
    const value = Number(item.value);
    return Number.isSafeInteger(value) ? value : null;
}

function rankFriends(data, key, self, selfScore) {
    const unique = new Map();
    (Array.isArray(data) ? data : []).forEach(user => {
        const id = user && (user.openid || user.openId);
        const score = user && readScore(user.KVDataList, key);
        if (!id || score === null) return;
        unique.set(id, { id, nickname: user.nickname || user.nickName || '微信好友', avatarUrl: user.avatarUrl || '', score });
    });
    const selfId = self && (self.openId || self.openid);
    if (selfId && selfScore !== null) {
        unique.set(selfId, { id: selfId, nickname: self.nickName || self.nickname || '我',
            avatarUrl: self.avatarUrl || '', score: selfScore });
    }
    const entries = Array.from(unique.values()).sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
    entries.forEach((entry, index) => {
        entry.rank = index > 0 && entry.score === entries[index - 1].score ? entries[index - 1].rank : index + 1;
        entry.isSelf = entry.id === selfId;
    });
    return { entries, self: entries.find(entry => entry.isSelf) || null };
}

module.exports = { readScore, rankFriends };
