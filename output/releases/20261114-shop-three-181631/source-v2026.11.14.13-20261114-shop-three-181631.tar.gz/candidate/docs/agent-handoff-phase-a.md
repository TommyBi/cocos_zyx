# 烦恼排排消 · 当前工程交接

> 供新接手的 agent 快速了解：现状、架构、数据流、部署方式、踩过的坑。
> 更新时间：2026-10-29。

> 2026-11-14 商城最新候选v2026.11.14.13：统一3豆换解压锤/魔法棒/1点体力；按钮仅价格、红绿状态、50px新角色、84px厚度、36px卡间距，服务器确认后弹“恭喜获得”并返回商城。发布 `20261114-shop-three-181631` 已更新Staging镜像 `sha256:373741f6da247069925efa3adf34a5c616533355f2f513143bcb2e3c947543ef`，冻结源与实际运行代码一致，58个旧玩家和全部旧业务行保留。195客户端+52服务端、实际镜像52测试及三尺寸真实Web交互通过。后端只改商品表，不改结构/API13/V10或数据代际。精确索引PNG压缩逐像素校验，不做有损量化。前后端包、扫码与CI状态见最新 `output/current-wechat-release.json`。**正式后端仍为20/20/5豆；验收通过后、提审前须同步新镜像，不能只发前端。** 手机本轮商城待用户验收，未提交审核。


> 2026-11-14 提审准备：用户已确认v12手机好友榜正常。发布 `20261114-friends-review-172243` 已将 `v2026.11.14.12` 上传微信开发版本，未提交审核；97文件与用户确认的扫码包完全一致。Staging复用API13/V10镜像，已完成一致性数据备份、运行镜像51测试、HTTPS协议和双榜对库验证；旧行全部保留，只新增隔离验收账号记录，所有服务容器和配置未变。开发/体验走Staging，release走Production，好友分数key隔离。不可变发布源及实际双环境代码与本地相同，历史共享server目录落后且未被运行容器使用，不得据此回退代码。交付入口 `output/current-wechat-release.json`，说明 `output/releases/20261114-friends-review-172243/提审说明.md`。后台隐私披露/官方隐私授权弹窗尚未登录核验，双好友账号互验尚待完成。

> 2026-11-14 更正及最新候选：v2026.11.14.12。v11真机好友榜全空白；上一条关于“主域尺寸只读、开放域设置宽高”的判断反了。实际微信工具内画布默认390×844，主域设置422×320后真实头像与已有1,750分恢复。v12明确主域先设置尺寸再发show、开放域仅绘制；保留无ellipse兼容。自身资料返回selfOpenId别名，新增同次托管的账号标记匹配自身，防重复入榜；不猜昵称/头像。195客户端+51服务端、类型检查、双构建与三尺寸模拟通过；重开微信工程v12后无需手动补丁，真实头像/1,750分/唯一自身记录/第1名正常，只读警告0。扫码ZIP及证据见 `output/wechat-friends-canvas-owner-20261114/`。真实手机与双好友复验仍待用户，新版未部署后端、未上传开发版本/提审。

> 2026-11-14 最新修复候选：v2026.11.14.11修复用户真机好友榜仅名次可见和只读Canvas警告。首页移除内置SubContextView的主域尺寸赋值，直接只读共享画布并8fps贴图；开放域移除ellipse依赖，头像失败不阻塞昵称/成绩，绘图栈finally恢复。194客户端+51服务端测试、双构建及三尺寸严格Canvas模拟通过；扫码预览与ZIP见 `output/wechat-friends-runtime-fix-20261114/`。真实微信好友结果待用户重扫本版复验，旧v10模拟验收不足以证明微信兼容。未部署后端或上传开发版本/审核，已发布版本入口不变。

> 2026-11-14 最新候选：v2026.11.14.10好友榜居中收拢为462×500、左右留入口，列表/头像放大，玩法示意位于标题与榜单之间。191客户端+51服务端测试、双构建、三尺寸带头像模拟通过；按用户要求已生成CI扫码预览及ZIP，见 `output/wechat-friends-centered-20261114/`。未上传开发版本/审核、未部署后端，真实微信关系链待真机体验。

> 2026-11-14 本地候选补充：v2026.11.14.09已实现首页微信开放域好友积分榜、邀请分享、紧凑演示布局和右下角版本号。好友榜口径为服务端确认的单局最高分；正式与体验key隔离。调研及真机步骤见 `docs/wechat-friends-integration-2026-11-14.md`。本地测试/构建和三尺寸模拟通过，尚未上传微信或真机验证，发布记录入口仍指向此前已交付版本。

> 2026-11-14 发布补充：客户端v2026.11.14.08已统一手绘角色，Staging已升级API13/V10/结构8，微信ZIP及扫码预览已生成。最新入口为 `output/current-wechat-release.json`；发布记录见 `output/releases/20261114-bean-icons-111748/发布说明.md`。下文中的周榜、旧程序豆子等描述为历史信息，当前实现以CHANGELOG最新条目为准。Production随后已按用户授权升级API13/V10，最新正式发布入口为 `output/current-production-release.json`，发布编号 `20261114-production-api13-141130`。

> 当前范围聚焦左右消除、结算、本周单局最高分排行榜，以及开心豆/经验收集与展示。旧秘境功能、资源和接口已从工程中移除；不得因此删除或重置玩家的生产数据。

## 1. 项目是什么

- Cocos Creator 2.4.13 小游戏「烦恼排排消」，TS 代码在 `assets/script/`，构建产物 `build/web-mobile` 与 `build/wechatgame`。
- 后端：Express + sql.js（WASM SQLite），`server/`，端口 8080，API 前缀 `/v1/cocos-zyx`。
- 构建采用消除主包与 `home` 首页分包。体力由服务端判定，规则见 [`stamina.md`](stamina.md)。

## 2. 核心概念与口径（重要，别搞混）

- **开心豆**（代码标识符仍是 `moodBean`）：1 个带表情色块消除 = 1 豆；同一色块同时给予 1 点经验。
- `moodBeanBalance` 是服务端确认的当前开心豆余额；待补传结算不预先计入余额，成功确认后才展示到账。
- 排行榜只显示服务端确认的本周单局最高分。
- 开新局须在线领取服务端开局凭证；已领取凭证的对局在途中掉线后仍可补传结算。以 [`stamina.md`](stamina.md) 为准。

## 3. 关键文件

| 文件 | 作用 |
|---|---|
| `assets/script/dataModule/MoodBeanConfig.ts` | 开心豆与本地待结算队列的集中配置 |
| `assets/script/dataModule/ZyxGameModule.ts` | 棋盘、余额、本局收集、本地进度与离线结算队列 |
| `assets/script/manager/CloudService.ts` | API 层；`PRODUCTION_API_BASE=https://api.tcjstory.cn/v1/cocos-zyx`；仅浏览器本机调试可用 `zyx_api_base_override`；微信包固定正式 HTTPS |
| `assets/script/zyxGame/MoodArt.ts` | 程序生成美术：`createMoodBean`/`createMoodBeanMascot`/`getMoodColor`，全部 `cc.Graphics`，无贴图 |
| `server/src/index.js` | 云档案、体力、结算、周榜与分享奖励 API |
| `server/src/economyConfig.js` | 服务端经济与风控参数 |
| `server/Dockerfile` `server/docker-compose.yml` | 部署（compose 项目 `tcjstory-cocos-zyx`，接 `tcjstory_gateway`，卷 `cocos_zyx_data`） |

## 4. 结算安全边界

- `bootstrap` 只提交身份资料，不接收客户端直接上报的资产绝对值。
- 一局结算先写本地待提交队列，再由单一工作器补传；服务端按玩家和 `roundId` 幂等确认并可靠落盘。
- 暂停菜单的“重新开始”放弃本局，不发放开心豆、经验或最高分。
- 体力由服务端校验。匿名设备标识可被重建；实物权益上线前需绑定可信身份并审计兑换。

> 2026-10-30 后端已发布，当前结构迁移与验证结果以 [发布记录](release-candidate-2026-10-30.md) 为准。

## 5. 部署（tcjstory.cn，按上线标准）

- 服务器：`root@8.134.218.234`，SSH 用密钥 `~/.ssh/chloeedu_tcjstory_deploy`（其它密钥都不行）。
- 目录 `/opt/tcjstory/apps/cocos-zyx/server`，`rsync -az --delete --exclude node_modules --exclude data --exclude .env` 上传。
- 构建启动：`docker compose up -d --build`（在服务器用 `setsid ... > /tmp/log 2>&1 &` 异步跑，SSH 直接跑会被 3 分钟超时杀掉；**pkill 的 pattern 不能匹配到自己 ssh 命令行，否则会自杀连接**）。
- Dockerfile 里 `npm config set registry https://registry.npmmirror.com`（不加会在 npm ci 卡死）。
- 网关：Caddyfile 已有 `handle /v1/cocos-zyx/*`（仅路由变化才运行 `/opt/tcjstory/bin/reload-gateway.sh`，不得直接重启共享网关）。
- 健康检查：`https://api.tcjstory.cn/v1/cocos-zyx/health`；Dawn 回归：`https://api.tcjstory.cn/health`。
- 生产数据卷包含玩家资产，不得因代码删减而清空；数据库结构变化应采用兼容迁移。
- 冒烟顺序：bootstrap 拿 token → 获取体力状态 → 授权开局 → 结算 → 查询排行榜（测试账号和请求格式见服务端测试）。

## 6. 构建与测试

- `npm test`（客户端模块测试与服务端 API 测试）。
- `npm run build:web` / `npm run build:wechat`（内部会先 `clean-build.js` + `validate-assets.js` 再调 Cocos Creator CLI）。
- `npm run open:wechat` 打开微信开发者工具；手机真机预览：点「预览」扫码。
- 类型检查：`npx -p typescript@4.9.5 tsc --noEmit -p tsconfig.json`。
- 资源校验：`scripts/validate-assets.js`。

## 7. 本地调试

- 服务端 `node server/src/index.js`（8080），Web `npm run serve:web`（7457）。
- 浏览器调试：往 `build/web-mobile/index.html` 注入 `localStorage.zyx_api_base_override` 指向本地 API（正式包绝不能带这个注入）。
- GM 只用于 Web Debug 本地调试；微信包及生产服务端不得暴露发放资产的 GM 入口。

## 8. 踩过的坑（别再犯）

1. **并行编辑同一文件会互相覆盖**：string_replace 同一文件必须串行，大改后 grep 验证最终内容，diff 输出不可尽信。
2. ssh+pkill 自杀、ssh 前台长跑被 3 分钟超时杀掉（用 setsid 后台 + 日志文件轮询）。
3. 服务器 8080/7457 被旧进程占用会假死；确认进程归属后再停止。
4. sql.js 数据库结构变更必须保留已有玩家资产和结算记录。

## 9. 当前待办/方向

- 当前重点是核心消除手感、体力、榜单及真机体验。
- 微信正式发布前：`api.tcjstory.cn` 需配进小程序后台合法域名。
- 开心豆外观见 `docs/mood-bean-visual-spec-v1.md`；体力规则见 `docs/stamina.md`。
