# Staging与微信小游戏交付 · v2026.11.16.04

发布编号 `20261117-revive-card-084636`，2026-11-17。Staging已部署API15/V11/结构10；微信包与临时扫码预览均已准备完成，开发/体验环境自动连接Staging。未上传微信开发版本、提交审核或发布前端；Production仍为API13/V10/结构8，未变更。

## 使用

- 扫描本目录 `wechat-preview-qr.jpg` 体验。首页右下角应为 `v2026.11.16.04`，好友榜由真实微信关系链返回，包中不含浏览器示例好友。
- `wechatgame-v2026.11.16.04.zip` 解压后，以内层 `wechatgame` 目录导入微信开发者工具。
- Staging接口：[Staging](https://staging-api.tcjstory.cn/v1/cocos-zyx/health)。日常本地预览7458服务已恢复，本地API8080仍为API15。
- 本轮仅准备Staging与扫码体验。正式发布前必须先升级Production至本次配套API15，再发布前端。

## 本次范围

复活卡25开心豆兑换1张，商城四商品可滑动查看；首次沿用原广告/分享复活，之后有卡才提示消费一张再复活一次，无卡直接结算，本局用卡后再失败直接结算。扣卡、消费凭据与完整复活存档同事务保存，最终结算核验用卡。保存返回、100步同步、冷启动继续、原首页/好友榜及此前UI优化全部保留；V10在途存档仍可恢复和结算。

## 验证

- 本地204客户端+66服务端测试、类型检查、源指纹一致性、微信完整构建及GM隔离通过；实际Node20候选镜像66服务端测试通过。
- Staging真实HTTPS验证3/3/3/25豆价格、伪造价格数量忽略、重复购卡/用卡和并发只扣一次、复活完整存档、用卡前本机前缀恢复、旧会话拒绝、最终重放结算及结算幂等；独立测试账号已恢复零资产/零分。
- 开局、体力/每日补充、旧版结算、双榜对库、鉴权与退役路由验证通过；音乐与分享CDN8文件内容一致。
- ZIP的99文件与冻结产物逐文件SHA-256一致，开放域代码与冻结源一致。主包本地2867102字节（2.73MiB），微信CI主包2844153字节；effects2.88MiB，home3.74MiB。
- 沿用前一轮三尺寸实际界面验收证据 `output/revive-card-20261116/`。本轮微信二维码生成成功，实际手机广告/分享、杀进程和双设备仍需真机确认，不能用浏览器模拟回调替代。

## 数据与回退

切换前停服一致性备份：`/opt/tcjstory/backups/cocos-zyx-staging-20261117-revive-card-084636/pre-switch`。升级只新增复活卡库存及保存进度结构，切换前后所有旧字段、旧行完整保留；线上验收后62个旧玩家、282个旧局、77条旧结算、38条旧道具流水仍完整保留。仅新增2个隔离测试账号与协议验收记录。Production、Dawn、共享配置、网关与历史共享server源未改。

实际运行镜像：`sha256:dac639fc1bd8ce56c008ef478f6a56caf50cad692fd22e7aba9ecd9ae864577b`。冻结源目录：`/opt/tcjstory/apps/cocos-zyx/releases/20261117-revive-card-084636/server`，覆盖配置：`/opt/tcjstory/apps/cocos-zyx/releases/20261117-revive-card-084636/staging-image.override.yml`。回退镜像：`cocos-zyx-staging-rollback:20261117-revive-card-084636`；旧覆盖配置保存在备份目录的 `previous-image.override.yml`。必要时只回退Staging服务代码，不自动恢复数据库或覆盖新玩家数据。

## 来源与交接

完整本地工作区（含未提交/未跟踪的已有功能）已与服务器不可变源及真实运行代码核对。旧共享源码落后，不作为基线；当前源、候选、实际容器代码已校验一致。

- 源SHA-256：`27d1ec1910a0ea5f684b53079e453e8af60ff798cf147a0958a3905f6bf518a7`
- 运行源SHA-256：`a104165d81011ab64c9ce695710a978890c1a37b04c3874dcdc355a383cf5802`
- 微信产物SHA-256：`57cddee79b0f4990f9a1e32c49ebe59fe34a3baa5525ce1d376a7509bf1f8b9d`
- 构建：Creator2.4.13，`npm run build:wechat`；本地Node24.19.0，镜像Node20；依赖锁指纹见source/runtime清单。
- 后端包与完整源包均排除.env、密钥、数据库和node_modules。交付清单覆盖本说明、包、二维码及验证证据。
