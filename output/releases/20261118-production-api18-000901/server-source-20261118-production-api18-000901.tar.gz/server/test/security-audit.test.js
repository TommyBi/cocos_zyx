const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('os');
const path = require('path');
const initSqlJs = require('sql.js');
const { start } = require('../src/index');
const { BOARD_RULES_VERSION } = require('../src/boardEngine');
const { csvCell, toCsv } = require('../src/riskControl');

let server, base, dbPath, clock, realNow, sequence = 0;
test.before(async () => {
  realNow = Date.now; clock = realNow(); Date.now = () => clock;
  dbPath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'zyx-security-')), 'test.sqlite');
  server = (await start(dbPath)).listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}/v1/cocos-zyx`;
});
test.after(async () => {
  Date.now = realNow; delete process.env.RISK_ADMIN_TOKEN;
  await new Promise(resolve => server.close(resolve));
});
async function api(route, token, body) {
  const response = await fetch(base + route, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: token.startsWith('Bearer ') ? token : `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: response.status, ...(await response.json()) };
}
async function player() {
  return (await api('/players/bootstrap', '', { deviceId: `security-player-${++sequence}` })).data;
}
async function rows(sql, params = []) {
  const SQL = await initSqlJs(); const db = new SQL.Database(fs.readFileSync(dbPath));
  const stmt = db.prepare(sql); stmt.bind(params); const result = [];
  while (stmt.step()) result.push(stmt.getAsObject());
  stmt.free(); db.close(); return result;
}

test('当前规则不能省略安全协议开局，旧规则仍可开局', async () => {
  const user = await player();
  const blocked = await api('/games/start', user.token, { roundId: 'insecure_v13', rulesVersion: BOARD_RULES_VERSION, collectionRule: 'progress_v2', resumeProtocol: 1 });
  assert.equal(blocked.errorCode, 'SECURITY_PROTOCOL_REQUIRED');
  assert.equal((await api('/players/bootstrap', '', { deviceId: `security-player-${sequence}` })).data.profile.stamina.current, 10);
  const legacy = await api('/games/start', user.token, { roundId: 'legacy_v12', rulesVersion: 12, collectionRule: 'progress_v2' });
  assert.equal(legacy.status, 200);
  assert.equal(legacy.data.stamina.current, 9);
});

test('广告复活没有服务端凭据时不能写入进度，风险只记核验事实', async () => {
  const user = await player();
  const begun = await api('/games/start', user.token, { roundId: 'reward_proof_round', rulesVersion: BOARD_RULES_VERSION, collectionRule: 'progress_v2', resumeProtocol: 1, securityProtocol: 1 });
  clock += 12000;
  const actions = [{ type: 'rules', version: BOARD_RULES_VERSION }, { type: 'revive', rowCount: 8 }];
  const saved = await api('/games/checkpoint', user.token, { roundId: begun.data.roundId, sessionToken: begun.data.sessionToken, actions, elapsedMs: 10000 });
  assert.equal(saved.errorCode, 'REWARD_PROOF_REQUIRED');
  const events = await rows('SELECT code, weight FROM risk_events WHERE player_id = ?', [user.profile.playerId]);
  assert.deepEqual(events, [{ code: 'REWARD_PROOF_REQUIRED', weight: 20 }]);
});

test('省略续玩会话不能放弃旧局；奖励未到观察时间不能领取', async () => {
  const user = await player();
  const begun = await api('/games/start', user.token, { roundId: 'session_guard_round', rulesVersion: BOARD_RULES_VERSION, collectionRule: 'progress_v2', resumeProtocol: 1, securityProtocol: 1 });
  const sessionToken = begun.data.sessionToken;
  const resumed = await api('/games/resume', user.token, { roundId: begun.data.roundId, expectedGeneration: 0, requestId: 'resume_session_guard' });
  assert.equal(resumed.status, 200);
  const bypass = await api('/games/start', user.token, {
    roundId: 'replacement_without_session', rulesVersion: BOARD_RULES_VERSION, collectionRule: 'progress_v2', resumeProtocol: 1, securityProtocol: 1,
    replaceRoundId: begun.data.roundId, replacementGeneration: resumed.data.generation,
  });
  assert.equal(bypass.errorCode, 'ROUND_SESSION_CONFLICT');
  assert.equal((await rows('SELECT status FROM game_rounds WHERE round_id = ?', [begun.data.roundId]))[0].status, 'active');
  clock += 1000;
  const intent = await api('/games/reward-intents', user.token, {
    placement: 'hammer', roundId: begun.data.roundId, sessionToken: resumed.data.sessionToken,
    actions: resumed.data.actions, elapsedMs: 1000,
  });
  assert.equal(intent.status, 200);
  assert.equal((await api('/games/reward-intents/complete', user.token, { intentId: intent.data.intentId, sessionToken: resumed.data.sessionToken })).errorCode, 'REWARD_TOO_EARLY');
  clock += 3000;
  assert.equal((await api('/games/reward-intents/complete', user.token, { intentId: intent.data.intentId, sessionToken: resumed.data.sessionToken })).status, 200);
  const claim = { roundId: begun.data.roundId, sessionToken: resumed.data.sessionToken, item: 'hammer', actionId: 'secure_hammer_claim', intentId: intent.data.intentId };
  assert.equal((await api('/games/tools/reward', user.token, claim)).status, 200);
  assert.equal((await api('/games/tools/reward', user.token, claim)).data.duplicate, true);
  assert.equal((await api('/games/tools/reward', user.token, { ...claim, actionId: 'secure_hammer_claim_again' })).errorCode, 'TOOL_ALREADY_OWNED');
});

test('未配置管理令牌时风险接口不存在；导出表不带公式，且默认不含 openid', async () => {
  assert.equal(csvCell('=cmd'), '"\t=cmd"');
  const csv = toCsv([{ playerId: 'p', nickname: '小熊', wechatBound: 1, wechatOpenId: '', riskLevel: 'review', riskScore: 20, distinctFlaggedRounds: 1, eventCount: 1, firstSeen: 1, lastSeen: 2, highestScore: 0, beanBalance: 0, reviewStatus: 'pending', reviewNotes: '' }]);
  assert.equal(csv.includes('secret-openid'), false);
  assert.equal((await api('/admin/risks/export')).status, 404);
  process.env.RISK_ADMIN_TOKEN = 'a'.repeat(32);
  assert.equal((await api('/admin/risks/export', 'wrong-token')).status, 403);
  const exported = await api('/admin/risks/export?format=json', process.env.RISK_ADMIN_TOKEN);
  assert.equal(exported.status, 200);
  assert.ok(Array.isArray(exported.users));
  assert.ok(exported.users.every(row => row.wechatOpenId === ''));
});
