require('dotenv').config();

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const express = require('express');
const helmet = require('helmet');
const initSqlJs = require('sql.js');

const economy = require('./economyConfig');
const { migrateSchema } = require('./schema');
const { verifyReplay } = require('./replayService');
const { BOARD_RULES_VERSION } = require('./boardEngine');
const { exchangeWeChatLoginCode } = require('./wechatAuth');
const { createDefaultNickname } = require('./defaultNickname');

const app = express();
const port = Number(process.env.PORT || 8080);
let dbPath = path.resolve(process.env.DB_PATH || path.join(__dirname, '..', 'data', 'game.sqlite'));
const chinaOffsetMs = 8 * 60 * 60 * 1000;
let db;
let risk = null;
let rewards = null;

fs.mkdirSync(path.dirname(dbPath), { recursive: true });
app.use(helmet());
app.use(cors());
app.use((req, res, next) => {
  res.locals.auditRequest = req;
  res.setHeader('Cache-Control', 'no-store');
  next();
});
// 长局可获得多颗豆子，需要保留完整重放操作，不能因旧 32KB 上限丢弃结算。
app.use(express.json({ limit: '2mb' }));
app.use((req, res, next) => {
  if (req.method === 'POST' && (!req.body || typeof req.body !== 'object' || Array.isArray(req.body))) {
    return fail(res, '请求内容必须是 JSON 对象', 400, 'REQUEST_INVALID');
  }
  next();
});

function ok(res, data) {
  res.json({ code: 0, data });
}

function fail(res, message, status = 400, errorCode) {
  const body = { code: status, message };
  // 稳定业务错误码：客户端按错误码区分“记录本身不可重试”与可恢复错误，不只依赖 HTTP 状态段。
  if (errorCode) body.errorCode = errorCode;
  if (risk && status < 500) risk.record(res.locals.auditRequest, res.locals.auditUser, errorCode);
  res.status(status).json(body);
}

function now() {
  return Date.now();
}

function clampInt(value, min, max) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return min;
  return Math.max(min, Math.min(max, parsed));
}

function stringValue(value, maxLength, fallback = '') {
  return String(value || fallback).trim().slice(0, maxLength);
}

function newToken() {
  return crypto.randomBytes(24).toString('hex');
}

function newGuestId() {
  return `guest_${crypto.randomBytes(18).toString('hex')}`;
}

const PERSIST_DEBOUNCE_MS = 500;
let persistTimer = null;
let persistPending = false;
/** 上次落盘失败留下的“未持久化”状态；只有成功写盘才能清除。 */
let persistDirty = false;

/**
 * 原子落盘：同目录临时文件写入 → fsync 刷盘 → rename 原子替换，
 * 避免直接覆盖写一半损坏完整数据库。失败时保留 persistDirty，不得伪装成功。
 */
function persistNow() {
  try {
    const tmpPath = `${dbPath}.tmp`;
    const fd = fs.openSync(tmpPath, 'w');
    try {
      fs.writeFileSync(fd, Buffer.from(db.export()));
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(tmpPath, dbPath);
    persistPending = false;
    persistDirty = false;
  } catch (error) {
    persistDirty = true;
    throw error;
  }
}

/**
 * 防抖落盘：sql.js 每次导出都是整库拷贝，500ms 内的连续写只落盘一次，
 * 避免一次结算多条 UPDATE 引发多次全量写盘阻塞请求。进程退出前强制 flush。
 */
function persist() {
  persistPending = true;
  if (persistTimer) return;
  persistTimer = setTimeout(() => {
    persistTimer = null;
    if (!persistPending) return;
    try {
      persistNow();
    } catch (error) {
      // 保持 persistDirty，等待下一次关键事务的落盘确认重试。
      console.error('debounced persist failed', error);
    }
  }, PERSIST_DEBOUNCE_MS);
  if (persistTimer.unref) persistTimer.unref();
}

function flushPersist() {
  if (persistTimer) {
    clearTimeout(persistTimer);
    persistTimer = null;
  }
  if (!persistPending && !persistDirty) return;
  try {
    persistNow();
  } catch (error) {
    // 退出阶段无法重试，保持数据库文件为最近一次成功落盘的状态。
  }
}

/**
 * 关键经济事务的落盘确认：只要存在未落盘写入（含此前失败遗留）就立即原子写盘。
 * 所有关键经济接口在返回任何 2xx 前都必须通过本确认；幂等重放同样适用。
 * 写盘失败抛错，由接口返回 5xx，客户端保留相同 roundId/actionId 重试。
 */
function ensurePersisted() {
  if (!persistPending && !persistDirty) return;
  persistNow();
}

process.on('exit', flushPersist);
['SIGINT', 'SIGTERM'].forEach((signal) => {
  process.on(signal, () => {
    flushPersist();
    process.exit(0);
  });
});

function run(sql, params = []) {
  db.run(sql, params);
  persist();
}

/**
 * 多步写入的事务包裹：任一步失败整体回滚，避免“对局已记录但奖励未入账”这类半完成状态。
 * sql.js 的写操作是同步的，防抖 persist 只会在事务结束后落盘，不会导出中间态。
 */
function withTransaction(fn) {
  db.run('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.run('COMMIT');
    return result;
  } catch (error) {
    try { db.run('ROLLBACK'); } catch (rollbackError) { /* 连接已断开时忽略 */ }
    throw error;
  }
}

function get(sql, params = []) {
  const statement = db.prepare(sql);
  statement.bind(params);
  try {
    return statement.step() ? statement.getAsObject() : null;
  } finally {
    statement.free();
  }
}

function all(sql, params = []) {
  const statement = db.prepare(sql);
  statement.bind(params);
  const rows = [];
  try {
    while (statement.step()) rows.push(statement.getAsObject());
    return rows;
  } finally {
    statement.free();
  }
}

/** 体力按服务端时钟懒恢复；低于上限时每 5 分钟恢复 1 点，额外发放可超过上限。 */
function getStaminaState(user, at = now()) {
  let current = Math.max(0, Number.parseInt(user.stamina_current, 10) || 0);
  let updatedAt = Number(user.stamina_updated_at) || at;
  if (current >= economy.STAMINA_MAX) {
    updatedAt = at;
  } else {
    const recovered = Math.max(0, Math.floor((at - updatedAt) / economy.STAMINA_REGEN_MS));
    current = Math.min(economy.STAMINA_MAX, current + recovered);
    updatedAt = current >= economy.STAMINA_MAX ? at : updatedAt + recovered * economy.STAMINA_REGEN_MS;
  }
  const dayKey = new Date(at + chinaOffsetMs).toISOString().slice(0, 10);
  const sharedToday = user.player_id
    ? !!get('SELECT 1 FROM stamina_share_claims WHERE player_id = ? AND day_key = ?', [user.player_id, dayKey])
    : false;
  return {
    current,
    updatedAt,
    max: economy.STAMINA_MAX,
    regenSeconds: economy.STAMINA_REGEN_MS / 1000,
    nextRecoveryAt: current >= economy.STAMINA_MAX ? null : new Date(updatedAt + economy.STAMINA_REGEN_MS).toISOString(),
    serverTime: new Date(at).toISOString(),
    shareAvailableToday: !sharedToday,
  };
}

// 按服务端实际开局顺序，每5局一次；rowid保证重试及后续新开局不会改变旧凭证资格。
function heartRescueEligible(playerId, roundId) {
  const round = get('SELECT rowid AS ordinal FROM game_rounds WHERE player_id = ? AND round_id = ?', [playerId, roundId]);
  if (!round) return false;
  const row = get('SELECT COUNT(*) AS count FROM game_rounds WHERE player_id = ? AND rowid <= ?', [playerId, round.ordinal]);
  return Number(row.count) > 0 && Number(row.count) % 5 === 0;
}

function safeProfile(user) {
  const gameCountRow = get('SELECT COUNT(*) AS count FROM round_settlements WHERE player_id = ?', [user.player_id]);
  return {
    playerId: user.player_id,
    nickname: user.nickname,
    avatarUrl: user.avatar_url,
    registeredAt: new Date(user.created_at).toISOString(),
    level: user.level,
    experience: user.experience,
    moodBeanBalance: user.mood_bean_balance,
    assetRevision: user.asset_revision,
    inventory: { hammer: user.hammer_count, magicWand: user.wand_count, reviveCard: user.revive_card_count },
    totalMoodBeans: user.total_mood_beans,
    highestSingleGameScore: user.highest_single_game_score,
    gameCount: Number(gameCountRow && gameCountRow.count) || 0,
    stamina: getStaminaState(user),
  };
}

function findUser(token) {
  if (!token) return null;
  return get('SELECT * FROM players WHERE token = ?', [token]);
}

function authenticate(req, res) {
  const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const user = findUser(token);
  if (!user) {
    fail(res, '登录已失效，请重新进入游戏', 401, 'UNAUTHORIZED');
    return null;
  }
  res.locals.auditUser = user;
  if (process.env.NODE_ENV === 'production' && process.env.ALLOW_GUEST_ACCOUNTS !== '1' && !user.wechat_openid) {
    fail(res, '请通过微信重新登录', 401, 'WECHAT_LOGIN_REQUIRED'); return null;
  }
  if (risk && !risk.guard(req, res, user)) return null;
  return user;
}

function getExperienceTarget(level) {
  return Math.max(15, Math.ceil(15 * Math.pow(1.32, Math.max(1, level) - 1)));
}

function addExperience(user, amount) {
  let level = user.level;
  let experience = user.experience + amount;
  while (experience >= getExperienceTarget(level)) {
    experience -= getExperienceTarget(level);
    level++;
  }
  return { level, experience };
}

/**
 * 永久榜单：积分榜基于最高分；开心榜只读取当前钱包余额。
 * 动态 SQL 列名只来自内部白名单，不接受请求中的任意字段。
 */
function leaderboard(user, type = 'power') {
  const column = type === 'beans' ? 'mood_bean_balance' : 'highest_single_game_score';
  const rows = all(
    `SELECT player_id, nickname, avatar_url, ${column} AS value
     FROM players WHERE ${column} > 0
     ORDER BY ${column} DESC, updated_at ASC, player_id ASC
     LIMIT 200`,
  );
  const entries = rows.map((row, index) => ({
    rank: rows.findIndex(other => other.value === row.value) + 1,
    playerId: row.player_id,
    nickname: row.nickname,
    avatarUrl: row.avatar_url,
    value: row.value,
    rewardTier: index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : 'normal',
  }));
  const bestScore = Math.max(0, user.highest_single_game_score || 0);
  const moodBeanBalance = Math.max(0, user.mood_bean_balance || 0);
  const value = type === 'beans' ? moodBeanBalance : bestScore;
  const onBoard = entries.some((entry) => entry.playerId === user.player_id);
  // 数值严格高于自己的人数 + 1；同值并列，余额为 0 不上榜。
  let rank = null;
  if (value > 0) {
    const higher = get(`SELECT COUNT(*) AS count FROM players WHERE ${column} > ?`, [value]);
    rank = (Number(higher && higher.count) || 0) + 1;
  }
  return { type, entries, self: { playerId: user.player_id, avatarUrl: user.avatar_url,
    rank, bestScore, moodBeanBalance, value, onBoard } };
}

risk = require('./riskControl').createRiskControl({ app, get, all, run, ensurePersisted, now, fail });

app.get(['/health', '/v1/cocos-zyx/health'], (_req, res) => {
  ok(res, { ok: true, service: 'cocos-zyx-cloud', apiVersion: 18, schemaVersion: 12, capabilities: ['wechat-login', 'stamina', 'round-start', 'settlement', 'power-leaderboard', 'bean-balance-leaderboard', 'daily-share', 'bean-collection-progress', 'adaptive-combo-v2', 'bean-collection-1pct', 'bean-tool-shop', 'difficulty-ramp-2x', 'difficulty-pressure-v4', 'rising-rows-v5', 'balloon-rescue-v6', 'balloon-blast-v7', 'random-rescue-v8', 'rescue-scoring-v9', 'heart-rescue-v10', 'round-checkpoints-v1', 'revive-card-v11', 'round-tools-lightning-v12', 'rising-specials-lightning-v13', 'reward-intents-v1', 'security-audit-v1'], checkedAt: new Date().toISOString() });
});

app.post('/v1/cocos-zyx/players/bootstrap', async (req, res) => {
  try {
    const deviceId = stringValue(req.body.deviceId, 128);
    const loginCode = stringValue(req.body.loginCode, 128);
    if ((process.env.NODE_ENV === 'production' || process.env.SECURITY_ENFORCE_LIMITS === '1')
      && !risk.allow('bootstrap:' + req.socket.remoteAddress, 60, 60000)) return fail(res, '登录请求过于频繁', 429, 'RATE_LIMITED');
    if (process.env.NODE_ENV === 'production' && process.env.ALLOW_GUEST_ACCOUNTS !== '1' && !loginCode)
      return fail(res, '请通过微信登录', 401, 'WECHAT_LOGIN_REQUIRED');
    if (!deviceId) return fail(res, '缺少设备标识', 400, 'DEVICE_ID_REQUIRED');

    // 微信端只信任服务端用一次性 code 换回的 openid；Web 预览才单独使用 deviceId。
    const wechatOpenId = loginCode ? await exchangeWeChatLoginCode(loginCode) : '';
    const deviceUser = get('SELECT * FROM players WHERE device_id = ?', [deviceId]);
    if (!wechatOpenId && deviceUser && deviceUser.wechat_openid) {
      return fail(res, '请通过微信重新登录', 401, 'WECHAT_LOGIN_REQUIRED');
    }
    let user = wechatOpenId
      ? get('SELECT * FROM players WHERE wechat_openid = ?', [wechatOpenId])
      : deviceUser;

    // 设备ID不是所有权凭据：首次绑定必须同时持有原设备账号令牌。
    const deviceToken = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!user && wechatOpenId && deviceUser && !deviceUser.wechat_openid && deviceToken !== deviceUser.token)
      return fail(res, '需要原设备账号凭据，请更新游戏后重试', 401, 'DEVICE_CLAIM_REQUIRED');
    if (!wechatOpenId && deviceUser && (process.env.NODE_ENV === 'production' || process.env.REQUIRE_DEVICE_TOKEN === '1') && deviceToken !== deviceUser.token)
      return fail(res, '设备账号凭据已失效', 401, 'UNAUTHORIZED');
    // 旧账号首次微信登录时原地绑定，保留 playerId、资产、分数和历史对局。
    if (!user && wechatOpenId && deviceUser && !deviceUser.wechat_openid) {
      run('UPDATE players SET wechat_openid = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?',
        [wechatOpenId, now(), deviceUser.player_id]);
      user = get('SELECT * FROM players WHERE player_id = ?', [deviceUser.player_id]);
    }

    // bootstrap 只负责身份建档，资料只能经显式授权接口修改；其他客户端数值一律忽略。
    if (!user) {
      const createdAt = now();
      // 同一设备切换微信账号时不能再占用旧账号的唯一 deviceId，身份仍以 openid 为准。
      const storedDeviceId = deviceUser ? `wx_${crypto.randomBytes(18).toString('hex')}` : deviceId;
      run(
        `INSERT INTO players (player_id, device_id, wechat_openid, token, nickname, avatar_url, level, experience,
          mood_bean_balance, total_mood_beans, highest_single_game_score, stamina_current, stamina_updated_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 1, 0, 0, 0, 0, ?, ?, ?, ?)`,
        [newGuestId(), storedDeviceId, wechatOpenId || null, newToken(), createDefaultNickname(), '', economy.STAMINA_MAX, createdAt, createdAt, createdAt],
      );
      // R5：新玩家建档是关键经济事务，落盘成功后才能返回。
      ensurePersisted();
      user = get('SELECT * FROM players WHERE device_id = ?', [storedDeviceId]);
    } else {
      // 历史通用名只迁移一次，之后登录绝不覆盖默认昵称或已授权微信资料。
      if (user.nickname === '解忧玩家' || user.nickname === '顺心朋友') {
        run('UPDATE players SET nickname = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?',
          [createDefaultNickname(), now(), user.player_id]);
      }
      // 建档落盘失败后的重试会走到这里：必须先把内存中的档案可靠写盘才能返回 2xx。
      if (persistDirty || persistPending) ensurePersisted();
      user = get('SELECT * FROM players WHERE player_id = ?', [user.player_id]);
    }
    if (req.body.securityProtocol === 1 && user.security_version !== 1) {
      run('UPDATE players SET security_version=1 WHERE player_id=?', [user.player_id]); ensurePersisted();
    }
    ok(res, { token: user.token, serverTime: new Date().toISOString(), profile: safeProfile(user) });
  } catch (error) {
    fail(res, error.message || '初始化玩家失败', error.status || 500, error.errorCode);
  }
});

/** 微信资料由玩家主动授权后单独更新，普通 bootstrap 不得覆盖。 */
app.post('/v1/cocos-zyx/players/profile', (req, res) => {
  try {
    const user = authenticate(req, res);
    if (!user) return;
    const nickname = stringValue(req.body.nickname, 24);
    const avatarUrl = stringValue(req.body.avatarUrl, 512);
    if (!nickname) return fail(res, '微信昵称不能为空', 400, 'PROFILE_NICKNAME_INVALID');
    if (avatarUrl && !/^https:\/\//i.test(avatarUrl)) {
      return fail(res, '微信头像地址无效', 400, 'PROFILE_AVATAR_INVALID');
    }
    run('UPDATE players SET nickname = ?, avatar_url = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?',
      [nickname, avatarUrl, now(), user.player_id]);
    ensurePersisted();
    ok(res, { profile: safeProfile(get('SELECT * FROM players WHERE player_id = ?', [user.player_id])) });
  } catch (error) {
    fail(res, error.message || '更新玩家资料失败', 500);
  }
});

function roundToolState(playerId, roundId) {
  const state = {};
  for (const item of ['hammer', 'magicWand']) {
    const row = get(`SELECT SUM(CASE WHEN kind = 'reward' THEN 1 ELSE 0 END) AS acquired,
      SUM(CASE WHEN kind = 'use' THEN 1 ELSE 0 END) AS used FROM tool_transactions
      WHERE player_id = ? AND round_id = ? AND item = ?`, [playerId, roundId, item]);
    const acquired = row.acquired || 0, used = row.used || 0;
    state[item] = { acquired, used, owned: Math.max(0, acquired - used) };
  }
  return state;
}
const progress = require('./roundProgress').createRoundProgress({ app, get, run, withTransaction, ensurePersisted, authenticate, ok, fail, now, heartRescueEligible, safeProfile, roundToolState,
  validateRewards: (round, actions) => rewards.checkActions(round, actions) });
rewards = require('./rewardSecurity').createRewardSecurity({ app, get, all, run, withTransaction, ensurePersisted, authenticate, ok, fail, now, progress, roundToolState });

/** 入局凭证由服务端记录，体力在这里扣除；同一 roundId 重试不会重复扣点。 */
app.post('/v1/cocos-zyx/games/start', (req, res) => {
  try {
    const user = authenticate(req, res);
    if (!user) return;
    const roundId = stringValue(req.body.roundId, 96);
    if (!roundId) return fail(res, '缺少对局标识', 400, 'ROUND_ID_INVALID');
    const collectionRule = req.body.collectionRule || 'legacy';
    const rulesVersion = req.body.rulesVersion === undefined ? 1 : Number(req.body.rulesVersion);
    if (![1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, BOARD_RULES_VERSION].includes(rulesVersion)) return fail(res, '不支持的棋盘规则', 400, 'BOARD_RULES_UNSUPPORTED');
    if (!['legacy', 'progress_v1', economy.MOOD_COLLECTION_RULE].includes(collectionRule)) return fail(res, '不支持的收集规则', 400, 'COLLECTION_RULE_UNSUPPORTED');

    const existing = get('SELECT * FROM game_rounds WHERE player_id = ? AND round_id = ?', [user.player_id, roundId]);
    if (existing) {
      if (existing.status !== 'active') return fail(res, '此对局已结算', 409, 'ROUND_ALREADY_SETTLED');
      if (existing.rules_version !== rulesVersion) return fail(res, '对局棋盘规则不一致', 409, 'BOARD_RULES_UNSUPPORTED');
      if (existing.collection_rule !== collectionRule) return fail(res, '对局收集规则不一致', 409, 'ROUND_COLLECTION_RULE_CONFLICT');
      const saved = progress.checkpoint(user.player_id, roundId);
      if (saved && (req.body.resumeProtocol !== 1 || JSON.parse(saved.actions_json).length > 1 || saved.resume_generation > 0)) return fail(res, '已有保存进度，请继续上局', 409, 'ROUND_RESUME_REQUIRED');
      ensurePersisted();
      const fresh = get('SELECT * FROM players WHERE player_id = ?', [user.player_id]);
      return ok(res, {
        roundId,
        duplicate: true,
        ...(saved ? { sessionToken: saved.session_token, generation: saved.resume_generation, startedAt: existing.started_at } : {}),
        stamina: getStaminaState(fresh),
        seed: existing.seed,
        isTutorial: !!existing.is_tutorial,
        collectionRule: existing.collection_rule,
        rulesVersion: existing.rules_version,
        heartRescueEligible: existing.rules_version >= 10 && heartRescueEligible(user.player_id, roundId),
        profile: safeProfile(fresh),
      });
    }

    // 滚动发布期间保留V5–V10与当前V11新开局；更早协议仅供历史局补传。
    // 都必须使用当前收集规则、服务端种子及完整重放，不开放旧奖励协议。
    if ((![5, 6, 7, 8, 9, 10, 11, 12, BOARD_RULES_VERSION].includes(rulesVersion) || collectionRule !== economy.MOOD_COLLECTION_RULE)
      && process.env.ALLOW_LEGACY_ROUND_STARTS !== '1') {
      return fail(res, '请更新游戏后重新开始', 400, 'COLLECTION_RULE_UNSUPPORTED');
    }

    const resumable = req.body.resumeProtocol === 1;
    if (req.body.resumeProtocol !== undefined && (!resumable || ![10, 11, 12, BOARD_RULES_VERSION].includes(rulesVersion))) return fail(res, '不支持的保存协议', 400, 'BOARD_RULES_UNSUPPORTED');
    const secureRound = req.body.securityProtocol === 1;
    if (!secureRound && (process.env.REQUIRE_SECURITY_PROTOCOL === '1' || (rulesVersion >= 13 && process.env.ALLOW_LEGACY_ROUND_STARTS !== '1')))
      return fail(res, '请更新游戏以使用安全核验协议', 400, 'SECURITY_PROTOCOL_REQUIRED');
    const previous = progress.active(user.player_id);
    if (previous) {
      const saved = progress.checkpoint(user.player_id, previous.round_id);
      if (!resumable || req.body.replaceRoundId !== previous.round_id || req.body.replacementGeneration !== saved.resume_generation)
        return fail(res, '还有未结算的对局，可以继续上局', 409, 'ROUND_RESUME_REQUIRED');
      if (!progress.guard(user.player_id, previous.round_id, req.body.replaceSessionToken, res)) return;
    }
    const startedAt = now();
    const state = getStaminaState(user, startedAt);
    if (state.current < economy.STAMINA_COST_PER_ROUND) {
      return res.status(429).json({
        code: 429,
        message: '体力不足，请等待恢复',
        errorCode: 'STAMINA_EMPTY',
        data: { stamina: state },
      });
    }

    // 生成对局种子：服务端权威随机源，客户端用同一种子驱动棋盘生成
    const seed = crypto.randomBytes(4).readUInt32BE(0) || 1;
    // 判断教学局：完成局数 < 2 时为教学
    const gameCountRow = get('SELECT COUNT(*) AS count FROM round_settlements WHERE player_id = ?', [user.player_id]);
    const gameCount = Number(gameCountRow && gameCountRow.count) || 0;
    const isTutorial = gameCount < 2;

    let stamina;
    withTransaction(() => {
      // 旧客户端在升级后补领的库存，进入V12前同样折算；清零与凭据同事务，不重复返还。
      if (rulesVersion >= 12 && (user.hammer_count > 0 || user.wand_count > 0)) {
        const beans = (user.hammer_count + user.wand_count) * 3;
        run('INSERT OR IGNORE INTO tool_inventory_refunds (player_id, hammer_count, wand_count, awarded_beans, created_at) VALUES (?, 0, 0, 0, ?)', [user.player_id, startedAt]);
        run('UPDATE tool_inventory_refunds SET hammer_count = hammer_count + ?, wand_count = wand_count + ?, awarded_beans = awarded_beans + ? WHERE player_id = ?', [user.hammer_count, user.wand_count, beans, user.player_id]);
        run('UPDATE players SET mood_bean_balance = mood_bean_balance + ?, hammer_count = 0, wand_count = 0 WHERE player_id = ?', [beans, user.player_id]);
      }
      const spent = state.current - economy.STAMINA_COST_PER_ROUND;
      run('UPDATE players SET stamina_current = ?, stamina_updated_at = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?',
        [spent, state.updatedAt, startedAt, user.player_id]);
      run('INSERT INTO game_rounds (player_id, round_id, started_at, status, seed, is_tutorial, collection_rule, rules_version, tool_rules_version, security_version) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
        [user.player_id, roundId, startedAt, 'active', seed, isTutorial ? 1 : 0, collectionRule, rulesVersion, secureRound ? 1 : 0]);
      if (resumable) progress.initialize(user.player_id, roundId, rulesVersion);
      if (previous) run("UPDATE game_rounds SET status = 'abandoned' WHERE player_id = ? AND round_id = ?", [user.player_id, previous.round_id]);
      stamina = getStaminaState({ player_id: user.player_id, stamina_current: spent, stamina_updated_at: state.updatedAt }, startedAt);
    });
    ensurePersisted();
    ok(res, { roundId, stamina, seed, isTutorial, collectionRule, rulesVersion, ...(resumable ? { sessionToken: progress.checkpoint(user.player_id, roundId).session_token, generation: 0, startedAt } : {}), heartRescueEligible: rulesVersion >= 10 && heartRescueEligible(user.player_id, roundId), profile: safeProfile(get('SELECT * FROM players WHERE player_id = ?', [user.player_id])) });
  } catch (error) {
    fail(res, error.message || '开始对局失败', 500);
  }
});

/** 分享补体力：每个服务端玩家按北京时间每天领取一次，允许额外体力超过自然恢复上限。 */
app.post('/v1/cocos-zyx/stamina/share-claim', (req, res) => {
  try {
    const user = authenticate(req, res);
    if (!user) return;
    const claimId = stringValue(req.body.claimId, 96);
    if (!/^share_[a-z0-9_]{8,80}$/.test(claimId)) return fail(res, '缺少领取标识', 400, 'SHARE_CLAIM_ID_INVALID');
    const claimedAt = now();
    const dayKey = new Date(claimedAt + chinaOffsetMs).toISOString().slice(0, 10);
    const sameClaim = get('SELECT day_key FROM stamina_share_claims WHERE player_id = ? AND claim_id = ?', [user.player_id, claimId]);
    if (sameClaim) {
      ensurePersisted();
      const previousDay = sameClaim.day_key !== dayKey;
      return ok(res, { duplicate: true, awarded: previousDay ? 0 : economy.STAMINA_SHARE_REWARD,
        previousDay, stamina: getStaminaState(get('SELECT * FROM players WHERE player_id = ?', [user.player_id]), claimedAt) });
    }
    const existing = get('SELECT claim_id FROM stamina_share_claims WHERE player_id = ? AND day_key = ?', [user.player_id, dayKey]);
    if (existing) {
      ensurePersisted();
      const fresh = get('SELECT * FROM players WHERE player_id = ?', [user.player_id]);
      const stamina = getStaminaState(fresh, claimedAt);
      return res.status(429).json({
        code: 429,
        message: '今天的分享体力已经领取，明天再来吧',
        errorCode: 'STAMINA_SHARE_DAILY_LIMIT',
        data: { stamina },
      });
    }
    const state = getStaminaState(user, claimedAt);
    withTransaction(() => {
      rewards.consume(req, user, 'stamina', null, claimId);
      run('UPDATE players SET stamina_current = ?, stamina_updated_at = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?',
        [state.current + economy.STAMINA_SHARE_REWARD, state.updatedAt, claimedAt, user.player_id]);
      run('INSERT INTO stamina_share_claims (player_id, day_key, claim_id, claimed_at) VALUES (?, ?, ?, ?)',
        [user.player_id, dayKey, claimId, claimedAt]);
    });
    ensurePersisted();
    const fresh = get('SELECT * FROM players WHERE player_id = ?', [user.player_id]);
    ok(res, { awarded: economy.STAMINA_SHARE_REWARD, stamina: getStaminaState(fresh, claimedAt) });
  } catch (error) {
    fail(res, error.message || '领取分享体力失败', error.status || 500, error.businessCode);
  }
});

/** 固定商品表；客户端不能指定价格、数量或库存基线。 */
const TOOL_COLUMNS = { hammer: 'hammer_count', magicWand: 'wand_count' };
const SHOP_PRICES = { stamina: 3, reviveCard: 25 };
const INVENTORY_COLUMNS = { ...TOOL_COLUMNS, reviveCard: 'revive_card_count' };
async function transactTool(req, res, kind) {
  try {
    let user = authenticate(req, res);
    if (!user) return;
    const { actionId, item } = req.body;
    if (typeof actionId !== 'string' || !/^[a-zA-Z0-9_:.-]{8,160}$/.test(actionId)
      || typeof item !== 'string' || !Object.prototype.hasOwnProperty.call(kind === 'exchange' ? SHOP_PRICES : TOOL_COLUMNS, item)) {
      return fail(res, '兑换或道具参数无效', 400, 'TOOL_REQUEST_INVALID');
    }
    const roundId = kind === 'exchange' ? '' : req.body.roundId;
    if (kind !== 'exchange' && !progress.guard(user.player_id, roundId, req.body.sessionToken, res)) return;
    const actionIndex = kind === 'use' ? req.body.actionIndex : -1;
    const target = kind === 'use' ? req.body.target : -1;
    if (kind !== 'exchange' && (typeof roundId !== 'string' || roundId.length > 96 || !roundId)) {
      return fail(res, '缺少对局标识', 400, 'TOOL_REQUEST_INVALID');
    }
    if (kind === 'use' && (!Number.isSafeInteger(actionIndex) || actionIndex < 1 || actionIndex > 100000
      || !Number.isSafeInteger(target) || target < 0 || target > 1000000)) {
      return fail(res, '道具目标无效', 400, 'TOOL_REQUEST_INVALID');
    }
    const existing = get('SELECT * FROM tool_transactions WHERE player_id = ? AND action_id = ?', [user.player_id, actionId]);
    if (existing) {
      if (existing.kind !== kind || existing.item !== item || existing.round_id !== roundId
        || existing.action_index !== actionIndex || existing.target !== target) {
        return fail(res, '同一操作内容不一致', 409, 'TOOL_PAYLOAD_CONFLICT');
      }
      ensurePersisted();
      return ok(res, { duplicate: true, item, price: kind === 'exchange' ? SHOP_PRICES[item] : 0, profile: safeProfile(user),
        ...(kind !== 'exchange' ? { roundTools: roundToolState(user.player_id, roundId) } : {}) });
    }
    let roundScoped = false;
    let round;
    if (kind !== 'exchange') {
      round = get('SELECT * FROM game_rounds WHERE player_id=? AND round_id=?', [user.player_id, roundId]);
      if (!round || round.status !== 'active' || round.started_at < now() - economy.MAX_OFFLINE_SETTLEMENT_AGE_MS) {
        return fail(res, '当前对局不可使用道具', 409, 'ROUND_NOT_ACTIVE');
      }
      if (kind === 'use' && rewards.secure(round)) {
        if (!Array.isArray(req.body.actions) || actionIndex !== req.body.actions.length) return fail(res, '缺少当前操作核验信息', 400, 'TOOL_PROOF_REQUIRED');
        const verified = await progress.validate(round, progress.checkpoint(user.player_id, roundId), req.body.actions, req.body.elapsedMs);
        const board = verified.replay && verified.replay.board;
        if (!board || board.isGameOver() || (item === 'hammer' ? !board.getPiece(target) : !board.pieces.some(piece => piece.color === target)))
          return fail(res, '当前道具目标不存在', 400, 'TOOL_PROOF_REQUIRED');
        const concurrent = get('SELECT * FROM tool_transactions WHERE player_id=? AND action_id=?', [user.player_id, actionId]);
        if (concurrent) {
          if (concurrent.kind !== kind || concurrent.item !== item || concurrent.round_id !== roundId || concurrent.action_index !== actionIndex || concurrent.target !== target)
            return fail(res, '同一操作内容不一致', 409, 'TOOL_PAYLOAD_CONFLICT');
          ensurePersisted(); return ok(res, { duplicate: true, item, price: 0, profile: safeProfile(get('SELECT * FROM players WHERE player_id=?', [user.player_id])), roundTools: roundToolState(user.player_id, roundId) });
        }
        user = get('SELECT * FROM players WHERE player_id=?', [user.player_id]);
      }
    }
    if (kind !== 'exchange') {
      roundScoped = round.rules_version >= 12;
      const tool = roundToolState(user.player_id, roundId)[item];
      if (kind === 'reward') {
        // 分享/广告补给沿用现有客户端完成回调，每局每种最多三次，限制重复伪造领取。
        const claims = get("SELECT COUNT(*) AS count FROM tool_transactions WHERE player_id = ? AND round_id = ? AND item = ? AND kind = 'reward'", [user.player_id, roundId, item]);
        const limit = roundScoped && item === 'magicWand' ? 1 : 3;
        if (claims.count >= limit) return fail(res, `每局仅可获得${limit}次`, 409, 'TOOL_REWARD_LIMIT');
        if (roundScoped && tool.owned > 0) return fail(res, '请先使用已领取的道具', 409, 'TOOL_ALREADY_OWNED');
      } else if (get("SELECT 1 FROM tool_transactions WHERE player_id = ? AND round_id = ? AND action_index = ? AND kind = 'use'", [user.player_id, roundId, actionIndex])) {
        return fail(res, '这一步已经使用过道具', 409, 'TOOL_PAYLOAD_CONFLICT');
      }
      if (kind === 'use' && roundScoped && tool.owned < 1) return fail(res, '请先领取本局道具', 409, 'TOOL_INSUFFICIENT');
    }
    const column = INVENTORY_COLUMNS[item];
    const price = kind === 'exchange' ? SHOP_PRICES[item] : 0;
    if (kind === 'exchange' && user.mood_bean_balance < price) return fail(res, `开心豆不足，需要 ${price} 颗`, 409, 'BEANS_INSUFFICIENT');
    if (kind === 'use' && !roundScoped && user[column] < 1) return fail(res, '道具库存不足', 409, 'TOOL_INSUFFICIENT');
    withTransaction(() => {
      if (kind === 'reward') rewards.consume(req, user, item === 'hammer' ? 'hammer' : 'tool', round, actionId);
      const delta = kind === 'use' ? -1 : 1;
      if (item === 'stamina') {
        const at = now();
        const state = getStaminaState(user, at);
        run('UPDATE players SET mood_bean_balance = mood_bean_balance - ?, stamina_current = ?, stamina_updated_at = ?, asset_revision = asset_revision + 1, updated_at = ? WHERE player_id = ?',
          [price, state.current + 1, state.updatedAt, at, user.player_id]);
      } else if (!roundScoped) {
        run(`UPDATE players SET mood_bean_balance = mood_bean_balance - ?, ${column} = ${column} + ?, asset_revision = asset_revision + 1, updated_at = ? WHERE player_id = ?`,
          [price, delta, now(), user.player_id]);
      }
      run('INSERT INTO tool_transactions (player_id, action_id, kind, item, round_id, action_index, target, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [user.player_id, actionId, kind, item, roundId, actionIndex, target, now()]);
    });
    ensurePersisted();
    ok(res, { item, price, profile: safeProfile(get('SELECT * FROM players WHERE player_id = ?', [user.player_id])),
      ...(kind !== 'exchange' ? { roundTools: roundToolState(user.player_id, roundId) } : {}) });
  } catch (error) { fail(res, error.message || '道具操作未确认，请重试', error.status || 500, error.businessCode); }
}
app.post('/v1/cocos-zyx/shop/exchanges', (req, res) => transactTool(req, res, 'exchange'));
app.post('/v1/cocos-zyx/games/tools/use', (req, res) => transactTool(req, res, 'use'));
app.post('/v1/cocos-zyx/games/tools/reward', (req, res) => transactTool(req, res, 'reward'));

app.post('/v1/cocos-zyx/games/settlements', async (req, res) => {
  try {
    let user = authenticate(req, res);
    if (!user) return;
    const roundId = stringValue(req.body.roundId, 96);
    if (!roundId) return fail(res, '缺少对局标识');
    const startedAt = req.body.startedAt;
    const endedAt = req.body.endedAt;
    const score = req.body.score;
    if (!Number.isSafeInteger(score) || score < 0 || score > 1000000) return fail(res, '分数格式或范围异常', 400, 'REPLAY_INVALID');
    // 历史字段名表示带表情块原始数，不是奖励豆子数。
    const collectedMoodBeanCount = Number(req.body.collectedMoodBeanCount);
    if (!Number.isSafeInteger(collectedMoodBeanCount) || collectedMoodBeanCount < 0
      || collectedMoodBeanCount > economy.MAX_COLLECTED_MOOD_BLOCKS_PER_ROUND) return fail(res, '收集数量异常', 400, 'COLLECTION_COUNT_INVALID');
    // R6：规范化经济载荷后再比较，字段固定顺序，禁止依赖 JSON 属性顺序。
    const payloadJson = JSON.stringify({ startedAt, endedAt, score, collectedMoodBeanCount });

    // R6：幂等按玩家作用域。同一玩家重复提交时先比对载荷：
    // 载荷一致返回第一次保存的结果快照；载荷不同返回 409，不改变任何数据。
    const existing = get('SELECT * FROM round_settlements WHERE player_id = ? AND round_id = ?', [user.player_id, roundId]);
    if (existing) {
      if (existing.payload_json === payloadJson) {
        // 幂等重放也必须先完成落盘确认：上次 2xx 前的写盘可能失败，内存记录不代表已持久化。
        ensurePersisted();
        return ok(res, { duplicate: true, ...JSON.parse(existing.result_json) });
      }
      return fail(res, '同一对局标识的请求内容不一致', 409, 'ROUND_PAYLOAD_CONFLICT');
    }

    const startedRound = get('SELECT * FROM game_rounds WHERE player_id = ? AND round_id = ?', [user.player_id, roundId]);
    if (!startedRound) return fail(res, '对局未在服务端开始', 409, 'ROUND_NOT_STARTED');
    if (startedRound.status !== 'active') return fail(res, '此对局已结算', 409, 'ROUND_ALREADY_SETTLED');
    const checked = await progress.checkSettlement(startedRound, req, res);
    if (!checked) return;

    if (!Number.isSafeInteger(startedAt) || !Number.isSafeInteger(endedAt)) return fail(res, '对局时间异常', 400, 'INVALID_ROUND_TIME');
    const duration = endedAt - startedAt;
    if (duration < economy.MIN_ROUND_DURATION_MS || duration > economy.MAX_ROUND_DURATION_MS) return fail(res, '对局时长异常', 400, 'INVALID_ROUND_DURATION');
    if (endedAt > now() + economy.MAX_FUTURE_SKEW_MS) return fail(res, '对局时间异常', 400, 'INVALID_ROUND_TIME');
    if (now() - startedRound.started_at < economy.MIN_ROUND_DURATION_MS) return fail(res, '对局时长异常', 400, 'ROUND_TOO_SHORT');
    // 离线补传窗口依据服务端记录的开局时间，客户端改本地时钟不能延长窗口。
    if (startedRound.started_at < now() - economy.MAX_OFFLINE_SETTLEMENT_AGE_MS) return fail(res, '对局超出离线补传窗口', 400, 'SETTLEMENT_TOO_OLD');

    // ---- 种子重放校验：服务端用相同种子重放操作序列，验证分数和心情豆 ----
    const actions = Array.isArray(req.body.actions) ? req.body.actions : [];
    if (actions.length > 100000) return fail(res, '操作序列过长', 400, 'REPLAY_INVALID');
    if (startedRound.rules_version >= 5) {
      // V8由棋盘重放逐次检查两种提示的共享60秒CD，不设整局次数上限。
      // 旧协议按对局时长检查总量；广告复活每局一次，V11额外一张卡，均固定清理顶部8排。
      const clearCount = actions.filter(action => action && ['clear', 'balloonOffer', 'rescueOffer'].includes(action.type)).length;
      const revives = actions.filter(action => action && action.type === 'revive');
      const cards = actions.filter(action => action && action.type === 'reviveCard');
      const elapsed = Math.max(0, Math.min(duration, now() - startedRound.started_at));
      if ((startedRound.rules_version < 8 && clearCount > 1 + Math.floor(elapsed / 60000)) || revives.length > 1 || cards.length > (startedRound.rules_version >= 11 ? 1 : 0)
        || (startedRound.rules_version >= 8 && actions.some(action => action && ['rescueOffer', 'heartOffer'].includes(action.type)
          && (!Number.isSafeInteger(action.elapsedMs) || action.elapsedMs < 0 || action.elapsedMs > elapsed)))
        || [...revives, ...cards].some(action => action.rowCount !== 8)) {
        return fail(res, '救场次数或范围异常', 400, 'REPLAY_INVALID');
      }
    }
    // 新规则中，每一次道具操作都必须有已经扣库存的服务端凭据。
    if (startedRound.tool_rules_version === 1) {
      for (let index = 0; index < actions.length; index++) {
        const action = actions[index];
        if (!action || !['hammer', 'purify', 'reviveCard'].includes(action.type)) continue;
        const use = get("SELECT item, target FROM tool_transactions WHERE player_id = ? AND round_id = ? AND kind = 'use' AND action_index = ?",
          [user.player_id, roundId, index]);
        if (!use || use.item !== (action.type === 'reviveCard' ? 'reviveCard' : action.type === 'hammer' ? 'hammer' : 'magicWand')
          || use.target !== (action.type === 'reviveCard' ? 8 : action.type === 'hammer' ? action.id : action.color)) {
          return fail(res, '道具使用记录未确认', 400, 'REPLAY_INVALID');
        }
      }
    }
    const progressRule = ['progress_v1', economy.MOOD_COLLECTION_RULE].includes(startedRound.collection_rule);
    if ((startedRound.rules_version >= 2 || (progressRule && collectedMoodBeanCount > 0))
      && (!actions.length || !startedRound.seed)) {
      return fail(res, '收集结算缺少重放操作', 400, 'REPLAY_INVALID');
    }
    if (!progressRule && collectedMoodBeanCount > economy.MAX_COLLECTED_MOOD_BEANS_PER_ROUND) return fail(res, '收集数量异常', 400, 'COLLECTION_COUNT_INVALID');
    if (actions.length > 0 && startedRound.seed) {
      const replayResult = checked.replay || await verifyReplay({ seed: startedRound.seed, tutorial: !!startedRound.is_tutorial, actions,
        version: startedRound.rules_version, heartEligible: startedRound.rules_version >= 10 && heartRescueEligible(user.player_id, roundId) });
      if (!replayResult.valid) {
        return fail(res, '操作序列校验失败', 400, 'REPLAY_INVALID');
      }
      if (replayResult.score !== score || replayResult.collectedMoodBeans !== collectedMoodBeanCount) {
        console.warn(`[结算校验] 玩家 ${user.player_id} 局 ${roundId} 重放不一致: 提交 score=${score} beans=${collectedMoodBeanCount}, 重放 score=${replayResult.score} beans=${replayResult.collectedMoodBeans}`);
        return fail(res, '结算数据校验失败', 400, 'REPLAY_MISMATCH');
      }
    }

    // 重放期间其他请求可能已结算/续玩/消费资产，不能用异步前的状态再次入账。
    const committed = get('SELECT * FROM round_settlements WHERE player_id=? AND round_id=?', [user.player_id, roundId]);
    if (committed) {
      if (committed.payload_json !== payloadJson) return fail(res, '同一对局标识的请求内容不一致', 409, 'ROUND_PAYLOAD_CONFLICT');
      ensurePersisted(); return ok(res, { duplicate: true, ...JSON.parse(committed.result_json) });
    }
    const currentRound = get('SELECT * FROM game_rounds WHERE player_id=? AND round_id=?', [user.player_id, roundId]);
    if (currentRound.status !== 'active') return fail(res, '此对局状态已更新', 409, 'ROUND_NOT_ACTIVE');
    if (!progress.guard(user.player_id, roundId, req.body.sessionToken, res)) return;
    user = get('SELECT * FROM players WHERE player_id=?', [user.player_id]);
    const settledAt = now();
    // 每局独立换算整颗开心豆；保留旧客户端与历史开局的结算协议。
    const baseMoodBeans = progressRule ? economy.collectedBlocksToBeans(collectedMoodBeanCount, startedRound.collection_rule) : collectedMoodBeanCount;
    const bonusMoodBeans = 0;
    const awardedMoodBeans = baseMoodBeans + bonusMoodBeans;
    const gainedExperience = collectedMoodBeanCount;
    const experience = addExperience(user, gainedExperience);
    const highestScore = Math.max(user.highest_single_game_score, score);

    let resultData;
    // 结算记录与玩家进度同事务写入；单局最高分直接落在 players，排行榜实时读取，无需额外表。
    withTransaction(() => {
      run('INSERT INTO round_settlements (player_id, round_id, score, mood_token_count, awarded_mood_beans, payload_json, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [user.player_id, roundId, score, collectedMoodBeanCount, awardedMoodBeans, payloadJson, '', settledAt]);
      run('UPDATE game_rounds SET status = ?, settled_at = ? WHERE player_id = ? AND round_id = ?',
        ['settled', settledAt, user.player_id, roundId]);
      run(`UPDATE players SET mood_bean_balance = mood_bean_balance + ?, total_mood_beans = total_mood_beans + ?,
           highest_single_game_score = ?, level = ?, experience = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?`,
        [awardedMoodBeans, awardedMoodBeans, highestScore, experience.level, experience.experience, settledAt, user.player_id]);
      const fresh = get('SELECT * FROM players WHERE player_id = ?', [user.player_id]);
      resultData = {
        accepted: true,
        roundId,
        settlement: {
          score,
          baseMoodBeans,
          bonusMoodBeans,
          awardedMoodBeans,
          gainedExperience,
          profile: safeProfile(fresh),
        },
      };
      // 保存第一次事务完成后的权威结果快照，重复请求原样返回。
      run('UPDATE round_settlements SET result_json = ? WHERE player_id = ? AND round_id = ?',
        [JSON.stringify(resultData), user.player_id, roundId]);
    });
    // R5：关键经济事务落盘成功后才能返回 2xx；写盘失败返回 5xx，客户端用同一 roundId 重试。
    ensurePersisted();
    ok(res, resultData);
  } catch (error) {
    fail(res, error.message || '对局结算失败', error.status || 500, error.businessCode);
  }
});

app.get('/v1/cocos-zyx/leaderboards', (req, res) => {
  try {
    const user = authenticate(req, res);
    if (!user) return;
    const type = req.query.type || 'power';
    if (!['power', 'beans'].includes(type)) return fail(res, '不支持该排行榜类型', 400, 'LEADERBOARD_TYPE_UNSUPPORTED');
    ok(res, leaderboard(user, type));
  } catch (error) {
    fail(res, error.message || '读取排行榜失败', 500);
  }
});

/**
 * R0：调试路由只在「非生产环境 + 显式启用」双条件同时满足时注册。
 * 任一条件不满足时路由不存在（404），而不是返回 401/403 暗示接口仍存在；
 * 隐藏客户端按钮不属于安全措施，服务端路由隔离才是最终安全边界。
 * 普通玩家 Bearer Token 不是管理员权限；未来线上 GM 需另立管理员身份与审计。
 */
const gmRoutesEnabled = process.env.NODE_ENV !== 'production' && process.env.ENABLE_GM_ROUTES === '1';

if (gmRoutesEnabled) {
/** GM：把客户端调试后的档案绝对值写回服务端，避免下次 bootstrap/结算覆盖本地发放。 */
app.post('/v1/cocos-zyx/debug/profile', (req, res) => {
  try {
    const user = authenticate(req, res);
    if (!user) return;
    const balance = clampInt(req.body.moodBeanBalance, 0, 100000000);
    const total = Math.max(balance, clampInt(req.body.totalMoodBeans, balance, 100000000));
    const level = req.body.level === undefined ? user.level : clampInt(req.body.level, 1, 1000);
    const experience = req.body.experience === undefined ? user.experience : clampInt(req.body.experience, 0, 100000000);
    const highScore = req.body.highestSingleGameScore === undefined
      ? user.highest_single_game_score
      : clampInt(req.body.highestSingleGameScore, 0, 100000000);
    const updatedAt = now();
    run(
      `UPDATE players SET mood_bean_balance = ?, total_mood_beans = ?,
       level = ?, experience = ?, highest_single_game_score = ?, hammer_count = ?, wand_count = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?`,
      [balance, total, level, experience, highScore, req.body.hammerCount === undefined ? user.hammer_count : clampInt(req.body.hammerCount, 0, 100000), req.body.magicWandCount === undefined ? user.wand_count : clampInt(req.body.magicWandCount, 0, 100000), updatedAt, user.player_id],
    );
    ensurePersisted();
    ok(res, { profile: safeProfile(get('SELECT * FROM players WHERE player_id = ?', [user.player_id])) });
  } catch (error) {
    fail(res, error.message || '调试档案同步失败', 500);
  }
});

/** GM：重置当前账号进度（保留 player_id / device_id / token / 昵称头像）。 */
app.post('/v1/cocos-zyx/debug/reset', (req, res) => {
  try {
    const user = authenticate(req, res);
    if (!user) return;
    const updatedAt = now();
    withTransaction(() => {
      run(
        `UPDATE players SET level = 1, experience = 0, mood_bean_balance = 0,
         total_mood_beans = 0, highest_single_game_score = 0, hammer_count = 0, wand_count = 0, revive_card_count = 0,
         stamina_current = ?, stamina_updated_at = ?, updated_at = ?, asset_revision = asset_revision + 1 WHERE player_id = ?`,
        [economy.STAMINA_MAX, updatedAt, updatedAt, user.player_id],
      );
      run('DELETE FROM round_settlements WHERE player_id = ?', [user.player_id]);
      run('DELETE FROM game_rounds WHERE player_id = ?', [user.player_id]);
      run('DELETE FROM round_checkpoints WHERE player_id = ?', [user.player_id]);
      run('DELETE FROM stamina_share_claims WHERE player_id = ?', [user.player_id]);
      run('DELETE FROM tool_transactions WHERE player_id = ?', [user.player_id]);
    });
    ensurePersisted();
    ok(res, { profile: safeProfile(get('SELECT * FROM players WHERE player_id = ?', [user.player_id])) });
  } catch (error) {
    fail(res, error.message || '重置账号失败', 500);
  }
});
}

app.use((_req, res) => fail(res, '接口不存在或已下线', 404, 'ENDPOINT_NOT_FOUND'));
app.use((error, _req, res, _next) => fail(res, error.type === 'entity.parse.failed' ? '请求 JSON 格式错误' : '请求处理失败', error.status || 500, 'REQUEST_INVALID'));

/** 初始化数据库（可选覆盖路径，供测试使用临时库）并返回可挂载的 app。 */
async function start(overrideDbPath) {
  if (overrideDbPath) dbPath = path.resolve(overrideDbPath);
  const SQL = await initSqlJs();
  db = fs.existsSync(dbPath) ? new SQL.Database(fs.readFileSync(dbPath)) : new SQL.Database();
  migrateSchema(db);
  persistNow();
  return app;
}

if (require.main === module) {
  start().then(() => {
    app.listen(port, () => console.log(`cocos-zyx cloud listening on ${port}`));
  }).catch((error) => {
    console.error(error);
    process.exit(1);
  });
}

module.exports = { app, start };
