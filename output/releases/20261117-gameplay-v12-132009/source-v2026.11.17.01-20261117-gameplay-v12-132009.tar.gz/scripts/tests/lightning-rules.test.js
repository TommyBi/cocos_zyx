const test = require('node:test');
const assert = require('node:assert/strict');
const { default: BoardEngine } = require('../../server/src/boardEngine');
const piece = (id, row, col, size, extra = {}) => ({ id, row, col, size, color: id % 3 + 1,
    stampMood: 1, stampCell: 0, collectibleType: 0, collectibleCell: 0, ...extra });
function board(pieces) { const b = new BoardEngine(); b.resetBoard(742, false, 12); b.pieces = pieces; return b; }
function assertCells(b) {
    const occupied = new Set();
    assert.equal(new Set(b.pieces.map(p => p.id)).size, b.pieces.length);
    for (const p of b.pieces) for (let x = p.col; x < p.col + p.size; x++) {
        assert.ok(x >= 0 && x < 8); const key = `${p.row}:${x}`;
        assert.ok(!occupied.has(key), '碎裂后的单格不得重叠'); occupied.add(key);
    }
}
test('炸弹及重叠连锁消除闪电仍放电一次，光束只命中闭包后的幸存长块', () => {
    const b = board([piece(1, 9, 0, 1, { bomb: true }), piece(2, 8, 0, 1, { lightning: true }),
        piece(3, 8, 1, 1, { bomb: true }), piece(4, 7, 0, 1, { lightning: true }),
        piece(10, 5, 0, 3), piece(11, 4, 4, 4), piece(12, 3, 0, 2), piece(13, 2, 4, 3)]);
    const blast = b.detonateBomb(1), effects = b.takeLightningEffects();
    assert.deepEqual(effects.map(e => e.source.id), [2, 4]);
    assert.equal(effects.flatMap(e => e.targets).length, 4, '两颗闪电不对已拆成单格的长块重复处理');
    assert.equal(new Set(effects.flatMap(e => e.targets.map(t => t.original.id))).size, 4);
    assert.ok(blast.removedPieceIds.includes(2)); assert.ok(blast.removedPieceIds.includes(4));
    assert.equal(b.takeLightningEffects().length, 0); assert.ok(b.pieces.every(p => p.size === 1)); assertCells(b);
});
test('长块拆分保持颜色、占格及唯一表情、收藏物和旧炸弹，不复制奖励', () => {
    const target = piece(21, 6, 2, 3, { stampCell: 2, bomb: true, collectibleType: 7, collectibleCell: 1 });
    const b = board([piece(20, 9, 0, 1, { lightning: true }), target]); b.hammerCount = 1;
    assert.ok(b.useHammer(20)); const [effect] = b.takeLightningEffects();
    assert.equal(effect.targets[0].fragments.length, 3);
    assert.deepEqual(b.pieces.map(p => p.col), [2, 3, 4]);
    assert.equal(b.pieces.filter(p => p.stampMood > 0).length, 1);
    assert.equal(b.pieces.find(p => p.stampMood > 0).col, 4);
    assert.equal(b.pieces.filter(p => p.bomb).length, 1);
    assert.equal(b.pieces.find(p => p.bomb).col, 3);
    assert.equal(b.pieces.filter(p => p.collectibleType > 0).length, 1);
    assert.ok(b.pieces.every(p => p.color === target.color)); assertCells(b);
});
test('魔法棒移除闪电先排除同批被消除目标；没有长块时仍能结束', () => {
    const b = board([piece(1, 9, 0, 1, { lightning: true, color: 1 }), piece(2, 8, 0, 3, { color: 1 }), piece(3, 7, 5, 1, { color: 2 })]);
    b.colorPurifierCount = 1; assert.deepEqual(b.useColorPurifier(1), [1, 2]);
    assert.equal(b.takeLightningEffects()[0].targets.length, 0);
    b.resolveBoard(); b.finishPlayerAction(); assertCells(b);
});
test('连消炸弹避开全部闪电宿主，仅有闪电且无空位时不发炸弹', () => {
    const b = board([piece(50, 9, 0, 1, { lightning: true }), piece(51, 9, 1, 2)]);
    assert.equal(b.awardBomb(2).id, 51); assert.ok(!b.pieces.find(p => p.id === 50).bomb);
    b.pieces = Array.from({ length: 80 }, (_, n) => piece(n + 100, Math.floor(n / 8), n % 8, 1, { lightning: true }));
    assert.equal(b.awardBomb(2), null); assert.ok(b.pieces.every(p => !p.bomb));
});
test('累计按行在20/40行生成，出生保持静止棋盘，不参加自己的出生连锁', () => {
    const b = board([piece(1, 9, 0, 8), piece(2, 8, 0, 8), piece(3, 7, 0, 1)]);
    b.roundClearedRows = 19; b.resolveBoard(); assert.equal(b.roundClearedRows, 21);
    const rewards = b.finishPlayerAction(); assert.equal(b.pieces.filter(p => p.lightning).length, 1);
    assert.ok(rewards.some(p => p.lightning)); assert.equal(b.takeLightningEffects().length, 0);
    assert.equal(b.applyGravity().length, 0, '闪电出生不制造悬空或额外消行');
    assert.ok(b.pieces.filter(p => p.lightning).every(p => !p.bomb && p.size === 1));
    assert.deepEqual(b.finishPlayerAction(), []);
});
test('每类普通救场四次、拒绝计次、独立爱心不占配额，旧V11仍无上限', () => {
    const b = board([piece(1, 3, 0, 1)]); b.score = 501;
    for (let i = 0; i < 8; i++) { assert.ok(b.offerRoundRescue(i * 60000)); b.dismissRoundRescue(); }
    assert.deepEqual(b.rescueOfferCounts, { balloon: 4, clear: 4 }); assert.equal(b.offerRoundRescue(480000), null);
    b.heartRescueEligible = true; b.pieces[0].row = 2; assert.ok(b.offerHeartRescue(480000));
    const old = board([piece(2, 3, 0, 1)]); old.rulesVersion = 11; old.score = 501;
    for (let i = 0; i < 20; i++) { assert.ok(old.offerRoundRescue(i * 60000)); old.dismissRoundRescue(); }
});

test('第40行无普通单格宿主时，闪电完整预告在下一排，当前棋盘保持稳定', () => {
    const b = board([piece(1, 9, 0, 8), piece(2, 8, 0, 3)]);
    b.roundClearedRows = 39; b.resolveBoard(); b.finishPlayerAction();
    assert.equal(b.roundClearedRows, 40);
    assert.equal(b.nextPieces.filter(p => p.lightning).length, 1);
    assert.ok(b.nextPieces.filter(p => p.lightning).every(p => p.size === 1));
    assert.equal(b.applyGravity().length, 0);
    assert.ok(b.appendNextRow()); assert.equal(b.pieces.filter(p => p.lightning).length, 1); assertCells(b);
});
