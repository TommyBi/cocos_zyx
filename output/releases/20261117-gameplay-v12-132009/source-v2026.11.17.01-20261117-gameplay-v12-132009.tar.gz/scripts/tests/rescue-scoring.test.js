const test = require('node:test');
const assert = require('node:assert/strict');
const { default: BoardEngine } = require('../../server/src/boardEngine');
const { replayRound } = require('../../server/src/gameEngine');
const piece = (id, row, col, size = 1, color = 1, bomb = false) =>
    ({ id, row, col, size, color, bomb, stampMood: 0, stampCell: 0, collectibleType: 0, collectibleCell: 0 });

test('V9 道具按实际色块加5分，长块算一块；无目标不加分，V8 保留旧积分', () => {
    for (const version of [8, 9]) {
        const b = new BoardEngine(); b.resetBoard(42, false, version);
        b.pieces = [piece(101, 9, 0, 3), piece(102, 9, 4, 2), piece(103, 8, 0, 1, 2)];
        b.hammerCount = b.colorPurifierCount = 2;
        assert.equal(b.useHammer(101), true);
        assert.equal(b.score, version === 9 ? 5 : 0);
        assert.equal(b.useHammer(101), false);
        assert.deepEqual(b.useColorPurifier(1), [102]);
        assert.equal(b.score, version === 9 ? 10 : 0);
        assert.deepEqual(b.useColorPurifier(1), []);
        assert.equal(b.bestScore, b.score);
    }
});

test('V9 爆炸交叠去重，基础行分和combo照常计算', () => {
    const b = new BoardEngine(); b.combo = 2;
    b.pieces = [piece(1, 9, 0, 3, 1, true), piece(2, 9, 3, 5), piece(3, 8, 2, 1, 1, true)];
    const r = b.eliminateFullRows();
    assert.equal(r.combo, 3);
    assert.equal(r.gainedScore, 10 * 3 + 3 * 5);
    assert.equal(b.score, r.gainedScore);
    assert.equal(b.bestScore, b.score);
});

test('V9 气球即使炸空仍补1排，闪电固定整体补2排；各难度阶段相同', () => {
    for (const kind of ['balloon', 'clear']) for (const actions of [0, 25, 40, 100]) {
        const b = new BoardEngine(); b.resetBoard(42, false);
        b.difficultyActionCount = actions; b.score = 501;
        b.pieces = [piece(101, 3, 0), piece(102, 9, 0)];
        b.random = () => kind === 'balloon' ? 0.25 : 0.75;
        assert.equal(b.offerRoundRescue(0), kind);
        b.pieces[0].row = 8;
        const result = kind === 'balloon' ? b.applyBalloonRescue() : b.applyClearRescue();
        assert.ok(result);
        assert.equal(b.pieces.length, 0);
        assert.equal(b.score, 511);
        const rows = kind === 'balloon' ? 1 : 2;
        assert.equal(b.getRiseRowCount(), rows);
        assert.equal(b.appendTurnRows(), true);
        assert.equal(b.actionAppends, rows);
        assert.deepEqual(b.roundActions.at(-1), { type: 'rise', rows });
        b.resolveBoard(); b.finishPlayerAction();
        assert.ok(b.pieces.some(p => { const range = b.getMoveRange(p.id); return range.min < 0 || range.max > 0; }));
        assert.equal(b.applyBalloonRescue(), null);
        assert.equal(b.applyClearRescue(), null);
    }
});

function replayToOffer(kind) {
    const trace = require('../fixtures/board-v8-' + kind + '-replay.json');
    const b = new BoardEngine(); b.resetBoard(trace.seed, false, 9);
    const lastOffer = trace.actions.filter(a => a.type === 'rescueOffer').at(-1);
    for (const a of trace.actions.slice(1)) {
        switch (a.type) {
            case 'move': assert.ok(b.movePiece(a.id, a.offset)); break;
            case 'bomb': assert.ok(b.detonateBomb(a.id)); break;
            case 'settle': b.applyGravity(); b.eliminateFullRows(); break;
            case 'finish': b.finishPlayerAction(); break;
            case 'rise': assert.ok(b.appendTurnRows()); break;
            case 'append': assert.ok(b.appendNextRow()); break;
            case 'rescueOffer': assert.equal(b.offerRoundRescue(a.elapsedMs), a.kind); break;
            case 'rescueDismiss': b.dismissRoundRescue(); break;
            default: throw new Error(a.type);
        }
        if (a === lastOffer) return b;
    }
    throw new Error('missing rescue');
}

test('V9 真实长局气球/清屏双端积分一致，禁止漏补、重复补、改排数和漏结束', () => {
    for (const kind of ['balloon', 'clear']) {
        const b = replayToOffer(kind), seed = b.roundSeed;
        kind === 'balloon' ? b.applyBalloonRescue() : b.applyClearRescue();
        b.resolveBoard(); b.appendTurnRows(); b.resolveBoard(); b.finishPlayerAction();
        assert.deepEqual(replayRound(seed, false, b.roundActions, 9),
            { valid: true, score: b.score, collectedMoodBeans: b.roundCollectedMoodBeans });
        const rise = b.roundActions.map(a => a.type).lastIndexOf('rise');
        const invalid = actions => assert.equal(replayRound(seed, false, actions, 9).valid, false);
        invalid(b.roundActions.filter((_, i) => i !== rise));
        invalid(b.roundActions.map((a, i) => i === rise ? { type: 'rise', rows: 3 - a.rows } : a));
        invalid([...b.roundActions.slice(0, rise + 1), b.roundActions[rise], ...b.roundActions.slice(rise + 1)]);
        invalid(b.roundActions.slice(0, -1));
        invalid(b.roundActions.map((a, i) => i === rise ? { type: 'append' } : a));
    }
});
