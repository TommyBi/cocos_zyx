"use strict";
cc._RF.push(module, '38274Z6sA9LIKSBWe0xsSzi', 'EditorModule');
// script/merge/dataModule/EditorModule.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.editorModule = void 0;
var DataModule_1 = require("./DataModule");
var EditorModule = /** @class */ (function (_super) {
    __extends(EditorModule, _super);
    function EditorModule() {
        var _this = _super.call(this) || this;
        // 已生成的所有花朵
        _this.flowerList = [];
        // 当前正在选择的花朵id
        _this.curSelectFlowerIdx = -1;
        // 花朵id 逐渐递增，不会随着删除层级和删除花朵减少
        _this.produceCnt = 0;
        return _this;
    }
    EditorModule.prototype.parseData = function (data) {
        _super.prototype.parseData.call(this, data);
    };
    // 获取花朵类型数量
    EditorModule.prototype.getFlowerGroupCnt = function () {
        var typeArr = [];
        this.flowerList.forEach(function (flower) {
            if (typeArr.indexOf(flower.type) === -1) {
                typeArr.push(flower.type);
            }
        });
        return typeArr.length;
    };
    // 当前配置是否合规
    EditorModule.prototype.isOk = function () {
        if (this.flowerList.length % 3 !== 0 || this.flowerList.length < 3)
            return false;
        var flowerType = {};
        for (var i = 0; i < this.flowerList.length; i++) {
            if (flowerType[this.flowerList[i].type] === undefined) {
                flowerType[this.flowerList[i].type] = 1;
            }
            else {
                flowerType[this.flowerList[i].type]++;
            }
        }
        for (var key in flowerType) {
            if (flowerType[key] % 3 !== 0)
                return false;
        }
        return true;
    };
    EditorModule.prototype.getCfg = function () {
        var cfg = {};
        for (var i = 0; i < this.flowerList.length; i++) {
            var flower = this.flowerList[i];
            var flowerCfg = {};
            flowerCfg['type'] = flower.type;
            flowerCfg['layer'] = flower.layer;
            flowerCfg['x'] = flower.node.getPosition().x;
            flowerCfg['y'] = flower.node.getPosition().y;
            if (!cfg["" + flower.layer]) {
                cfg["" + flower.layer] = [];
            }
            cfg["" + flower.layer].push(flowerCfg);
        }
        return JSON.stringify(cfg);
    };
    return EditorModule;
}(DataModule_1.default));
exports.default = EditorModule;
exports.editorModule = new EditorModule();

cc._RF.pop();